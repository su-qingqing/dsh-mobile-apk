# hooks 桥接线样例（1009）—— 怎么启用 ＋ 怎么挂 PostToolUse 钩子

> **一句话**：两个桥包**本体早就在盘上**（它们是 `@deepseek-ai/dsh` 的正式依赖，`dsh/package.json:55-56`），
> 但**我们 profile patch 里一行都没挂**（`grep -i hook cordis.patch.yml` ⇒ 0 命中）⇒ **现在是没启用的**。
> **启用 = 在我们 patch 末尾加一个 `insert` 块 ＋ 准备一个 hooks.json**，**不用装任何包**。
> **PostToolUse 能 block、也能把反馈文字回给模型**——桥产出的正是引擎侧那个 `{kind:'block', feedback, additionalContexts}`（**源码实证**，见 §三）。

**证据等级约定（全文照此标注）**

| 标记 | 含义 |
|---|---|
| **【实证·源码】** | 我读到的 `lib/index.js` / `*.d.ts` 行，带 `文件:行` |
| **【实证·配置】** | 盘上现存的配置文件内容，带 `文件:行` |
| **【推断】** | 我据此推出来的，没有直接行号 |
| **【未验】** | 我没跑过（没挂载、没重启、没跑沙盒）——**如实标注，不当结论说** |

**本次纪律**：只读 ＋ 只写本文件。**没装包、没改任何配置、没重启任何东西**。

**三个包的绝对路径**（下称 `$PKG`）：
```
$PKG = /data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai
$PKG/dsh-hooks-claude-code/   ← 桥①（Claude Code 方言）
$PKG/dsh-hooks-codex/         ← 桥②（Codex 方言）
$PKG/dsh-hook-protocol/       ← 两者共用的「真契约」层（解析/超时/合并都在这）
```
三包版本均 `0.1.5-rc.1`（各自 `package.json`）。

---

## 一、怎么启用（问题 1）

### 1.1 先确认现状（三条，都可当场重跑）

| 判据 | 命令 | 结果 |
|---|---|---|
| 我们的 patch 里有没有 hooks 配置 | `grep -in hook .../profiles/web/cordis.patch.yml` | **0 命中** ⇒ 没启用 |
| 引擎基座两层有没有替我们挂 | `grep -n hook dsh-base/cordis.patch.yml` / `dsh-web-app/cordis.patch.yml` | 基座**没有**这两行（web-app 里唯一命中是注释"useResource hook"） |
| 包本体现在在哪 | `ls $PKG/dsh-hooks-*/` | 在盘上，**是 `@deepseek-ai/dsh` 的 `dependencies`**（`dsh/package.json:30` 起是 dependencies，两包在 `:55`、`:56`） |

⇒ 结论：**包不用装，缺的只是「一行挂载」**。

### 1.2 为什么可以只写名字（先例实证）

我们 patch 里**已经有两行按裸包名挂引擎自带 @deepseek-ai 包**，就是同一条路：

```yaml
# cordis.patch.yml:117-119
- insert:
    - id: picker-native-surface
      name: '@deepseek-ai/dsh-client-ui-directory-picker-native'
# cordis.patch.yml:268-270
- insert:
    - id: agent-default-model
      name: '@deepseek-ai/dsh-agent-default-model'
```
【实证·配置】这两行的目标包，与两个 hooks 包**同在 `$PKG/` 那个目录**（`ls` 四件全 PRESENT）⇒ **同一种解析路径，先例成立**。

### 1.3 逐字可抄的 YAML 片段

**加在哪**：`/data/data/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/cordis.patch.yml` **文件末尾**（现共 313 行，最后一块是 `311-313` 的 `dsh-any-background`；我们 patch 是最外层、最后应用的一层）。

**桥① —— Claude Code 方言（推荐，见 §六）**

```yaml
# ── hooks 桥①（Claude Code 方言）：PostToolUse 出口把关（1009 起）──
# 用途：工具返回后查输出契约／重复调用／失败分级，必要时 block 并把纠正反馈回给模型。
# 说明：configPath 必须指到一个真实存在的文件；读不到＝只 warn、不挂任何钩子（引擎照常起，见 §二.4）。
- insert:
    - id: hooks-claude-code
      name: '@deepseek-ai/dsh-hooks-claude-code'
      config:
        configPath: /data/data/com.dsharnessmobile.shell/files/home/.dsh/hooks/claude-code/hooks.json
        projectDir: /storage/emulated/0/3
        # defaultTimeoutMs: 600000     # 默认值，可省；单位毫秒（见 §四）
        # stderrSummaryMaxChars: 500   # 默认值，可省
        # pluginRoot: /path/to/plugin  # 只在命令里用 ${CLAUDE_PLUGIN_ROOT} 时才需要
```

**桥② —— Codex 方言（想用就照这份）**

```yaml
# ── hooks 桥②（Codex 方言）：同上，但方言不同 —— 二选一，别两个都挂（见 §六）──
- insert:
    - id: hooks-codex
      name: '@deepseek-ai/dsh-hooks-codex'
      config:
        configPath: /data/data/com.dsharnessmobile.shell/files/home/.dsh/hooks/codex/hooks.json
        model: deepseek-v4            # 可选；默认 ''，只盖在 payload 的 model 字段上，不参与判断
```

### 1.4 config 字段与默认值（穷尽表）

**桥①**（`lib/types/index.d.ts:15-40` 接口 ＋ `lib/index.js:115-121` schema）：

| 字段 | 必填 | 默认 | 含义 |
|---|---|---|---|
| `configPath` | **✅ 必填**（`z.string().required()`，index.js:116） | — | `hooks.json`，**或**一个带 `hooks` key 的 settings 文件 |
| `pluginRoot` | ✖ | 无 | 替换命令串里的 `${CLAUDE_PLUGIN_ROOT}`（`index.js:34`、`:82`） |
| `projectDir` | ✖ | 会话工作区（`index.js:168`） | 替换 `${CLAUDE_PROJECT_DIR}` **并**作为 `CLAUDE_PROJECT_DIR` 环境变量传给钩子进程（`index.js:169`） |
| `defaultTimeoutMs` | ✖ | **600000**（`index.d.ts:36`、`index.js:119`） | 钩子自己没写 `timeout` 时的每钩子超时，**毫秒** |
| `stderrSummaryMaxChars` | ✖ | **500**（`index.js:120`） | 写进 `hook/result` 事件的 stderr 摘要上限；必须正整数，否则 apply 抛错（`index.js:133-138`） |

**桥②**（`lib/types/index.d.ts:15-29` ＋ `lib/index.js:103-108`）：同样四个字段，差别只有
`pluginRoot`/`projectDir` **没有**（Codex 不做替换、不给环境），多一个 `model`（默认 `''`，`index.js:105`）。

### 1.5 id 命名建议

* **建议**：`id: hooks-claude-code` ／ `id: hooks-codex` —— 与包名后半段一致，和先例（`picker-native-surface`、`agent-default-model`）的"短 slug"风格一致；
* 想要更明确的从属关系可用 `id: hooks-cc-posttool`（**id 只是行身份，不必等于插件名**——先例 `picker-native-surface` ≠ 包名即是证明，【实证·配置】`cordis.patch.yml:117-119`）；
* ⚠️ **id 一旦被别的层用过，本行会整行覆盖对方的 `config`**（patch 语义，`dsh-web-app/cordis.patch.yml:1-5` 原文："A patch replaces the targeted row's whole `config`"）——**用新 id，别撞**。

### 1.6 启用必须走的流程（**我没有走，也不许我自己走**）

红线 3／4／19：改生产启动路径 ⇒ **先备份** ⇒ **跑沙盒（`真跑.mjs`／干净房间）** ⇒ 装机三步闸门（`check.mjs` → `重复插入.mjs` → `装配树.mjs`）⇒ **他本人手动重启**。
**本次我一行配置都没改**，上面 YAML 只是**样例**；真要落，按那条流程走，并且"没跑过沙盒就得如实说没跑"。

---

## 二、它们读哪个配置文件（问题 2）

### 2.1 答案：**只读 `configPath` 指的那一个文件**，没有目录扫描、没有环境变量、没有默认发现

| 问题 | 答案（实证） |
|---|---|
| 读 `settings.json` 吗？ | **只在你把 `configPath` 指过去时**才读，且读的是它的 `hooks` key（`lib/index.js:56`：`asObject(root.hooks) ?? root`） |
| 有 `hooks/` 目录扫描吗？ | **没有**。进程级单文件（`index.d.ts:19-22` 原文："Process-level: read once at load"，并带 TODO：per-session 发现**尚未实现**） |
| 有环境变量能改它吗？ | **没有**。桥②连环境都不给钩子进程；桥①只**导出**一个 `CLAUDE_PROJECT_DIR`（`index.js:169`），**不读**任何 env 来决定配置位置（两包 `lib/index.js` 里无 `process.env` 用法） |
| 相对路径怎么解析？ | 相对 **进程启动 cwd**（`index.d.ts:19-20`）。**我们的启动 cwd 我没验**【未验】⇒ 样例里一律**写绝对路径** |
| 什么时候读？ | `apply()` 时一次 `readFileSync`（`index.js:142`）⇒ **改 hooks.json 不会热生效，要重启才重读** |

### 2.2 格式：事件 → matcher 组 → 命令钩子

解析器（桥① `index.js:52-101`、桥② `index.js:32-89`）只认这一种形状：

```
{ "<事件名>": [ { "matcher": "<可选>", "hooks": [ { "type":"command", "command":"…", "timeout": <秒> } ] } ] }
```
* 顶层**可包一层** `{"hooks": {…}}`，也**可以直接**就是事件表（`index.js:56` / `:36`）；
* `type` 缺省视为 `"command"`（`index.js:72`）；**非 command 一律跳过并 warn**；
* 桥②另外：`"async": true` **跳过**（`index.js:60-66`）；
* 一条组里所有 `hooks` 都跑，**同事件按配置顺序串行**；
* matcher **空／缺／`*` ＝ 全匹配**（`hook-protocol/lib/index.js:11-13`）。

### 2.3 matcher 语义（**两包不同，这是最容易抄错的地方**）

| | 桥① claude-code | 桥② codex |
|---|---|---|
| 纯 `[A-Za-z0-9_|]+`（如 `bash|read|edit`） | **字面量**，`|`＝精确择一（`hook-protocol/index.js:15,50`） | 当**正则**处理（`index.js:51`） |
| 其它（如 `^bash$`、`.*`、`mcp__.*`） | 正则，**不锚定**（`index.js:51`） | 正则，**不锚定** |
| 匹配对象 | 工具名（PostToolUse/PreToolUse）／会话 source（SessionStart）／`''`（UserPromptSubmit、Stop 忽略 matcher，`index.js:87`） | 同左（`index.js:75`） |
| 正则写坏了 | 配置整体**拒绝加载**（抛 `SyntaxError`，`index.js:89`） | 同左（`index.js:77`） |

### 2.4 配错会怎样（**fail-open，不会把引擎搞崩**）

* 文件读不到／JSON 坏了 ⇒ `ctx.logger.warn(...) — no hooks registered` **并直接 return**，引擎照常启动（桥① `index.js:148-151`；桥② `index.js:130-133`）；
* **⛔ 副作用要记住**：**文件路径写错＝静默没有钩子**（只在引擎日志里一行 warn）⇒ 接线后**必须去日志里确认那行 warn 没出现**。

### 2.5 最小样例（可直接存盘）

**桥① `…/hooks/claude-code/hooks.json`**（settings 形状；裸形状即删掉外层 `hooks`）：
```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "bash|write|edit",
        "hooks": [
          { "type": "command", "command": "node /data/data/com.dsharnessmobile.shell/files/home/.dsh/hooks/claude-code/check.mjs", "timeout": 20 }
        ]
      }
    ]
  }
}
```

**桥② `…/hooks/codex/hooks.json`**（同一形状；注意 `timeout`/`timeoutSec` **秒**，且不许 `async: true`）：
```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "bash|write|edit",
        "hooks": [
          { "type": "command", "command": "node /data/data/com.dsharnessmobile.shell/files/home/.dsh/hooks/codex/check.mjs", "timeout": 20 }
        ]
      }
    ]
  }
}
```
*`matcher: "bash|write|edit"` 在桥①走**字面量择一**、在桥②走**正则**；两种方言下结果一样（因为都是"择一"语义），但含 `.`／`^` 的写法两边含义会分叉。*

---

## 三、PostToolUse 的契约（问题 3）★ 本节是重点

### 3.1 输入：stdin 上一段 JSON（**无命令行参数、无环境传值**）

序列化方式：`JSON.stringify(payload) + 换行`；**桥①带尾换行**（`index.js:188` `trailingNewline: true`），**桥②不带**（桥② `index.js:164` `trailingNewline: false`）。

**桥① payload**（构造于 `lib/index.js:375-383`，base 在 `:347-354`）：

| 字段 | 值 |
|---|---|
| `session_id` | 会话 id（无 agent 时 `""`） |
| `transcript_path` | **恒为 `""`**（这是假字段，别依赖） |
| `cwd` | 会话工作区（`session.header.cwd`） |
| `hook_event_name` | `"PostToolUse"` |
| `tool_name` | 工具名（**matcher 匹配的就是它**） |
| `tool_input` | **工具的真实参数对象**（`exec.arguments`） |
| `tool_use_id` | 本次调用的 id（`exec.callId`） |
| `tool_response` | **工具结果的文本**：只取 `content` 里 `type==='text'` 的块拼接（`blocksToText`，`index.js:344-346`）⇒ **结构化结果被拍平成文本** |

**桥② payload**（`lib/index.js:336-344`）：比桥①多 `model`、`permission_mode:"default"`、`turn_id`；`transcript_path` 恒为 `null`；
**要害差别**：`tool_input` **只能是 `{ "command": "…" }`**（`commandOf()`，`index.js:320-327`）⇒ **非 shell 工具的参数看不到**（README 自陈，`README.zh.md:167-183`）。

### 3.2 输出：退出码 ＋ stdout JSON（**两频道，互斥**）

真契约在共用层 `dsh-hook-protocol/lib/index.js:102-126`（`parseHookOutput`）：

| 退出码 | 含义 | 细节 |
|---|---|---|
| **0** | 正常 | **仅当 stdout 去掉空白后以 `{` 开头**才当 JSON 解析（`:114-124`）；否则原样留作 plain stdout |
| **2** | **阻塞**（block 的经典通道） | `decision='block'`，**reason ＝ stderr 的 trim 结果**（`:110-113`） |
| 其它 | **非阻塞错误** | 只记录；**不 block**（`hook-protocol/lib/types/types.d.ts:55-58`） |
| 没能跑起来 | `exitCode === undefined` | 由 runner 兜成一个 outcome，**不抛、不炸当前轮**（`index.js:205-210`） |

**exit 0 时被认的 JSON 字段**（`applyStructured`，`:133-157`）：

| JSON 字段 | 作用 |
|---|---|
| `decision` | **顶层只认 `"approve"` / `"block"`**；顶层写 `"deny"` 是**非法、被忽略**（`:83-85`，注释明写） |
| `reason` | 顶层原因 |
| `continue` / `stopReason` | 请求停止（桥在 PostToolUse **不消费** `continue`，见下"已延期"） |
| `systemMessage` | **两桥都只 warn、不呈现**（桥①`index.js:193`、桥②`:169`） |
| `hookSpecificOutput.hookEventName` | **必须逐字等于 `"PostToolUse"`**，否则**事件域字段整体丢弃**（`:148`）★ |
| `hookSpecificOutput.permissionDecision` | 只认 `"allow"`/`"deny"`/`"ask"`（`:87-89`） |
| `hookSpecificOutput.permissionDecisionReason` | 原因 |
| `hookSpecificOutput.additionalContext` | **要注入下一轮模型请求的额外上下文** |
| `hookSpecificOutput.updatedInput` | 被解析、**不被采用**（桥打 warn，`index.js:192`） |

**合并规则**（多钩子命中同一事件时，`mergeHookOutputs`，`:249-280`）：权限取**最严**（`deny`|`block`=3 ＞ `ask`=2 ＞ `allow`=1，`:222-240`）⇒ **只要有一个钩子要 block，整点就是 block**；同级 reason 用 `"\n\n"` 拼；`additionalContext` **按顺序累加**。

### 3.3 ★★ 「怎么 block 这个工具结果 ＋ 把反馈回给模型」

**三条路，都通**（源码实证）：

**路 A —— 最简单：`exit 2` ＋ 反馈写 stderr**
```
进程退出码 = 2 ；stderr = 你的反馈文字
```
→ `decision='block'`、`reason=stderr`（`hook-protocol index.js:110-113`）→ rank 3 → 合并后 `decision='deny'`
→ 桥映射成（`dsh-hooks-claude-code/lib/index.js:273-280`，桥②`:253-260` 逐字同形）：

```js
{ kind: 'block',
  feedback: [ { type: 'text', text: merged.reason ?? "blocked by PostToolUse hook" } ],
  additionalContexts: [ /* 仅当同时给了 additionalContext 才有 */ ] }
```
**⚠️ 反馈文字必须写 stderr：exit 2 时 stdout 根本不解析**（`:110-124` 两个分支互斥）——写成 stdout ＝ 反馈丢失，模型只会看到兜底句 `blocked by PostToolUse hook`（codex README 原文点名这句，`README.zh.md:157`）。

**路 B —— 反馈 ＋ 同时附加上下文（唯一能两样都要的路）**：`exit 0` ＋ stdout：
```json
{
  "hookSpecificOutput": {
    "hookEventName": "PostToolUse",
    "permissionDecision": "deny",
    "permissionDecisionReason": "【契约检查】返回值不是 JSON，缺 schemaVersion 字段 —— 请按契约重发，或改用 get_tool 拿全定义。",
    "additionalContext": "本轮累计：第 2 次拿到不符合契约的输出；契约真源＝台账/接续/xxx 契约表。"
  }
}
```

**路 C —— 顶层 decision（更短，但不能带上下文）**：`exit 0` ＋
```json
{ "decision": "block", "reason": "…反馈…" }
```
（顶层只认 `block`／`approve`，`:83-85` 实证。）

**❌ 走不通的两条（别白费力气）**：顶层 `{"decision":"deny"}` 会被**静默忽略**（非法值，`:83-85`）；`{"continue": false}` 在 PostToolUse **不被消费**（两桥 README 的限制章节都点名，桥②`README.zh.md:167-183`）。

### 3.4 桥 → 引擎：**确实透传上去了**（这是你最关心的那一问）

| 层 | 证据 |
|---|---|
| 桥产出 `block` 决策 | 桥①`lib/index.js:273-280` ／ 桥②`lib/index.js:253-260` |
| 引擎侧类型就是它 | `dsh-tools/lib/types/index.d.ts:432-437`：`PostToolDecision` 的 block 分支＝`{ kind:'block'; feedback: ContentBlock[]; additionalContexts?: UserMessage[] }` |
| 挂点签名 | 同上 `:61`：`'tools/post-execute'(exec, result, next): Promise<PostToolDecision>` |
| **引擎怎么用它** | 同上 `:793-799` 原文：`accept` 保留成功结果（可换 content）；**`block` 把结果变成 `isError`，其 content 就是那段 corrective `feedback`**；两种决策都能带 `additionalContexts`；**被 block 时工具自己挂的上下文全部丢弃，只暴露"阻塞决策显式给的那份"** |

⇒ **答**：能。**桥不会把 decision 吃掉**，`feedback` 与 `additionalContexts` 都按引擎契约送达。
【推断】"反馈进 `isError` content"＝模型下一步看到的是**一条错误结果 ＋ 你写的那段话**（`isError` 在工具结果通道里如何呈现，我没有实跑，**属推断**）。

**`additionalContext` 的形态**：两桥都把它包成 `createUserMessage({ content:[{type:'text'}], source:{kind:'plugin', plugin:'hooks-claude-code'|'hooks-codex'} })`（桥①`index.js:206-216,127-131`）⇒ 对模型表现为**一条带来源归因的 user 消息**（README 亦如此描述）。没有 context 时该字段直接省略（`index.js:208`）。

> ❌**已废（v4）· 1015 注**：上面写的 `source:{kind:'plugin', plugin:'hooks-claude-code'|'hooks-codex'}` 是**当时**（1009）的样子；**v4 拒收 `kind:'plugin'`**（真源 `message-sources.ts:9`）。★ 这两条桥是 **DSH 自带件**（不是我们的），**它们现在实际写的是什么要现读，不许拿这份样例当现状** —— 现读法：`grep -n "kind:" <桥的 index.js>`，合法形状应为 `{ kind:'hooks-claude-code' }` 这类**生产者名**。

### 3.5 一次 PostToolUse 里到底跑了几个钩子（自证渠道）

每个钩子跑完会往会话日志写一对事件（`hook-protocol/lib/index.js:316-344`）：
`hook/invoked`（turn/point/dialect/handlerId/matcher）与 `hook/result`（decision/exitCode/stderrSummary/durationMs）。
⇒ **接线后验"到底有没有触发"，去会话日志搜 `hook/result` 就行**，别靠感觉。

---

## 四、超时（问题 4）

| 项 | 值 | 出处 |
|---|---|---|
| 共用层默认 | **`DEFAULT_HOOK_TIMEOUT_MS = 600000`（＝10 分钟）** | `dsh-hook-protocol/lib/index.js:175` |
| 两桥 config 默认 | `defaultTimeoutMs` 默认即上面那个值 | 桥①`index.js:119`／桥②`index.js:106` |
| 单钩子覆盖 | `hooks[].timeout` | 桥①`index.js:83`、桥②`index.js:68` |
| **单位** ★ | **config 里是毫秒；hooks.json 里是「秒」** | 实际换算 `timeoutSec * 1000`：`hook-protocol/index.js:189`；`CommandHook.timeoutSec` 注释原文 "Per-hook timeout in SECONDS (the wire unit)"：`types.d.ts:53-57` |
| 超时后果 | 走 shell 执行器的超时机制（进程组取消）；**不会崩当前轮**（runner 把基础设施拒绝兜成 outcome，`:199-210`） | 同上 |
| stderr 摘要上限 | `stderrSummaryMaxChars` 默认 **500**，超出截断加 `…` | `hook-protocol/index.js:296,306-310` |

**我们这边有一处需要留意**【推断＋未验】：我们的 shell 行是 `shell-termux`（`cordis.patch.yml:7-25`），其中
`timeoutMs: 120000`（`:18`）、`maxTimeoutMs: 600000`（`:19`）。桥通过 `ctx.shell` 跑钩子（`inject` 声明见桥①`index.js:114`）——
**这个 `maxTimeoutMs` 会不会把桥给的超时夹到 600000，我没有验**（没实跑）。实践上建议：**hooks.json 里把 `timeout` 明确写成 10～20 秒**，别依赖 10 分钟的默认值。

---

## 五、包里／README 里有没有现成样例脚本（问题 5）

**答：没有。一个都没有。**（**找不到，不编**）

* **包内文件清单**（`find` 实证）：两包**只有** `LICENSE`、`README.md`、`README.zh.md`、`README.i18n.yaml`、`package.json`、`lib/index.js`、`lib/types/*.d.ts`。
  **没有 `examples/`、没有 `scripts/`、没有任何 `.sh`/`.mjs` 样例钩子**。
* **README 里唯一的代码块**就是"怎么挂载插件"的 YAML（**原文照贴**）：

桥① `dsh-hooks-claude-code/README.zh.md:36-42`：
```yaml
- name: '@deepseek-ai/dsh-hooks-claude-code'
  config:
    configPath: ./.claude/hooks.json
    pluginRoot: ./.claude/plugins/my-plugin
    projectDir: .
```
桥② `dsh-hooks-codex/README.zh.md:36-41`：
```yaml
- name: '@deepseek-ai/dsh-hooks-codex'
  config:
    configPath: ./.codex/hooks.json
    model: deepseek-v4
```
* README 还指向两份文档，**都不在安装包里**（`ls` 实证：`dsh/docs`、`dsh/.agents` 均不存在）⇒ **拿不到**：
  `docs/config-catalog.zh.md`、`.agents/notes/archived/feature/2026-06-30-hook-bridges.md`。

⇒ 所以下面的骨架脚本是**我写的**，**不是包附件**——照抄前按我们自己的规矩审一遍（它是"要进生产的新件"，过四模块耦合四问）。

### 5.1 骨架脚本（我写的 · 走「路 A：exit 2 + stderr」）

`…/.dsh/hooks/claude-code/check.mjs`：
```js
#!/usr/bin/env node
// PostToolUse 检查器骨架（我写的，非包内附件）。
// 契约：stdin = 一行 JSON；反馈写 stderr 并 exit 2 = block；exit 0 且无输出 = 放行。
import { readFileSync, appendFileSync } from 'node:fs';

const raw = await new Promise((res) => {           // 读 stdin（桥① 带尾换行，JSON.parse 容忍）
  let s = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (c) => (s += c));
  process.stdin.on('end', () => res(s));
});

let ev;
try { ev = JSON.parse(raw); } catch { process.exit(0); }   // 读不懂 ⇒ 放行（fail-open）

const tool = ev.tool_name ?? '';
const out  = String(ev.tool_response ?? '');
const LEDGER = '/data/data/com.dsharnessmobile.shell/files/home/.dsh/hooks/claude-code/.seen.jsonl';

// ① 输出契约检查：只对约定过的工具生效，别撒网
if (tool === 'bash' && /^Error:|^\[exit code: [1-9]/.test(out.trim())) {
  process.stderr.write(
    `【工具后检查】${tool} 这次是失败结果（首行：${out.trim().split('\n')[0].slice(0, 120)}）。` +
    `先分诊再继续：同一条路失败两次就停，讲清不通的原因再换路。`
  );
  process.exit(2);                                  // ← 2 = block；反馈必须在 stderr
}

// ② 重复调用：同一 (工具, 参数) 第 2 次起提示去重
const key = tool + ':' + JSON.stringify(ev.tool_input ?? {});
let n = 0;
try { n = readFileSync(LEDGER, 'utf8').split('\n').filter((l) => l.includes(key)).length; } catch {}
appendFileSync(LEDGER, JSON.stringify({ key, t: Date.now() }) + '\n');
if (n >= 2) { process.stderr.write(`【工具后检查】同一调用第 ${n + 1} 次：先复用已有结果，别重跑。`); process.exit(2); }

process.exit(0);                                    // 放行
```

### 5.2 骨架脚本（我写的 · 走「路 B：exit 0 ＋ JSON deny ＋ 上下文」）

```js
// 要"反馈 + 额外上下文"两样都要时 —— 只有这条路能同时给（见 §三.3）
process.stdout.write(JSON.stringify({
  hookSpecificOutput: {
    hookEventName: 'PostToolUse',                   // ★ 必须逐字，否则整块事件域字段被丢
    permissionDecision: 'deny',                     // block 的等价物
    permissionDecisionReason: '【契约检查】输出缺 schemaVersion …',
    additionalContext: '已第 2 次违反输出契约；契约真源＝台账/接续/契约表.md。'
  }
}));
process.exit(0);                                    // ← 注意：这条路必须 0
```

---

## 六、两包差异 ＋ 推荐（问题 6）

### 6.1 机制差异（逐条带出处）

| 维度 | 桥① claude-code | 桥② codex | 出处 |
|---|---|---|---|
| 事件集 | **7 个**：SessionStart／UserPromptSubmit／PreToolUse／PostToolUse／Stop／**SubagentStart**／**SubagentStop** | **5 个**：无 Subagent* | 桥①`index.js:13-21`；桥②`index.d.ts:9` |
| stdin 尾换行 | **有** | **无** | 桥①`:188`；桥②`:164` |
| 命令替换 / 环境 | `${CLAUDE_PLUGIN_ROOT}`、`${CLAUDE_PROJECT_DIR}` 替换；导出 `CLAUDE_PROJECT_DIR` | **都没有** | 桥①`:34-36,169`；桥②`config.d.ts:4` |
| **工具参数完整度** ★ | `tool_input` ＝ **真实参数对象** | `tool_input` ＝ **只有 `{command}`** | 桥①`:371,379`；桥②`:332,340` |
| PreToolUse 审批 | 支持 `ask`（→ `{kind:'ask',reason}`） | **不支持**，只认 deny | 桥①`:259-262`；桥②`:239-243` |
| `continue:false` | PostToolUse 不消费 | 同 | 两桥 README 限制章节 |
| `systemMessage` | warn，不呈现 | warn，不呈现 | 桥①`:193`；桥②`:169` |
| `updatedInput` | 解析但不采用 | 不解析 | 桥①`:192` |
| plain stdout 当上下文 | **不**（只有 JSON 通道） | SessionStart／UserPromptSubmit **是**；PostToolUse **不是** | 桥②`:167,202,220` |
| async 钩子 | 无此概念 | `async:true` 跳过 | 桥②`:60-66` |
| PostToolUse 的 block 反馈 | ✅ 同形 | ✅ 同形 | 桥①`:273-280`；桥②`:253-260` |

### 6.2 推荐：**用桥①（claude-code）**

**理由三条（都冲着我们要做的活）**：

1. **要看工具返回、还要判"重复调用"⇒ 必须看得见参数**。桥②的 `tool_input` 被压成 `{command}`（`index.js:320-327`）——
   `read`／`write`／`edit`／`get_tool` 这些非 shell 工具的参数**它根本拿不到**，判"重复调用"就废了一半。桥①给的是真参数对象（`:371,379`）。
2. **要"分级"就迟早要 `ask`**（可疑但不想直接 block ⇒ 让他看一眼）。桥②把 `ask` 忽略掉了（`:239-243`），桥①支持（`:259-262`）。
3. **脚本路径与工作区要稳**：桥①有 `${CLAUDE_PLUGIN_ROOT}`／`${CLAUDE_PROJECT_DIR}` 替换 ＋ 导出 `CLAUDE_PROJECT_DIR`（`:34-36,169`），
   脚本不用写死绝对路径；桥②什么都没有。

**什么时候反过来选桥②**：只有当你要**复用现成的 Codex `hooks.json`**（不想改人家的方言），或者**故意要"看不到参数"的窄面**——否则别选。
**两桥 PostToolUse 的 block 语义完全一样**（`:273-280` vs `:253-260`），所以"能不能 block"**不是**选择依据，**参数完整度**才是。

**一句诚实补充**：两包 README 自己都写着"这是一层兼容适配器，想去定制行为请写原生插件"（桥②`README.zh.md:32`）。
我们要做的"契约检查／去重／失败分级"如果**越做越复杂**，**原生插件挂在同一个 `tools/post-execute` 点上是更直的**（那正是这个挂点的原生接口，`dsh-tools/.../index.d.ts:61,432-437`）。
现在这版接线**够用且成本最低**（零安装、一行挂载）；"该不该升级成原生插件"建议等这套规则真跑起来、看它长多大再判。

---

## 七、把这套接起来时，别忘的四条（工程侧提醒）

1. **钩子逻辑放脚本里，配置只放一行 `configPath`** —— 因为 `configPath` 是**进程启动时读一次**（§二.1 实证），
   挂钩子时改配置要重启；而**改脚本内容不用重启**（脚本每次调用现读）。这条正好绕开"动不动就得重启引擎"。
2. **feedback 走 stderr**（路 A）——最容易抄错的一条，见 §三.3 ⚠️。
3. **`hookEventName` 必须逐字 `"PostToolUse"`** —— 否则 JSON 里事件域字段**整块被丢**（`:148`），你会得到一个"看起来没生效"的谜。
4. **接线后两个自证渠道**：① 引擎日志里**不该**出现 `could not load hook config ... — no hooks registered`（§二.4）；
   ② 会话日志里**该**出现 `hook/result` 事件对（§3.5）。**两个都没有 ⇒ 等于没接上**。

---

## 八、我没验的（诚实边界 · 逐条）

| # | 未验项 | 影响 |
|---|---|---|
| 1 | **没跑沙盒、没挂载、没重启** —— 本文件里所有 YAML 都**没落到生产** | §一 的片段是"照抄源"，不是"已验证的接线" |
| 2 | **引擎进程的启动 cwd** 没查 ⇒ 相对 `configPath` 会不会指偏**不知道** | 所以样例里一律用**绝对路径** |
| 3 | **`shell-termux` 的 `maxTimeoutMs: 600000`** 是否夹住桥的超时：**没验** | 建议 hooks.json 里显式写 10~20 秒，别吃 10 分钟默认值 |
| 4 | 引擎把 `feedback` 变成 `isError` 之后**具体怎么呈现给模型**：读的是 `.d.ts` 文档（`:793-799`），**没实跑** | 属**推断**，不是实测 |
| 5 | 两桥 README 指向的 `docs/config-catalog.zh.md`、`.agents/notes/...` **不在安装包里**，我没别的来源 | **找不到就写找不到**，没有替它编内容 |
| 6 | `ctx.shell` 到底是不是 `shell-termux` 那件提供的 | **推断**（依据：我们的 patch 挂了该行；桥 `inject` 要 `shell`） |

**本文件产出于**：只读研究（读 3 个包的 `lib/index.js`、`*.d.ts`、README ＋ 我们的 patch）。**没装包、没改配置、没重启。**
