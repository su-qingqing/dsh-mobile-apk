# 交件 ② · 1017 · Cordis 家族专项 diff（你 §4 要的那件事）

> 〔电脑侧 · 优化者〕→ 苏青青
> 你原话：「diff Cordis 本体时，请**专门看 `waterfall` 那一段的派发逻辑**」
> 我照办了，而且**顺手把整个 Cordis 家族都过了一遍** —— 结果和你担心的**不是一个地方**，
> 反而**撞上了你 §4 需求单里 C 档「我们怀疑在客户端 loader 的『上下文导出』那一段」**。
> 全部读数为 npm 真包逐文件 SHA256 比对，**不是提交信息**。

---

## §1 先回答你问的那一条：**waterfall 派发逻辑没变，一个字都没动**

| 包 | 旧 | 新 | 32 文件里变了几个 | 变的是哪些 |
|---|---|---|---|---|
| **`@deepseek-ai/cordis`** | `4.0.4` | `4.0.5-alpha.2` | **1 个** | **只有 `package.json`** |
| **`@deepseek-ai/cosmokit`** | `1.8.5` | `1.8.6-alpha.2` | **1 个** | **只有 `package.json` 的版本字符串** |

- **`cordis/lib/index.js` 哈希完全相同** —— `dispatch()` / `waterfall()` / `next()` 的语义、arity 处理**逐字节未变**；
- `cosmokit` 25 个文件里 24 个哈希相同，唯一不同的 `package.json` **差异只有一行 `"version"`**（连依赖范围都没动）。

⇒ **你对 A6 的担心，在这一条上是「没事」**，而且是**可复算的没事**：
```sh
# 你那边若有 alpha 包，可自己核
sha256sum .../cordis-4.0.4/package/lib/index.js .../cordis-4.0.5-alpha.2/package/lib/index.js
```

**另外报你一个你可能想知道的事实**：`@deepseek-ai/cordis` 已经发了 **`4.0.5` 正式版**（不是 alpha）。
dsh alpha.5 钉的是 `~4.0.5-alpha.2` —— 也就是说**上游自己还在 alpha 轨道上**，
和你文档 N54 引的那句 `docs(cordis): plan the staged rc.11 vendor upgrade`（它也没升完）对得上。

---

## §2 但整个家族里**有一个包真的改了代码** —— 而且正好是 P1 那一处

家族共 4 个包，逐个比完是这样：

| 包 | 变了几个文件 | 有代码改动吗 |
|---|---|---|
| `cordis` `4.0.4 → 4.0.5-alpha.2` | 1 / 32 | ❌ 只有 package.json |
| `cosmokit` `1.8.5 → 1.8.6-alpha.2` | 1 / 25 | ❌ 只有版本号 |
| `cordis-plugin-include` `1.0.9 → 1.0.10-alpha.2` | 1 / 7 | ❌ 只有 package.json |
| **`cordis-plugin-loader`** `1.0.5 → 1.0.6-alpha.2` | **6 / 28** | ✅ **真的改了** |

### 改了什么：`src/config/entry.ts`（236 → 239 行）

```diff
- let exports: any
-   exports = await this.parent.tree.import(this.options.name, this.getOuterStack)
- const plugin = this.loader.unwrapExports(exports)
+ /** Raw import result before export normalization; HMR updates it after a successful reload. */
+ public moduleNamespace: unknown
+   let moduleNamespace: unknown
+     moduleNamespace = await this.parent.tree.import(this.options.name, this.getOuterStack)
+ const plugin = this.loader.unwrapExports(moduleNamespace)
+ this.moduleNamespace = moduleNamespace
```

编译产物 `lib/index.js` 同步改了（672 → 675 行，9 行差异）。

### 为什么这条**直冲 P1**（而不是我硬凑）

1. **名字对上了**：你们现场那句报错是 **`requires-upstream-loader-context-export`** ——
   字面就是「**要求上游 loader 把 context 导出**」。
   而这个改动做的正是：**把 `unwrapExports()` 之前那个原始模块命名空间留下来**（`moduleNamespace`），
   以前它是**函数内局部变量，用完即弃**；现在变成 **entry 上的公开字段**。
   ⇒ **"loader 把模块命名空间导出来"** —— 这就是那句报错的字面诉求。
2. **注释自己说了用途**：`HMR updates it after a successful reload` ——
   和 N14／P2（改插件不用重启）是**同一处机制**。**P1 与 P2 共用一个改动**，这解释了你
   需求单 §3 里「第一档 · 直冲 P1／P2（同一部位）」为什么能放在一起。
3. **文件对上了**：`cordis-plugin-loader` 就是**装配器**（`tree.import` 的调用方），
   而你需求单 §2 P1 描述的是「**引擎判 `client-plugin-tree-failed`**」—— **树的装配就在这个包里**。

⚠️ **我把话停在证据边界上**：这**是一条高度吻合的候选根因**，不是"我复现了"。
真正的判定还是那句 —— **J9 真跑**。我没有在你机上跑过任何东西。

**但这一条足以回答需求单 §4 C 档**：你们怀疑的那一处，**方向是对的，而且能指到行**。

---

## §3 针对你 §4 的请求，我给一条可执行的验证法（不用等升级）

你原话：「看有没有改 `next()` 的语义 / arity 的处理」—— **答案：没改**（§1）。
所以 A6 那条**可以暂时从"升级风险"里划掉**，把注意力挪到 §2 这个 loader 改动上。

如果你想把 §2 坐实到"它到底解不解 P1"，我给你一条**不依赖升级**的办法：
在 alpha.5 里把 `cordis-plugin-loader` 的 `moduleNamespace` 取值处**加一行日志**，
看页面侧 loader 到底读没读它 —— 若读了，`requires-upstream-loader-context-export` 就应当消失。
（这条我**没做**，只是给法；要不要做、什么时候做，你定。）

---

## §4 我这一件的诚实边界

- 只读 npm 公开包，**没碰你平板上的任何东西**（连只读都只用了 `/sdcard` 与本次拉包）；
- **没跑** J9；**没跑**升级；
- §2 的因果链是**我按证据推的**（名字吻合 + 注释自证 + 文件职责吻合），**不是我复现的**；
- 我没读 alpha.5 里 `dsh-client-modules` 删除 `invariant.js` 后**替代它的是什么** —— 那是下一件，
  你要我先做我就先做。

---

_电脑侧 · DSH desktop ｜ 2026-10-17 ｜ 信箱：`/sdcard/3/_tmp/电脑侧信箱/`_
