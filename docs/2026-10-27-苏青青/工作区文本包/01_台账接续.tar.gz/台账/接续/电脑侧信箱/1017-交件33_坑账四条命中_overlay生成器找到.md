# 交件33 · ★★★ 坑账里直接命中批1 的四条：**overlay 生成器找到了**（坑 #41）；`assets/patched/` 的升级危害（坑 #38）

> **给**：苏青青（平板） ｜ **写自**：电脑侧 ｜ 2026-10-17
> 来源：`docs/AGENTS/gotchas.md`（296,619 B）。我按"引擎升级／追上游／overlay／pi-ai"筛过，**四条直接命中**。

---

## 一、★★★ 坑 #41 —— **我找了五轮的 overlay 生成器，在这里**

**原文（摘）：**
> **overlay 登记表漏项（primitives 缺失 rc.1 升级）**：`engine-overlay.json` **生成自 research 的 196 包清单为主循环**——`@deepseek-ai/dsh-client-ui-primitives` 在旧树但不在清单 → 未覆盖留在 rc.2。
> **修复/约定**：**登记表必须与基座树全量对账**（**`.tmp-upgrade/audit-manifest.mjs`**：`base-nm-paths` 逐包 vs `manifest ∖ keepUnpublished`，未覆盖即查 npm）；发现 npm 有新版即补登记/抓 tgz。grep `audit-manifest`。

**⇒ 三条结论：**
1. **overlay 确实是"生成"的**——**主循环是 research 的 196 包清单**；
2. **它有一个对账工具：`.tmp-upgrade/audit-manifest.mjs`**，职责是 **`base-nm-paths` 逐包 vs `manifest ∖ keepUnpublished`，未覆盖即查 npm** —— **这正是我算不出的 `vendorTop` 那一块**；
3. **它的对账对象是"基座树"** ⇒ **证实了我交件29／31 的判断：`packages`/`vendorTop` 的完备性依赖基座，没有基座算不出来。**

**⇒ 所以我要问你的那件事有确切名字了**：**平板上有没有 `.tmp-upgrade/audit-manifest.mjs`（或它已并入哪个脚本）？**
（`.tmp-upgrade/` 名字像临时目录，**很可能不在 `调研/` 或 `工具/` 里**，请在全盘找一下。）

---

## 二、★★★ 坑 #38 —— **`assets/patched/` 的升级危害（这条直接管我交件13/14 那批活）**

**原文（摘）：**
> **rc.2 锁定型运行时补丁在引擎升级时抹掉新引擎代码**（0.13.3 模拟器实锤，prompt 链阻断）：
> `assets/patched` 的 `session-persistence-jsonl`/`attachment-local` 等是 **0.1.1-rc.2 原版整文件（无 delta）**，0.1.2-rc.1 引擎启动前 `applyRuntimePatches` **整文件覆盖** → **新代码被旧版回退**（`persistence.borrowSession is not a function` → 一切会话写入/发送全断）。
> **修复/约定**：**升级引擎时逐补丁核对上游是否原生覆盖**（能退役则退役——`fs-local/primitives` 已退役）；**重出 asset 必须从新版本包文件改起**（RUNTIME-PATCHES.md §3-2）；本次重出 SPJ/ATT 的**最小 delta = `link(2)` 失败 EACCES/EPERM/ENOTSUP → rename 回退**。grep `borrowSession`。

**⇒ 这解释了我交件13 那三个 `assets/patched/` 文件的**性质**：它们不是"补丁"，是「**锁定型整文件覆盖**」，而它们的**版本是钉死的** ⇒ **引擎升级时会把新代码覆盖回旧版**。**

**⇒ 与我实测的对账：**
| 文件 | 我交件14 的 1-A 重放结果 |
|---|---|
| `attachment-local-index.js` | **逐字节复现** ✓ |
| `fs-local-index.js` | **逐字节复现** ✓ |
| `session-persistence-jsonl-index.js` | 不重现 —— **我判"正确，因为 alpha.5 上游改了这个包"** |

**而坑 #38 的约定正是我在做的方向**：「**升级引擎时逐补丁核对上游是否原生覆盖（能退役则退役）**」＋「**重出 asset 必须从新版本包文件改起**」。

### ★ 一处我要跟你核对的矛盾
坑 #38 说「**`fs-local`/`primitives` 已退役**」，**但 APK 的 `assets/patched/` 里 `fs-local-index.js` 在（47,826 B）**。
两种可能：① 坑 #38 记的是 0.13.3 的状态，**之后又重出了**；② 它说的"退役"指别的东西。
**⇒ 请你核一下：当前这版 `assets/patched/fs-local-index.js` 是"仍有必要的重出版"，还是"该退役却没清掉的残留"。**
**这件事对 alpha.5 有直接影响**：若它是残留，**升级时它会拿旧代码覆盖新引擎**——正是坑 #38 描述的事故。

---

## 三、★ 坑 #16 —— 第三处 `assets/patched/`，以及"升级要同步哈希"

> **老内核 ES2022 polyfill（issue apk#81/#79）**：华为/荣耀/小米定制 WebView（**Chromium<92**）缺 `Object.hasOwn`/`Array.at`/`String.at` → 前端加载插件报 "Failed to load plugins"。
> polyfill 注入点 = **`assets/patched/web-frontend-index.html`** `<head>` 首个 script 之前；**升级 dsh 后其模块脚本哈希（`index-ClqxG24t.js`）须同步更新**。

**⇒ 又一处 `assets/patched/`（共三处器物：两个 js + 一个 html），而且明写「升级后哈希须同步更新」。**

**★ 这与我交件30 的发现连上了**：坑 #16 说的 **Chromium<92 缺 `Object.hasOwn`/`Array.at`**，与语法下限门禁的 **`chrome87` 口径**是**同一类关切的两个面**（一个是**运行时 API** 缺，一个是**语法**不认）。**⇒ "老内核"这条线在你们账上是成体系的，不是零散补丁。**

---

## 四、★ 坑 #43 —— 白屏的那条，与 P1 同族

> **AppFrame 白屏静默挂起：create 循环 + rc.1 session-scope 严格绑定**（0.13.3，两轮定位，已修）
> 真因在 mount 后的 **React 渲染错误**：`Error: strict session slot 'details' rendered without a scope binding`
> **⇒ React 渲染错误不变量进 `Runtime.consoleAPICalled`（error boundary 前抛出）→ 零 console 静默白屏。**

**★ 定位方法论（它自己写的，可复用）**：
1. `Runtime.consoleAPICalled` **必须先发 `Runtime.enable`** 才投递——
   **没 enable 时「零 console」是探针假象**（**这正是本坑第一轮误判"静默"的根因之一**）；
2. 设备侧 python 给 minified bundle 插桩（boot await 链插 `console.log`）→ push + `run-as`（带全套引擎 env）→ 重启引擎 → CDP reload 读日志；
3. **服务器内存 serve**：combo bundle 从 flush 时内存 responses 出（非磁盘直读）⇒ **改 dist 文件后必须重启引擎**才生效。

**⇒ 这三条对 P1 直接有用。特别是第 1 条**：老板那边 P1 探针"看不到输出"的现场，**要先排除"没 enable"这个假象**。

---

## 五、我要问你的两件

1. **`.tmp-upgrade/audit-manifest.mjs` 在不在平板上？**（在 ⇒ 我就能拿到 overlay 的正式生成/对账逻辑，`vendorTop` 那块不再是黑盒）
2. **`assets/patched/fs-local-index.js` 是"仍有必要的重出版"还是"该退役的残留"？**（坑 #38 说 fs-local 已退役，但 APK 里有它）

---

## 六、诚实边界

- **已实测/已读**：`gotchas.md` 全文的**关键词计数**（overlay 35 行／engine-overlay 13 行／pi-ai 5 行／引擎升级 2 行／追上游 2 行）与**上述四条的原文**（我只精读了这四条）。
- **★ 我 grep 的是关键词，不是读完了 296 KB** ⇒ **可能还有命中的条目我没看到**。我下一步会按"坑号"系统扫（尤其 `borrowSession`／`audit-manifest`／`rebuild-runtime-patches` 这三个 grep 锚）。
- **没核**：坑 #38 与 APK 里 `assets/patched/fs-local-index.js` 的矛盾**我没有独立判据**，所以我是**把矛盾报给你**而不是给结论。
- **没跑**：`audit-manifest.mjs` 我连文件都还没见到。
- **平板侧一个字没动**（`cordis.patch.yml` 仍 61,175 B / 2026-10-15 08:25）。

_电脑侧 · 2026-10-17_
