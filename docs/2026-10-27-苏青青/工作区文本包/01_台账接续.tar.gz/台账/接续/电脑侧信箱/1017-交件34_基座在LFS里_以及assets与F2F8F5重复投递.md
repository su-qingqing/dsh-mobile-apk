# 交件34 · ★★★ 基座在 git LFS 里（批1 缺的那件料，坑账给了确切命令）；以及 `assets/patched/` 与 F2/F8/F5 的**重复投递**

> **给**：苏青青（平板） ｜ **写自**：电脑侧 ｜ 2026-10-17
> 系统扫了 `gotchas.md`（296 KB）。两个发现改变了批1 与批2 的局面。

---

## 一、★★★ 批1 缺的那件料：**基座在仓库的 git LFS 里**

坑账（L1444）原文：
> **修法**：CI checkout 使用 `lfs: false`，**快照 job 只按 ABI `git lfs pull --include="base/base-usr-<abi>.tar.xz,base/base-dsh.tar.xz"`**，并以 pointer 文件哈希为缓存键；不消费底座……

**⇒ 所以我交件27／29／31 反复说的"缺基座"，缺的是一份**在仓库 `base/` 目录、由 LFS 管着**的文件：**
```
base/base-usr-arm64.tar.xz
base/base-usr-x86_64.tar.xz
base/base-dsh.tar.xz
```
**取法就是它自己给的那句：`git lfs pull --include="base/base-usr-<abi>.tar.xz,base/base-dsh.tar.xz"`**

**★ 这条对你的意义**：**批1 的"电脑侧不能跑构建器"这个边界，可能不是原理上的，而是"那三个 LFS 文件没在这台平板上"。** 若那个仓在别处能取到，**这台机器上就可能真跑一次 `build-snapshot-013.mjs`。**

---

## 二、★★★ `assets/patched/` 那三个文件，与三条引擎补丁是**同一件事**

我核准了 APK 的实际内容（`assets/patched/` 恰好 3 个）：

| `assets/patched/` 文件 | 大小 | 对应的**引擎补丁**（我交件27 实测其在 alpha.5 上的结果） |
|---|---|---|
| `attachment-local-index.js` | 47,937 B | **`attach-durable-F2`** → `[ok] applied` ✓ |
| `fs-local-index.js` | 47,826 B | **`fs-local-link-F8`** → `[ok] applied` ✓ |
| `session-persistence-jsonl-index.js` | 145,247 B | **`spj-migration-link-F5`** → `[ok] applied` ✓ |

**而坑 #38 明写：这三个（跑 `applyRuntimePatches`）是「锁定型整文件覆盖」，**引擎升级时会把新代码覆盖回旧版**，并且**真出过事故**（`borrowSession is not a function`，会话写入全断）。**

**⇒ 于是有一个很重的推论：**
- **同一批修复被投递了两次**：一次是**构建期**的登记表补丁（F2／F8／F5，**从新版包文件改起**），一次是**运行期**的整文件资产（**版本钉死**）；
- **构建期那份会随版本更新，运行期那份不会** —— **⇒ 运行期那份在升级时就是在往回退。**

### ★ 而我的实测支持"可以退役"
**F2／F8／F5 三条在 alpha.5 上都 `[ok] applied`**（交件27／28／34 的输出）。
**⇒ 若快照侧已经带了这些修复，运行期资产就是重复的、且是有害的重复。**

### ★ 但我不下定论，把两种情况都摆出来
- **(a) 冗余**：资产是 0.13.7 时代的历史遗留（那时快到还没进登记表），**现在应当退役**；
- **(b) 另有用途**：资产作用于**用户设备上已解包的运行树**（例如热推/OTA、或对旧快照的补救），**构建期补丁盖不到那种场景**。

**⇒ 请你判：这三个资产在 alpha.5 的构建里是"该退役"还是"该重出"。**
（坑 #38 的约定原话是「**升级引擎时逐补丁核对上游是否原生覆盖（能退役则退役）**」＋**「要么不写，要么写就得随每次引擎升级核对」**——**所以这本来就是每次升级必须逐条裁的事**。）

### ★ 一处我核过的细节（给出可比对的事实）
坑账另一处（L116）说：**0.13.7fx-1 直接退役 `web-frontend-index.html`**（RUNTIME-PATCHES §8）。
**我查了 APK：`assets/patched/` 里没有它** ⇒ **与"已退役"一致 ✓**。**⇒ 说明"退役"是会真的从 APK 里消失的，可以当作判据。**

---

## 三、★★ 批2 的核心隐患（坑 #36，原文摘）

> 本仓库是**云端自包含构建宿主**（`.github/workflows/build-apk.yml` 依赖 `$GITHUB_WORKSPACE`=本仓库，**不签协调私库**），仓库内自带整套**子仓副本**（`dsh-shell-termux`、`dsh-client-ui-responsive`、`dsh-host-web-compat`、`plugins/dsh-android-*`）。**协调仓改动这些子仓的源码或 bump 版本后，必须把产物同步进本仓库对应子目录（`src` + `package.json` + `lib/`），否则自包含链注入的是旧副本**——设备上表现「悬浮球开关消失／ADB 面板缺失／#120 拒绝信号缺失／配置导入导出按钮消失」这类**功能性缺失但编译通过**的幽灵缺陷。
> **0.13.2 实测**：协调仓 `ui-responsive` **0.1.11** vs apk 仓副本 **0.1.9**（DevSection 少了 W7 悬浮球开关行 + 配置导入导出块）；`host-web-compat` **0.1.8 vs 0.1.6**。
> **教训**：凡协调仓动了这三个独立子仓，发布前**必须比对两个仓库的 `package.json` version ＋ 抠验 apk 仓副本 `lib/client.js` 关键字符串（如「悬浮球」）**，不一致即 `robocopy` 同步。**⇒ `lib/` 必须一并抠入——自包含链不对这些子仓执行 `npm build`。**

**⇒ 这条对目标 ③（`ui-responsive` 重编到 alpha.5）是决定性的：**
1. **`ui-responsive` 在本仓与协调仓各有一份**，本次要动的是**协调仓那一份**；
2. **产物必须同步进本仓的对应子目录（`src` + `package.json` + `lib/`）**；
3. **★ 自包含链不跑 `npm build`** ⇒ **`lib/` 得由你（或协调仓那边）产出后抠进来**，不能指望构建时生成；
4. **失败形态是"编译通过、功能缺失"** ⇒ 不会在构建期报错，**只能靠比对 `package.json` 版本 + `lib/client.js` 关键字符串**。

**★ 又问出**：`ui-responsive` 重编到 alpha.5 后，**新的 `lib/client.js` 关键字符串**取哪几个当判据？（坑 #36 用的是「悬浮球」；我这边也可以拿语法下限门禁的 `--scan` 兜底——它认 `lib/client.js` 这个路径。）

---

## 四、另外两条零星（都记下来）

- **L125**：「**0.13.7 追上游 0.1.5 后，运行期 asset `session-persistence-jsonl-index.js` 只给 `materialize` 路径**」 ⇒ **这是 SPJ 资产当前的"最小 delta"约定**（交件33 里我说它的 delta 是 link→rename；**这两条要给到一起看**）。
- **`SKIP_LIMIT`／`DSH_MOBILE_ASSEMBLED_MANIFEST`／`SHIPPED_PLUGIN` 在坑账里 0 命中** ⇒ 这三套机制（你答过的那部分）**不在坑账里**，应当记在别处。

---

## 五、诚实边界

- **已实测**：APK `assets/patched/` 的**实际条目与字节数**（3 个 ＋ `undo-emergency.mjs`；**`web-frontend-index.html` 不在**）；`assets/` 顶层条目；坑账里 12 个关键词的**逐行命中位置**。
- **★ 关键推论我没实测**：**"这三个资产可以退役"是我的推论，不是验证过的结论。** 我只实测了「F2/F8/F5 在 alpha.5 上锚命中」，**没有实测"退役后引擎行为不变"**。**⇒ 我把它作为**待你裁的问题**，不是建议。**
- **没做**：没去取那三个 LFS 文件（不在本机）；没读 `RUNTIME-PATCHES.md §8`（退役记录那份）；`gotchas.md` 我仍是**关键词命中式地读**，**没有逐坑通读 296 KB**（`ui-responsive` 那 7 行我只精读了 4 条）。
- **平板侧一个字没动**（`cordis.patch.yml` 仍 61,175 B / 2026-10-15 08:25）。

_电脑侧 · 2026-10-17_
