# 交件36 · ★★★ 批1 的目标环境定案：**GitHub Actions `ubuntu-latest`**（不是本机）；而他们**已有**防"LFS 指针冒充"的门禁

> **给**：苏青青（平板） ｜ **写自**：电脑侧 ｜ 2026-10-17
> 上一轮我取到了基座。这一轮我查"在哪台机器上跑构建器"，答案是：**不在本机，在云端 —— 而且那条路是全自动的。**

---

## 一、★ 本机跑不了（已实测，不是猜测）

`scripts/lib/shell.mjs` 第 13 行：
```js
export const IS_WSL_HOST = process.platform === 'win32'
```

**⇒ 在 Windows 上它是**硬编码为 true** 的，与"WSL 有没有装"无关。**
**⇒ 即使设 `DSH_NO_WSL_REEXEC=1`（那只跳过"把自己重入 WSL"那一步），脚本里每一个 `wsl(...)` 调用仍会去执行 `wsl.exe`。**

**我实测了本机 WSL：`wsl.exe` 在（`C:\windows\system32\wsl.exe`），但 `wsl -l -v` 只回版权＋用法、exit=1 ⇒ 没有装任何发行版。**
**⇒ 逐条 `wsl(...)` 步骤必失败 ⇒ `build-snapshot-013.mjs` 在本机跑不了。**

**★ 而构建器自己的头注释写明了它的**两种**宿主**：
> 让同一份构建脚本既能本地跑（**Windows + WSL，走 wsl.exe**），又能云端跑（**GHA ubuntu，原生 Linux bash**）

---

## 二、★★★ 目标环境：`ubuntu-latest`，而且那条路是**全自动**的

`/sdcard/3/调研/_外部源码/dsh-mobile-apk/.github/workflows/build-apk.yml`（6,732 B）：
```
L42: runs-on: ubuntu-latest
L51: # 每个 ABI job 只需要本 ABI 的 base-usr 与共用 base-dsh；先缓存，未命中才按路径拉取。
L52: # checkout 的 lfs:true 是按 ref fetch，不能从 fetch-depth:0 推断它会下载历史全部 LFS。
L53: - name: 检出本仓库（不含 LFS 归档；底座下方按需拉取）
L58:   lfs: false
L59: - name: 缓存底座归档（命中则跳过 LFS 拉取）
L64:   key: lfsbase-${{ matrix.abi }}-${{ hashFiles('base/base-dsh.tar.xz', 'base/base-usr-<abi>.tar.xz') }}
L65: - name: 按需拉取 LFS 底座（仅本 ABI，未命中缓存时）
L70:   git lfs install --local
L71:   git lfs pull --include="base/base-usr-${{ matrix.abi }}.tar.xz,base/base-dsh.tar.xz"
L72: - name: 断言底座确实已落地（拒绝 LFS pointer 冒充文件）
L76:   node scripts/require-lfs-materialized.mjs \
L77:     "base/base-usr-${{ matrix.abi }}.tar.xz" "base/base-dsh.tar.xz"
L108: # build-snapshot-013.mjs 的 BASE_DIR：arm64 -> arm64-base；x86_64 -> x64-base（缩写，勿写 x86_64-base）
```

### ★★★ 三条要点
1. **构建在 `ubuntu-latest` 上做**，`git lfs pull --include=` 只拉**本 ABI 的 base-usr ＋ 共用 base-dsh**（**正是我上一轮取的那两个**）；
2. **★★ 他们有一道专门的门禁**：`scripts/require-lfs-materialized.mjs` —— **「断言底座确实已落地（拒绝 LFS pointer 冒充文件）」**。
   **⇒ 我上一轮发现的那个"133 字节指针冒充基座"的问题，**他们的 CI 早就防着**——但那道门**只在 CI 里**；平板／本地的指针文件**没人拦**。**
   **★ 这解释了一件事**：CI 上这个坑被门禁挡住，所以**从没在云端复发**；而**"在平板上直接跑"这条路没有这道门**，于是指针一直躺在那儿没人发现。
3. **`BASE_DIR` 的命名**：`arm64 -> arm64-base`、`x86_64 -> x64-base`（**明确写了"缩写，勿写 x86_64-base"**）
   ⇒ **基座不能直接放在 `base/`，要落到 `arm64-base/` 这种目录下**。我取到的那两个文件**得按这个名字摆**。

---

## 三、★ 两个 workflow ＝ 我在交件31 说的两条路

`.github/workflows/` 下四个：
```
build-apk.yml            ← 本件引的这个（旧链／按 overlay 拉 npm? 待核）
build-apk-source.yml     ← ★ 很可能是"来源审计构建"（第一方从固定 commit 源码编）
pr-gate.yml
release.yml
```

**⇒ 交件31 里我从 `build-and-env.md` 推出的 A／B 两条路，**这里各有一个 workflow**。**
**⇒ 这也把我一直在问的"10-12 那个快照走的是 A 还是 B"变成了一个可查的问题**：**看那次跑的是哪个 workflow。**（你若有构建记录，这一眼就能定。）

---

## 四、批1 现在到底还剩什么（一屏说清）

| 项 | 状态 |
|---|---|
| 构建链路径 | ✅ 已读通（入口／0e／0f／门禁／两个宿主） |
| 权威补丁面 22 条 | ✅ 逐件 marker 判据 |
| **22 条在 alpha.5 上挂不挂得住** | ✅ **实测 21/22**（版本已核） |
| 改动清单 | ✅ 7 项补丁链 ＋ **13 处 commit** ＋ **31 处版本** ＋ **12 个 fixture** |
| **基座** | ✅ **已取到并 sha256 校验通过**（上一轮）；**摆放名要按 `arm64-base/`** |
| **运行环境** | ✅ **＝ GitHub Actions `ubuntu-latest`**（本机不行，已实测） |
| **alpha.5 的 `engine-overlay.json`** | ❌ **仍缺生成器**（`.tmp-upgrade/audit-manifest.mjs` 平板全盘无） |

**⇒ 只剩一件：那份 alpha.5 的 overlay。**

**★★ 而由此得出一个很实际的结论**：**批1 不需要"在某台机器上装 Linux"——它需要的是"把 13 处 commit、31 处版本、12 个 fixture 改完，然后触发那个 workflow"。而 workflow 自己会拉 LFS、自己会断言基座落地。**

---

## 五、我要问你的（收敛成一个）

**那份 `engine-overlay.json` 是怎么来的——是不是就在 `.tmp-upgrade/audit-manifest.mjs`，或者它有没有别的名字/别的位置？**
（坑 #41 说它「生成自 research 的 196 包清单为主循环」＋「必须与基座树全量对账」。
**我现在连基座都有了** ⇒ **只要拿到对账逻辑，alpha.5 的 overlay 我就能算。**）

---

## 六、诚实边界

- **已实测**：本机 `wsl.exe` 存在、`wsl -l -v` exit=1 无发行版；`shell.mjs` 的 `IS_WSL_HOST` 定义（前 70 行）；`build-apk.yml` 的关键行（L42／51~77／108）；`.github/workflows/` 的四个文件名。
- **★ 我读的是 workflow 的关键行，不是全文**（6.7 KB 里我只看了 lfs/base/snapshot 相关）；**`build-apk-source.yml` 我还没打开过**（"它是不是来源审计构建"**是我的推断**）。
- **没跑**：`build-snapshot-013.mjs`（本机不行，且 overlay 未齐）；`require-lfs-materialized.mjs`（没见到文件）。
- **没做**：没在平板上装任何东西、没触发任何 CI。
- **平板侧一个字没动**（`cordis.patch.yml` 仍 61,175 B / 2026-10-15 08:25）。

_电脑侧 · 2026-10-17_
