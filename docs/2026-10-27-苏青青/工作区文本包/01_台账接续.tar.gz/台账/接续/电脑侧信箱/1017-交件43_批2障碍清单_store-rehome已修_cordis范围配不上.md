# 交件43 · 批2 的现状与**具体障碍清单**：store-rehome 已修好、但 peer/dev 全钉在 `0.2.0-rc.2`

> **给**：苏青青（平板） ｜ **写自**：电脑侧 ｜ 2026-10-17
> 目标 ③ 说"界面切官方最新＋`ui-responsive` 重编到 alpha.5"。这一轮我把它**能不能重编**这件事查到了具体条款。

---

## 一、★★ 好消息：坑 #39 里那个"必炸"的点，**已经修好了**

坑 #39 的原话是：
> rc.1 loader module table 不再应答 client-runtime require（store-rehome 落地）……`ui-responsive` 构建预设的 **`RUNTIME_STORE_EXEMPTION`**（把 `require("@deepseek-ai/dsh-client-runtime/client")` 当 external）**在新 loader 上必炸**——"missed the module table — build-time externals drift"，**boot 即 `Failed to load plugins`**。
> **修复**：源码 import 迁到 `client-store`；构建预设 `CLIENT_EXTERNALS` 移除豁免；`INLINE_SAFE` 加 `client-store`。

**我在仓内 `ui-responsive` 0.3.3 里逐串查了：**

| 关键串 | 命中文件数 | 判 |
|---|---:|---|
| **`RUNTIME_STORE_EXEMPTION`** | **0** | ★ **豁免已移除** ✓ |
| **`client-store`** | **8** | ★ **已迁到 client-store** ✓ |
| `store-rehome` | 1 | 有该约定的落点 ✓ |
| `INLINE_SAFE` | 1 | ✓ |
| `CLIENT_EXTERNALS` | 2 | ✓ |
| `dsh-client-runtime/client` | 1 | ⚠ **残留 1 处**（可能是测试或注释，**我没去看是哪一处**） |

**⇒ 结论：0.3.3 已经带着 store-rehome 的修复 ⇒ 坑 #39 那个失效点不构成批2 的障碍。**

---

## 二、★★★ 具体障碍：**peerDependencies / devDependencies 全部钉在 `0.2.0-rc.2`**

0.3.3 的 `package.json`：
```
"version": "0.3.3"
"peerDependencies": {
  "@deepseek-ai/cordis": "^4.0.4",
  "@deepseek-ai/dsh-client-ui-settings":  "0.2.0-rc.2",
  "@deepseek-ai/dsh-client-ui-workspace": "0.2.0-rc.2",
  "@deepseek-ai/dsh-client-ui-slots":     "0.2.0-rc.2",
  "@deepseek-ai/dsh-client-ui-theme":     "0.2.0-rc.2",
  …
}
"devDependencies": {
  "@deepseek-ai/cordis": "4.0.4",
  "@deepseek-ai/dsh-client-store": "0.2.0-rc.2",
  "@deepseek-ai/dsh-client-ui-conversation": "0.2.0-rc.2",
  "@deepseek-ai/dsh-client-ui-layout": "0.2.0-rc.2",
  …  （全部 0.2.0-rc.2）
}
```

**⇒ 它对 alpha.5 的引擎包的依赖，**一条都不是 alpha.5 的版本**。**
**⇒ 要"重编到 alpha.5"，最低限度要**把这些 pin 全部抬到 `0.2.1-alpha.5`**，然后重装、重编。**

### ★★★ 而且有一处**精确的类型不匹配**（不是"要不要更新"的问题，是"根本配不上"）
alpha.5 的锁文件里，`@deepseek-ai/cordis` 解析为 **`~4.0.5-alpha.2`**。
而 0.3.3 的 peer 写的是 **`^4.0.4`**。

**⇒ 按 semver 规则，`^4.0.4`（= `>=4.0.4 <5.0.0`）**不匹配带预发布号的 `4.0.5-alpha.2`****
（预发布版本只有在范围本身在**同一 major.minor.patch** 上带预发布时才被接受）。
**⇒ 所以哪怕只跑 `npm install`，这一条 peer 也会报不满足。**
**⇒ 这一条要**显式改成** `~4.0.5-alpha.2` 或 `^4.0.4-0` 之类，**不能靠"抬版本号"糊过去。**

**★（顺带：坑 #40 记过「npm arborist 对复杂 peer 树 + 精确 pin 会崩（`spec undefined`）」，并给的处置是「删 `node_modules` + `package-lock` 全新 install `--legacy-peer-deps`」。⇒ 这一片的操作细节在你们账上是有的。）**

---

## 三、批2 的障碍清单（我这一轮能给的）

| # | 事项 | 状态 |
|---|---|---|
| 1 | store-rehome 修复（坑 #39 的失效点） | ✅ **已修好** |
| 2 | 现有产物的语法下限 | ✅ **过**（交件42：0 违规 ＋ 差分归零） |
| 3 | peer/dev 的版本 pin | ❌ **全在 `0.2.0-rc.2`，须抬到 `0.2.1-alpha.5`** |
| 4 | **`cordis` 的 peer 范围** | ❌ **`^4.0.4` 配不上 `4.0.5-alpha.2`（semver 预发布规则）—— 须显式改** |
| 5 | **仓内副本没有 `lib/`** | ❌ 与坑 #36 的规则冲突；**产物来源待你答**（交件42） |
| 6 | 整文件覆盖风险 | ⚠ 三个 `.pre-*` 备份证明机制活着（交件42） |
| 7 | **0.3.3 与 alpha.5 的源码级 API 兼不兼容** | ❓ **我这一轮只查了"依赖声明"，没查"实际用了哪些 API"** |

**⇒ 第 7 条才是批2 的真正未知数。** 我下一轮的做法：**把 0.3.3 的 `src/` 里对 `dsh-client-*` 的 import 全部列出来，与 alpha.5 那些包实际导出的符号对账** —— 那才是"能不能重编"的答案。

---

## 四、诚实边界

- **已实测**：仓内 `package.json` 的 `version`／`peerDependencies`／`devDependencies` 全文关键段；六个关键串的 `grep -rl` 文件数。
- **★ 我这一轮做的是"读依赖声明"，不是"跑一次 install"** ⇒ **第 4 条（cordis 范围）是我按 semver 规则推的，我没真让 npm 报一次错。** 但我把推理链写出来了，**你可以直接反驳。**
- **★ 第 3 条我也没实测**："抬到 alpha.5 就能编过"**是推论**，不是验证。
- **没看**：`dsh-client-runtime/client` 那 1 处残留在哪个文件；0.3.3 的 `src/` 一行都没读。
- **没动平板**：这一轮只做了 `cat` 与 `grep -rl`（只读）。
- **平板侧生产配置一个字没动**（`cordis.patch.yml` 仍 61,175 B / 2026-10-15 08:25）。

_电脑侧 · 2026-10-17_
