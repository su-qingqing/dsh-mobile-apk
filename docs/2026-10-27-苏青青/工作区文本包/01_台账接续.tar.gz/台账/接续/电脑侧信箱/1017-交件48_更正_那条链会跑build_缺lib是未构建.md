# 交件48 · ★★★ 更正我上一件：`build-release.ps1` **会跑 `npm run build`** —— 缺 `lib/` 是"源码检出未构建"，不是"注入源坏了"

> **给**：苏青青（平板） ｜ **写自**：电脑侧 ｜ 2026-10-17
> **本件更正交件42／47 的一处结论。** 我把 `$plugDir`／`$pluginSrcs` 的定义处读全了，看到的和我上一轮的推断不一样。

---

## 一、★★★ 原文：那条链**确实在 build**

`scripts/build-release.ps1` L83~93：
```powershell
foreach ($p in @($pluginSrcs[0], $pluginSrcs[1])) {        # dsh-shell-termux, dsh-client-ui-responsive
  Push-Location (Join-Path $root $p)
  npm run build 2>$null | Out-Null                          # ← ★ L85 真的在 build
  if ($LASTEXITCODE -ne 0) { throw ($p + " build failed") }  # ← ★ 失败即中止
  npm pack --pack-destination $plugDir 2>$null | Out-Null
  if ($LASTEXITCODE -ne 0) { throw ($p + " pack failed") }
  Pop-Location
}
Push-Location (Join-Path $root $pluginSrcs[2])              # dsh-host-web-compat
npm pack --pack-destination $plugDir 2>$null | Out-Null
Pop-Location
```
注释也直说：`# 1) Plugin build + npm pack (artifacts reused for host injection)`

**⇒ `build-release.ps1` 会：① `npm run build`（失败即 throw）→ ② `npm pack` 到 `$plugDir`（= `$outDir/plugins`）→ ③ 之后才 `inject-snapshot.py` ＋ 门禁 2e。**

---

## 二、★★ 所以坑 #36 那句"自包含链不 build"**指的是另一条链**

`plugin-dirs.json` 的 `$comment` 自己写着：
> **本地链 `scripts/build-apk-013.ps1` 与云端链 `scripts/build-apk.mjs` 都从这里读**，禁止各写一份……

**⇒ 至少有**三条**链：**
| 链 | 会不会 `npm run build` 这些子仓 |
|---|---|
| **`build-release.ps1`** | ★ **会**（L85，失败即中止） |
| `build-apk-013.ps1`（本地） | 按坑 #36：**不会** ⇒ `lib/` 必须事先抠入 |
| `build-apk.mjs`（云端） | 同上 |

**⇒ 坑 #36 那条规则（「`lib/` 必须一并抠入——自包含链不对这些子仓执行 `npm build`」）管的是 **`build-apk-*` 那两条**，**不是 `build-release.ps1`**。**

---

## 三、★★★ 更正：缺 `lib/` 是"源码检出未构建"，**不是"注入源坏了"**

**我在交件42／47 说**：「注入源就是本仓那个目录，而它没有 `lib/` ⇒ 构建时拿不到要注入的字节 ⇒ 门禁 2e 会中止」。
**⇒ 这个结论**错了一半**：**
- ✅ 「注入源就是本仓那个目录」—— **对**（`plugin-dirs.json` 与 L143 `(Join-Path $root $p)` 都指向它）；
- ❌ 「没有 `lib/` ⇒ 会中止」—— **不对**：**只要走 `build-release.ps1`，它自己会先 `npm run build` 把 `lib/` 建出来。**
- **⇒ 一个干净的源码检出**本来**就没有 `lib/`** —— 那是**正常的**，不是缺陷。**我上一轮把"还没构建"误读成了"注入源缺件"。**

**★ 而这个更正让批2 **更好办**，不是更难办。**

---

## 四、于是批2 的真实障碍链（收敛成 4 步）

```
① 把 peer/dev 的 pin 从 0.2.0-rc.2 抬到 0.2.1-alpha-5（你复核过：24 处 rc.2 / 0 处 alpha.5）
② 修 @deepseek-ai/cordis 的 peer 范围（^4.0.4 配不上 ~4.0.5-alpha.2；须显式改）
③ npm install（若 arborist 崩，按坑 #40：删 node_modules + package-lock，全新 install --legacy-peer-deps）
④ 走 build-release.ps1 —— 它会 npm run build → npm pack → 注入 → 门禁 2e
```

**⇒ 缺 `lib/` **不在**这 4 步里** —— 它是第 ④ 步的产物。
**⇒ 所以批2 真正要动的，只有 ①②**（然后 ③④ 是跑）。

**★ 但第 ④ 步里那两道我会盯的**：
- 门禁 2e：**快照内的 `lib/` 必须与 `$outDir/plugins/*.tgz` **逐字节一致****（同一份产物两处用，所以正常路径下必然一致——**除非中途有人手改了快照**）；
- 那三个 `.pre-client.js-*` 备份（交件42）说明**运行期还有一次整文件覆盖** —— **它与构建期的注入是两回事，我在下一轮会把这两条线的先后关系理清。**

---

## 五、这一轮我还顺手核到的一件事

**L96~102**：
```powershell
$snapSrc = Join-Path $root "dsh-mobile-apk\snapshot"
$armSnap = Join-Path $snapSrc "snapshot-arm64.tar.xz"
…
if (-not (Test-Path $abi.f)) { throw ("快照缺失: " + $abi.f + "（设备侧 make-snapshot.sh 产出后按 ABI 命名放入）") }
```
**⇒ ★ 它明确说：快照是**设备侧 `make-snapshot.sh` 产出**、再按 ABI 命名放进 `dsh-mobile-apk\snapshot\`。**
**⇒ 这与我交件25 的结论（`make-snapshot.sh` 是 legacy、真正入口是 `build-snapshot-013.mjs`）**冲突** —— 但可能只是"两条链各说各的"：
- `build-snapshot-013.mjs` 是**快照本身**的构建器；
- `build-release.ps1` 期望**已经有一份快照**放在 `dsh-mobile-apk\snapshot\`，由设备侧产出。
**⇒ 这一条我标为"待理清"，不硬下结论。**

---

## 六、诚实边界

- **已实测/已读**：`build-release.ps1` 的 L83~112 全文（含 L85 的 `npm run build` 与 L86 的 throw）；`plugin-dirs.json` 的 `$comment`；L143／L160 对 `$pluginSrcs`／`$plugDir` 的使用。
- **★ 本件是一次**自我更正****：交件47 里「没有 `lib/` ⇒ 门禁 2e 会中止」这句**我撤回**。**注入源的位置我说对了，后果我说错了。**
- **没跑**：`build-release.ps1` 一步都没跑；`npm run build` 也没跑（那需要先装上 alpha.5 的依赖）。
- **没读**：`build-apk-013.ps1`／`build-apk.mjs` 我**没打开过** ⇒ "它们不 build"**是引用坑 #36 的说法，不是我实测的**。
- **一条待理清**：`make-snapshot.sh`（设备侧）与 `build-snapshot-013.mjs` 的分工（§五）。
- **平板侧一个字没动**（`cordis.patch.yml` 仍 61,175 B / 2026-10-15 08:25）。

_电脑侧 · 2026-10-17_
