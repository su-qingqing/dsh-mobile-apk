# 交件49 · ★★★ 更正交件25：`make-snapshot.sh` **不是 legacy**，它是**设备侧**那条路；两条路分工清楚了

> **给**：苏青青（平板） ｜ **写自**：电脑侧 ｜ 2026-10-17
> **本件更正交件25 的一处结论。** 起因是 `build-release.ps1` L102 那句「设备侧 `make-snapshot.sh` 产出」——我当初把它当陈旧注释，这一轮去读了脚本本身。

---

## 一、它是设备侧的脚本，而且是真的在干活

`make-snapshot.sh` 头部原文：
```sh
#!/system/bin/sh
# M1.5: slim Termux environment snapshot (exclude toolchain/headers/man; rewrite embedded paths)
set -e
ROOT="${DSH_SNAPSHOT_ROOT:-/data/data/com.termux/files}"
…
export PATH="$ROOT/usr/bin:/system/bin"
export HOME="$ROOT/home"; export PREFIX="$ROOT/usr"
export LD_PRELOAD=…libtermux-exec-ld-preload.so        # ★ 就是"坑 #22"那套全套引擎 env
export TERMUX_EXEC__SYSTEM_LINKER_EXEC__MODE=force
export TERMUX__ROOTFS / TERMUX__PREFIX / TERMUX_APP__DATA_DIR
export OPENSSL_CONF="$ROOT/usr/etc/tls/openssl.cnf"
cd "$ROOT"
if command -v pkg >/dev/null 2>&1; then pkg install -y wget git jq unzip nano …; fi
```

末尾 L219：
```sh
tar -cf - $EXCLUDES -C "$ROOT" usr -C "$ROOT/stage-root" home/.dsh | xz -9 -T0 > "$ROOT/home/snapshot/snapshot.tar…
```

**⇒ 它做的事：在一台**已经装好的 Termux 环境**里，① 装工具、② 瘦身（剔 `usr/lib/clang`、`python3.14`、`gcc`… 见 L49／L55）、③ 重写内嵌路径、④ 把 `usr` ＋ **`stage-root`** ＋ `home/.dsh` 打成 `snapshot.tar`。**

---

## 二、★★ 两条路**不是新旧，是两个方向**

| | **`make-snapshot.sh`（设备侧）** | **`build-snapshot-013.mjs`（电脑／CI 侧）** |
|---|---|---|
| 在哪跑 | **平板上**（`/system/bin/sh`＋Termux app domain） | 电脑 WSL／GHA ubuntu |
| 输入 | **一棵已长成的 Termux 环境**（`$ROOT`）＋ **`$ROOT/stage-root`** | **`base-usr-<abi>.tar.xz` ＋ `base-dsh.tar.xz` ＋ overlay ＋ registry** |
| 动作 | **瘦身**（剔工具链/头/man）＋ 重写内嵌路径 ＋ 打包 | **组装**：解压基座 → 0e overlay → 预装工具集 → 0f 补丁 → 门禁 → 归档 |
| 输出 | `$ROOT/home/snapshot/snapshot.tar` | `.deploy-tmp/snapshot-013/<abi>/snapshot.tar.xz` |

**⇒ 一句话：`build-snapshot-013.mjs` 是"从基座**造**出一棵引擎树"；`make-snapshot.sh` 是"把一棵**长成**的环境**瘦身打包**"。**

**⇒ 所以 `build-release.ps1` L102 那句话**是对的、不是陈旧注释** —— 我交件25 把它当陈旧的，错了。**

---

## 三、★ 我当初为什么会判错（值得记，因为这是第四次的同类错误）

交件25 我的证据是**真的**：`make-snapshot.sh` 里有一段 **sed 式补丁**，目标 `dsh-sandbox`／`dsh-sandbox-local` **实测与 npm 发布包逐字节相同（零 delta）**，而且**没有 `dsh-mobile` marker** ⇒ **那一段补丁确实没落地。**

**⇒ 但"脚本里有一段过时"和"整个脚本作废"是两件事。我把前者扩大成了后者。**

**★ 而且我当时还有一个**看起来**支持它的旁证**：`ci-snapshot-build.md` 里引的是 `make-snapshot.sh`，所以我判"那份文档也过时了"。
**⇒ 现在看：文档未必过时 —— 它引的可能是**设备侧那条路**，而我一直只盯着电脑侧那条。**

**★★ 一个很可能加剧了这个误判的因素：两条路的产物**都叫 `snapshot.tar(.xz)`**。**
**⇒ 命名撞车 —— 我建议在沟通里明确区分「电脑侧组装产物」与「设备侧瘦身产物」。**

---

## 四、这对批1 的影响（要紧）

**我交件25／31／36 一直是按"批1 走 `build-snapshot-013.mjs` → GHA workflow"这条线写的。这条线本身没错，但本件要求补一句边界：**

| 问题 | 现状 |
|---|---|
| 组装引擎树（alpha.5 的树） | **`build-snapshot-013.mjs`**（电脑侧／GHA）—— 这条是我一直在准备的 |
| **产出"设备侧最终快照"（`snapshot.tar`）** | **`make-snapshot.sh`**（平板上）—— **这条我之前根本没纳入批1 的视野** |
| 两者关系 | **`build-snapshot-013.mjs` 的产物是否就是 `make-snapshot.sh` 的输入（或其 `stage-root`）？** ★ **我没查证** |

**⇒ 这一条是**新的待理清项**，而且它直接影响"批1 到底要在几处动手"。**
**★ 我下一轮要查的是**：`$ROOT/stage-root` 是谁放进去的、它与 `build-snapshot-013.mjs` 的产物是不是同一份。

---

## 五、诚实边界

- **已实测/已读**：`make-snapshot.sh` 头 40 行全文与关键行（L49／L55／L80／L89／L182／L219）；`build-release.ps1` L102 的原文。
- **★ 本件是**第四次自我更正****（真值源两次、`lib/` 一次、本件一次）。**四次都是"从局部读推全局断言"。** 我把它当模式记下来。
- **★ 我**没有**推翻交件25 的全部**：那段 sed 补丁"没落地"的**实测结论仍然成立**；我撤回的是"因此整个 `make-snapshot.sh` 是 legacy"这个**推论**。
- **没查证**：`$ROOT/stage-root` 的来源；`build-snapshot-013.mjs` 产物与 `make-snapshot.sh` 输入的关系（§四）。
- **没跑**：`make-snapshot.sh` 一步都没跑（它要**在平板上**跑，且会 `pkg install` 动环境 ⇒ **我不会在未获你同意前跑它**）。
- **平板侧一个字没动**（`cordis.patch.yml` 仍 61,175 B / 2026-10-15 08:25）。

_电脑侧 · 2026-10-17_
