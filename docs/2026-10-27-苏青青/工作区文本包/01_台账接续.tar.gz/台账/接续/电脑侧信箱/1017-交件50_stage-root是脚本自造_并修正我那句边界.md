# 交件50 · `stage-root` 是脚本自己造的；★ 并报一个我必须如实说的测量结果：live `cordis.patch.yml` **两边都对不上**，且 mtime 晚快照三天

> **给**：苏青青（平板） ｜ **写自**：电脑侧 ｜ 2026-10-17

---

## 一、`stage-root` 不是外部输入 —— 是 `make-snapshot.sh` 自己造的

**我全仓 grep 了 `stage-root`：** 只出现在 **`scripts/make-snapshot.sh` 一个文件**里。它的用法（L63~92、L139、L157、L221~222）：

```sh
L63:  rm -rf stage-root
L64:  mkdir -p stage-root/home
L65:  cp -r home/.dsh stage-root/home/.dsh
L68:  rm -rf stage-root/home/.dsh/.credentials.yaml      # ← 剔凭据
L69:  rm -rf stage-root/home/.dsh/.anonymous-user-id
L70:  rm -rf stage-root/home/.dsh/sessions              # ← 剔会话
L71:  rm -rf stage-root/home/.dsh/storages
L72:  rm -rf stage-root/home/.dsh/attachments
L73:  rm -rf stage-root/home/.dsh/llm-deepseek
L74:  rm -rf stage-root/home/.dsh/update-cache
L77:  cat > stage-root/home/.dsh/settings.yaml <<'SEED_EOF'          # ← 写种子 settings
L85:  find stage-root/home/.dsh -name '*.map' -delete
L91:  mkdir -p stage-root/home/.dsh/profiles/web
L92:  cat > stage-root/home/.dsh/profiles/web/cordis.patch.yml <<'PATCH_EOF'   # ★ 自己写一份 profile 补丁
L139: PATCH_TARGET=stage-root/home/.dsh/profiles/web/cordis.patch.yml
L157: sed -i "s|/data/data/com.termux/files/usr|$SNAP_PKG_ROOT/usr|g; …" stage-root/…/cordis.patch.yml
L221: tar -cf - $EXCLUDES -C "$ROOT" usr -C "$ROOT/stage-root" home/.dsh | xz -9 -T"$XZ_THREADS" > …/snapshot.tar.xz
L222: rm -rf stage-root
```

**⇒ `stage-root` = 一个**临时暂存目录**：从**活的 `home/.dsh`** 拷一份 → 剔掉凭据/会话/存储/附件 → 写进种子 `settings.yaml` → **再写进它自己的那份 `cordis.patch.yml`** → 重写内嵌路径 → 打进快照 → **用完即删**。**

**⇒ 所以我上一轮说的"接缝"**不存在**：`stage-root` 不是两条路之间的接口，它是**设备侧这条路的内部环节**。**
**⇒ 两条路比我以为的**更独立**：**
- **电脑侧**：吃**基座 tarball**（base-usr ＋ base-dsh）＋ overlay ＋ registry；
- **设备侧**：吃**这台机器上活的 Termux 环境**（`$ROOT`）。

---

## 二、★★★ 而顺着这条线，我撞到一个必须如实报的结果

**我一直想找一个"判别器"：**live 的 `cordis.patch.yml` 出自哪条路？**（电脑侧用 `scripts/profile-web.cordis.patch.yml` 权威覆盖；设备侧的 heredoc 是另一份。）**

**实测结果：两边都对不上。**

| 来源 | 大小 |
|---|---:|
| 仓里 `scripts/profile-web.cordis.patch.yml`（`调研/` 那份，mtime 10-11 04:26） | **16,803 B** |
| `工具/` 那份（mtime 09-26 05:09） | **8,603 B** |
| `make-snapshot.sh` 的 heredoc（L92 起，内容看着是短的一份） | 远小于上面 |
| **平板 live `files/home/.dsh/profiles/web/cordis.patch.yml`** | **★ 61,175 B** |

**★★ 而且 mtime 是这里最要紧的一条：**
```
live cordis.patch.yml    mtime = 2026-10-15 08:25
出厂快照（APK 内）        mtime = 2026-10-12 00:58
```
**⇒ live 那份比快照**晚了三天** ⇒ **它在装好之后**又被写过**。**
**⇒ 所以（a）它**不能**用来判"快照出自哪条路"；**（b）**我这十几轮一直报的那句"平板生产配置未动（61,175 B / 2026-10-15 08:25）"，守着的其实是一份**已经和任何构建源都不相等**的文件。**

**★ 我把这条明说，因为它是对我自己那句"边界"的修正**：
**"没动"只说明"我没动"，不等于"它等于构建产物"。** 这两件事我之前混着说了。

**★ 一个可能的解释（我没证据，只是列出来）**：老板本人在 10-15 手改过它（他一直在场做这些事）；或者引擎运行期会规范化写回。**我判不了，请你或老板确认。**

---

## 三、这一轮对批1 的净影响

| 项 | 变化 |
|---|---|
| 两条 snapshot 路线的接缝 | ✅ **查清：`stage-root` 是设备侧内部环节，不是接口** ⇒ **两条路独立** |
| 批1 该走哪条 | **仍是电脑侧（`build-snapshot-013.mjs` ＋ GHA）** —— 我前面十几轮的准备**没有用错方向** |
| "设备侧最终快照"这条线 | ★ **它吃的是活的 Termux 环境**，与电脑侧的基座路线**不共享输入** ⇒ **`make-snapshot.sh` 不是批1 的一环**（除非老板要的是"从当前这台机器的环境直接出快照"） |
| live profile 补丁的来源 | ❌ **两边都对不上，且晚快照三天** ⇒ **待你或老板确认 10-15 那次写入是谁做的** |

---

## 四、诚实边界

- **已实测**：全仓 `grep -rln 'stage-root'`（**只 1 个文件**）；`make-snapshot.sh` 的 L63~92／L139／L157／L221~222 全文行号；四处 `cordis.patch.yml` 的**字节数**与其中三处的 **mtime**；两份首行内容对照。
- **★ 我这一轮**没有**读 `make-snapshot.sh` 里那段 heredoc 的**全文**（只看了头 6 行）⇒ **"它远小于上面"是我的目测，不是量出来的。** 我标出来。
- **没做**：没有去比 live 那份 61,175 B 的**内容**（只比了字节数）⇒ **"两边都对不上"目前的依据是**尺寸**，不是逐字节。** 若要确证，得把 live 那份拉下来逐字节比（下一轮可做）。
- **没跑**：`make-snapshot.sh` 一步没跑（它要在平板上跑且会 `pkg install`，**未获同意我不跑**）。
- **平板侧**：本轮只做 `ls`／`grep`／`pull`（只读）；**生产配置我一个字没动**（但这句的**含义**已按 §二 修正）。
- `cordis.patch.yml` 仍 **61,175 B / 2026-10-15 08:25**。

_电脑侧 · 2026-10-17_
