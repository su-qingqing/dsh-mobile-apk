# 交件60 · 批2（手机适配层）的电脑侧候选 ＋ 一条硬阻塞｜电脑侧 → 苏青青

> 接交件59。本件两件事：**① 批2 的 pin 面算完了，出候选 diff；② 其中有一个包在 npm 上根本没有 alpha.5。**
> **只读**：对平板只用 `ls / cat / grep / adb pull`。**没有在本机 npm install**（按老板话，装/构建归 GHA）。

---

## 一、我直接去问了 npm registry（本次新增的一类证据：不再靠推断）

| 包 | 有 `0.2.1-alpha.5` 吗 | 备注 |
|---|---|---|
| `@deepseek-ai/dsh` | **★ 有** | `latest` 标签仍是 `0.2.0-rc.2`（alpha.5 是预发布） |
| `@earendil-works/pi-ai` | — | `1.2.0` **在**（`latest` 已到 `1.3.0`） |
| `@deepseek-ai/cordis` | — | `4.0.5-alpha.2` **在** |
| `@deepseek-ai/dsh-client-store` | **★ 有** | |
| `@deepseek-ai/dsh-client-ui-slots` | **★ 有** | |
| `@deepseek-ai/dsh-client-ui-primitives` | **★ 有** | |
| `@deepseek-ai/dsh-client-ui-theme` / `-layout` / `-settings` / `-workspace` | **★ 有** | |
| `@deepseek-ai/dsh-session` / `-scope` / `dsh-api-workspace-controller` / `dsh-webhook-github` | **★ 有** | |
| **`@deepseek-ai/dsh-invariants`** | **★★ 没有** | 最新只到 **`0.2.0-rc.2`**；连 `0.2.1-alpha.*` 都没有 |

**⇒ 批2 的形状就此定了一半**：`dsh-client-ui-responsive` 有 **3 处**引用 `dsh-invariants`
（`overrides` / `peerDependencies` / `devDependencies`）—— **它升不上去，只能保持 `0.2.0-rc.2`，
或者摘掉这条依赖。这个要你和老板定，我不擅自改。**

---

## 二、真 semver 库验过的两条（不是我说的，是算出来的）

用 pnpm 自带的 `semver@7.8.4` 实算：

| range | version | satisfies |
|---|---|---|
| `^4.0.4` | `4.0.5-alpha.2` | **false** ★ |
| `^4.0.4` | `4.0.5` | true |
| `~4.0.5-alpha.2` | `4.0.5-alpha.2` | **true** ★ |
| `0.2.0-rc.2`（精确钉） | `0.2.1-alpha.5` | **false** |

**⇒ 两条都成立**：① cordis 的 peer `^4.0.4` 配不上 `4.0.5-alpha.2`（预发布的匹配规则要求
比较子的 `major.minor.patch` 与版本完全一致，且范围里本身要有预发布）——**必须一起改**；
② `0.2.0-rc.2` 是精确钉，升 alpha.5 时**不写就装不上**，不会自己漂过去。

---

## 三、批2 的候选改动面（**只出 diff，未落仓库**）

`dsh-client-ui-responsive/package.json`：**`@deepseek-ai/*` 引用 30 处**（`overrides` 3 ＋ `peerDependencies` 7 ＋ `devDependencies` 20）。

| | 数 |
|---|---|
| 版本字面量 = `0.2.0-rc.2` | 28 |
| **改成 `0.2.1-alpha.5`** | **27** |
| **保持 `0.2.0-rc.2`（`dsh-invariants`，3 处）** | 3 |
| `cordis` peer `^4.0.4` → `~4.0.5-alpha.2` | 1 |
| `cordis` dev `4.0.4` → `4.0.5-alpha.2` | 1 |

**diff = +27 / −27 行**（附件 `1017-附_批2_ui-responsive_pin面候选.diff`，3,645 B）。

★ **我没做的、也不该在电脑侧做的**：`npm install` / `npm run build` / `vitest`。
按老板这次的话，**装与构建归 GitHub Actions 运行环境**。所以本件只到"字面量算准"为止，
**能不能装、能不能编，是 GHA 那份日志说了算**。

---

## 四、又一条我自己的更正（第 7 条）

我在交件59 里写「`packages` 里 **45 条**模板有而 alpha.5 无 ⇒ 待核」。**拆开之后不是 45 条一件事，是两件事：**

| | 数 | 是什么 |
|---|---|---|
| rc.2 有、alpha.5 没有（**真变了**） | **10** | `dsh-client-store`／`dsh-client-ui-primitives`／`dsh-client-ui-slots`／`dsh-hook-protocol`／`dsh-hooks-claude-code`／`dsh-hooks-codex`／`dsh-invariants`／`dsh-subagent-in-process-driver`／`dsh-webhook`／`dsh-webhook-github` |
| 两张解析图**都没有**（**既存现象，与升版无关**） | **31** | browser-use／computer-use／lsp／ssh／subagent-* 那一族 |
| 只有 alpha.5 有（新增） | 4 | |

**⇒「45 条待核」应改成「10 条真变 ＋ 31 条既存」。** 而且这 10 条里，**9 条在 npm 上都有 alpha.5，只有 `dsh-invariants` 没有** —— 也就是说
**"不在 alpha.5 的解析图里" 与 "没有 alpha.5 可装" 是两件事**，我上一批把前者当后者看了。这一条是我该挨的。

---

## 五、电脑侧现在剩下的、真正卡住的只有一件

**裁定5 的 A 路：老板名下要有一个仓库。** 我已实测：
本机 **没有 `gh`**、**没有 `~/.git-credentials`**、**没有 `~/.config/gh`**、**环境里没有任何 GITHUB/GH_TOKEN**；
而 `build-apk.yml` 是 `workflow_dispatch`（**手动点**，要目标仓写权限），`kelai141/...` 是第三方的。
**⇒ 在有一个能推的仓库之前，「GHA 去装」这一步在这台机器上点不动 —— 这不是我偷懒，是权限边界。**

**落地顺序（照裁定5）**：① 改动进仓 → ② 推 → ③ 点一下跑流水线。
**① 我已经备好了两件 diff**（批1 补丁面 4 文件/9 块、批2 pin 面 27 处），
**只要有个仓库，它们就是两条 `git apply`。**

---

## 六、附件

| 文件 | 是什么 |
|---|---|
| `1017-附_批2_ui-responsive_pin面候选.diff` | 批2 pin 面 **+27 −27**，`dsh-invariants` 3 处标为保持不动 |
| `1017-交件60_批2候选与dsh-invariants硬阻塞.md` | 本件 |

---

## 七、等什么

1. **【2】confinement 门改法** —— 老板点头即定稿（**已实测 23/23**）。
2. **A1 launch block 重锚** —— 请过一眼语义承接（`bootstrapPath === void 0` ⇔ `launch.kind === "embedded"`）。
3. **`dsh-invariants` 怎么办**（保持 rc.2 混用 / 摘掉）—— 这是批2 唯一的真阻塞。
4. **裁定5 A 路**（仓库）—— 这是「GHA 去装」唯一的真阻塞。
5. **【4】重启验 P1** —— 老板没说，**我不动**。

---

_电脑侧 · 2026-10-17 ｜ 对平板全程只读：未写、未装、未改_
