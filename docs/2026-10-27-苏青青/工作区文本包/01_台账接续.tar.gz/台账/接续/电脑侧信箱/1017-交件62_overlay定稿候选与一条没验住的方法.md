# 交件62 · overlay 候选定稿 ＋ 一条**没验住**的方法（如实报）｜电脑侧 → 苏青青

> 接交件61。本件两件事：①把 overlay 候选里**已经权威确定**的四处换掉；
> ②报一条**我试了、但自校验没通过**的方法 —— 不许当成果讲。
> **只读平板**：未写、未装、未改。

---

## 一、权威确定的四处（已换进候选）

来源全部是**上游源码仓** `deepseek-ai/deepseek-harness` 的 tag `dsh-v0.2.1-alpha.5`
（= `1517a4dbca0a2789ff1d41ba439600f8547d23fa`）：

| 字段 | 换成 | 出处 |
|---|---|---|
| `pins` | **`@earendil-works/pi-ai: 1.1.0`** | `pnpm-workspace.yaml → patchedDependencies` |
| `packages['@deepseek-ai/cosmokit']` | **`1.8.6-alpha.2`** | `vendor/cosmokit/package.json`（走 `link:`，锁里没有） |
| `packages['@deepseek-ai/schemastery']` | **`3.18.5-alpha.2`** | `vendor/schemastery/package.json` |
| `assemblyInventory.sourceCommit` ＋ `catalogDiff.pinned` ＋ `requiredUpstreamPatches` | **`1517a4db…` / `1.1.0` / sha `66eaf960…`** | tag ＋ 官方补丁原件 |

候选现状：`engineVersion=0.2.1-alpha.5`、`packages=356`、`vendorTop=62`、`nested=5`、`pins=pi-ai 1.1.0`（46,332 B）。

---

## 二、★ 一条我试了、**自校验没通过**的方法（不许当成果）

**想法**：既然上游源码仓有 `pnpm-lock.yaml`（alpha.5 那份 1,087,351 B），
那它就该是**全套版本的权威源** —— 比"我自己 install"可靠。于是我把两份锁都拉下来解析。

**自校验（这一步是必须的，也正是在这里失败了）**：
用**同一套解析器**去吃 **rc.2** 的锁，拿结果去复现**现役 overlay**的 `packages`：

```
现役 overlay packages 322 条：
  与 rc.2 锁逐条一致      2
  不一致                  2      （got 14.6.6 vs 锁 11.8.6；js-yaml 4.3.1 vs 4.2.0）
  rc.2 锁里根本没有      318
```

**两个原因，都实打实：**
1. **第一方在锁里是 workspace 链接，不是带版本的包** —— 322 条里 318 条查不到版本。
   所以"第一方版本"这条路，锁给不了。
2. **同名多版本时"首次出现"取错了** —— 那 2 条不一致就是取到了嵌套的旧副本
   （`got` 取到 11.8.6 而不是 14.6.6）。要用锁选版本，得**从根 importer 顺着依赖图做解析**，
   那是真解析器，不是正则能对付的。

**⇒ 结论：`packages` 与 `vendorTop` 的版本面，我没有可信来源。** 具体地说：

| 面 | 现状 |
|---|---|
| `pins` / vendored 两包 / `sourceCommit` / 官方补丁 | **权威**（上游 tag 直读） |
| `packages` 的成员与第一方版本 | **取自电脑侧自己 install**，是"参考"不是"权威" |
| `vendorTop` 的**版本** | 同上，**没验住** |
| `vendorTop` 的**成员集合** | 沿用模板 ＋ 实测新增，**没被上游门禁核过** |

**这些都写进候选的 `contrastNotes.NOTverified` 里了**（不藏在附件里）。
**⇒ 这一面只能由 GHA 上的官方门禁来判** —— 正好落在老板说的"装与构建归 GHA"上。

---

## 三、顺带一条正面的交叉印证

上游锁里那些第三方包，与我上一版（自己 install）差得很大 —— 但那**大部分是解析器取错**（见上）。
真正可信的那几条是：

- **`@earendil-works/pi-telemetry` 跟 pi-ai 同档**：`0.87.1 → 1.1.0`（不是 1.2.0）。
- **`compression 1.8.1 → 1.8.2`**（两处口径一致）。
- `cosmokit` 在锁里**没有**（`link:vendor/`）⇒ **必须从 vendored 包读**，这一步在此之前是错的来源。

---

## 四、附件

| 文件 | 是什么 |
|---|---|
| `1017-附_alpha5_overlay_定稿候选.json` | 46,332 B；`NOTverified` 四条写在里面 |
| `1017-交件62_overlay定稿候选与一条没验住的方法.md` | 本件 |

---

## 五、等什么（未变）

1. **【2】confinement 门改法** —— 老板点头即定稿（补丁侧两棵树已 23/23）。
2. **A1 launch block 的语义承接** —— 请过一眼 `bootstrapPath === void 0` ⇔ `launch.kind === "embedded"`。
3. **`dsh-invariants`**（npm 上无 alpha.5）—— 批2 唯一真阻塞。
4. **裁定5 A 路（仓库）** —— 「GHA 去装」唯一真阻塞。

---

_电脑侧 · 2026-10-17 ｜ 对平板全程只读_
