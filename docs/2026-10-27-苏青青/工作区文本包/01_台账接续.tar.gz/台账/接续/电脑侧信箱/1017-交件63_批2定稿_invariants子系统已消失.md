# 交件63 · 批2 定稿：`invariants` 在 alpha.5 里**整个没了**（不是"版本跟不上"）｜电脑侧 → 苏青青

> 接交件60。上件我把批2 的阻塞写成「`dsh-invariants` 没有 alpha.5 → 只能保持旧版混用或摘掉，请你和老板定」。
> **本件把它查到底了：不用定，答案是「摘掉」—— 因为那个子系统在 alpha.5 里整个不存在。**
> **只读平板**：未写、未装、未改。

---

## 一、三条**独立**证据，指向同一件事

| # | 证据 | 读数 |
|---|---|---|
| ① | npm registry：`@deepseek-ai/dsh-invariants` 有哪些版本 | 最新 **`0.2.0-rc.2`**；**没有** `0.2.1-alpha.5`（连 `0.2.1-alpha.*` 都没有） |
| ② | 它在不在 alpha.5 的解析图里 | **不在** —— 而同为"rc.2 独有"的另外 **9 个**包（`dsh-client-store`、`dsh-client-ui-slots`、`dsh-client-ui-primitives`、`dsh-session`…）**都已经重发到 `0.2.1-alpha.5`** |
| ③ | ★ 树里还有没有这个**服务** | rc.2：`@deepseek-ai/dsh-invariants@0.2.0-rc.2` 是 `invariants` 服务的**唯一提供者**（`super(ctx, "invariants")`），**38 个包**声明 `inject = ['invariants']`；<br>**alpha.5：提供者 0 个，声明者 0 个，目录名带 invariant 的 0 个** |

**⇒ 这不是"某个包没跟上版本"，是上游在 0.2.1-alpha.5 里把整套 invariant companion 机制**去掉了**。**

---

## 二、为什么"保持 `0.2.0-rc.2` 混用"这条路走不通

`dsh-client-ui-responsive` 的 invariant 入口只有 9 行，但它是**运行时注册**：

```ts
export const inject = ['invariants']                       // ← 注入的是**服务名**
const install: InvariantInstaller = () => {}               // ← 空实现
Promise.resolve(ctx.invariants.register(PACKAGE_NAME, install))
```

在 alpha.5 里 **没有任何插件提供 `invariants` 这个服务** ⇒ 这条 `inject` **永远等不到**。
**⇒ 把 `dsh-invariants` 的版本"保住"没有意义：不是版本不匹配，是对面那个服务不存在了。**

---

## 三、批2 定稿改动面（`git apply --check` **exit 0**）

对上游 main `f61539e3cb`，文件 `dsh-client-ui-responsive/package.json`，**+27 −35**（附件 4,954 B）：

| | 内容 |
|---|---|
| ① | **25 处** `0.2.0-rc.2` → **`0.2.1-alpha.5`**（`overrides` / `peerDependencies` / `devDependencies` 全量） |
| ② | `@deepseek-ai/cordis`：peer `^4.0.4` → **`~4.0.5-alpha.2`**；dev `4.0.4` → **`4.0.5-alpha.2`**<br>（`semver@7.8.4` 实算：`^4.0.4` 配不上 `4.0.5-alpha.2`；而且 **alpha.5 自己声明的就是 `~4.0.5-alpha.2`**，两处口径一致） |
| ③ | ★ **摘掉** `@deepseek-ai/dsh-invariants`（3 处）＋ `exports` 的 `./invariant` 段 ＋ `files` 里的 `lib/invariant.js` |

**★ 还需要删文件（不在 diff 里，因为 diff 只覆盖一个文件）**：
`dsh-client-ui-responsive/src/invariant.ts` 及其产物 `lib/invariant.js`、`lib/types/invariant.d.ts`。
另外 `build-scripts/tsdown.client.ts:89` 的注释提到「package-invariants gate」，**落仓时要一起核**。

**没有做的（按老板话归 GHA）**：`npm install` / `npm run build` / `vitest`。本件只到"字面量与依赖面算准"。

---

## 四、残留不确定（如实写，不许含糊）

第 ③ 条证据是 **字面量**匹配（`super(ctx, "invariants")` / `inject = ['invariants']`）——
**万一上游只是把服务改了名**，我这个扫法会漏。
另外我扫的是 **npm 安装树**（303 个第一方包），不是**源码构建导出集**。
**⇒ 这两点我不敢说"已经排除"，只能说"三条独立信号都指向同一结论"。**
如果在 GHA 上跑出来反过来（服务还在、只是换了名），**以 GHA 的日志为准，我这条作废。**

---

## 五、附件

| 文件 | 是什么 |
|---|---|
| `1017-附_批2_定稿候选_ui-responsive.diff` | **+27 −35**，`git apply --check` 通过 |
| `1017-交件63_批2定稿_invariants子系统已消失.md` | 本件 |

---

## 六、等什么

1. **【2】confinement 门改法** —— 老板点头即定稿（补丁侧两棵树已 23/23）。
2. **A1 launch block 语义承接** —— 请过一眼。
3. **批2**：改动面已定稿，**只差一个能推的仓库**（不再需要你和老板裁决）。
4. **裁定5 A 路（仓库）** —— 「GHA 去装」唯一真阻塞。

---

_电脑侧 · 2026-10-17 ｜ 对平板全程只读_
