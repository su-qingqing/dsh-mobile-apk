# 交件69 · 阶段四：第二条红也定位并修了（根因在你们自己记的坑里）｜电脑侧 → 苏青青

> 接交件68。**#2 又红了，但红法变了** —— 说明第一条修对了，这是第二条。
> **只读平板**：本轮对平板只做了 `ls / cat`。

---

## 一、#2 的红：**换了根因**

```
npm error While resolving: @dsh-android/dsh-shell-termux@0.2.0
npm error Found: @deepseek-ai/dsh-bash-local@0.2.0-rc.2
npm error   dev @deepseek-ai/dsh-bash-local@"0.2.1-alpha.5" from the root project
npm error Conflicting peer dependency: @deepseek-ai/dsh-shell@0.2.1-alpha.5
npm error   peer @deepseek-ai/dsh-shell@"0.2.1-alpha.5" from @deepseek-ai/dsh-bash-local@0.2.1-alpha.5
```

⇒ 根要 `dsh-bash-local@0.2.1-alpha.5`，它的 peer 是**精确的** `dsh-shell@0.2.1-alpha.5`；
而**提交里那份 `package-lock.json` 还解析在 `0.2.0-rc.2`** ⇒ npm 判无解。

**★ 我这次没自己发明办法 —— 先去找你们自己记的账，两条都在：**

| 出处 | 原文要点 |
|---|---|
| `docs/AGENTS/gotchas.md:656`（**坑 #174**） | 「上游 peer 门禁与 npm 解析用的是**两套 semver 判据**……上游判兼容用 `{includePrerelease:true}`，而 **npm 自己解析 peer 时不带** ⇒ 同一个区间在运行时门禁里放行、在 `npm install` 里却判不满足」 |
| `docs/AGENTS/gotchas.md:48`（**坑 #40**） | 「npm arborist 对复杂 peer 树 ＋ 精确 pin 会崩……**处置**：删 node_modules ＋ package-lock 全新 install **`--legacy-peer-deps`**」 |
| `plugins/dsh-android-vdisplay/README.md:57` | 「`npm install --no-audit --no-fund **--legacy-peer-deps**` # **本仓既有插件同口径**（cordis 与 cordis-plugin-include 的 peer 冲突）」 |

**⇒ 坑 #174 讲的就是我们这次的机制**（精确预发布 peer 在 runtime 放行、在 npm 里 ERESOLVE），
而 **坑 #40 与那两份 README 给的就是处置**：`--legacy-peer-deps`。

---

## 二、阶段四 = 一处改动，**没有放松任何门禁**

改 `scripts/source-build/install-project-dependencies.mjs`：两次 npm 调用都加 `--legacy-peer-deps`
（`install --package-lock-only` 与 `npm ci`），并把依据（坑 #40／#174／README:57）写进注释。

**门禁一条没松**：脚本仍然断言
① `package.json` 未被解析改过；② `checkPackageLockRoot` 必须通过；③ `npm ci` 不许改它自己的输入（manifest/lock）。

---

## 三、四条改动现在的样子

| 提交 | 内容 | 改动量 |
|---|---|---|
| `4e33128` | 阶段一：补丁面（版本分档）＋ invariants 摘除 | 7 文件 |
| `45160ae` | 阶段二：身份改基 25 处 ＋ 12 插件版本钉 | 24 文件 |
| `abcc8e9` | 阶段三：cordis 精确钉 → `~4.0.5-alpha.2`（照上游自己的声明）＋ A1 版本清单 | 11 文件 |
| **`47a5b0a`** | **阶段四：`--legacy-peer-deps`** | **1 文件** |

**三条流水线：`#1` 红（cordis 精确钉）→ `#2` 红（精确 peer ＋ 旧锁）→ `#3` 正在跑。**

**★ 这个循环本身在正常工作**：每一轮 GHA 把下一个真障碍顶出来，我按它修，而不是我猜。
（这也正是老板说的「装与构建归 GHA」的实际形态。）

---

## 四、还欠一件（未变）

**机器挂点仍未落**：① `工具/开工/必读卡.mjs` 的「已交付」警报格（＋ `pins类` 表标栏）
② `台账/轮末/打烊规程.md` 的「真源写一次 ＋ 只留指针 ＋ 清账」。
这两轮我的时间给了引擎线（有实测结果要接 ＋ 你那份答复要回）。**下一轮优先做挂点。**

---

## 五、边界

平板**引擎配置一个字没动**：`cordis.patch.yml` 仍 **61,175 B / 2026-10-15 08:25**。
上一轮改的两处规矩文件都有备份、都回读校验过。

---

_电脑侧 · 2026-10-17_
