# 交件81：判决二 方案① **验证成功** ＋ ★ 官方 overlay 门禁抓到我一处真错（已修）｜电脑侧 → 苏青青

> 回你 09:08 判决里「你这边的下一批」第 1、2 条。本件三件事：
> **① 方案①在 CI 上验证成功**（那道卡很久的门禁**过了**）；
> **② A4① 在真链上也验证过**（施加 ＋ 幂等 ＋ overlay 无异议）；
> **③ ★ 官方 overlay 门禁抓到我 A1 的一处真错，是我的补丁错、不是门禁错，已修并加反回归钉。**
> 平板生产件一个字没动。

---

## 一、判决二（Kotlin 门禁 方案①）：**CI 上验证成功**

`build-apk` run **38990106675**（分支 @ `ce5e025`）逐字读数：

```
[build-apk/arm64] Kotlin 单测：先跑 :app:testDebugUnitTest（让下面的数量门禁有真结果可判）…
> Task :app:testDebugUnitTest
BUILD SUCCESSFUL in 2m 41s
[build-apk/arm64] 门禁：Kotlin 单测数量反回归（逐类基线只许升 + 无缺席 + 结果新鲜）…
Kotlin 单测: 源测试类=122 有结果=122 用例总数=1364（基线 1364）
CHECK-KOTLIN-TEST-COUNT PASSED（SKIP=0；逐类不低于基线 + 无缺席 + 结果新鲜 + 无失败用例）
```

⇒ **1364 个用例、122 个类，一个不缺、一个不挂**；门禁从「缺结果判红」变成**真检通过**。
而且链条**走过**了它，继续往下跑了 `CHECK-CODE-MAP` / `CHECK-STATE-REGISTRY` / `CHECK-GATE-SKIPS` 全 PASSED。
→ 方案① 不是"把门禁绕过去"，是**让注释描述的事实成真**（真跑了单测，再拿真结果判）。

---

## 二、A4①（同族三处）：**在真链上也验证过**

`build-apk` run **38990398434**（分支 @ `0a10407`）逐字读数：

```
[build-013/arm64] 施加引擎树补丁（… truncated-first-frame-A4 …，apply-patches --scope engine）…
[ok]   truncated-first-frame-A4 applied（…/dsh-session-persistence-jsonl/lib/index.js）
[skip] truncated-first-frame-A4 已应用（…）          ← 幂等，第二次不重复施
CHECK-PATCH-TEST-MANIFEST PASSED（33 个文件均已纳入自动化执行，已知失败 0 项）
CONTRACT PASS（SKIP=12）
CHECK-KOTLIN-TEST-COUNT PASSED（SKIP=0；…）
```

而且那道官方 overlay 门禁**对它一条异议都没有**（下面第三节会看到它只报了我 A1 那一条）。

---

## 三、★ 官方 overlay 门禁抓到我 A1 的一处**真错** —— 是我的补丁错
同一轮 run 里，**最后一道官方门禁**判红，只报一条：

```
ENGINE-OVERLAY CHECK FAILED（1 项）:
- [patch-marker] 缺失: required-sections-A1
  (usr/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-system-prompt/lib/types/index.d.ts)
```

**根因两条机器读数相乘**（不是推断）：

| # | 位置 | 逐字 |
|---|---|---|
| ㈠ | `scripts/build-snapshot-013.mjs:1134` | `extensionDelete`: @deepseek-ai/dsh 子树的 **.d.ts** ——「Node 执行 lib/*.js，**类型声明不参与执行**」⇒ 快照**故意删掉**这些文件 |
| ㈡ | `scripts/check-engine-overlay.mjs:139` | `for (const path of [patch.target, ...(patch.additionalTargets ?? [])])` ⇒ 每个声明的目标都**必须**在**已出货的快照里**带 marker |

⇒ 我最初给 A1 **既改了 `.d.ts`、又把它写进 `additionalTargets`**，而那个文件在出货前被删掉
⇒ **marker 永远不可能在场** ⇒ 官方门禁必红。

**这条要记我账上**：我在交件76 里把"公开类型面同步补 `required?: boolean`"当成 A1 的一部分交付，
还因此**多声明了一个目标** —— 而对这个产品，**`.d.ts` 根本不上平板**，它不是契约的一部分。

**修法（`ac4f80c`）**：把 `.d.ts` 从补丁里**整个摘掉** ——
不是"不声明它却继续打它"（那等于把目标从门禁面前藏走，是另一种不诚实），而是**真不打它**：
- `required-sections-A1.mjs`：删掉 types 计划与 types marker，把这条踩坑写进模块头注；
- `apply-patches.mjs`：删 `additionalFiles`，check 只看运行时 marker；
- `registry.json`：删 `additionalTargets`，provenance 记下上面两条行号与结论；
- 回归测试：把原来那条「类型面补上了」换成**反回归钉** —— 断言登记项**没有** `additionalTargets`、
  且补丁没写出任何 `.d.ts`，免得以后有人再加回来；
- 夹具随之少一个文件（49→48），`dsh-system-prompt-0.2.0-rc.2/lib/types/index.d.ts` 消失。

**★ 这是一条通用陷阱，不止 A1**：任何把 `.d.ts`（或其他被 `extensionDelete` 清掉的扩展名）
放进 `additionalTargets` 的补丁都会踩。现在有行号与反回归钉可查。

**A1 能力本身没受影响**：`required` 是运行时行为，改的是 `lib/index.js`；回归 15 项全过
（含原来的「缺席即抛」「complete 覆盖时也判红」「注册路径仍原样保存对象」）。

---

## 三·五、★★ 更要紧的一条：**A4 的两条补丁在设备上本来会被整份覆盖 ⇒ 等于没修**

A1 那处修好之后（同一 run 里 `ENGINE-OVERLAY CHECK PASSED（437 包版本断言 + presets 在场）`），
下一道门禁又抓到一处，**这条比 A1 那条严重得多**：

```
CHECK-RUNTIME-ASSETS FAILED：运行时资产缺少同源补丁 marker（该补丁在设备上会被本资产整份覆盖 ⇒ 等于没修）：
session-persistence-jsonl-index.js：缺 generation-failure-A4 的 marker
session-persistence-jsonl-index.js：缺 truncated-first-frame-A4 的 marker
```

**机制**：`app/src/main/assets/patched/*` 是**预打补丁副本**，引擎启动时由
`EngineManager.applyAssetPatch(...)`（`EngineManager.kt:1260-1266`）**整份覆盖运行树**。
所以 A4② / A4① 两条补丁**虽然进了快照**，一到平板就会被那份旧资产盖掉 ——
**构建期 marker 全绿，设备上却没有这个修复。**

★ 这不是新坑，是**同一个坑第二次**：`check-runtime-assets.mjs` 头注逐字记着上一次
——「F7 进了快照，但 `assets/patched/` 那份是 9-11 的旧文件，启动时把 F7 静默**改了回去**」。
我加补丁时**只想到"进快照"**，没想到"还有第二份副本会盖回来"。这条记我账上。

**修法**（按门禁自己给的判据）：从出厂态夹具按 registry 顺序施加该文件的全部 engine 补丁，
用产物覆盖资产。本轮算出该文件按 registry 顺序是 **4 条**：
`generation-failure-A4 → truncated-first-frame-A4 → spj-migration-link-F5 → publish-exclusive-F7`

★★ **覆盖前我做了安全核对**（不敢直接盖，因为资产可能是手改的）：
用「出厂态 ＋ 旧补丁(F5,F7)」重新生成一份，与**已提交资产**逐字节比对 —— **完全相同（true）**。
⇒ 已提交资产确实是这条生成路径的产物、**没有手改痕迹**，覆盖它是安全的。
（这一步是我这轮最在意的核对：资产一旦被手改过，直接覆盖就是抹掉别人的东西。）

结果：**145,207 → 146,399 字节（+1,192）**，4 个 marker 全部在场；
`git diff` 该资产**恰好 4 个 hunk、+20 −4**，全部是 A4 两条补丁的插入，没有别的改动。

**给你的一条通用判据**：以后**任何**改 `dsh-session-persistence-jsonl` / `dsh-attachment-local` /
`dsh-fs-local` 这三个包的补丁，**都必须同步重生成 `assets/patched/<asset>`**，
否则设备上等于没修。前两个包目前都还没有我的补丁，但那两个资产同样存在（`attachment-local-index.js` 47,937 B、
`fs-local-index.js` 47,826 B）。

---

## 四、链条当前状态（这条线真在往前走）

| run | sha | 死在哪 | 说明 |
|---|---|---|---|
| 38987892728 | `728e137` | `CHECK-KOTLIN-TEST-COUNT`（缺结果） | 方案①之前 |
| 38990106675 | `ce5e025` | **`ENGINE-OVERLAY`**（A1 的 `.d.ts` marker） | **方案①过了** Kotlin 门禁 |
| 38990398434 | `0a10407` | 同上（只剩 A1 那条） | **A4① 三处**在真链上 applied ＋ 幂等 |
| 38991206840 | `d5f67f4` | **`CHECK-RUNTIME-ASSETS`**（资产没跟上） | **A1 修好 ⇒ OVERLAY PASSED（437 包版本断言）** |
| 38992214132 | `2f5f095` | **跑着**（资产已重生成） | 这一轮验它能不能清掉 runtime-assets |

**逐道都在往前走，没有原地打转。**

---

## 五、下一批（按你第三节，不用等你）

- **第 7 条 A7(b) 第一步**（`resolveMeta` 否定缓存**只加诊断**）：待做。
- **第 4 条 A4③**（只按**内容哈希**判"内容真变了"才中断 ＋ **带反证**）：待做。
- **第 5 条 A2①**（页面侧串行链 S1，`dsh-cordis-client-runner` 一个包）：待做。
- **第 8 条**（界面显示待生效清单）：**单开一件**；动之前我先报你打算动哪个文件。
- **第 6 条 A7(a)**：⏸ **还等你复判**（交件80 第二节：实测 34 条 inject 边里 **1 条**指向的不是 client 行
  —— `dsh-client-ui-primitives`，被 5 行注入 ⇒ 按原判会造成 5 条假失败）。

_电脑侧 · 2026-10-17 ｜ 分支 `fix/rc2-engine-bugs-a1-a7` @ `d5f67f4`_
