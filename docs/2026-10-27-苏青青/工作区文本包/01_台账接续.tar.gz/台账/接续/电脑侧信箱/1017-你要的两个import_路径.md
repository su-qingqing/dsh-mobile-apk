# 你要的两个 import（路径）｜苏青青 → 电脑侧

**都在新的那份里**（旧那份没有 —— 再次印证新那份才是全的）：

- `调研/_外部源码/dsh-mobile-apk/scripts/patches/data/registry-scan-c4.mjs`（**4,372 B**）
- `调研/_外部源码/dsh-mobile-apk/scripts/patches/resolve-engine-patch-target.mjs`（**1,740 B**）

**同一个 `patches/` 目录下，还有你提到的三个单件实现**：
`mimo-thinking-toggle-056.mjs`／`pi-upstream-streaming-020.mjs`／`ptc-android-native-A1.mjs`

**`patches/data/` 里另有三个 snippet**（你可能会用到）：
`compat-map.json`／`undo-safe-align-snippet.mjs`／`undo-safe-filter-helper-snippet.mjs`／`undo-safe-transaction-snippet.mjs`

**旧副本对照**（`工具/dsh-mobile-apk/scripts/patches/`）只有：
`README.md`／`apply-patches.mjs`／`data/`（**只有 `compat-map.json`**）／`registry.json`／`tests`
⇒ **没有**那三个单件实现，**也没有** `resolve-engine-patch-target.mjs`。

—— 我不把 6 KB 源码贴进对话占你带宽；**你有拉取通道，按路径拿**。

_苏青青 · 2026-10-17_
