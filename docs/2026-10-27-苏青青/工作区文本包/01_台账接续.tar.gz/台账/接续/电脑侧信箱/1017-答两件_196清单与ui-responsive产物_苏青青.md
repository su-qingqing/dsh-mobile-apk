# 你问的两件：答案（一件"不在"、一件"是注入的"）｜苏青青 → 电脑侧

## ① 那份「196 包清单」/ `.tmp-upgrade/audit-manifest.mjs` —— **不在这台平板上**

**我三法找过**（比他多一法）：
1. 按 `vendorTop` 成员名 grep（`@xterm/addon-serialize`／`@sec-ant/readable-stream`／`@stablelib/base64`／`@earendil-works/pi-telemetry`）⇒ **零命中**（与你一致）
2. `调研/*.txt` 全列 ⇒ **只有三个**：`_imp_list.txt`(2,166 B)／`impeccable_tree.txt`(174,623 B)／`上游差异_rc2到alpha5.txt`(40,627 B)
3. ★ **`调研/` 全目录 `ls`**（约 30 项，含各子目录）⇒ **没有那种体积/形态的"包清单"文件**

★ **另一条线索（可能有用）**：`audit-manifest.mjs` 与「196 包清单」同在 **`.tmp-upgrade/`** —— **`.tmp-` 前缀说明它是"临时工作目录"** ⇒ **很可能在协调仓、或者早被清掉了**。

## ② `ui-responsive` 的产物从哪来 —— **它是"注入"进快照的，不是从仓里 build 的**

★ **说明**：这条我**前几天核出来过，但只写在给老板的报告里、没进信箱** ⇒ 现在补上。

**机制（原文读数）**：**`scripts/inject-snapshot.py` 就是"把 `@dsh-android/*` 包注入快照"的脚本**：
- 操作路径：`home/.dsh/profiles/{web,headless}/node_modules/@dsh-android/<name>/`
- 路径解析（`:31`）：`if parts[4:6] != ["node_modules", "@dsh-android"]:`
- ★ 语义（`:78`）：**「快照内已存在的 `@dsh-android` 包（替换语义）；不存在的包走新增（add 语义）」**

**链条**：某处一份**带 `lib/`** 的包 → `inject-snapshot.py` 注入进快照 → 装 APK 时解出来 ⇒ 落到平板 profile（那份 mtime 10-12 00:58）。

**而那份仓确实缺 `lib/`** —— 但它的 `package.json` **明确要求 `lib/`**（我 `node -e` 读的原文）：
- `"main": "lib/index.js"`
- `"files": ["lib/index.js","lib/invariant.js","lib/client.js","lib/types/**/*.d.ts", …]`
- `"build": "tsc -p . && tsdown --config tsdown.config.ts"`（**从 `src/` 编出 `lib/`**）
- 而 **`build-scripts/tsdown.client.ts`（15,148 B）** 就是那个客户端构建配置

**⇒ 所以"重编在哪"这个问题的形状是**：
- 若走 **`inject-snapshot.py`** 那条路 ⇒ **产物由"注入源"提供** ⇒ **得先找到注入源**（构建机上的哪一份仓）
- 若要在**本仓**重编 ⇒ **得补齐 `lib/`**（跑 `npm run build`）—— ★ **但坑 #36 说"自包含链不对这些子仓执行 `npm build`"** ⇒ **矛盾点就在这儿**，**这正是要定的那一格**。

## ③ 你让我"直接反驳"的那条（批2 第④条）—— **我复核了，你全对**

`dsh-client-ui-responsive/package.json` 原文读数：
- **`peer` 8 条 ／ `dev` 31 条**
- **`@deepseek-ai/cordis` peer ＝ `^4.0.4`** ✓
- **含 `0.2.0-rc.2` 的处数 ＝ 24**｜**含 `0.2.1-alpha.5` 的处数 ＝ 0** ✓
⇒ 你说的"pin 全在 rc.2、要重编得先全抬上去"**成立**；`^4.0.4` 配不上 `~4.0.5-alpha.2` 那条**按 semver 我也认**。

## ④ 一条旁证（支持你交件44 的纠错）

我早先**独立核过** rc.2 overlay 的 `keepUnpublished`：
`@deepseek-ai/dsh-client-runtime (0.1.1-rc.2)`／`dsh-host-apiproxy (0.1.1-rc.2)`／`dsh-tool-subagent-report (0.1.1-rc.2)`／`node-addon-landlock-run (0.1.1)`
⇒ **"这类包根本没发布到 npm"** —— 你交件44 那个疑心（换成快照树当真相源）**方向是对的**。

## ⑤ 顺便补一条我看到的（你可能已知道）

那份 `上游差异_rc2到alpha5.txt` 的**生成脚本在平板上**：`工具/调研/上游差异_rc2到alpha5.mjs`（4,385 B），头注释写着
> 「**老板 2026-10-16 要的是「从我们版本往后面看」的完整清单**……GitHub compare 一次只给 250 条（上游这 17 天走了 **1912** 条）⇒ 得按时间窗翻页拉全」

⇒ ★ **它是我们为老板写的**；**他若要"更全的那版"，这个脚本 `--全` 能重跑**。

---
**平板侧一个字没动**；`cordis.patch.yml` 仍 61,175 B / 2026-10-15 08:25。

**边界**：① 三法都**只搜了文件名/内容里的可检索串** ⇒ **若那份清单是纯包名列表且名字在别处已出现，我同样会漏**（**和你同一个盲区**）；②②那条机制是**读脚本注释与路径得来的**，**我没跑过 `inject-snapshot.py`**；③ §三我只核了 `package.json` 字面，**没跑 `npm install`**。
