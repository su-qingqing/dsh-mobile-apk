# 批1 施工图：rc.2 的补丁在 alpha.5 上还挂不挂得住

> 判法：每块补丁都有「它要替换掉的原代码」（= 出厂快照 vs npm rc.2 的 diff 里的 `减` 行）。
> 拿这段原代码去 **alpha.5 的对应文件**里找：
> **找得到 ⇒ 锚还在、可机械重放；找不到 ⇒ 上游改过这块、补丁要重写。**
> alpha.5 树 = `@deepseek-ai/*@0.2.1-alpha.5`（303 包，全树 0 处 `dsh-mobile` ⇒ 干净、一补丁未打）。

## 结论

| 面 | 块数 | 可机械重放 | 要重写 |
|---|---:|---:|---:|
| **node 侧（12 个文件）** | **56** | **49** | **7** |
| client 侧（3 个文件） | 1997 | —— | —— （压缩包，锚法不可靠，另案） |

**⇒ 批1 的活可以这么拆：`49` 块机械重放 ＋ `7` 块人工重写。**

## 要人工重写的 7 块（逐块）

| 件/文件 | 块 | alpha.5 上的判定 | 锚首行（它要替换的原代码） |
|---|---:|---|---|
| `dsh-client-modules/lib/index.js` | #1 | 改了要重写(前缀3/4) | `import { createRequire } from "node:module";` |
| `dsh-fs-local/lib/index.js` | #3 | 改了要重写(前缀3/4) | `await linkFile(tempPath, absolutePath);` |
| `dsh-fs-local/lib/index.js` | #4 | 锚完全找不到 | `if (!(error instanceof Error && "code" in error && (error.code === "EACCES" || error.cod` |
| `dsh-ptc-runtime-node/lib/index.js` | #2 | 改了要重写(前缀2/4) | `}` |
| `dsh-ptc-runtime-node/lib/index.js` | #3 | 锚完全找不到 | `const packaged = "pkg" in process && this.config.bootstrapPath === void 0;` |
| `dsh-ptc-runtime-node/lib/index.js` | #4 | 改了要重写(前缀3/5) | `const argv = [` |
| `dsh-typert-loader/lib/index.js` | #2 | 锚完全找不到 | `const qualifies = (entryName, mountedNames) => {` |

## node 侧逐件

| 件/文件 | alpha.5 行数 | 块数 | 可重放 | 要重写 | 标签 |
|---|---:|---:|---:|---:|---|
| `dsh-app-boot/lib/index.js` | 3675 | 2 | 2 | 0 | G3 |
| `dsh-client-modules/lib/index.js` | 771 | 11 | 10 | 1 | C4、P1 |
| `dsh-fs-local/lib/index.js` | 687 | 12 | 10 | 2 | (无标签)、F8 |
| `dsh-session-persistence-jsonl/lib/index.js` | 2847 | 4 | 4 | 0 | (无标签)、F7 |
| `node-addon-system/lib/flock.js` | 37 | 1 | 1 | 0 | (无标签)、F3 |
| `dsh-ptc-runtime-node/lib/index.js` | 1626 | 6 | 3 | 3 | A1、L1 |
| `dsh-attachment-local/lib/index.js` | 796 | 4 | 4 | 0 | (无标签) |
| `dsh-client-file-upload/lib/index.js` | 260 | 1 | 1 | 0 | R1 |
| `dsh-llm-pi-ai/lib/index.js` | 2143 | 7 | 7 | 0 | (无标签) |
| `dsh-ptc-runtime-node/lib/process.js` | 927 | 1 | 1 | 0 | A1 |
| `dsh-subprocess-local/lib/runner-launch-B2zsQ1Dz.js` | 1225 | 1 | 1 | 0 | D1 |
| `dsh-typert-loader/lib/index.js` | 330 | 6 | 5 | 1 | C4 |

## 诚实边界

- **`可重放` 的含义**：那段**原代码逐行（规范化后）在 alpha.5 里还在** ⇒ 补丁的替换点没被上游挪走。
  **不等于**重放后行为一定对 —— 版本跨了 rc.2→alpha.5，周边语义可能变了。**每一块重放后仍要过行为验证。**
- **client 侧 3 件不可靠**：alpha.5 的客户端包与出厂快照是两套构建参数，行结构不同，锚法定不了。
  **这 3 件（H1／J1／F6）必须用「按标签注释定位」的办法重放，不能用本件的锚法。**
- **没跑**：本件**一块补丁都没实际重放**。真正重放要在电脑侧建 alpha.5 移动构建的快照之后。
