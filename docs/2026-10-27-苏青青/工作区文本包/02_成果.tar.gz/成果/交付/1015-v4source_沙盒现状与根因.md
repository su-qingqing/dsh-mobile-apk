# v4source · 沙盒现状与根因（1015 · 给下一轮／电脑侧）

## 一 · 我跑到哪了（六步逐格）

| 步 | 状态 | 凭据 |
|---|---|---|
| ① 认路 | ✅ | 这 4 件不在启动路径四条路上 |
| ② 留回头路 | ✅ | `_backup/{四件}.bak-1015-前v4source`，**逐字节核对过**（三对 sha256 全一致） |
| 改动 | ✅ | 13 处（修复器 6／房间 5／补丁模板 1／真源 1）＋ 注释补全 |
| 语法 | ✅ | `node --check` 两个 `.mjs` 全过 |
| ③ **沙盒** | ⚠️ **跑了三次，`rc=1`** | 见下 |
| ④ 双证 | ❌ 没跑（③ 不过就不许往下） |
| ⑤ 同步现役 | ❌ 没做（**所以改动还没生效**） |
| ⑥ 重启后读数 | ❌ 未到 |

## 二 · 沙盒三次的读数（含一次对照）

| 跑的 | 房内 md5 | index.js 行数 | `failed-to-load` | **引擎退出码** |
|---|---|---|---|---|
| 我的改后版 | `bc674048f4e3`（＝候选） | 1755 | **0** | **1** |
| 0928 未改版（**对照**） | `e0bf5bfd00e5`（＝候选） | 1579 | **0** | ★ **1（一样）** |

⇒ ★ **两版都红、红法一模一样** ⇒ **红的根因与我的改动无关**（对照实验的用法：变的是候选，输出不变 ⇒ 红不由候选解释）。

## 三 · 根因（有日志原文）

房内 log 里引擎**真的起来了**，是被 CLI 噎死的：

```
[perf] boot singles=-1 records=56
error: too many arguments. Expected 0 arguments but got 1: 只回答两个字：在的.
【房内】引擎退出码 1
```

引擎自己的用法写着：

```
Usage: dsh [--profile] <name> [options] [app-args...]
  dsh headless "run the tests"       ← answer one task, print the result, and exit
```

⇒ **`headless` 是一个 profile 名，不是参数**。房内脚本写的是
`node bin.js --profile dev "只回答两个字：在的"` ⇒ 那句话被当成 **`dev` profile 的 app-args**，而 dev（从 web 拷来）的 app 不收位置参数 ⇒ `too many arguments` ⇒ **rc=1**。
⇒ ★ 这是**脚本调用形态过时**（0928 的写法在新引擎的 CLI 契约下不成立），**不是插件的问题**。

**另一处过时**（一并记）：
```
cp: cannot stat '…/.dsh/settings.yaml': No such file or directory
```
`$DSH_HOME/settings.yaml` **已废**（只剩 `.imported` 残留）⇒ 那行 `cp` 恒失败，属噪音，但**说明这脚本该整体过一遍**。

## 四 · 下一步（下一轮照着走，不用重摸）

1. ★★ **先纠一条我判错的**：`headless` **是引擎的"内置入口"，不是 profile 名**（记忆 `0mv4ed377`，1012 就记着；我上一版读成 profile 名了）。
   正确用法：**`node $E/lib/bin.js headless "<任务>"`**（**不带 `--profile`**）。
   - 附带（另一回事，别混）：`$DSH_HOME/profiles/headless/cordis.patch.yml:134` 有 YAML **`duplicated mapping key`** ⇒ 那个**同名的用户 profile** 起不来（电脑侧实测：`failed to parse overlay`）。★ 而且它是**什么时候坏的、谁写坏的**没人拦 —— 这比修它更重要。
2. ★★ **六步③的正解不是"硬起整套服务"**（记忆 `0muv7tu08`，1005 三连实测）：房间 `--from-profile web` 只拷 package.json／cordis.patch.yml／pnpm-workspace.yaml ＋ `node_modules` **软链回生产** ⇒ 引擎 loader 解析裸包名的参照系是**引擎树** ⇒ 插件全报 `Cannot find package`、plugin tree failed to load。
   ⇒ **正解＝房间内跑 harness**：`run --name X --quiet -- bash -c 'VAR=… node <harness>'`；证据 JSON 要 **`exitCode=0` 且 `residueFree=true`**（后者我前两次都没拿到）。
   ⇒ 现成模板：`工具/沙盒/试挂点/harness.mjs`；候选用 **`KICKOFF_PLUGIN=<候选副本>`** 那个开关（记忆 `0muv80hqf`）。
   ⇒ ⚠️ 房内坑：**`--quiet` 会把房内脚本 stdout 一起吞掉**；探活判据要 `200` 或 `401`。
3. **房内起引擎必须 `--expose-internals`**（记忆 `0mv4ed377`）：否则报 `dsh: host preparation failed: Cannot find module 'internal/modules/esm/loader'` —— **看起来像缺件，其实是少那个开关**。
4. **电脑侧补的两条**（我采信为线索，改前各自复验一遍）：
   - 房内**缺共享 node_modules 根**：`$HR/profiles/node_modules` 不存在（现在只建了 `profiles/dev/node_modules`）⇒ headless 那些 bundle 解析不到 ⇒ 至少补一条 `ln -s "$PROD/profiles/node_modules" "$HR/profiles/node_modules"`。
   - ★ 脚本把 `cordis.patch.yml` **整个覆盖**了 ⇒ 会**丢掉那个 profile 自己的 patch**（如 Android 适配那一大坨）⇒ 应改成**追加**。
5. `cp "$PROD/settings.yaml"` **恒失败**（`$DSH_HOME/settings.yaml` 已废）⇒ 是噪音；`.credentials.yaml` 在（284 B），留它。
6. ⇒ ★ **修完这些才重跑**；跑到 `rc=0` **且** `residueFree=true` 才算 ③ 过，然后才谈 ④ 双证 → ⑤ 同步现役 → ⑥ 重启。

## 五 · 两条规矩上的自省（我踩了，记下来）

- ⚠️ **`cmd | tail; echo $?` 拿到的是 `tail` 的退出码**（记忆里被摆过 66 次）。我第一次跑就是这么干的、还差点把那个 0 当结论 ⇒ 第二轮改成**输出直接落盘**才对。**别再用管道取退出码。**
- ⚠️ 我看见 `rc=1` 时**第一反应是想说"我的改动坏了"** —— 那是"我以为"。**跑对照**才把它分开。⇒ 这条值得进坑账。

## 六 · 状态一句话

**工作区那几处改净了、语法过了、备份在、沙盒跑了但没跑通（根因在脚本不在改动）⇒ 一个字都没进生产。**
