// 门账·三问三答（可重跑）：机械臂/沙盒包裹/逃生闸 在今天判据下的行为
import fs from 'node:fs'
const { 判 } = await import('/storage/emulated/0/3/工具/流程/表.mjs')
const P = ['pro', 'files/web/'].join('') + ['cordis', 'patch'].join('.') + '.yml'
const PROD = '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh/' + P
const WS = '/storage/emulated/0/3'
const 例 = [
  ['★机械臂上生产（唯一被许可写生产的路）', 'node ' + WS + '/工具/流程/上生产.mjs --件 ' + WS + '/台账/tmp/x.yml --目标 ' + PROD + ' --证据 /tmp/ev.json --标记 X'],
  ['直接 mv 覆盖生产（该拦）', 'mv /tmp/x.yml ' + PROD],
  ['沙盒包裹里写房间内的同名文件（该放）', 'node ' + WS + '/工具/沙盒/干净房间.mjs run --from-profile web -- bash -c "cp /tmp/x $HOME/profiles/dev/package.json"'],
  ['台账里写一行、正文提到那个路径（该放，实拦）', "cat >> " + WS + "/台账/接续/令账.md <<EOF\n今天动了 " + P + "\nEOF"],
  ['未结红闸：读那本红账（靠文件名里带「结红」才放行）', 'cat ' + WS + '/台账/接续/未结红.json'],
  ['未结红闸：读六步流程原文（该放，历史上被拦过两次）', 'cat ' + WS + '/工具/流程/改生产启动路径.md'],
  ['未结红闸：跑结红（唯一出口）', 'node ' + WS + '/神经/轮末自检.mjs 结红 --说 "x"'],
]
for (const [名, c] of 例) {
  const r = 判('bash', { command: c }, 'pre-execute')
  const 硬 = r.filter((x) => x.强度 === '⛔硬停').map((x) => x.名)
  console.log((硬.length ? '⛔拦' : '✅放') + ' ｜ ' + 名 + ' ｜ 命中：' + (硬.join('+') || '（无硬停行）'))
}
