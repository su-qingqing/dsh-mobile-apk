// 门账·回放 —— 把历史上真被拦下来的调用，喂给**今天的** 表.mjs 判一遍
// 回答：这 134 次「改生产启动路径」硬停里，有多少在今天的判据下**仍然该拦**（真拦），
//       有多少**今天会放行**（＝当时的判据比该拦的大 ⇒ 误拦）。
// 只读：不改任何生产件；只 import 判()。
import fs from 'node:fs'

const 原始 = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'))
const { 判 } = await import('/storage/emulated/0/3/工具/流程/表.mjs')

let 仍拦 = 0, 今放 = 0
const 明细 = []
for (const r of 原始) {
  let a = {}
  try { a = JSON.parse(r.参数) } catch (e) { a = {} }
  const rows = 判(r.工具, a, 'pre-execute')
  const 硬 = rows.filter((x) => x.强度 === '⛔硬停').map((x) => x.名)
  const c = a.command || a.file_path || a.old_string || JSON.stringify(a)
  if (硬.length) { 仍拦++; 明细.push({ 结果: '仍拦', 今天: 硬.join('+'), 工具: r.工具, 当时: r.row, 命令: String(c).slice(0, 200) }) }
  else { 今放++; 明细.push({ 结果: '今放行', 今天: rows.map((x) => x.名).join('+') || '（无命中）', 工具: r.工具, 当时: r.row, 命令: String(c).slice(0, 200) }) }
}
console.log('回放条数 =', 原始.length)
console.log('仍被拦 =', 仍拦, ' ｜ 今天会放行 =', 今放, ' ⇒ 误拦率 =', (今放 / 原始.length * 100).toFixed(1) + '%')
const 类 = {}
for (const d of 明细) { const k = d.结果 + '·' + d.工具; 类[k] = (类[k] || 0) + 1 }
console.log(JSON.stringify(类, null, 1))
fs.writeFileSync('/storage/emulated/0/3/台账/分析/门账_回放_1010.json', JSON.stringify(明细, null, 1))
for (const d of 明细.filter((x) => x.结果 === '今放行').slice(0, 40)) console.log('  放行 ｜', d.工具, '｜', d.命令.replace(/\s+/g, ' ').slice(0, 130))
