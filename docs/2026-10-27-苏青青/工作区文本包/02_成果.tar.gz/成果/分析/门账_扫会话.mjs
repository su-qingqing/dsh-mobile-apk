// 门账·扫会话 —— 从会话原文里数「门真拦过几次、拦的是谁、拦的是读还是写」
// 只读：不解压到磁盘，流式解压每一份 session.v3.jsonl.zstd，把 tool/call 与 tool/result 配对。
// 用法：node 台账/分析/门账_扫会话.mjs <会话目录> <输出jsonl>
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'

const 根 = process.argv[2]
const 出 = process.argv[3]

// 门的特征串（与源码逐字对）：deny 时这些串会出现在 tool/result 正文里
const 门特征 = [
  { 门: '出发表·硬停', 串: '⛔【出发表·硬停】' },
  { 门: '未结红·硬停', 串: '上一轮轮末自检留了未结红' },
  { 门: '取＝动作', 串: '取＝动作' },
  { 门: 'HUMAN-DENY', 串: 'HUMAN-DENY' },
  { 门: '缺格路由', 串: '缺格路由' },
]

const 结果 = []

async function 扫一份(p) {
  const sid = path.basename(path.dirname(p))
  return new Promise((res) => {
    const cp = spawn('zstd', ['-dc', p])
    let buf = ''
    const 调用 = new Map()
    cp.stdout.on('data', (d) => {
      buf += d.toString('utf8')
      let i
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1)
        if (!line.trim()) continue
        let j
        try { j = JSON.parse(line) } catch (e) { continue }
        if (j.type === 'tool/call' && j.data) {
          调用.set(j.data.callId, { name: j.data.name, args: j.data.arguments, time: j.time, turn: j.data.turn, step: j.data.step })
        } else if (j.type === 'tool/result' && j.data && j.data.message) {
          const src = j.data.message.source || {}
          const cid = src.callId
          const c = j.data.message.content || []
          let text = ''
          for (const blk of c) for (const t of (blk.content || [])) if (t.type === 'text') text += t.text
          if (!text) continue
          const c0 = 调用.get(cid) || {}
          for (const f of 门特征) {
            if (text.includes(f.串)) {
              // 取该门的判定行
              let 判 = ''
              if (f.门 === '出发表·硬停') {
                const m = text.match(/落在「([^」]+)」的触发面上/)
                判 = m ? m[1] : '(未解析)'
              }
              结果.push({
                sid, 门: f.门, 判, time: new Date(j.time).toISOString(),
                工具: c0.name || '?',
                参数: String(c0.args || '').slice(0, 4000),
                回程头: text.slice(0, 160).replace(/\s+/g, ' '),
              })
            }
          }
        }
      }
    })
    cp.on('close', () => res())
    cp.on('error', () => res())
  })
}

const 文件 = []
for (const d of fs.readdirSync(根)) {
  const f = path.join(根, d, 'session.v3.jsonl.zstd')
  if (fs.existsSync(f)) 文件.push(f)
}
let n = 0
const 并发 = 3
async function 工() { while (文件.length) { const f = 文件.pop(); await 扫一份(f); n++; if (n % 20 === 0) process.stderr.write(`  … ${n}\n`) } }
await Promise.all(Array.from({ length: 并发 }, 工))
fs.writeFileSync(出, 结果.map((r) => JSON.stringify(r)).join('\n') + '\n')
console.log(`扫完 ${n} 份会话 ⇒ ${结果.length} 条门事件 ⇒ ${出}`)
