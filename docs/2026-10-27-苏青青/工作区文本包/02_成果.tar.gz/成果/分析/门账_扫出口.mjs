// 门账·出口用量 —— 数「两道门的出口各被用过几次」：结红（未结红闸的出口）／放行牌（改生产闸的出口）
// 只读：流式解压会话原文，在字符串层找关键词（不解析 JSON，避开转义差异）
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'

const 根 = process.argv[2]
const 模式 = [
  { 名: '结红-表态', 串: '轮末自检.mjs 结红' },
  { 名: '结红-他批', 串: '--他批' },
  { 名: '放行牌-批', 串: '放行.mjs 批' },
  { 名: '放行牌-销', 串: '放行.mjs 销' },
  { 名: '放行牌-看', 串: '放行.mjs 看' },
  { 名: '轮末自检-跑一轮', 串: '轮末自检.mjs 跑一轮' },
  { 名: '取工具-记忆', 串: '坑账.mjs 查' },
]
const 桶 = {}
for (const m of 模式) 桶[m.名] = []
const 写门 = []

function 扫(p) {
  return new Promise((res) => {
    const sid = path.basename(path.dirname(p))
    const cp = spawn('zstd', ['-dc', p])
    let buf = ''
    cp.stdout.on('data', (d) => {
      buf += d.toString('utf8')
      let i
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1)
        for (const m of 模式) {
          let idx = -1
          while ((idx = line.indexOf(m.串, idx + 1)) >= 0) {
            桶[m.名].push({ sid, time: '', 片段: line.slice(Math.max(0, idx - 60), idx + 160) })
          }
        }
        // 顺带：工具调用行里带写的（tool/call 的 name）
        if (line.includes('"type":"tool/call"')) 写门.push({ sid, line })
      }
    })
    cp.on('close', () => res())
    cp.on('error', () => res())
  })
}

const 文件 = []
for (const d of fs.readdirSync(根)) {
  const f = path.join(根, d, 'session.v3.jsonl.zstd')
  if (fs.existsSync(f)) 文件.push(f)
}
// 串行（每个会话内部已是一条流），并发 3
let n = 0
async function 工() { while (文件.length) { await 扫(文件.pop()); if (++n % 20 === 0) process.stderr.write('  …' + n + '\n') } }
await Promise.all([工(), 工(), 工()])

const 汇总 = {}
for (const k in 桶) 汇总[k] = 桶[k].length
console.log('出口用量（会话原文命中次数 · 含正文引用，非纯调用次数）：')
console.log(JSON.stringify(汇总, null, 1))
fs.writeFileSync('/storage/emulated/0/3/台账/分析/门账_出口用量_原始.json', JSON.stringify(桶, null, 1))
console.log('⇒ 台账/分析/门账_出口用量_原始.json')
