// 门账·精确用量 —— 只认**真调用**（tool/call 且 name=bash 且命令匹配），不认正文里提一句
// 另捞：未结红.json 的内容快照（带时间）⇒ 看那条红怎么复活
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'

const 根 = process.argv[2]
const 调用规则 = [
  { 名: '结红', re: /轮末自检\.mjs\s+结红/ },
  { 名: '放行牌·批', re: /放行\.mjs\s+批/ },
  { 名: '放行牌·销', re: /放行\.mjs\s+销/ },
  { 名: '放行牌·看', re: /放行\.mjs\s+看/ },
  { 名: '上生产·机械臂', re: /上生产\.mjs/ },
  { 名: '轮末自检·跑一轮', re: /轮末自检\.mjs\s+跑一轮/ },
]
const 调用 = []
const 快照 = []
const 拒文 = { 结红: [], 放行: [] }

function 扫(p) {
  return new Promise((res) => {
    const sid = path.basename(path.dirname(p))
    const cp = spawn('zstd', ['-dc', p])
    let buf = ''
    const 池 = new Map()
    cp.stdout.on('data', (d) => {
      buf += d.toString('utf8')
      let i
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1)
        let j
        try { j = JSON.parse(line) } catch (e) { continue }
        if (j.type === 'tool/call') {
          let a = {}; try { a = JSON.parse(j.data.arguments || '{}') } catch (e) {}
          const c = String(a.command || '')
          if (j.data.name === 'bash') for (const r of 调用规则) if (r.re.test(c)) 调用.push({ sid, 名: r.名, time: new Date(j.time).toISOString(), 命令: c.slice(0, 300) })
          池.set(j.data.callId, j.data.name)
        } else if (j.type === 'tool/result') {
          const cid = (j.data.message && j.data.message.source || {}).callId
          let text = ''
          for (const b of (j.data.message.content || [])) for (const t of (b.content || [])) if (t.type === 'text') text += t.text
          if (!text) continue
          if (text.includes('未结红.json') && text.includes('"报警"')) {
            快照.push({ sid, time: new Date(j.time).toISOString(), 文: text.replace(/\s+/g, ' ').slice(0, 420) })
          }
        }
      }
    })
    cp.on('close', () => res())
    cp.on('error', () => res())
  })
}

const 文件 = []
for (const d of fs.readdirSync(根)) { const f = path.join(根, d, 'session.v3.jsonl.zstd'); if (fs.existsSync(f)) 文件.push(f) }
let n = 0
async function 工() { while (文件.length) { await 扫(文件.pop()); if (++n % 30 === 0) process.stderr.write('  …' + n + '\n') } }
await Promise.all([工(), 工(), 工()])
const 汇总 = {}
for (const r of 调用) 汇总[r.名] = (汇总[r.名] || 0) + 1
console.log('★ 真调用次数：', JSON.stringify(汇总, null, 1))
fs.writeFileSync('/storage/emulated/0/3/台账/分析/门账_真调用_1010.json', JSON.stringify({ 调用, 快照 }, null, 1))
console.log('快照条数 =', 快照.length)
console.log('⇒ 台账/分析/门账_真调用_1010.json')
