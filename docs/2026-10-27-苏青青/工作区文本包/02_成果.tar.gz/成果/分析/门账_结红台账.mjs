// 门账·结红台账 —— 唯一能重建「同一条红被表过几次态」的地方：会话原文
// 做法：把 `轮末自检.mjs 结红` 的调用与它后面的回程配对，从回程里抠出它当时在结哪几条红。
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'

const 根 = process.argv[2]
const 行 = []

function 扫(p) {
  return new Promise((res) => {
    const sid = path.basename(path.dirname(p))
    const cp = spawn('zstd', ['-dc', p])
    let buf = ''
    const 池 = new Map()
    cp.stdout.on('data', (d) => {
      buf += d.toString('utf8')
      let i
      while ((i = buf.indexOf('\n')) >= 0) {
        const l = buf.slice(0, i); buf = buf.slice(i + 1)
        let j; try { j = JSON.parse(l) } catch (e) { continue }
        if (j.type === 'tool/call') {
          let a = {}; try { a = JSON.parse(j.data.arguments || '{}') } catch (e) {}
          const c = String(a.command || '')
          if (j.data.name === 'bash' && /轮末自检\.mjs\s+结红/.test(c) && /(^|\s|&&|;)node\s/.test(c)) {
            const 说 = (c.match(/--说\s*"([^"]*)"/) || c.match(/--他批\s*"([^"]*)"/) || [, ''])[1]
            池.set(j.data.callId, { sid, time: new Date(j.time).toISOString(), 说: 说.slice(0, 120), 命令: c.slice(0, 200) })
          }
        } else if (j.type === 'tool/result') {
          const cid = (j.data.message && j.data.message.source || {}).callId
          if (!池.has(cid)) continue
          const c0 = 池.get(cid); 池.delete(cid)
          let text = ''
          for (const b of (j.data.message.content || [])) for (const t of (b.content || [])) if (t.type === 'text') text += t.text
          const 红 = [...text.matchAll(/· (.+)/g)].map((m) => m[1].trim()).filter((s) => s.length > 4)
          const 已结 = /已经结过了|已表过态|不用重表/.test(text)
          const 清了 = /账是清的/.test(text)
          行.push({ ...c0, 结果: 清了 ? '账已清' : 已结 ? '已结过' : 红.length ? '结了几条红' : '其它', 红: 红.slice(0, 6) })
        }
      }
    })
    cp.on('close', () => res())
    cp.on('error', () => res())
  })
}
const 文件 = []
for (const d of fs.readdirSync(根)) { const f = path.join(根, d, 'session.v3.jsonl.zstd'); if (fs.existsSync(f)) 文件.push(f) }
let n = 0
async function 工() { while (文件.length) { await 扫(文件.pop()); if (++n % 30 === 0) process.stderr.write('  …' + n + '\n') } }
await Promise.all([工(), 工(), 工()])

const 结果 = {}
for (const r of 行) 结果[r.结果] = (结果[r.结果] || 0) + 1
console.log('★ 结红 真调用 =', 行.length, '｜结果分布 =', JSON.stringify(结果))
// 同一条红被表过几次
const 计数 = {}
for (const r of 行) for (const s of r.红) { const k = s.slice(0, 70); 计数[k] = (计数[k] || 0) + 1 }
const 榜 = Object.entries(计数).sort((a, b) => b[1] - a[1]).slice(0, 15)
console.log('★ 同一条红被表态次数 前 15：')
for (const [k, v] of 榜) console.log('  ' + v + ' 次 ｜ ' + k)
fs.writeFileSync('/storage/emulated/0/3/台账/分析/门账_结红台账_1010.json', JSON.stringify(行, null, 1))
console.log('⇒ 台账/分析/门账_结红台账_1010.json')
