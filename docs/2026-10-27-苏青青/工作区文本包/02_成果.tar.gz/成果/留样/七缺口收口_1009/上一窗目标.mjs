#!/usr/bin/env node
// ── 上一窗目标.mjs —— 把「上一个窗的长期目标（还剩什么）」摆到**开窗第一屏** ─────────────
// 治的病（老板 1009 23:0x 追问）：「**上一个窗口的长期目标还有多少没做完？为什么没有流过来，直接一起做**」。
//   根因：goal 是**按窗存**的（`$DSH_HOME/storages/session_projcache/sessions/session-<窗id>.json`
//   里的 `record.rows.goal.val.current`），**引擎没有跨窗继承** ⇒ 新窗 `get_goal` 直接 `null`，
//   上一窗的目标（哪怕撞满轮数被标 `blocked`）就**掉在地上没人看见**。
// 它只做一件事：**把上一窗的目标摆出来**。**不自动建 goal**（红线 2：东西不许自己冒出来；
//   建 goal ＝ 自动续跑 ⇒ 要老板发话）。
// 用法：node 工具/开工/上一窗目标.mjs [--静] [--本窗=<session-id>]
//   退出码：0＝印出来了（上一窗有目标）｜1＝**没有**（上一窗没建过 goal；`--静` 时**零字**）｜2＝**读不出**（目录／文件坏）
//
// 【四模块耦合】
//   法（判据住在哪）：本文件。真源＝projcache 的 `record.rows.goal.val.current`（别处不许再解析一遍）。
//     ① 「上一窗」怎么认：本窗 id 取 `DSH_SESSION_ID`（或 `--本窗=`）⇒ **排掉本窗**后取 mtime 最新那份。
//        拿不到本窗 id ⇒ 退回「第二新」并在输出里**明说这是猜的**（不许假装知道 —— 坑 `0mupjcspa`）。
//     ② **「没有」与「读不出」必须分开**：上一窗没建过 goal（val 缺席）＝ 退 1；文件在但解不开 ＝ 退 2。
//   记忆（什么时候用它）：开窗第一屏（`工具/开工/库.mjs` 调它）；或老板问「上一窗目标还剩什么」时；
//     或想核「上一窗那个 goal 是不是撞满轮数了」时。
//   神经（怎么自己响）：挂 `库.mjs` 的【上一窗目标】格（**独立 try**；照交接牌那条纪律：
//     「未读到」≠「读不出」）。
//   动作（没做到怎么办）：印出有剩 ⇒ **当场问老板一句"要不要接上"**（不自动建）；读不出 ⇒ 如实印读不出，
//     **不许当成"没有目标"**。
import fs from 'node:fs'
import path from 'node:path'

// ★ 入口守卫（照坑 `0mupkb1z6`：新仪器被 import 时 `process.argv` 还是父进程的 ⇒ 它会替宿主跑一遍
//   并 `process.exit`，把宿主当场掐断）。`库.mjs` 是用 **spawn** 调它的，但守住更稳：被 import 就一个字不做。
//   ⚠️ 判据必须是「**argv[1] 存在且就是本文件名**」——**不许写成 `!argv[1] || …`**：
//      `node -e "import(...)"` 时 `argv[1]` 是 **undefined** ⇒ 那种写法会把它当"直跑"（本窗实测踩到：
//      import 进来照样印＋`process.exit(0)`，把宿主当场掐死）。
const 直接跑 = !!process.argv[1] && process.argv[1].endsWith('上一窗目标.mjs')
if (直接跑) {

const argv = process.argv.slice(2)
const 静 = argv.includes('--静')
const H = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const 目录 = path.join(H, 'storages/session_projcache/sessions')
let 本窗 = process.env.DSH_SESSION_ID || ''
const 给 = argv.find((a) => a.startsWith('--本窗='))
if (给) 本窗 = 给.slice('--本窗='.length)
本窗 = 本窗.replace(/^session-/, '').trim()

let 全部 = []
try {
  全部 = fs.readdirSync(目录)
    .filter((f) => f.startsWith('session-') && f.endsWith('.json'))
    .map((f) => { const p = path.join(目录, f); let m = 0; try { m = fs.statSync(p).mtimeMs } catch {} ; return { f, p, m } })
    .sort((a, b) => b.m - a.m)
} catch { console.log('【上一窗目标】⚠️ **读不出**：projcache 目录打不开（' + 目录 + '）'); process.exit(2) }
if (!全部.length) { if (!静) console.log('【上一窗目标】⚠️ **读不出**：projcache 目录里一个会话缓存都没有'); process.exit(2) }

let 猜 = false
let 目标 = 全部.find((x) => !(本窗 && x.f.includes(本窗)))
if (!目标) { 目标 = 全部[1] || 全部[0]; 猜 = true }
if (!目标) { if (!静) console.log('【上一窗目标】⚠️ **读不出**：只有本窗这一份缓存'); process.exit(2) }

let j = null
try { j = JSON.parse(fs.readFileSync(目标.p, 'utf8')) } catch { console.log('【上一窗目标】⚠️ **读不出**：那份缓存解不开（' + 目标.f + '）—— 「读不出」≠「没有目标」'); process.exit(2) }

const cur = j && j.record && j.record.rows && j.record.rows.goal && j.record.rows.goal.val && j.record.rows.goal.val.current
if (!cur || !cur.goal) { if (!静) console.log('【上一窗目标】上一窗（' + 目标.f.slice(8, 16) + '）**没建过长期目标**（不是读不出）'); process.exit(1) }

const g = cur.goal
const 码 = (g.blockedReason && g.blockedReason.code) || ''
const 态 = g.phase === 'active' ? '还在跑（active）'
  : g.phase === 'blocked' ? ('已停（blocked' + (码 ? ' · ' + 码 : '') + '）' + (码 === 'round-limit' ? '＝**撞满轮数上限**，那个窗再也不会自己跑' : ''))
  : String(g.phase || '（没写状态）')
const 轮 = (cur.roundsStarted != null ? cur.roundsStarted : '?') + '/' + (g.maxGoalRounds != null ? g.maxGoalRounds : '?')
const 末 = cur.updatedAt ? new Date(cur.updatedAt).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false }) : '（没写）'
const 句 = String(g.objective || '（没写目标句）').replace(/\s+/g, ' ')
console.log('【上一窗目标】' + String(g.id || '').slice(0, 17) + ' ｜ ' + 态 + ' ｜ 轮 ' + 轮 + ' ｜ 末更 ' + 末 + (猜 ? ' ｜ ⚠️ 本窗 id 拿不到，「上一窗」是按第二新**猜**的' : ''))
console.log('            目标句：' + (句.length > 96 ? 句.slice(0, 96) + '…' : 句))
console.log('            ⇒ 有剩 ⇒ **要不要接上＝老板说**（我不自动建 goal）：说一句「继续／接着跑」，我就在**本窗**建 goal 接上（红线 2：东西不许自己冒出来）')
process.exit(0)
}  // ← 入口守卫块收尾（被 import 时整块不执行）
