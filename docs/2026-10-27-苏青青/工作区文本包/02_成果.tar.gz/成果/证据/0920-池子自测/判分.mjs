// E1 判分器 · 机器判分（"让模型当眼睛、代码当法官"）· 2026-09-20 苏青青
// 用法：node 判分.mjs <作答文件> A|B
import fs from 'node:fs'
const f = process.argv[2], kind = process.argv[3]
const EXP = {
  A: { Q1:'AP-17', Q2:'MN-04', Q3:'BR-91', Q4:'QING-2026', Q5:'MT-55', Q6:'RV-33',
       Q7:'含「规矩里没给」', Q8:'规矩里没给', Q9:'END-OF-ANSWER' },
  B: { Q1:'AP-17', Q2:'MN-04', Q3:'BR-91', Q4:'QING-2026', Q5:'MT-55', Q6:'RV-33',
       Q7:'含「规矩里没给」', Q8:'规矩里没给', Q9:'<div align="center">', Q10:'END-OF-ANSWER' },
}
const txt = fs.readFileSync(f, 'utf8')
const got = {}
for (const line of txt.split('\n')) { const m = line.match(/^(Q\d+)\s*=\s*(.+?)\s*$/); if (m) got[m[1]] = m[2] }
const exp = EXP[kind]; let ok = 0, bad = []
for (const [q, want] of Object.entries(exp)) {
  const g = got[q] || '（缺）'
  const pass = want.startsWith('含「') ? g.includes(want.slice(1, -1)) : g === want
  if (pass) ok++; else bad.push(`${q}: 期望「${want}」实得「${g}」`)
}
console.log(`【${f.split('/').pop()}】答对 ${ok}/${Object.keys(exp).length}` + (bad.length ? `  错：${bad.join(' ｜ ')}` : '  ✅ 全对'))
