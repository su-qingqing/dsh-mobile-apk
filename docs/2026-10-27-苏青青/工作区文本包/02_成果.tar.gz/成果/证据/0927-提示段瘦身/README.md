# 证据 · 提示段瘦身 A/B（2026-09-27 16:45）

## 一句话
系统提示词里两段**出厂英文**换成中文＋真源指针：**A 段 persona 2,075→1,080 B**、**B 段 undo 插件硬写的那段 2,857→661 B** ⇒ 合计 **省 3,191 B/步 ≈ 732 token/步 ≈ 145 万 token/窗**（按本窗 1,976 步）。**别人插件的源码一个字节没动。**

## 为什么能换掉别人插件写死的段（真源）
`@deepseek-ai/dsh-system-prompt/lib/index.js`
- `:231-232` 注释原文：`A scoped section shadows a global section with the same name` —— 作用域段**盖**同名全局段；
- `:238-240` `section(section)` 用 `this.layers.effect(this.ctx, …)` ⇒ 落在**调用方 ctx 的作用域**；agent preset 就是比全局更内的一层；
- `:112` `.filter((text) => text.length > 0)` ⇒ **`text: ''` ＝ 整段摘掉**（本次没用这条，留着备用）。

## 怎么做的
| | 改法 | 备份 |
|---|---|---|
| A 段 | 预设 `persona.prefix` 英文 2,075 B → 3 行中文（1,080 B）：两份 AGENTS.md 是唯一真源＋我能改写脚下运行时＋宿主/预设两平面＋加载技能 | `_backup/0927-提示段瘦身/agent.cordis.yml.bak-0927-前A段B段`（21,699 B） |
| B 段 | 新建 **`@dsh-user/dsh-prompt-slim`**（1,191 B：读 `config.sections[]` 逐条 `ctx.systemPrompt.section`，try/catch fail-open）＋预设插一行 `- id: prompt-slim` | 同上一份 .bak（预设只此一处改动） |
| 规矩去哪了 | undo 那 12 条规矩**一条没删**，搬进 `台账/做法库.md` 第 1619 行「撤销与安全模式」；覆盖文本留死指针 | 做法库是追加，无破坏 |

## 判据（可重跑）
```sh
node 工具/降本/提示段瘦身_单测.mjs      # 23 条全绿，rc=0
node 工具/台账/冻结.mjs 校验            # 6 条全绿
```
单测里**真跑**了插件（假 ctx 记 section）＋3 条负对照（脏条目被跳过／`section()` 抛也不炸／无 config 空跑不炸）。

## ★ 未证项（诚实记账）
1. **`dsh --profile web --dump-config` 不读 agent preset** ⇒ 它 rc=0 **不构成**预设改动的判据（我先前误用过一次，记为 0mujkpxf）。所以「同名覆盖真的盖住了」目前只有**源码级**证据＋**真跑注册**证据，**没有**渲染后的一枪。
2. 因此生效判据放到**重启后当场量**：新窗系统提示词里应出现「细则真源：`台账/做法库.md`「撤销与安全模式」」，且 `Undo / rollback (dsh-undo-savepoint)` 那句英文应消失。
3. 回退＝删预设 `- id: prompt-slim` 那一行（A 段还原上面那份 .bak）。
