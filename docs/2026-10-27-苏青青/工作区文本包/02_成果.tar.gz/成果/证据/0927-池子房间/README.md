# 池子 · 房间真跑（第三段）· 2026-09-27 21:0x

> **为什么有这个房间**：假 ctx harness（见 `../0927-池子骨架/挂点harness.log`）只能证明**逻辑对**，
> 证不了「**真引擎会不会调它**」。这一段就是补这一格。
> 房间 `池子-2100-20260927121833…` · 端口 3323 · rc=0 · 驱动 `房间驱动.v4.mjs`

## 一、判据（三条全绿）

| # | 判据 | 结果 |
|---|---|---|
| A | 池子插件在**真引擎**里真 apply | ✅ `summary-pool.log`：`已挂上：llm/stream` ＋ `已载入 …/摘要池.mjs` |
| B | **真 Cordis 派发**打中了它并真换了 | ✅ `换：摘要-76bf36a9 ／ 原文 72,019 字节 → 名册 285 字节（缩 99.6%）` |
| C | 派发方看到 messages 真变了 | ✅ 探针：`正文段变名册了吗=true ／ 正文段字节=285` |

**怎么做到的**：房里除了池子插件，还挂了**一个探针插件**（只存在于房间的 `profiles/node_modules/` 里，房外一份都没有）：它在 `apply` 后 2.5s／6s 各打一发 `ctx.waterfall('llm/stream', 假options, () => 'FAKE-STREAM')` ⇒ 用**真引擎的真派发**去打池子那个监听器。两发都中。
**为什么不用真模型**：房间里 `DEEPSEEK_API_KEY` 不在环境里（key 由壳侧注入），而 headless 那份 profile 在房里装不起来（见下）⇒ 真会话这一步**留到生产挂上之后再验**。

## 二、房间里踩到的两件事（都留档）

1. **房内 `node_modules` 必须挂 web 那份**：先挂 headless 那份 ⇒ `Cannot find package '@dsh-user/dsh-summary-pool'`（我的插件住在 web 的 node_modules 里）。
2. **headless profile 在房里装不起来**（老记忆 `0mu7qu2ee` 那条现形）：`Cannot find package '@dsh-android/dsh-android-vdisplay'` ＋ `tool-bash: the mounted bash executor confines but ctx.sandboxPolicy is missing` ⇒ **一次性任务模式**（`dsh --profile dev "<任务>"`）在房里走不通 ⇒ 换探针派发那条路。

## 三、装机三闸门（要请他重启的东西，先过闸）

| 闸 | 结果 |
|---|---|
| `工具/装机闸门/check.mjs <插件目录>` | ✅ 可装（本地目录 ／ 装配方式 非 bundle） |
| `工具/装机闸门/重复插入.mjs` | ✅ 没有重复 id（23 insert ／ 7 id 定向补丁） |
| `工具/装机闸门/装配树.mjs` | ✅ 条目 175 ／ 输出里错误行 0 ／ id 全部唯一 |
| `--profile web --dump-config`（生产） | ✅ rc=0 ／ 19,962 字节（`dumpconfig.生产.txt`） |

## 四、要老板定的一件事（本段**没有**碰生产）

**挂哪一行**：`$DSH_HOME/profiles/web/cordis.patch.yml` 里 `kickoff-gate` 那两行之后，加

```yaml
    - id: summary-pool
      name: '@dsh-user/dsh-summary-pool'
```

**要不要重启**：要 —— 插件行是 apply 期读的。生效后每步那块摘要会变成名册（本窗这块 **15,303 字/步**），
要用时取：`node 工具/池子/池.mjs 取 <id> <段号>`（名册里带着取法）。
**回退**：删掉那两行 ＋ 重启 ⇒ 一切复原（名册只是"这一请求"里的替换，历史那份从没被改过）。

## 五、本段**没验**的（诚实标）

- **真模型那一步**（生产挂上后一条真会话就能看到 summary-pool.log 的「换」行与注入计量下降）。
- 挂着之后「**名册够不够用**」（取回得方不方便、我会不会真的去取）—— 这是要跑几轮才知道的事，不是仪器能判的。

---

## ★ v2（记录层）· 2026-09-27 21:0x 追加 —— **上一版的结论被推翻**

**上一版错在哪**：那份「房间三判据全绿 ／ 72,019 → 285 字节」是拿**手搓可写对象**测的；真引擎里请求**被 deepFreeze**（`dsh-agent-loop/lib/index.js:1204-1217`）且有不变量「请求必须逐字节等于 `session.deriveMessages()`」（`lib/invariant.js:26-28`）⇒ v1 挂 `llm/stream` 改 `options.messages` 在**生产里从未生效**（异常被自己的 try/catch 吞成 fail-open，日志也静默）。**房间绿、生产哑。**

**v2 正解＝记录层**：挂 `agent/pre-step`（先 `await next()`），用 `session.append('user/message', 名册, {surfaceOp:{op:'replace',startSeq:seq,endSeq:seq}, sourceEventSeqs:[seq]})` 把那条检查点在 surface 上换成名册 ⇒ 同一步的请求自然跟着变（`preStep` 在 `step()` 建请求之前）。

**证据文件**：
- `记录层房间_0927.log` —— 新房间 `工具/池子/房间-记录层.mjs` 全跑（**22 条全绿 ／ rc=0**），含 6 条反证。
- 复跑一条命令：`node 工具/池子/房间-记录层.mjs`（房内池子根写在临时目录，不碰生产池子）。
- 判据与退路：见 `profiles/web/cordis.patch.yml` 里 summary-pool 那段注释 ／ 做法库 §五十。
ddbe8c9aefe607964e1c25d2d3f6c3d2  /data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/node_modules/@dsh-user/dsh-summary-pool/lib/index.js
5815d5919522e386a0d7531c372ec993  /data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/node_modules/@dsh-user/dsh-summary-pool/lib/index.js.bak-0927-前改记录层
24db001eb4dc7cbb04aa0076717db1e4  /data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/cordis.patch.yml
97dfe91e0b52de004e3568a6e5b207d1  /data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/cordis.patch.yml.bak-0927-前改池子注释

## 第五节 · 重启后验收红 ⇒ v3 返工（2026-09-27 21:1x）

**红的事实**：v2 挂载成功（`summary-pool.log` 有「已挂上」×8 ＋「已载入 摘要池.mjs」），**生产零动作、日志零行**。
**根因**：幂等判据写在正文里（找 `【池子 · 名册】`），而摘要器把我的源码抄进了检查点正文 —— 真检查点 seq 19951／20155／20292／20409 本体全含该字样 ⇒ 判据恒真 ⇒ 静默跳过。
**v3**：判据改到结构化字段（引擎检查点 `data.source={kind:'plugin',plugin:'compact'}`；我的名册 `{kind:'summary-pool'}`）＋ 加「首步体检」与每条候选留痕。

**本节证据文件**：
- `真样本/真检查点_20409.json`、`真样本/真检查点_20292.json` —— 从本窗 `session.v3.jsonl.zstd` 抽出来的**真事件**（含 `data.source` 来路字段）；
- `真样本/反例_普通user消息_20420.json` —— 不含抬头的反例；
- 判据房间与记录层房间的输出见 `判据房间_0927.txt`、`记录层房间_0927.txt`（本节同时落盘）。
- 复跑：`node 工具/池子/房间-判据.mjs`（13 过 0 红）｜`node 工具/池子/房间-记录层.mjs`（24 项全绿）。
- 回退：插件退回 `lib/index.js.bak-0927-前改v3判据`（＝v2）再重启；或删 `cordis.patch.yml` 里 summary-pool 那两行。

**第六节 · 测量面自己先擦干净（2026-09-27 21:2x）**
- 症状：房间跑一场就往**生产** `$DSH_HOME/summary-pool.log` 写「已挂上：…（记录层 · v3）」——21:18–21:19 有三行（v3 字样）是**房间噪声**，不是生产；判据房间还没设池子根。
- 修：插件日志路径改成每次现算、可被 `DSH_POOL_LOG` 覆盖；两个房间把日志 ＋ 池子根都指到临时目录（`$DSH_HOME/tmp/`、`工具/池子/_房间-池子根*`）。
- 锁：记录层房间新增**反证⑧**「跑一场生产日志字节数不许变」——实测 `生产 8993B → 8993B ／ 房日志 474B` ✅（判据房间 13 过 0 红、记录层房间 rc=0）。
- 历史噪声处置：那三行留着（日志是追加型），**核验收时按时间戳分辨**：13:18:29／13:18:57／13:19:46（UTC）＝房间。
