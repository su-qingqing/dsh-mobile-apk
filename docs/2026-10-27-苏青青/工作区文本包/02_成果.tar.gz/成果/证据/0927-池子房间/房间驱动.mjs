#!/usr/bin/env node
// 池子 · 房间驱动（在干净房间里跑；房外的生产 patch 一个字节都不碰）
// 2026-09-27 立。判据：① 房间里加行后装配仍健康（dump-config rc=0）
//   ② 真跑一步（一次性任务模式） ③ 插件日志里出现「已挂上：llm/stream」＝真引擎真 apply
//   ④ 插件日志里出现「换：摘要-… 原文 N 字节 → 名册 M 字节」＝**这一步真被调到并真换了**
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const R = process.env.DSH_HOME
const E = '/storage/emulated/0/3/台账/证据/0927-池子房间'
const BIN = '/data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/lib/bin.js'
const 记 = []
const 说 = (s) => { console.log(s); 记.push(s) }
fs.mkdirSync(E, { recursive: true })

// ── ① 房间里给池子插件加一行（照 kickoff-gate 那行的形状与缩进）──────────────
const patch = path.join(R, 'profiles/dev/cordis.patch.yml')
let y = fs.readFileSync(patch, 'utf8')
if (!y.includes('dsh-summary-pool')) {
  const 行 = "    - id: summary-pool\n      name: '@dsh-user/dsh-summary-pool'\n"
  const 锚 = "    - id: kickoff-gate\n      name: '@dsh-user/dsh-kickoff-gate'\n"
  if (y.includes(锚)) { y = y.replace(锚, 锚 + 行); 说('① 房间里已加 summary-pool 行（接在 kickoff-gate 之后）') }
  else { y = y.replace(/\s*$/, '\n') + 行; 说('① ⚠️ 没找到 kickoff-gate 锚点 ⇒ 行追加到文件尾（如实记）') }
  fs.writeFileSync(patch, y)
} else 说('① 行已在（上次跑过）')

// ── ② 装配判据（免费）────────────────────────────────────────────────────
const dump = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--dump-config'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 240000 })
fs.writeFileSync(path.join(E, 'dumpconfig.txt'), String(dump.stdout || '') + String(dump.stderr || ''))
说(`② dump-config rc=${dump.status} ／ 字节 ${(String(dump.stdout || '')).length}`)

// ── ③ 真跑一步：把真摘要原文当任务喂进去（它一定是消息里最长的串）──────────
const 样本 = fs.readFileSync(path.join(E, '真摘要样本.txt'), 'utf8')
const 任务 = 样本 + '\n\n（上面那段是压缩摘要原文。请只回三个字：收到了）'
const 跑 = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', 任务], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 420000 })
fs.writeFileSync(path.join(E, '一次性任务.log'), String(跑.stdout || '') + String(跑.stderr || ''))
说(`③ 一次性任务 rc=${跑.status} ／ 输出 ${(String(跑.stdout || '')).length} 字节（详见 一次性任务.log）`)

// ── ④ 插件日志（apply 有没有跑、这一步有没有换）────────────────────────────
const 日志 = path.join(R, 'summary-pool.log')
const 日 = fs.existsSync(日志) ? fs.readFileSync(日志, 'utf8') : '（没有 summary-pool.log ⇒ 插件根本没挂上）'
fs.writeFileSync(path.join(E, 'summary-pool.log'), 日)
说('④ 插件日志：' + (日.trim() ? 日.trim().split('\n').map((l) => l.replace(/^\S+ /, '')).join(' ｜ ') : '（空）'))
说('   判据A 已挂上：' + (日.includes('已挂上：llm/stream') ? '✅' : '❌'))
说('   判据B 真换了：' + (/换：摘要-[0-9a-f]{8}/.test(日) ? '✅ ' + (日.match(/换：摘要-[0-9a-f]{8}[^\n]*/) || [''])[0] : '❌ 没换'))

fs.writeFileSync(path.join(E, '判据.md'), 记.join('\n') + '\n')
console.log('房间=' + (process.env.CLEANROOM || '?'))
