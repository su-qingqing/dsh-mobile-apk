#!/usr/bin/env node
// 池子 · 房间驱动 v2（在干净房间里跑；房外的生产 patch 一个字节都不碰）
// 2026-09-27。判据链：
//   ⓪ 把生产 profile（headless）与配置搬进房间（照 0927-七件那次的跑.sh，同样做法）
//   ① 只在**房间的** patch 里给池子插件加一行（照 kickoff-gate 那行的形状与缩进）
//   ② 装配健康：dump-config rc=0
//   ③ 真跑一步：一次性任务模式（`--profile dev "<任务>"`），任务正文＝真摘要原文（含抬头）
//   ④ 插件日志：出现「已挂上：llm/stream」＝真引擎真 apply；出现「换：摘要-…」＝这一步真被调到并真换了
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const R = process.env.DSH_HOME
const REAL = path.join(process.env.HOME, '.dsh')
const E = '/storage/emulated/0/3/台账/证据/0927-池子房间'
const BIN = '/data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/lib/bin.js'
const 记 = []
const 说 = (s) => { console.log(s); 记.push(s) }
fs.mkdirSync(E, { recursive: true })
fs.mkdirSync(path.join(R, 'profiles/dev'), { recursive: true })

// ── ⓪ 搬 profile 与配置（**只读生产、只往房间里写**）────────────────────────
for (const f of ['package.json', 'cordis.patch.yml', 'pnpm-workspace.yaml', 'cordis.yml']) {
  try { fs.copyFileSync(path.join(REAL, 'profiles/headless', f), path.join(R, 'profiles/dev', f)) } catch { 说('⚠️ 缺 ' + f) }
}
try { fs.symlinkSync(path.join(REAL, 'profiles/headless/node_modules'), path.join(R, 'profiles/dev/node_modules')) } catch { }
try { fs.cpSync(path.join(REAL, '.agent-presets'), path.join(R, '.agent-presets'), { recursive: true }) } catch { 说('⚠️ 预设没搬进来') }
for (const f of ['settings.yaml', '.credentials.yaml', 'models-store.json']) {
  try { fs.copyFileSync(path.join(REAL, f), path.join(R, f)) } catch { 说('⚠️ 缺 ' + f) }
}
try { fs.copyFileSync('/storage/emulated/0/3/AGENTS.md', path.join(R, 'AGENTS.md')) } catch { }
说('⓪ 房间装配好了：' + fs.readdirSync(R).join(' '))
说('   房内 profile：' + fs.readdirSync(path.join(R, 'profiles/dev')).join(' '))
说('   模型 key 在环境变量里吗（只看有没有，不打印值）：' + (process.env.DEEPSEEK_API_KEY ? '有' : '没有 ⇒ 这一步会走到 adapter 才失败，但挂点仍会被调到'))

// ── ① 只在房间里加池子那一行 ───────────────────────────────────────────────
const patch = path.join(R, 'profiles/dev/cordis.patch.yml')
let y = fs.readFileSync(patch, 'utf8')
if (!y.includes('dsh-summary-pool')) {
  const 行 = "    - id: summary-pool\n      name: '@dsh-user/dsh-summary-pool'\n"
  const 锚 = /^(\s*- id: kickoff-gate\s*\n\s*name: '@dsh-user\/dsh-kickoff-gate'\s*\n)/m
  if (锚.test(y)) { y = y.replace(锚, (m) => m + 行); 说('① 房间里已加 summary-pool 行（接在 kickoff-gate 之后）') }
  else { y = y.replace(/\s*$/, '\n') + 行; 说('① ⚠️ 没找到 kickoff-gate 锚点 ⇒ 行追加到文件尾（如实记）') }
  fs.writeFileSync(patch, y)
} else 说('① 行已在')

// ── ② 装配判据（免费）────────────────────────────────────────────────────
const dump = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--dump-config'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 240000 })
const dump文 = String(dump.stdout || '') + String(dump.stderr || '')
fs.writeFileSync(path.join(E, 'dumpconfig.txt'), dump文)
说(`② dump-config rc=${dump.status} ／ 输出 ${dump文.length} 字节`)
if (/[Ee]rror|Cannot find|失败/.test(dump文)) 说('   ⚠️ dump 输出里有可疑字样（全文在 dumpconfig.txt）')

// ── ③ 真跑一步（任务正文＝真摘要原文）────────────────────────────────────
const 样本 = fs.readFileSync(path.join(E, '真摘要样本.txt'), 'utf8')
const 任务 = 样本 + '\n\n（上面那段是压缩摘要原文。请只回三个字：收到了）'
const 跑 = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', 任务], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 420000 })
const 跑文 = String(跑.stdout || '') + String(跑.stderr || '')
fs.writeFileSync(path.join(E, '一次性任务.log'), 跑文)
说(`③ 一次性任务 rc=${跑.status} ／ 输出 ${跑文.length} 字节`)
说('   模型回话（截 200 字）：' + 跑文.replace(/\s+/g, ' ').slice(0, 200))

// ── ④ 插件日志 ───────────────────────────────────────────────────────────
const 日志 = path.join(R, 'summary-pool.log')
const 日 = fs.existsSync(日志) ? fs.readFileSync(日志, 'utf8') : '（没有 summary-pool.log ⇒ 插件根本没挂上）'
fs.writeFileSync(path.join(E, 'summary-pool.log'), 日)
说('④ 插件日志：' + (日.trim() ? 日.trim().split('\n').map((l) => l.replace(/^\S+ /, '')).join(' ｜ ') : '（空）'))
说('   判据A 真引擎真 apply（已挂上：llm/stream）：' + (日.includes('已挂上：llm/stream') ? '✅' : '❌'))
说('   判据B 这一步真被调到并真换了：' + (/换：摘要-[0-9a-f]{8}/.test(日) ? '✅ ' + (日.match(/换：摘要-[0-9a-f]{8}[^\n]*/) || [''])[0] : '❌ 没换'))

fs.writeFileSync(path.join(E, '判据.md'), 记.join('\n') + '\n')
console.log('房间=' + (process.env.CLEANROOM || '?'))
