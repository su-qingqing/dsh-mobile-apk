#!/usr/bin/env node
// 池子 · 房间驱动 v4（**不需要模型**的真跑法）
// 2026-09-27。v3 的教训：房里的 headless profile 装不起来（缺 @dsh-android/* ＋
//   `tool-bash: the mounted bash executor confines but ctx.sandboxPolicy is missing`，老记忆 0mu7qu2ee 那条），
//   而一次性任务模式必须过它 ⇒ 换路：**在房里再挂一个探针插件**，它在真引擎里用 `ctx.waterfall('llm/stream', …)`
//   主动打一发 ⇒ 证明「真 Cordis 派发会不会调到池子那个监听器、改了 messages 算不算数」。
// 判据：① 装配健康 dump-config rc=0 ② 真引擎起得来
//   ③ 池子插件在真引擎里 apply 了（summary-pool.log：「已挂上：llm/stream」）
//   ④ 真派发打中了它并真换了（探针日志：messages 里出现【池子 · 名册】＋ summary-pool.log 出现「换：摘要-…」）
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const R = process.env.DSH_HOME
const REAL = path.join(process.env.HOME, '.dsh')
const E = '/storage/emulated/0/3/台账/证据/0927-池子房间'
const BIN = '/data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/lib/bin.js'
const 记 = []
const 说 = (s) => { console.log(s); 记.push(s) }
fs.mkdirSync(E, { recursive: true })
fs.mkdirSync(path.join(R, 'profiles/dev'), { recursive: true })

// ── ⓪ 搬 **web** profile（那是本机唯一装得起来的那份）与配置 ────────────────
for (const f of ['package.json', 'cordis.patch.yml', 'pnpm-workspace.yaml', 'cordis.yml']) {
  try { fs.copyFileSync(path.join(REAL, 'profiles/web', f), path.join(R, 'profiles/dev', f)) } catch { 说('⚠️ 缺 ' + f) }
}
try { fs.symlinkSync(path.join(REAL, 'profiles/web/node_modules'), path.join(R, 'profiles/dev/node_modules')) } catch { }
try { fs.cpSync(path.join(REAL, '.agent-presets'), path.join(R, '.agent-presets'), { recursive: true }) } catch { 说('⚠️ 预设没搬进来') }
for (const f of ['settings.yaml', '.credentials.yaml', 'models-store.json']) {
  try { fs.copyFileSync(path.join(REAL, f), path.join(R, f)) } catch { 说('⚠️ 缺 ' + f) }
}
try { fs.copyFileSync('/storage/emulated/0/3/AGENTS.md', path.join(R, 'AGENTS.md')) } catch { }
说('⓪ 房间装配好了：' + fs.readdirSync(R).join(' '))

// ── ⓪b 把探针插件放进**房间自己的** profiles/node_modules（房外一个字节不写）──
const 探针目录 = path.join(R, 'profiles/node_modules/@dsh-user/dsh-pool-probe')
fs.mkdirSync(探针目录, { recursive: true })
fs.writeFileSync(path.join(探针目录, 'package.json'), JSON.stringify({ name: '@dsh-user/dsh-pool-probe', version: '1.0.0', private: true, type: 'module', main: 'index.js' }, null, 2))
fs.writeFileSync(path.join(探针目录, 'index.js'), `
import fs from 'node:fs'
export const name = '@dsh-user/dsh-pool-probe'
export function apply(ctx) {
  const 日志 = (s) => { try { fs.appendFileSync(process.env.DSH_HOME + '/pool-probe.log', new Date().toISOString() + ' ' + s + '\\n') } catch { } }
  const 抬头 = 'This is an automatically generated checkpoint condensing an earlier span of the conversation to free up context.'
  const 正文 = '## A 段\\n' + '这是一段很长的正文。'.repeat(1200) + '\\n## B 段\\n' + '另一段同样长的正文。'.repeat(1200)
  日志('探针已挂上')
  const 打一发 = (序号) => {
    const options = { provider: 'probe', model: 'probe', messages: [
      { role: 'system', content: [{ type: 'text', text: '系统提示词（不动）' }] },
      { role: 'user', content: [{ type: 'text', text: 抬头 }, { type: 'text', text: 正文 }] },
    ] }
    try {
      const 出 = ctx.waterfall('llm/stream', options, () => 'FAKE-STREAM')
      const 换后 = options.messages[1].content[1].text
      日志('第' + 序号 + '发：waterfall 返回=' + 出 + ' ／ 正文段变名册了吗=' + 换后.includes('【池子 · 名册】') + ' ／ 正文段字节=' + Buffer.byteLength(换后, 'utf8'))
    } catch (e) { 日志('第' + 序号 + '发 炸：' + (e && e.message)) }
  }
  setTimeout(() => 打一发(1), 2500)   // 等池子插件把模块 import 完
  setTimeout(() => 打一发(2), 6000)
}
`)
说('⓪b 探针插件已放进房间：' + path.relative(R, 探针目录))

// ── ① 房间里给两个插件加行（照 kickoff-gate 那行的形状与缩进）──────────────
const patch = path.join(R, 'profiles/dev/cordis.patch.yml')
let y = fs.readFileSync(patch, 'utf8')
const 锚 = /^(\s*- id: kickoff-gate\s*\n\s*name: '@dsh-user\/dsh-kickoff-gate'\s*\n)/m
const 新行 = "    - id: summary-pool\n      name: '@dsh-user/dsh-summary-pool'\n    - id: pool-probe\n      name: '@dsh-user/dsh-pool-probe'\n"
if (!y.includes('dsh-summary-pool')) {
  if (锚.test(y)) { y = y.replace(锚, (m) => m + 新行); 说('① 已加两行（summary-pool ＋ pool-probe），接在 kickoff-gate 之后') }
  else { y = y.replace(/\s*$/, '\n') + 新行; 说('① ⚠️ 没找到 anchor ⇒ 追加到文件尾（如实记）') }
  fs.writeFileSync(patch, y)
} else 说('① 行已在')

// ── ② 装配判据 ───────────────────────────────────────────────────────────
const dump = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--dump-config'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 240000 })
fs.writeFileSync(path.join(E, 'dumpconfig.v4.txt'), String(dump.stdout || '') + String(dump.stderr || ''))
说(`② dump-config rc=${dump.status}`)

// ── ③ 真起一次引擎（探针在 apply 期自己打两发）────────────────────────────
const 跑 = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--port', '3323', '--no-open'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 30000 })
const 跑文 = String(跑.stdout || '') + String(跑.stderr || '')
fs.writeFileSync(path.join(E, '房间引擎.log'), 跑文)
说(`③ 引擎起过（rc=${跑.status}，124＝活到被掐＝正常）／ 输出 ${跑文.length} 字节`)
说('   起没起来（找 web 地址）：' + (/http:\/\/127\.0\.0\.1:3323/.test(跑文) ? '✅ 起了' : '❌ 没看到地址'))

// ── ④ 两本日志 ───────────────────────────────────────────────────────────
for (const [名, 文件] of [['池子插件', 'summary-pool.log'], ['探针', 'pool-probe.log']]) {
  const p = path.join(R, 文件)
  const 文 = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '（没有 ' + 文件 + '）'
  fs.writeFileSync(path.join(E, 文件), 文)
  说('④ ' + 名 + '日志：' + (文.trim() ? 文.trim().split('\n').map((l) => l.replace(/^\S+ /, '')).join(' ｜ ') : '（空）'))
}
const 池日 = fs.existsSync(path.join(R, 'summary-pool.log')) ? fs.readFileSync(path.join(R, 'summary-pool.log'), 'utf8') : ''
const 探日 = fs.existsSync(path.join(R, 'pool-probe.log')) ? fs.readFileSync(path.join(R, 'pool-probe.log'), 'utf8') : ''
说('   判据A 真引擎真 apply（已挂上：llm/stream）：' + (池日.includes('已挂上：llm/stream') ? '✅' : '❌'))
说('   判据B 真派发打中了它并真换了：' + (/换：摘要-[0-9a-f]{8}/.test(池日) ? '✅ ' + (池日.match(/换：摘要-[0-9a-f]{8}[^\n]*/) || [''])[0] : '❌ 没换'))
说('   判据C 探针那边看到 messages 变了：' + (/正文段变名册了吗=true/.test(探日) ? '✅' : '❌'))

fs.writeFileSync(path.join(E, '判据.v4.md'), 记.join('\n') + '\n')
console.log('房间=' + (process.env.CLEANROOM || '?'))
