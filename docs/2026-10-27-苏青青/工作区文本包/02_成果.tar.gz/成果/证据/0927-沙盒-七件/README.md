# 沙盒测试 · 0927 重启批次 7 件（房间 `七件-1751-20260927095127-29275` · 端口 3314 · **rc=0**）
跑于 2026-09-27 17:51（干净房间 `工具/沙盒/干净房间.mjs run --name 七件-1751 … --keep --quiet -- sh 台账/证据/0927-沙盒-七件/跑.sh`）
房间把生产的 `profiles/web/*`（package.json／cordis.patch.yml／pnpm-workspace.yaml ＋ **node_modules 走 symlink**）与 `.agent-presets/` 原样搬进去 ⇒ 房内跑的就是生产那份。

## 一、七件逐条：验到什么程度（★ 每条都写清"没验的部分"）
| 件 | 判据 | 结论 |
|---|---|---|
| ① 门插件＋预设门行 | 预设 yaml 解析 ok（34 条插件行，含 `tool-gate`）＋ 引擎真起得来（`boot.log` 只有 dsh-router 那条既有告警） | ✅ 在位（**没验**：族表运行行为 —— 门机制单测已 rc=0 全绿） |
| ② 摘要 `maxTokens: 4096` | 预设**第 177 行**、属 `compaction-basic` 行 | ✅ 在位（**没验**：真压缩行为，需真模型） |
| ③ `reinject: false` | 宿主装配 dump **行 619** 在场；生产 patch 行 209 原文也核过 | ✅ 在位 |
| ④ 记忆指南编号断档 | 文本件，房间不验 | ⏳ 重启后开窗当场看 |
| ⑤ `fs/write-intent` 感受器 | **真身当场查清**：事件发得出去 —— `dsh-tool-fs/lib/index.js:650` 与 `dsh-tool-str-replace-editor/lib/index.js:144` 都用 `ctx.waterfall('fs/write-intent',…)` 发；死的是**插件侧监听** `dsh-kickoff-gate/lib/index.js:1377`。账本 `台账/接续/写意图.jsonl` 10 条，末条 `2026-09-24T20:40:31.980Z` ＝ **本地 09-25 04:40**（UTC，先 +8 再判新旧） | ⏳ 重启看能否重挂（兜底 mtime 一直在用） |
| ⑥ A/B 提示段瘦身 | 预设 **21,263 B → 16,899 B**；`prompt-slim` 行在场；yaml 解析 ok | ✅ 在位（**没验**：渲染级文本，须真会话） |
| ⑦ 开工简报投递 8s→30s | 不是房间验的，是**仪器验的**：`神经/闸门自测.mjs` 四跑 **全绿 153/153**（J8 自动投递 ✅／J9 同会话不重复 ✅／J10 新会话重投 ✅） | ✅ 已验证 |

## 二、唯一免费装配判据
`DSH_HOME=<房间> node --expose-internals <dsh>/lib/bin.js --profile dev --dump-config` ⇒ **rc=0**，落盘 `dumpconfig.txt`（**20,250 B**，与上次 4 件那次同字节数）。真起引擎：`timeout 60 … --port 3314` ⇒ 打出 `dsh web: http://127.0.0.1:3314/?token=…` ⇒ 活着 ✓。

## 三、这间房**没验到**的（诚实标）
- ②④⑥ 都是**渲染级/行为级**：房间里没有可用模型，跑不了真会话 ⇒ 只能验"配置在位"。**判据留到重启后开窗第一轮**（看记忆指南是否变成 4./5.、压缩摘要上限、A/B 段实际字数）。
- `--dump-config` 只出**宿主** base 层，**看不到 agent 预设里的 maxTokens／tool-gate／prompt-slim** —— 这是正常的，不是没生效。

## 四、审计噪音（不是故障）
房间报 `软链异常 482`：那是**我自己** `ln -s` 挂 `profiles/web/node_modules` 造成的（房内每个包都成了新软链），孤儿进程 0、端口已释放。
