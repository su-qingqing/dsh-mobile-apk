#!/bin/sh
R="$DSH_HOME"
[ -n "$R" ] || { echo "❌ 房间没给 DSH_HOME"; exit 1; }
echo "房=$R"
mkdir -p "$R/profiles/dev"
for f in package.json cordis.patch.yml pnpm-workspace.yaml; do cp "$HOME/.dsh/profiles/web/$f" "$R/profiles/dev/$f" 2>/dev/null || echo "❌缺 $f"; done
[ -e "$R/profiles/dev/node_modules" ] || ln -s "$HOME/.dsh/profiles/web/node_modules" "$R/profiles/dev/node_modules"
[ -d "$R/.agent-presets" ] || cp -a "$HOME/.dsh/.agent-presets" "$R/" 2>/dev/null || echo "❌预设没搬进来"
for f in settings.json settings.yaml .credentials.yaml models-store.json; do cp "$HOME/.dsh/$f" "$R/$f" 2>/dev/null; done
cp /storage/emulated/0/3/AGENTS.md "$R/AGENTS.md" 2>/dev/null
echo "── 房间顶层 ──"; ls "$R" | tr '\n' ' '; echo
echo "── 预设目录 ──"; ls "$R/.agent-presets" 2>/dev/null | tr '\n' ' '; echo
E=/storage/emulated/0/3/台账/证据/0927-沙盒-七件
Y=/data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/node_modules/yaml/dist/index.js
echo "── 判据A：预设 yaml 解析 ＋ 关键行在场 ──"
node -e '
const yaml=require(process.argv[1]),fs=require("fs");
const p=process.env.DSH_HOME+"/.agent-presets/suqingqing/agent.cordis.yml";
const s=fs.readFileSync(p,"utf8");
try{ yaml.parse(s); console.log("✅ yaml 解析 ok · 字节 "+s.length) }catch(e){ console.log("❌ yaml 解析炸："+e.message); process.exit(0) }
const ids=[...s.matchAll(/^\s*-\s*id:\s*([a-zA-Z0-9@/_.-]+)/gm)].map(m=>m[1]);
console.log("插件行 "+ids.length+" 条："+ids.join(" · "));
console.log("含 tool-gate："+ids.some(x=>/tool-gate/.test(x))+"｜含 prompt-slim："+ids.some(x=>/prompt-slim/.test(x)));
console.log("maxTokens 在场："+/maxTokens/.test(s)+"｜摘要 maxTokens 值："+(s.match(/maxTokens:\s*(\d+)/)||[])[1]);
' "$Y"
echo "── 判据B：免费装配判据 dump-config ──"
BIN=/data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/lib/bin.js
cd "$R/profiles" && DSH_HOME="$R" timeout 120 node --expose-internals "$BIN" --profile dev --dump-config > $E/dumpconfig.txt 2>&1; echo "dump rc=$?"
echo "reinject 命中 "$(grep -c "reinject" $E/dumpconfig.txt)" 处｜dump 字节 "$(wc -c < $E/dumpconfig.txt)
grep -n "reinject" $E/dumpconfig.txt | head -2
echo "── 判据C：真起一次引擎（60s 后掐＝活着）──"
cd "$R/profiles" && DSH_HOME="$R" timeout 60 node --expose-internals "$BIN" --profile dev --port 3314 --no-open > $E/boot.log 2>&1; echo "boot rc=$?（124=活到被掐 ✓）"
grep -n "apply(v3.2)\|tool-gate\|prompt-slim\|prompt-slim\|slim\|错\|Error" $E/boot.log | head -8
echo "── boot.log 字节 "$(wc -c < $E/boot.log)
