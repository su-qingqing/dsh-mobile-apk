# 沙盒测试 · 0927 重启批次 4 件（房间 `门真跑-20260927070537-31603` · job bash-8 · 端口 3312）
跑于 2026-09-27 16:21–16:26（**09-27 17:52 更正**：原写 16:36 是错的。这个窗口按房间 `门真跑-20260927070537-31603` 里 `undo-snapshots/auto/20260927-162115-c6a5/`＋末件 `home/model-capability.log` 16:26 现算）

## 一、被测的三份文件：房间 vs 生产 **逐字节相同**
| 文件 | 结论 |
|---|---|
| `agent.cordis.yml`（21,263 B · 含 `maxTokens: 4096` 与门行） | `diff -q` **同** ✓ |
| `profiles/*/cordis.patch.yml`（含 `reinject: false` 行 209） | `diff -q` **同** ✓ |
| `@dsh-user/dsh-tool-gate/lib/index.js`（17,162 B · 0 处自证残留） | `diff -q` **同** ✓（房间经 symlink 挂的就是生产那份） |

## 二、跑起来的结果
1. 房间按这份配置**起得来**：`http=401`（活着，要 token）✓
2. **唯一免费装配判据**：`DSH_HOME=<房间> node bin.js --profile dev --dump-config` ⇒ **rc=0** ✓（落盘 `dumpconfig-房间-0927.txt`，20,250 B）
3. 解析出的宿主配置里 **`reinject: false` 在场**（dump 行 619）✓
4. 房间活体 15:59 那次已量：工具面 **37 件／31,800 B** ✓（同一份配置）

## 三、**没验到的（诚实标）**
- `maxTokens: 4096` 只做了**配置在位**验证（预设行 190）；**行为验证需要一次真压缩且摘要 >4096 token** ⇒ 房间里没有可用模型 ⇒ **没跑**。回退＝删那一行。
- 宿主 dump 里看不到 `maxTokens`／`tool-gate` 是**正常的**：这两处在 **agent 预设**里，不是宿主装配（宿主那份 dump 只出 base 层）。
