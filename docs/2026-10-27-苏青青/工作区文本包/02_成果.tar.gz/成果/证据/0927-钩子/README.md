# 钩子重挂 · 证据 · 2026-09-27 21:0x–22:5x

> **老板令**（09-27 19:4x）：「**先继续做成本优化，做完成本优化以后，再把这个钩子重挂给做掉**」，理由他亲口给了：
> 「**你说那个（轮末）自检只能保当前窗……保不了交接那边的问题吧，保不了新窗口那边吧**」。
> 所以这一件的目标不是"账本多几行字"，是：**跨窗、交接侧也查得到"改过哪些"**。

## 一、根因（房间实测定的案，不是猜）

`fs/write-intent` / `fs/edit-intent` 是 **waterfall**（串行中间件）：**前一条不调 `next()` 就把后面全掐掉**。

- Cordis 源码（`@deepseek-ai/cordis/lib/index.js:317`）写着：*"a listener that does not call next() vetoes the rest of the chain"*。
- 房间里回读 `_hooks['fs/write-intent']`：**3 条，arity = 3,3,2** —— 那条 arity=2（**不收 next**）就是上游的 `dsh-fs-observation-policy`；
  它注册在 kickoff-gate 之前 ⇒ **kickoff-gate 那两条 intent 监听器永远轮不到**（所以生产里账本从 09-24 起一个字没长、日志里连 fail-open 都没有）。
- 判据：探针按 `dsh-tool-fs` 的形状真派发，**返回的不是我兜底的 `FALLBACK` 而是 `{}`** ⇒ 链子在中间就被别人接走并终止了。

## 二、修法（三处，都在 `@dsh-user/dsh-kickoff-gate`）

| 改 | 为什么 |
|---|---|
| 两条 intent 监听器加 **`{ prepend: true }`** | 跑到链首 ⇒ 不再被上游那条 arity=2 的截断（它照旧跑，我们只是先记一笔） |
| 两条 intent 监听器补 **`mkdirSync(dirname(...))`** | 目录不在时原来那句 `appendFileSync` 是**静默失败**（房内实测：账本一个字没生） |
| **新增** `session/event` ＋ `tool/call` 记一笔 | 这是**平播事件**（`ctx.emit`，不看注册先后、不会被谁掐）⇒ 双保险；参数里有**工具名 ＋ file_path**，`session.id` 当"谁"；注册带 **`{ global: true }`**（跨作用域都收得到） |

备份：`_backup/0927-钩子重挂/index.js.bak-0927-前加session-event钩子`｜`…前加prepend与global`｜`…前老钩子补mkdir`
（另两份为过程件：`_backup/0927-钩子重挂/新块_session-event.js`）

## 三、判据（房间真跑三跑，全绿）

| 跑 | 验什么 | 结果 |
|---|---|---|
| v7 | 链子构成 | ✅ `_hooks['fs/write-intent']` arity=3,3,2 ／ prepend=true,true,false（说明 prepend 落位） |
| v8b | **老钩子（prepend 后）在真引擎里记不记账** | ✅ 房内账本出现 `{"p":"…/_钩子探针.txt","k":"k1","who":"session-探针"}` |
| v9 | **新钩子（session/event）记不记账** | ✅ 账本出现 `{"kind":"tool","tool":"write",…}` 与 `{"kind":"tool","tool":"edit",…}`；反证：`bash` 那条**不记** |

日志：`hook-probe.log` ／ `判据.v7.md`、`判据.v8.md`、`判据.v9.md` ／ `房间引擎*.log` ／ `dumpconfig*.txt`
（房里的 kickoff-gate 行被指到房间内 `config.workspace` ⇒ **生产账本一个字节没动**）

## 四、没验的（诚实标）

- **生产真会话**：插件源码改动**要重启**才吃到。重启后判据两条：① 用文件工具改一个文件 ⇒ `台账/接续/写意图.jsonl` 应有新行（`kind: tool` ＋ 工具名 ＋ 路径 ＋ 会话 id）；② `轮末自检` 报的"改过哪些"应与账本能对上。
- **交接侧/新窗侧真的用得上**：还得看下一窗读不读这本账（这一层是"人/流程"的事，不是仪器能判的）。

---

## 五、重启后·生产实测（2026-09-27 20:48 那次重启之后）——**两条路都活了**

判据跑法：用**文件工具**（write）落下两个探针文件 ⇒ 看账本。

| 判据 | 结果 |
|---|---|
| 账本多没多行 | ✅ 10 条 → **14 条**（两次写各出两行：`{"kind":"tool","tool":"write",…}` 来自**新钩子** session/event；无 kind 那条来自**终于能跑到的老钩子** fs/write-intent） |
| who 对不对 | ✅ `session-0b98df7d-de15-4040-b3cc-b1378a034fdd`（本会话） |
| 对账仪器 | ✅ 从 ❌ 变 **rc=0**（`台账 14 条 ／ 末条 20:48 ／ 近24h 4 条`） |
| 插件日志 | ✅ 零 fail-open；`apply(v3.2): …workspace=/storage/emulated/0/3` |

**交接侧那一格也补上了**：`工具/开工/库.mjs`（新窗开工第一屏）现在印
`【改过哪些】写意图账 16 条 ／ 末条 09-27 12:49Z ／ 近24h 6 条` —— 老板的原话是「保不了交接那边的问题吧，
保不了新窗口那边吧」，所以光把钩子修好不够，**得有人在新窗把它念出来**（改前实测：这本账只有轮末自检和沙盒在读）。
备份 `_backup/0927-钩子重挂/库.mjs.bak-0927-前加改过哪些格`；对账仪器 `神经/写意图对账.mjs`（自测 4/4，含两条反证）。
**口径提醒**：盘上近 24h「改过 321 件」与账本 4 条不冲突 —— 账本只记**走文件工具**的写，那 300 多件里大部分是脚本/引擎写的记账件（自动记账.json、每轮必读.json…）。
