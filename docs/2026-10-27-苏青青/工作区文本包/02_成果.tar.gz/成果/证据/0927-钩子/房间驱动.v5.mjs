#!/usr/bin/env node
// 钩子重挂 · 房间驱动 v5（**fs/write-intent 到底能不能调到 kickoff-gate 那个监听器**）
// 2026-09-27。背景：生产里我用 write 工具真写过文件，`台账/接续/写意图.jsonl` 毫无反应、日志也没有 fail-open。
//   静态看：插件 apply 那行自报 workspace=/storage/emulated/0/3 ⇒ 守卫该过 ⇒ 嫌疑落在「**监听器根本没被调到**」。
// 本实验：房里的 kickoff-gate 行**改成把 workspace 指到房间内**（生产账本一个字不动），
//   再用探针插件按 dsh-tool-fs 的调用形状真派发 `ctx.waterfall('fs/write-intent', …)`。
// 判据：A 探针真派发了（自己的日志）｜B 房内账本出现探针那一行 ⇒ 监听器**能被真派发调到**
//      ｜C 房内 kickoff-gate.log 有没有 fs-hook fail-open ｜D 顺带证明房内路径可写
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const R = process.env.DSH_HOME
const REAL = path.join(process.env.HOME, '.dsh')
const E = '/storage/emulated/0/3/台账/证据/0927-钩子'
const BIN = '/data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/lib/bin.js'
const 记 = []
const 说 = (s) => { console.log(s); 记.push(s) }
fs.mkdirSync(E, { recursive: true })
fs.mkdirSync(path.join(R, 'profiles/dev'), { recursive: true })

// ── ⓪ 搬 web profile ＋ 配置 ───────────────────────────────────────────────
for (const f of ['package.json', 'cordis.patch.yml', 'pnpm-workspace.yaml', 'cordis.yml']) {
  try { fs.copyFileSync(path.join(REAL, 'profiles/web', f), path.join(R, 'profiles/dev', f)) } catch { 说('⚠️ 缺 ' + f) }
}
try { fs.symlinkSync(path.join(REAL, 'profiles/web/node_modules'), path.join(R, 'profiles/dev/node_modules')) } catch { }
try { fs.cpSync(path.join(REAL, '.agent-presets'), path.join(R, '.agent-presets'), { recursive: true }) } catch { }
for (const f of ['settings.yaml', '.credentials.yaml', 'models-store.json']) {
  try { fs.copyFileSync(path.join(REAL, f), path.join(R, f)) } catch { }
}
try { fs.copyFileSync('/storage/emulated/0/3/AGENTS.md', path.join(R, 'AGENTS.md')) } catch { }
说('⓪ 房间装配好了')

// ── ① 房里的 kickoff-gate 行：workspace 指到房间内（生产账本不动）──────────
const patch = path.join(R, 'profiles/dev/cordis.patch.yml')
let y = fs.readFileSync(patch, 'utf8')
const 锚 = "    - id: kickoff-gate\n      name: '@dsh-user/dsh-kickoff-gate'\n"
if (y.includes(锚) && !y.includes('workspace: ' + "'" + R + "'")) {
  y = y.replace(锚, 锚 + "      config:\n        workspace: '" + R + "'\n")
  说('① 房里的 kickoff-gate 行已加 config.workspace = ' + R)
  // 顺手加探针那一行
  y = y.replace(锚 + "      config:\n        workspace: '" + R + "'\n", 锚 + "      config:\n        workspace: '" + R + "'\n    - id: hook-probe\n      name: '@dsh-user/dsh-hook-probe'\n")
  fs.writeFileSync(patch, y)
} else 说('① ⚠️ 没找到 kickoff-gate 锚点或是改过了（如实记）')

// ── ①b 探针插件（只存在于房间）────────────────────────────────────────────
const 探针 = path.join(R, 'profiles/node_modules/@dsh-user/dsh-hook-probe')
fs.mkdirSync(探针, { recursive: true })
fs.writeFileSync(path.join(探针, 'package.json'), JSON.stringify({ name: '@dsh-user/dsh-hook-probe', version: '1.0.0', private: true, type: 'module', main: 'index.js' }, null, 2))
fs.writeFileSync(path.join(探针, 'index.js'), `
import fs from 'node:fs'
export const name = '@dsh-user/dsh-hook-probe'
export function apply(ctx) {
  const L = process.env.DSH_HOME + '/hook-probe.log'
  const 记 = (s) => { try { fs.appendFileSync(L, new Date().toISOString() + ' ' + s + '\\n') } catch { } }
  const 账 = process.env.DSH_HOME + '/台账/接续/写意图.jsonl'
  记('探针已挂上')
  setTimeout(() => {
    // 先证明这条房内路径写得进去（不然 B 判据分不清是钩子没调到还是盘写不了）
    try { fs.mkdirSync(process.env.DSH_HOME + '/台账/接续', { recursive: true }); fs.appendFileSync(账, JSON.stringify({ at: new Date().toISOString(), kind: 'probe-selfwrite', p: '探针自写' }) + '\\n'); 记('自写测试：房内账本可写 ✅') } catch (e) { 记('自写测试：写不进去 ❌ ' + e.message) }
    const target = { targetKey: 'hook-probe-1', displayPath: '/storage/emulated/0/3/工具/池子/_钩子探针.txt' }
    const actor = { sessionId: 'session-探针' }
    try { const 出 = ctx.waterfall('fs/write-intent', target, actor, () => 'NO-LISTENER'); 记('派发 fs/write-intent ⇒ 返回=' + JSON.stringify(出)) } catch (e) { 记('派发 fs/write-intent 炸：' + (e && e.message)) }
    try { const 出2 = ctx.waterfall('fs/edit-intent', target, actor, () => 'NO-LISTENER'); 记('派发 fs/edit-intent ⇒ 返回=' + JSON.stringify(出2)) } catch (e) { 记('派发 fs/edit-intent 炸：' + (e && e.message)) }
    try { const 内 = fs.readFileSync(账, 'utf8'); 记('此刻房内账本行数=' + 内.trim().split('\\n').length + ' ／ 末条=' + 内.trim().split('\\n').slice(-1)[0].slice(0, 160)) } catch (e) { 记('读账本失败：' + e.message) }
  }, 3000)
}
`)
说('①b 探针放进房间：' + path.relative(R, 探针))

// ── ② 装配判据 ───────────────────────────────────────────────────────────
const dump = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--dump-config'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 240000 })
fs.writeFileSync(path.join(E, 'dumpconfig.txt'), String(dump.stdout || '') + String(dump.stderr || ''))
说('② dump-config rc=' + dump.status)

// ── ③ 真起一次引擎（探针在 apply 后 3 秒自己派发）──────────────────────────
const 跑 = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--port', '3324', '--no-open'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 25000 })
const 跑文 = String(跑.stdout || '') + String(跑.stderr || '')
fs.writeFileSync(path.join(E, '房间引擎.log'), 跑文)
说('③ 引擎起过 rc=' + 跑.status + ' ／ 起了吗=' + (/http:\/\/127\.0\.0\.1:3324/.test(跑文) ? '✅' : '❌'))

// ── ④ 收三本账 ───────────────────────────────────────────────────────────
const 抄 = (名, 文件) => {
  const p = path.join(R, 文件)
  const 文 = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '（没有 ' + 文件 + '）'
  fs.writeFileSync(path.join(E, 名), 文)
  return 文
}
const 探日 = 抄('hook-probe.log', 'hook-probe.log')
const 账本 = 抄('房内写意图.jsonl', '台账/接续/写意图.jsonl')
const 闸日 = 抄('房内kickoff-gate.log', 'kickoff-gate.log')
说('④ 探针日志：' + 探日.trim().split('\n').map((l) => l.replace(/^\S+ /, '')).join(' ｜ '))
说('   房内账本：' + (账本.startsWith('（') ? 账本 : 账本.trim().split('\n').length + ' 行 ／ 末条 ' + 账本.trim().split('\n').slice(-1)[0].slice(0, 150)))
说('   kickoff-gate.log 里 fs-hook fail-open：' + (闸日.includes('fs-hook fail-open') ? '❌ 有（' + (闸日.match(/fs-hook fail-open[^\n]*/) || [''])[0].slice(0, 120) + '）' : '没有'))
说('   判据B 监听器被真派发调到（账本出现探针那一行）：' + (/hook-probe-1|_钩子探针/.test(账本) ? '✅' : '❌ 账本里没有探针那一行'))

fs.writeFileSync(path.join(E, '判据.v5.md'), 记.join('\n') + '\n')
console.log('房间=' + (process.env.CLEANROOM || '?'))
