#!/usr/bin/env node
// 钩子重挂 · 房间驱动 v6（验两件：① 老钩子为什么断 ② 新钩子（session/event·tool/call）在真引擎里记不记账）
// 2026-09-27。做法＝探针派发法（做法库 §四十七）。房里的 kickoff-gate 行 workspace 指到房间内 ⇒ 生产账本一个字不动。
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const R = process.env.DSH_HOME
const REAL = path.join(process.env.HOME, '.dsh')
const E = '/storage/emulated/0/3/台账/证据/0927-钩子'
const BIN = '/data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/lib/bin.js'
const 记 = []
const 说 = (s) => { console.log(s); 记.push(s) }
fs.mkdirSync(E, { recursive: true })
fs.mkdirSync(path.join(R, 'profiles/dev'), { recursive: true })

// ── ⓪ 搬 web profile ＋ 配置 ───────────────────────────────────────────────
for (const f of ['package.json', 'cordis.patch.yml', 'pnpm-workspace.yaml', 'cordis.yml']) {
  try { fs.copyFileSync(path.join(REAL, 'profiles/web', f), path.join(R, 'profiles/dev', f)) } catch { 说('⚠️ 缺 ' + f) }
}
try { fs.symlinkSync(path.join(REAL, 'profiles/web/node_modules'), path.join(R, 'profiles/dev/node_modules')) } catch { }
try { fs.cpSync(path.join(REAL, '.agent-presets'), path.join(R, '.agent-presets'), { recursive: true }) } catch { }
for (const f of ['settings.yaml', '.credentials.yaml', 'models-store.json']) {
  try { fs.copyFileSync(path.join(REAL, f), path.join(R, f)) } catch { }
}
try { fs.copyFileSync('/storage/emulated/0/3/AGENTS.md', path.join(R, 'AGENTS.md')) } catch { }
说('⓪ 房间装配好了')

// ── ① 房里的 kickoff-gate 行：workspace 指到房间内（生产账本不动）＋加探针行 ──
const patch = path.join(R, 'profiles/dev/cordis.patch.yml')
let y = fs.readFileSync(patch, 'utf8')
const 锚 = /(^ *- id: kickoff-gate\r?\n *name: '@dsh-user\/dsh-kickoff-gate'\r?\n)/m
if (锚.test(y)) {
  const 命中 = y.match(锚)[1]
  const 换行 = 命中.includes('\r\n') ? '\r\n' : '\n'
  const 加 = '      config:' + 换行 + "        workspace: '" + R + "'" + 换行 + '    - id: hook-probe' + 换行 + "      name: '@dsh-user/dsh-hook-probe'" + 换行
  fs.writeFileSync(patch, y.replace(锚, 命中 + 加))
  说('① 房里 kickoff-gate 行已指到房间内 ＋ 探针行已加')
} else 说('① ⚠️ 锚点没匹配（如实记）')

// ── ①b 探针（只存在于房间）────────────────────────────────────────────────
const 探针 = path.join(R, 'profiles/node_modules/@dsh-user/dsh-hook-probe')
fs.mkdirSync(探针, { recursive: true })
fs.writeFileSync(path.join(探针, 'package.json'), JSON.stringify({ name: '@dsh-user/dsh-hook-probe', version: '1.0.0', private: true, type: 'module', main: 'index.js' }, null, 2))
fs.writeFileSync(path.join(探针, 'index.js'), `
import fs from 'node:fs'
export const name = '@dsh-user/dsh-hook-probe'
export function apply(ctx) {
  const L = process.env.DSH_HOME + '/hook-probe.log'
  const 记 = (s) => { try { fs.appendFileSync(L, new Date().toISOString() + ' ' + s + '\\n') } catch { } }
  const 账 = process.env.DSH_HOME + '/台账/接续/写意图.jsonl'
  记('探针已挂上')
  // ① 链子语义：三个监听器（A 带 next ／ B 不带 next ／ C 带 next）—— 看 B 会不会把链子掐掉
  ctx.on('fs/write-intent', (t, a, next) => { 记('A（带 next）被调到'); return next() })
  ctx.on('fs/write-intent', () => { 记('B（不带 next）被调到'); return { B: 1 } })
  ctx.on('fs/write-intent', (t, a, next) => { 记('C（带 next）被调到'); return next() })
  ctx.on('fs/observed', () => { 记('O（fs/observed 平播）被调到') })
  setTimeout(() => {
    const target = { targetKey: 'k1', displayPath: '/storage/emulated/0/3/工具/池子/_钩子探针.txt' }
    const actor = { sessionId: 'session-探针' }
    try { ctx.waterfall('fs/write-intent', target, actor, () => 'FALLBACK') ; 记('派发 fs/write-intent 完成（返回见下）') } catch (e) { 记('派发 fs/write-intent 炸：' + (e && e.message)) }
    try { ctx.emit('fs/observed', target, { kind: 'present' }, actor) ; 记('派发 fs/observed 完成') } catch (e) { 记('派发 fs/observed 炸：' + (e && e.message)) }
    // ② 模拟一次 write 工具调用（真形状：session/event ＋ tool/call ＋ arguments 是 JSON 串）
    try {
      ctx.emit('session/event', { id: 'session-探针' }, { type: 'tool/call', seq: 1, data: { turn: 1, step: 1, callId: 'c1', name: 'write', arguments: JSON.stringify({ file_path: '/storage/emulated/0/3/工具/池子/_钩子探针.txt', content: 'x' }) } })
      记('派发 session/event（write）完成')
    } catch (e) { 记('派发 session/event（write）炸：' + (e && e.message)) }
    try {
      ctx.emit('session/event', { id: 'session-探针' }, { type: 'tool/call', seq: 2, data: { turn: 1, step: 1, callId: 'c2', name: 'edit', arguments: JSON.stringify({ file_path: '/storage/emulated/0/3/台账/在办.md', old_string: 'a', new_string: 'b' }) } })
      记('派发 session/event（edit）完成')
    } catch (e) { 记('派发 session/event（edit）炸：' + (e && e.message)) }
    try {
      const 文 = fs.readFileSync(账, 'utf8')
      记('此刻房内账本 ' + 文.trim().split('\\n').length + ' 行，全文＝' + JSON.stringify(文))
    } catch (e) { 记('读账本失败：' + e.message) }
  }, 3000)
}
`)
说('①b 探针放进房间')

// ── ② 装配判据 ＋ ③ 真起引擎 ─────────────────────────────────────────────
const dump = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--dump-config'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 240000 })
fs.writeFileSync(path.join(E, 'dumpconfig.v6.txt'), String(dump.stdout || '') + String(dump.stderr || ''))
说('② dump-config rc=' + dump.status)
const 跑 = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--port', '3326', '--no-open'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 22000 })
const 跑文 = String(跑.stdout || '') + String(跑.stderr || '')
fs.writeFileSync(path.join(E, '房间引擎.v6.log'), 跑文)
说('③ 引擎起过 rc=' + 跑.status + ' ／ 起了吗=' + (/http:\/\/127\.0\.0\.1:3326/.test(跑文) ? '✅' : '❌'))

// ── ④ 收日志与账本 ───────────────────────────────────────────────────────
const 抄 = (名, 文件) => {
  const p = path.join(R, 文件)
  const 文 = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '（没有 ' + 文件 + '）'
  fs.writeFileSync(path.join(E, 名), 文)
  return 文
}
const 探日 = 抄('hook-probe.v6.log', 'hook-probe.log')
const 账本 = 抄('房内写意图.v6.jsonl', '台账/接续/写意图.jsonl')
const 闸日 = 抄('房内kickoff-gate.v6.log', 'kickoff-gate.log')
说('④ 探针：' + 探日.trim().split('\n').map((l) => l.replace(/^\S+ /, '')).join(' ｜ '))
说('   判据① 链子语义（A/B/C 谁被调到）：' + ['A', 'B', 'C'].map((x) => x + '=' + (探日.includes(x + '（') ? '被调' : '没调')).join(' '))
说('   判据② 平播事件到没到（O）：' + (探日.includes('O（fs/observed 平播）被调到') ? '✅ 到了' : '❌ 没到'))
说('   判据③ 新钩子在真引擎里记了账：' + (/\"tool\":\"write\"/.test(账本) && /\"tool\":\"edit\"/.test(账本) ? '✅ write 与 edit 两行都在' : '❌ 账本：' + 账本.slice(0, 200)))
说('   kickoff-gate.log 有没有 fail-open：' + (闸日.includes('fail-open') ? (闸日.match(/[a-z-]*fail-open[^\n]*/) || [''])[0].slice(0, 140) : '没有'))

fs.writeFileSync(path.join(E, '判据.v6.md'), 记.join('\n') + '\n')
console.log('房间=' + (process.env.CLEANROOM || '?'))
