#!/usr/bin/env node
// 钩子重挂 · 房间驱动 v6（验两件：① 老钩子为什么断 ② 新钩子（session/event·tool/call）在真引擎里记不记账）
// 2026-09-27。做法＝探针派发法（做法库 §四十七）。房里的 kickoff-gate 行 workspace 指到房间内 ⇒ 生产账本一个字不动。
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const R = process.env.DSH_HOME
const REAL = path.join(process.env.HOME, '.dsh')
const E = '/storage/emulated/0/3/台账/证据/0927-钩子'
const BIN = '/data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/lib/bin.js'
const 记 = []
const 说 = (s) => { console.log(s); 记.push(s) }
fs.mkdirSync(E, { recursive: true })
fs.mkdirSync(path.join(R, 'profiles/dev'), { recursive: true })

// ── ⓪ 搬 web profile ＋ 配置 ───────────────────────────────────────────────
for (const f of ['package.json', 'cordis.patch.yml', 'pnpm-workspace.yaml', 'cordis.yml']) {
  try { fs.copyFileSync(path.join(REAL, 'profiles/web', f), path.join(R, 'profiles/dev', f)) } catch { 说('⚠️ 缺 ' + f) }
}
try { fs.symlinkSync(path.join(REAL, 'profiles/web/node_modules'), path.join(R, 'profiles/dev/node_modules')) } catch { }
try { fs.cpSync(path.join(REAL, '.agent-presets'), path.join(R, '.agent-presets'), { recursive: true }) } catch { }
for (const f of ['settings.yaml', '.credentials.yaml', 'models-store.json']) {
  try { fs.copyFileSync(path.join(REAL, f), path.join(R, f)) } catch { }
}
try { fs.copyFileSync('/storage/emulated/0/3/AGENTS.md', path.join(R, 'AGENTS.md')) } catch { }
说('⓪ 房间装配好了')

// ── ① 房里的 kickoff-gate 行：workspace 指到房间内（生产账本不动）＋加探针行 ──
const patch = path.join(R, 'profiles/dev/cordis.patch.yml')
let y = fs.readFileSync(patch, 'utf8')
const 锚 = /(^ *- id: kickoff-gate\r?\n *name: '@dsh-user\/dsh-kickoff-gate'\r?\n)/m
if (锚.test(y)) {
  const 命中 = y.match(锚)[1]
  const 换行 = 命中.includes('\r\n') ? '\r\n' : '\n'
  const 加 = '      config:' + 换行 + "        workspace: '" + R + "'" + 换行 + '    - id: hook-probe' + 换行 + "      name: '@dsh-user/dsh-hook-probe'" + 换行
  fs.writeFileSync(patch, y.replace(锚, 命中 + 加))
  说('① 房里 kickoff-gate 行已指到房间内 ＋ 探针行已加')
} else 说('① ⚠️ 锚点没匹配（如实记）')

// ── ①b 探针（只存在于房间）────────────────────────────────────────────────
const 探针 = path.join(R, 'profiles/node_modules/@dsh-user/dsh-hook-probe')
fs.mkdirSync(探针, { recursive: true })
fs.writeFileSync(path.join(探针, 'package.json'), JSON.stringify({ name: '@dsh-user/dsh-hook-probe', version: '1.0.0', private: true, type: 'module', main: 'index.js' }, null, 2))
fs.copyFileSync('/storage/emulated/0/3/台账/证据/0927-钩子/探针v3.mjs', path.join(探针, 'index.js'))
说('①b 探针放进房间')

// ── ② 装配判据 ＋ ③ 真起引擎 ─────────────────────────────────────────────
const dump = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--dump-config'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 240000 })
fs.writeFileSync(path.join(E, 'dumpconfig.v6.txt'), String(dump.stdout || '') + String(dump.stderr || ''))
说('② dump-config rc=' + dump.status)
const 跑 = spawnSync('node', ['--expose-internals', BIN, '--profile', 'dev', '--port', '3327', '--no-open'], { cwd: path.join(R, 'profiles'), env: process.env, encoding: 'utf8', timeout: 22000 })
const 跑文 = String(跑.stdout || '') + String(跑.stderr || '')
fs.writeFileSync(path.join(E, '房间引擎.v6.log'), 跑文)
说('③ 引擎起过 rc=' + 跑.status + ' ／ 起了吗=' + (/http:\/\/127\.0\.0\.1:3326/.test(跑文) ? '✅' : '❌'))

// ── ④ 收日志与账本 ───────────────────────────────────────────────────────
const 抄 = (名, 文件) => {
  const p = path.join(R, 文件)
  const 文 = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '（没有 ' + 文件 + '）'
  fs.writeFileSync(path.join(E, 名), 文)
  return 文
}
const 探日 = 抄('hook-probe.v7.log', 'hook-probe.log')
const 账本 = 抄('房内写意图.v7.jsonl', '台账/接续/写意图.jsonl')
const 闸日 = 抄('房内kickoff-gate.v7.log', 'kickoff-gate.log')
说('④ 探针：' + 探日.trim().split('\n').map((l) => l.replace(/^\S+ /, '')).join(' ｜ '))
说('   判据① 链子语义（A/B/C 谁被调到）：' + ['A', 'B', 'C'].map((x) => x + '=' + (探日.includes(x + '（') ? '被调' : '没调')).join(' '))
说('   判据② 平播事件到没到（O）：' + (探日.includes('O（fs/observed 平播）被调到') ? '✅ 到了' : '❌ 没到'))
说('   判据③ 新钩子在真引擎里记了账：' + (/\"tool\":\"write\"/.test(账本) && /\"tool\":\"edit\"/.test(账本) ? '✅ write 与 edit 两行都在' : '❌ 账本：' + 账本.slice(0, 200)))
说('   kickoff-gate.log 有没有 fail-open：' + (闸日.includes('fail-open') ? (闸日.match(/[a-z-]*fail-open[^\n]*/) || [''])[0].slice(0, 140) : '没有'))

fs.writeFileSync(path.join(E, '判据.v7.md'), 记.join('\n') + '\n')
console.log('房间=' + (process.env.CLEANROOM || '?'))
