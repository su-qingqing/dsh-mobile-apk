// 探针 v3（只存在于房间）· 问三件事：
//   ① ctx.on 注册到底成没成（回读 events 服务的 _hooks）
//   ② ctx.waterfall 派发会不会叫到用 ctx.on 注册的监听器
//   ③ ctx.emit（平播）会不会（对照）
// 2026-09-27 立。写法：先注册、立刻回读、再派发、再回读。
import fs from 'node:fs'

export const name = '@dsh-user/dsh-hook-probe'
export const inject = []

export function apply(ctx) {
  const L = process.env.DSH_HOME + '/hook-probe.log'
  const 记 = (s) => { try { fs.appendFileSync(L, new Date().toISOString() + ' ' + s + '\n') } catch { } }
  记('探针v3 已挂上 ／ ctx 有这些键：' + Object.keys(ctx).slice(0, 14).join(','))

  const 回读 = (标) => {
    try {
      const 服 = ctx.events || (ctx.root && ctx.root.events)
      if (!服 || !服._hooks) { 记(标 + ' 回读：拿不到 _hooks（服务在不在＝' + !!服 + '）'); return }
      const 键 = Object.keys(服._hooks).filter((k) => /^(fs|session|agent|tool)\//.test(k))
      记(标 + ' 回读 _hooks：' + (键.length ? 键.map((k) => k + '×' + 服._hooks[k].length).join(' ｜ ') : '（相关事件一个都没有）'))
    } catch (e) { 记(标 + ' 回读炸：' + (e && e.message)) }
  }

  const d1 = ctx.on('fs/write-intent', (t, a, next) => { 记('A（ctx.on 带 next）被调到'); return next() })
  const d2 = ctx.on('fs/write-intent', { global: true }, (t, a, next) => { 记('A2（ctx.on ＋ global:true）被调到'); return next() })
  const d3 = ctx.on('fs/observed', () => { 记('O（fs/observed 平播）被调到') })
  记('注册返回：d1=' + typeof d1 + ' ／ d2=' + typeof d2 + ' ／ d3=' + typeof d3)
  回读('注册后')

  setTimeout(() => {
    const target = { targetKey: 'k1', displayPath: '/storage/emulated/0/3/工具/池子/_钩子探针.txt' }
    const actor = { sessionId: 'session-探针' }
    let 出 = null
    try { 出 = ctx.waterfall('fs/write-intent', target, actor, () => 'FALLBACK') } catch (e) { 记('派发 waterfall 炸：' + (e && e.message)) }
    记('派发结果：' + (typeof 出 === 'object' ? '（对象／promise）' : String(出)))
    try { ctx.emit('fs/observed', target, { kind: 'present' }, actor) } catch (e) { 记('派发 emit 炸：' + (e && e.message)) }
    try {
      const 服 = ctx.events || (ctx.root && ctx.root.events)
      const 钩 = 服 && 服._hooks && 服._hooks['fs/write-intent']
      记('派发后 _hooks[fs/write-intent] 条数=' + (钩 ? 钩.length : '?') + ' ／ 各条 global=' + (钩 ? 钩.map((h) => !!h.global).join(',') : '?'))
    } catch (e) { 记('派发后回读炸：' + (e && e.message)) }
    try {
      const 文 = fs.existsSync(process.env.DSH_HOME + '/台账/接续/写意图.jsonl') ? fs.readFileSync(process.env.DSH_HOME + '/台账/接续/写意图.jsonl', 'utf8') : '（账本还没生）'
      记('账本：' + JSON.stringify(文.slice(0, 300)))
    } catch (e) { 记('读账本炸：' + (e && e.message)) }
  }, 3000)
}
