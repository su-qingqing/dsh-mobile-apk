// 探针 v4（只存在于房间）· 验「prepend 修好没有」＋ 看链上各条的 arity
//   ① 回读 _hooks['fs/write-intent'] 每条 callback.length（带 next 的＝3）
//   ② 真派发一次 ⇒ 打了 prepend 的 kickoff-gate 应当**第一个**被叫到 ⇒ 房内账本应当多一行
//   ③ 再派发一次 session/event 的 tool/call（给桩 session，尽量喂全它要的方法）⇒ 看新钩子那条
// 2026-09-27 立。
import fs from 'node:fs'

export const name = '@dsh-user/dsh-hook-probe'
export const inject = []

export function apply(ctx) {
  const L = process.env.DSH_HOME + '/hook-probe.log'
  const 账 = process.env.DSH_HOME + '/台账/接续/写意图.jsonl'
  const 记 = (s) => { try { fs.appendFileSync(L, new Date().toISOString() + ' ' + s + '\n') } catch { } }
  记('探针v4 已挂上')

  ctx.on('fs/write-intent', (t, a, next) => { 记('P（探针自己，带 next）被调到'); return next() }, { prepend: true })
  记('探针注册返回=' + typeof ctx.on('fs/observed', () => { 记('O（fs/observed）被调到') }))

  setTimeout(() => {
    try {
      const 服 = ctx.events || (ctx.root && ctx.root.events)
      const 钩 = (服 && 服._hooks && 服._hooks['fs/write-intent']) || []
      记('链上 fs/write-intent 共 ' + 钩.length + ' 条：arity=' + 钩.map((h) => (h.callback && h.callback.length)).join(',') + ' ／ prepend=' + 钩.map((h) => !!h.prepend).join(',') + ' ／ global=' + 钩.map((h) => !!h.global).join(',') + ' ／ ctx深度=' + 钩.map((h) => (h.ctx && h.ctx.fiber ? 'f' : '?')).join(','))
    } catch (e) { 记('回读炸：' + (e && e.message)) }

    const target = { targetKey: 'k1', displayPath: '/storage/emulated/0/3/工具/池子/_钩子探针.txt' }
    const actor = { sessionId: 'session-探针' }
    try { ctx.waterfall('fs/write-intent', target, actor, () => 'FALLBACK'); 记('派发 fs/write-intent 完成') } catch (e) { 记('派发 fs/write-intent 炸：' + (e && e.message)) }

    try {
      const 桩 = {
        id: 'session-探针',
        snapshotEvents: () => [],
        events: [],
        seq: 1,
        surface: () => [],
        append: () => ({ seq: 1 }),
        appendEvents: () => [],
        requestHeader: () => undefined,
        messages: () => [],
      }
      ctx.emit('session/event', 桩, { type: 'tool/call', seq: 1, time: Date.now(), data: { turn: 1, step: 1, callId: 'c1', name: 'write', arguments: JSON.stringify({ file_path: '/storage/emulated/0/3/工具/池子/_钩子探针.txt', content: 'x' }) } })
      记('派发 session/event（write）完成')
      ctx.emit('session/event', 桩, { type: 'tool/call', seq: 2, time: Date.now(), data: { turn: 1, step: 1, callId: 'c2', name: 'edit', arguments: JSON.stringify({ file_path: '/storage/emulated/0/3/台账/在办.md', old_string: 'a', new_string: 'b' }) } })
      记('派发 session/event（edit）完成')
    } catch (e) { 记('派发 session/event 炸：' + (e && e.message)) }

    try {
      const 文 = fs.existsSync(账) ? fs.readFileSync(账, 'utf8') : '（账本还没生）'
      记('账本 ' + (文.startsWith('（') ? 文 : 文.trim().split('\n').length + ' 行：' + JSON.stringify(文.slice(-260))))
    } catch (e) { 记('读账本炸：' + (e && e.message)) }
  }, 3000)
}
