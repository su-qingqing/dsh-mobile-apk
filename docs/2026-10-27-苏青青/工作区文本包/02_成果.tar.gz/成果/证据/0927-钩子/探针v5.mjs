// 探针 v5（只存在于房间）· 只验**新钩子**（session/event ＋ tool/call）
//   上两版的教训：整条链 emit 会被别人的监听器打断（它们要真会话对象）；所以这里**直接调那一条 callback**
//   —— 从 `_hooks['session/event']` 里取出 kickoff-gate 注册的那条（带 global 的），单独喂桩数据。
// 判据：房内账本出现 kind:"tool" / tool:"write" 与 tool:"edit" 两行。
// 2026-09-27 立。
import fs from 'node:fs'

export const name = '@dsh-user/dsh-hook-probe'
export const inject = []

export function apply(ctx) {
  const L = process.env.DSH_HOME + '/hook-probe.log'
  const 账 = process.env.DSH_HOME + '/台账/接续/写意图.jsonl'
  const 记 = (s) => { try { fs.appendFileSync(L, new Date().toISOString() + ' ' + s + '\n') } catch { } }
  记('探针v5 已挂上')
  // 让链上多一条已知的 fs/write-intent（顺便再验一次 prepend 生效）
  ctx.on('fs/write-intent', (t, a, next) => { 记('P（探针自己）被调到'); return next() }, { prepend: true })

  setTimeout(() => {
    const 服 = ctx.events || (ctx.root && ctx.root.events)
    const 钩 = (服 && 服._hooks && 服._hooks['session/event']) || []
    记('session/event 链上共 ' + 钩.length + ' 条 ／ global=' + 钩.map((h) => !!h.global).join(','))
    const 桩 = { id: 'session-探针', agent: { id: '探针', agentPreset: 'x' }, snapshotEvents: () => [], events: [], seq: 1 }
    const 造 = (名, 参) => ({ type: 'tool/call', seq: 1, time: Date.now(), data: { turn: 1, step: 1, callId: 'c1', name: 名, arguments: JSON.stringify(参) } })
    let 调了 = 0
    for (const h of 钩) {
      try { h.callback(桩, 造('write', { file_path: '/storage/emulated/0/3/工具/池子/_钩子探针.txt', content: 'x' })); 调了++ } catch (e) { 记('某条 session/event 监听器炸（已吞）：' + (e && e.message)) }
    }
    for (const h of 钩) {
      try { h.callback(桩, 造('edit', { file_path: '/storage/emulated/0/3/台账/在办.md', old_string: 'a', new_string: 'b' })); 调了++ } catch (e) { 记('（同上）' + (e && e.message)) }
    }
    // 反证：非写工具（bash）不该记账
    for (const h of 钩) {
      try { h.callback(桩, 造('bash', { command: 'echo hi' })); 调了++ } catch (e) { }
    }
    记('直接调用 ' + 调了 + ' 次 callback')
    try {
      const 文 = fs.existsSync(账) ? fs.readFileSync(账, 'utf8') : '（账本还没生）'
      记('账本 ' + (文.startsWith('（') ? 文 : 文.trim().split('\n').length + ' 行：' + JSON.stringify(文)))
    } catch (e) { 记('读账本炸：' + (e && e.message)) }
  }, 3000)
}
