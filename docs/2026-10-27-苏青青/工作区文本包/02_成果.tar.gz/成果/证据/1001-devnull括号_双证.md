# 双证 · devnull括号（kickoff-gate 判写器误伤 · 2026-10-01）

**改的是什么**：`writeTargets()` 里重定向目标那句（生产件第 216 行附近）
```js
旧： if (p && p !== '/dev/null' && p.charAt(0) !== '&') paths.push(p)
新： 归一化尾部引号/括号后再判"是不是空设备"（p0 === '/dev/null' 或 /^\/dev\/(stdout|stderr|tty|fd\/\d+)$/）
```
**病根**：命令替换里的 `$(grep … 2>/dev/null)` 会被取成 token `/dev/null)`（**带一个右括号**）⇒ 精确比较落空 ⇒ **只读命令被判成"实现类写入"**。
**案发（本窗实测）**：`kickoff-gate.log` 原文 `MEM-GATE deny bash [bash:/dev/null) /dev/null)"] 未取 N=1` —— 我那条命令只有 `for/grep/sed/echo`，一个写动作都没有。

---

## ① 反证（红）· 生产件上必须红 —— 证明用例真能抓到这件事

命令：`node 神经/闸门自测.mjs`（`GATE_PATH` 缺省 ⇒ 跑生产件本身）
输出（2026-10-01 23:5x）：
```
  ❌ F23 【案发原样】只读探针：循环里 $(grep … 2>/dev/null) → 放行
  ❌ F24 只读探针：单条 $(grep -c … 2>/dev/null) → 放行
通过 160 / 失败 2
```
（另 4 条同组用例在两边都绿：F25 双引号命令替换、F26/F27/F28 三条**对照·绝不能修漏**）

## ② 正证（绿）· 暂存镜像上必须全绿

命令：`GATE_PATH=$DSH_HOME/tmp/闸门暂存-devnull括号/kickoff-gate.index.js node 神经/闸门自测.mjs`
输出（2026-10-01 23:59）：
```
  ✅ F23 【案发原样】只读探针：循环里 $(grep … 2>/dev/null) → 放行
  ✅ F24 只读探针：单条 $(grep -c … 2>/dev/null) → 放行
  ✅ F26/F27/F28 【对照·绝不能修漏】真写实现文件（含带命令替换那种）→ 仍 deny
全绿：162/162
```

★ **镜像是必须的**（本窗踩到并记下）：插件用 `createRequire(import.meta.url)` 读同目录 `claim-lib.mjs`
⇒ 只把 index.js 拷到别处 ⇒ 认领库起不来（fail-open 静默）⇒ 自测 **A9b 假红**。
所以暂存目录＝**镜像**（index.js 打完补丁 ＋ claim-lib.mjs 原样）。第一版就是这么红的，已改。

## ③ 干净房间（流程第 ③ 步）

命令：`node 工具/沙盒/干净房间.mjs run --name 闸门devnull括号 --quiet -- bash -c 'GATE_PATH=<镜像> node /storage/emulated/0/3/神经/闸门自测.mjs'`
读数：**命令退出码 0** ｜ 房间已删 ✅ ｜ 孤儿进程 0 ｜ 白名单外 0 ｜ 软链异常 0
证据 JSON：`工具/沙盒/_证据/闸门devnull括号-20261001155926-11881.json`

## ④ 还没做的那半步（诚实）

生产那一写由 `工具/流程/上生产.mjs --配置 …` 执行（它校证据＋逐字节 md5 核＋核不过自动还原）。
**要重启才生效**（宿主插件）⇒ 记进重启批次；**重启后三项读数**：① F23/F24 在**生产件本尊**上转绿
② 用一条只读探针（`.dsh-kickoff` 之外的 grep 命令）看 `kickoff-gate.log` 里**不再出现** `MEM-GATE deny bash [bash:/dev/null)…`
③ 认领库仍 armed（`claim-store armed` 行仍在）。
