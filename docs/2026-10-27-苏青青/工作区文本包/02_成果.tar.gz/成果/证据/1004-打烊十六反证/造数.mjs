// 打烊 §十六 过期判据 · 反证造数器（私有区用 · 不碰生产）
// 用法：node 造数.mjs <假工作区目录> <锚模式 fresh|old|none> <_at 模式 now|yesterday|missing>
import fs from 'node:fs'
import path from 'node:path'

const [ws, 锚模式, at模式] = process.argv.slice(2)
if (!ws) { console.error('缺参数'); process.exit(2) }
fs.mkdirSync(path.join(ws, '台账/接续'), { recursive: true })
fs.mkdirSync(path.join(ws, '台账/轮末'), { recursive: true })

const now = Date.now()
const p2 = (n) => String(n).padStart(2, '0')
const fmt = (d) => d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes())

if (锚模式 !== 'none') {
  const 起 = 锚模式 === 'fresh' ? now - 600000 : now - 48 * 3600 * 1000
  fs.writeFileSync(path.join(ws, '台账/接续/轮次锚.json'), JSON.stringify({
    本轮起点: 起,
    上轮起点: 起 - 100000,
    写于: new Date(起).toISOString(),
    由: '造数（反证用 · 假锚）'
  }, null, 1))
} else {
  try { fs.unlinkSync(path.join(ws, '台账/接续/轮次锚.json')) } catch {}
}

const at = at模式 === 'now' ? fmt(new Date(now)) : at模式 === 'yesterday' ? fmt(new Date(now - 86400000)) : null
const 件 = {
  资料归集: { 状态: '✅', 说明: '反证造数 · 假装做了' },
  改动细节: { 状态: '✅', 说明: '反证造数 · 假装做了' },
  针归仓: { 状态: '✅', 说明: '反证造数 · 假装做了' },
  话分流: { 状态: '✅', 说明: '反证造数 · 假装做了' }
}
if (at) 件._at = at
fs.writeFileSync(path.join(ws, '台账/接续/手做四件.json'), JSON.stringify(件, null, 1))

console.log('造数完成｜ws=' + ws + '｜锚=' + 锚模式 + '｜_at=' + (at || '（无）'))
