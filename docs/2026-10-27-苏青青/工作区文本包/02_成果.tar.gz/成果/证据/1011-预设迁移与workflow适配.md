# 证据：1011 预设迁移与 workflow 行适配

> 一句话：引擎换代删了「预设＝磁盘目录」机制 ⇒ 把「苏青青」预设原样搬进装配清单（六步）；顺手修掉树里一个**在新引擎里已不存在**的包引用。

## 一、两次上生产（都走《改生产启动路径》六步）

| 序 | 改了什么 | 改前 md5 | 改后 md5 | 沙盒房间（rc=0） | 双证 | 备份 |
|---|---|---|---|---|---|---|
| 1 | `profiles/web/cordis.patch.yml` 末尾追加 `- insert: preset-suqingqing`（老预设树 26KB 原样内联，每行 +10 空格；`skills/` 改绝对路径） | `6e7a73c966486200881a30e48ac7e1a5` | `457df7d5600649db6e25a74993e86ca2` | `预设正证2-20261010221443-23738` | 好候选＝沙盒静默（只 otel 1 条）／坏候选（plugins 写成标量）＝引擎响亮报 `2 entries did not activate` ＋ `ValidationError: invalid config` | `_backup/1011-预设迁移/cordis.patch.yml.bak-1011-前加preset行` |
| 2 | 树里 `- id: workflow-worker-thread / name: @deepseek-ai/dsh-workflow-worker-thread` ⇒ `- id: workflow-ptc / name: @deepseek-ai/dsh-workflow-ptc`（config 不变） | `457df7d5…` | `a3f3b3660e32708f6f707faaa24c4913` | `预设正证3-20261010222303-27454` | 反证①（标量）必红 ✓｜反证②（缺包）＝**静默**（见 §三） | `cordis.patch.yml.bak-1010-前前改workflow行`（机械臂自动）｜源件 `_backup/1011-预设迁移/agent.cordis.yml.bak-1011-前改workflow行` |

- 净变化核对（第 2 次）：逐行 diff ⇒ **只在候选里 6 行**（4 行注释 ＋ `workflow-ptc` 两行）、**只在现产里 2 行**（老的 `workflow-worker-thread` 两行）；其余 728 行一致。
- 复现：`dsh --profile web --dump-config` ⇒ **rc=0、1597 行、`id: preset-` 命中 5 条**（4 条出厂 ＋ `preset-suqingqing`），块内 `workflow-ptc` 在。
- 运行时：`plugin_manager list_plugins` ⇒ `include:preset-suqingqing`／`enabled: true`／**`fiberPhase: active`**（写入后引擎**热重载**，未重启）。

## 二、记忆库（保住连续性资产）

| 项 | 真值 |
|---|---|
| **真身** | `/storage/emulated/0/3/.dsh-meow/memory.db`（源码 `memoryDbPath(workspace)` ⇒ 库在**工作区**下，不在 `$DSH_HOME`） |
| 规模 | 5,562,368 B ｜ 分表：soul 1／user 105／project 665／fact 891／lesson 1695／topic 178／rules 278（＝3,813 条）＋ dream_log 43／windows 86／dream_meta 1 |
| 一致性快照 | `_backup/1011-引擎换代/记忆库/memory.db.1011-工作区真身`（5,361,664 B，`VACUUM INTO`，**总行数 3,944 与现役一致**） |
| ⚠️ 纠偏 | 我 06:1x 那次"记忆库备份"实际备份的是 `$DSH_HOME/.dsh-meow/memory.db`（2.35 MB·10-09，**另一个工作区的旧库**）⇒ **打偏了**，本轮补做正确快照。`cp` 会漏 WAL，必须 `VACUUM INTO`。 |

## 三、判据边界（本轮新发现，重要）

**preset 树里引用一个不存在的包 ⇒ 起引擎这一步完全静默**（反证②实测：把 `@deepseek-ai/dsh-workflow-ptc` 换成不存在的包名，房内日志仍只有已知的 otel 1 条、`dump-config` rc=0、房间 exitCode 0）。
⇒ **「日志里没有 warn」不能当「预设树完整」的证据**。registry 把失败记在 `diagnostic()` / roster 的 `broken` 字段里，只有 **界面卡片** 或 `agentPreset.list` 看得到。

## 四、待验（只有老板能验）

刷新页面 ⇒ 设置 → **Agent 预设** → 「自定义」下应出现 **「苏青青」** 卡（若卡上带红字原因 ⇒ 把那段字发我，那就是 `broken` 的原文，我能直接定位）。

## 五、红线 23 的两格（它是谁写的／下次什么条件会再回来）

- **它是谁写的**：这次**不是谁写坏的** —— 是**引擎换代改了包名**（`@deepseek-ai/dsh-workflow-worker-thread` 在 0.2.0-rc.2 里不存在，同一槽位换名 `@deepseek-ai/dsh-workflow-ptc`）。
- **下次什么条件会再回来**：**引擎再删或再改任一被 preset 树引用的包名** ⇒ 会以「另一行」的形式回来；而且**起引擎这一步完全静默**（本轮拿不存在的包名反证过：日志不响、`--dump-config` rc=0、房间 exitCode 0），只有界面卡的 `broken` 或 `agentPreset.list` 看得见。
- **留下什么保证（机制）**：`工具/装机闸门/预设树对撞.mjs`（1011 造 · 装机闸门同族 · 自检 3/3：正样本必过／坏样本必报／sections 的 name 不算插件）—— **改／迁 preset 树之前跑一次**，把那一格提前量出来；已进 `台账/做法库.md` §九 仪器索引。现产读数：源件 31 个引用、内联块 32 个引用，**引用不到 0 个**。

