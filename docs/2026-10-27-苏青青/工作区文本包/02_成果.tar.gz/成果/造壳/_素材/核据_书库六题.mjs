#!/usr/bin/env node
/**
 * 核据 · 书库六题 —— 机器核 `成果/造壳/_素材/书库六题.md` 里每一条 id
 * ════════════════════════════════════════════════════════════════════
 * 为什么有这件：记忆 `0mv4dfei2` —— **子代理自报"逐字核过"不可信，唯一判据是
 *   机器逐字回源**。所以本文件里 48 条判据，不许靠"我看过了"过关。
 *
 * 三道核：
 *   ① id 在不在 `工具/书库/书库.jsonl`（编一个假 id ⇒ ERR）
 *   ② 类型列与库里 `type` 是否一致（库里带后缀的按前缀比）
 *   ③ 两向覆盖率（字符 2-gram）：
 *        cover = 我写的「判据」列 ⊂ 库正文   （防：我编了库里没有的话）
 *        kept  = 库正文 ⊂ 我写的「判据」列   （防：压过头把意思压没了）
 *      阈值 cover ≥ 0.80、kept ≥ 0.65；低于阈值 ⇒ 只报"可疑"，人去读那行
 *
 * 用法：node 成果/造壳/_素材/核据_书库六题.mjs
 * 退出码：0 = 全过（可有"可疑"）；1 = 有 ERR / 有可疑 / 节数不是 6 或某节不在 6–8 行
 * ════════════════════════════════════════════════════════════════════
 */
import fs from 'node:fs'
import path from 'node:path'

const WS = path.resolve(new URL('.', import.meta.url).pathname, '..', '..', '..')
const MD = path.join(WS, '成果/造壳/_素材/书库六题.md')
const DB = path.join(WS, '工具/书库/书库.jsonl')

if (!fs.existsSync(MD)) { console.error('⛔ 没有 ' + MD); process.exit(1) }
if (!fs.existsSync(DB)) { console.error('⛔ 没有 ' + DB + '（先跑 node 工具/书库/建库.mjs）'); process.exit(1) }

const db = fs.readFileSync(DB, 'utf8').trim().split('\n').map(l => JSON.parse(l))
const byId = new Map()
for (const r of db) { if (!byId.has(r.id)) byId.set(r.id, []); byId.get(r.id).push(r) }

const strip = s => String(s || '').replace(/[\s*`>#（）()「」]/g, '')
const bigrams = s => { const a = new Set(); for (let i = 0; i < s.length - 1; i++) a.add(s.slice(i, i + 2)); return a }

const rows = []
let sec = ''
for (const line of fs.readFileSync(MD, 'utf8').split('\n')) {
  const h = line.match(/^## (\d+) /); if (h) sec = h[1]
  if (!line.startsWith('| ')) continue
  const c = line.split('|').map(s => s.trim())
  // 行形如：| M1-33 | 约束 | 判据 | 意味着什么 |
  if (!/^[A-Z][A-Za-z0-9]*(\d+-\d+|\d+)$/.test(c[1])) continue
  rows.push({ sec, id: c[1], typ: c[2], crit: c[3] })
}

const count = {}; const bad = []
for (const r of rows) {
  count[r.sec] = (count[r.sec] || 0) + 1
  const hit = byId.get(r.id)
  if (!hit) { bad.push({ ...r, err: '❌ id 不在库里' }); console.log(`ERR  ${r.id}  ${r.err}`); continue }
  const t = strip(r.crit), q = strip(hit[0].text)
  const B = bigrams(t), Q = bigrams(q)
  let inLib = 0; for (const b of B) if (q.includes(b)) inLib++
  let inMine = 0; for (const b of Q) if (t.includes(b)) inMine++
  const cover = +(inLib / B.size).toFixed(2), kept = +(inMine / Q.size).toFixed(2)
  const typeOK = String(hit[0].type || '').startsWith(r.typ)
  const sus = cover < 0.8 || kept < 0.65
  const flags = [typeOK ? 'type✓' : 'type✗', `cover=${cover}`, `kept=${kept}`]
  if (hit.length > 1) flags.push(`同id${hit.length}条`)
  console.log(`${sus ? '⚠️ ' : '✅ '}${r.id.padEnd(8)} §${r.sec}  ${flags.join(' ')}`)
  if (sus || !typeOK) bad.push({ ...r, cover, kept, typeOK })
}

console.log('\n每组条数：', JSON.stringify(count))
const secs = Object.keys(count)
const shapeOK = secs.length === 6 && secs.every(s => count[s] >= 6 && count[s] <= 8)
console.log(`总行数：${rows.length}｜节数：${secs.length}｜形状（6 节 × 6–8 行）：${shapeOK ? '✓' : '✗'}`)
console.log(bad.length ? `\n⚠️ 可疑 ${bad.length} 行（要人去读那行，不是自动改）：${bad.map(b => b.id).join('、')}` : '\n✅ 全过：id 都在 · 类型都对 · 两向覆盖达标')
process.exit(bad.length || !shapeOK ? 1 : 0)
