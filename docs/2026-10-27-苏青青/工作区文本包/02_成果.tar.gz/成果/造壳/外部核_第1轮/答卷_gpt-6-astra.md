模型：gpt-6-astra
状态：空
用时：94s

（空）
原始：{"choices":[{"content_filter_results":{},"finish_reason":"length","index":0,"logprobs":null,"message":{"annotations":[],"content":"","refusal":null,"role":"assistant"}}],"created":1792682153,"id":"chatcmpl-EbooDAv1dcyTeMOBmFLM383HkoW9G","model":"gpt-6-astra-2026-09-03","object":"chat.completion","prompt_filter_results":[{"prompt_index":0,"content_filter_results":{"hate":{"filtered":false,"severity