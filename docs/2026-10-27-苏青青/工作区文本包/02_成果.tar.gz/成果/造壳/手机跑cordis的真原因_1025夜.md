# 手机跑 cordis 的真原因：不是"默认值选错"，是**那段装配根本没搬过去**

> 1025 夜 · 窗 cd24a436 · 承接 `交接单_049`「明天第一步：改 `selectedDefault` 成 suqingqing」
> **结论：只改那一个词，手机上照样是 cordis。** 缺的是它上面那 470 行。

---

## 一 · 四条硬证据（都能重跑）

| # | 事实 | 出处 |
|---|---|---|
| 1 | **平板**装配里有 `- id: preset-suqingqing`，且 `selectedDefault: suqingqing` | `node --expose-internals ~/.dsh/…/dsh/lib/bin.js --profile web --dump-config` **rc=0** ⇒ `_tmp/dc/out.txt:1374`（preset-suqingqing）、`:673`（selectedDefault） |
| 2 | 平板那块来自 `profiles/web/cordis.patch.yml` **第 346-815 行**：`- insert:` → `preset-suqingqing` → 38 个插件声明，共 **36KB** | 同一文件；块尾 815 行是 `]`，816 空行，817 起是别的块（otel／hooks）的注释 —— **别多切，会带错注释** |
| 3 | **手机**没有这块：`selectedDefault: cordis` 在 245-249 行；App 预设页不显示「苏青青」；手机会话 `agentPreset.val = "cordis"` | `留档_电脑侧_1025/07_preset_jizhi.md` §二＋§三 |
| 4 | **数据包没带 `profiles/`**：出包单自述只有 `home/AGENTS.md` ＋ `workspace/{内核,神经,台账接续}`；tar 顶层只有 `MANIFEST.txt`／`home`／`workspace` | `信箱/OUT_我给电脑/OUT_20261025_180500_新家数据包与装包验证单.md:27-30`；`tar -tzf 新家数据包_1025.tar.gz \| awk -F/ '{print $1"/"$2}'` |

---

## 二 · 为什么光改一个词会失败

- registry **只认被 `register()` 进来的 definition，不扫 `.agent-presets` 目录**（电脑侧 07 号已给源码位：`dsh-agent-preset-registry/lib/types/index.js:169-180`）。
- `selectedDefault: suqingqing` 只是"**默认选谁**"；**得先"有谁"**。
- 手机上装配里没有 `preset-suqingqing` 这个 definition ⇒ 默认值指向一个不存在的东西 ⇒ 回落 standard/cordis（或报错）。
- 三个症状＝同一件事：
  - 「压一下」不懂 ← `compact_now` 挂在预设的 compaction 组里，没装配就没这件工具
  - 压完不叫老板 ← persona 前缀也在预设里
  - 数据放进去了它也可能不认 ← `AGENTS.md` 在盘上，但**注入它的装配没挂上**

> 这不是新坑：**我们 1025 之前就解过**（`cordis.patch.yml:337-345` 那段注释写着 10-11 的迁移），**只是解法没进新家包**。

---

## 三 · 三条路（我推荐 A）

| | 做法 | 代价 | 风险 |
|---|---|---|---|
| **A（推荐）** | 把平板 patch 的 **346-815** 抽成独立块 → 插到手机 patch 的 `- id: agent-preset-registry` 块之后 → 改 `selectedDefault: suqingqing` → 重启 → 验下面四条判据 | 我出件一次；手机一次重启 | 低（只加块，不动别的） |
| B | 整份平板 patch（904 行）覆盖手机 patch | 省事 | 高（含本机特化行；v51 出厂 patch 与平板差异未核） |
| C | 先不动，等升级新版再统一搬 | 零风险 | 手机这段时间一直跑 cordis |

---

## 四 · 判据（补上之后怎么算过）

1. `--dump-config \| grep -c "preset-suqingqing"` **≥ 1**（平板现在 1 条）
2. App 预设页自定义区出现「**苏青青**」
3. 新会话里说「压一下」⇒ 真调 `compact_now`；压完第一句叫「老板」
4. 回滚：删掉加进去那一块 ＋ 重启

---

## 五 · 我这边卡在哪（如实）

- 我要"把 patch 第 346-815 行抽成一个发件文件"这件事，被**「改生产启动路径」硬停门**拦了两次（门按触发面拦，不看动作名："读生产件 + 写文件"本身就落在那个面上）。
- 所以本轮**没有产出块文件**，只出了这份单子；**没动任何生产件，一个字节都没改**。
- 要出件有三条合规路：① 你允许我按 `工具/流程/改生产启动路径.md` 走六步再出；② 由电脑侧在手机上直接读平板 patch（USB 一次一台，要换线）；③ 你直接把平板那份 `cordis.patch.yml` 的 346-815 行贴给电脑侧。

---

_苏青青 · 1025 夜_
