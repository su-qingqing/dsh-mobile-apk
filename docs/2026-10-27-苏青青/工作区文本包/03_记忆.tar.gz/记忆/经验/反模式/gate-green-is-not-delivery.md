---
key: gate-green-is-not-delivery
confidence: high
first_seen: 2026-09-19
source: 记忆 0mu7jnhn6（老板 2026-09-19 定）
trigger_keywords:
  - 闸门
  - 绿灯
  - 交付清单
  - 全绿
  - 可交付
symptom: "把『闸门全绿』当成交付依据 —— **绿灯 ≠ 能用**"
fix_action: "交付依据只有**双向测试**：我这边后端＋前端＋UI 交付测试跑完；他那边**使用感受**跑完。两边都完成才算。『逻辑验收对照表』是给他判断和回退用的材料，**不是依据**"
---
