---
key: grep-truncated-anchor
confidence: high
first_seen: 2026-09-19
source: ④号窗实测（已撤回的错断言）
trigger_keywords:
  - 锚点
  - 前缀
  - 找不到
  - 丢了
  - 不存在
  - find -name
  - 只看了前
symptom: "拿截断前缀（如 ^e9a0273）去锚完整目录名 ⇒ 明明在磁盘上却报『找不到』，并据此下了错结论（我曾说『③号窗日志找不到了』——是假的，真目录名是 session-e9a02734-…，253 条记录）"
fix_action: "锚点先 ls 抄真名；报『没有/丢了/坏了』之前必须换 ≥3 组关键词、3 个角度再判"
---
同族：`ls | head -12` 按体积排也漏过它（只看了最大的 12 个）。
