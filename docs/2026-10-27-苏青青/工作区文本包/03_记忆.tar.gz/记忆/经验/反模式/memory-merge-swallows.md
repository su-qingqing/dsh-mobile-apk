---
key: memory-merge-swallows
confidence: high
first_seen: 2026-09-19
source: 记忆 0mu7hpn8u
trigger_keywords:
  - memory_remember
  - 合并
  - 同一 id
  - 无需重复调用
  - memory_read
symptom: "记忆库『高度重复自动合并』会**静默吞掉后写的那条**：返回同一个 id，工具还说『无需重复调用』，但 memory_read 一看正文一个字都没进去"
fix_action: "① 同一件事别背靠背写两条；② 收到『已写入 id=X』而 X 与上一条相同时，**必须 memory_read X 核对**，别信那句『无需重复调用』"
---
