---
key: mjs-require
confidence: high
first_seen: 2026-09-19
source: 记忆 0mu7biixh ＋ 本轮第三次实测
trigger_keywords:
  - require
  - .mjs
  - patch-
  - ES module
  - module scope
symptom: ".mjs 是 ES 模块：ReferenceError: require is not defined in ES module scope"
fix_action: "补丁/一次性脚本一律写 .cjs；或把 require 改成 import。文件名里带 patch- 的尤其容易犯"
---
