---
key: other-peoples-numbers
confidence: high
first_seen: 2026-09-19
source: 记忆 0mu7hvjsh（老板当场质问）
trigger_keywords:
  - 实测
  - 别人的结论
  - 引用
  - 对照表
  - 数一遍
  - 偷懒
symptom: "把别人/别的窗口的产物当『我的实测』说出口。老板原话：『甚至连你这边都漏东西——我的那个熔断呢？你偷懒，你根本就没核对过这三个窗口』"
fix_action: "报『实测』之前自问一句『**这个数字是我打的吗**』；引用必须标出处、标证据等级（实测/文档/推断/假设）"
---
