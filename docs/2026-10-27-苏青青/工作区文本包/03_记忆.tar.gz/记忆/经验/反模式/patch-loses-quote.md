---
key: patch-loses-quote
confidence: high
first_seen: 2026-09-19
source: ⑤号窗（本窗）实测，就在建本账本的过程中
trigger_keywords:
  - 打补丁
  - 替换
  - replace
  - 锚点
  - 引号
  - patch
symptom: "批量替换时替换串没把锚点整段回写 ⇒ 吃掉结尾的引号/括号，写出非法代码；而补丁脚本只验『锚点命中 1 次』，**照样报成功**"
fix_action: "① 替换串 = 新内容 ＋ 完整回写锚点尾部；② 打完补丁**立刻 `node --check <文件>`**（或 python -m py_compile），语法检查不通过一律当补丁失败"
---
同族（都在同一台机器上踩过）：`0mu62qbc9` 多行 JS 塞 node -e（摆 3 次）、
`0mu2mu8ii` 全局替换误伤"看起来一样"的地方、`0mu7etdza` 旧串尾换行导致命中 0。
