---
key: pipe-eats-exit-code
confidence: high
first_seen: 2026-09-19
source: 记忆 0mu7kgppd
trigger_keywords:
  - '| tail'
  - '| head'
  - 管道
  - exit code
  - 退出码
  - 2>&1
symptom: "管道会吃掉真实退出码 ⇒ 任务状态报 exit code: 0，而正文里明明是 dpkg: error（又一次假绿）"
fix_action: "判退出码时别接管道；或 set -o pipefail；**判据看正文，不只看退出码**"
---
