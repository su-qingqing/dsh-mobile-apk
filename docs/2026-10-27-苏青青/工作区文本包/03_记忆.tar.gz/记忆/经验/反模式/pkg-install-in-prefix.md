---
key: pkg-install-in-prefix
confidence: high
first_seen: 2026-09-19
source: 台账/环境/dpkg病历_0919/README.md ＋ 工作区 AGENTS.md 红线
trigger_keywords:
  - pkg install
  - pkg upgrade
  - apt install
  - apt upgrade
  - apt --fix-broken
  - apt-get
  - dpkg -i
symptom: "在引擎所在的 Termux 前缀里装包/升级：dpkg 元数据缺约 84 个包，apt 会去『修』，中途可能提议移除 dpkg/dash/coreutils —— 而 DSH 引擎的 node 就住在那棵树上"
fix_action: "先问老板；能不用 apt 就不用（先问『Node 自带的够不够』）。病历 台账/环境/dpkg病历_0919/README.md"
---
现状（已实测）：status 最后改动 9-17 18:37，两天没恶化；在用的一律正常
（node v24.18.0 / ffmpeg 8.1.2 / zstd / curl / dpkg / apt / sh / rm / tar / grep）。
⇒ 判决＝**判死但不修**：修它要重装约 84 个包进那棵住着引擎的树，收益零、风险极不对称。

**真要装之前的三步自保**（出处：记忆 `0mu5frpq5`，2026-09-17 实测）：
① 先模拟：`apt -s install <包>`（只读）—— 看输出里是不是 `0 upgraded`；若它要**升级 libc 之类**就停。
② 模拟输出里出现任何 **remove/移除** 字样 ⇒ 立刻停手（那是在拆这棵树）。
③ 装完立刻验引擎：`node -v` ＋ 起一次隔离实例看正向信号。
