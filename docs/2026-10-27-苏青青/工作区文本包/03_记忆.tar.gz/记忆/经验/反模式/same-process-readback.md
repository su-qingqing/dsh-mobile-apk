---
key: same-process-readback
confidence: high
first_seen: 2026-09-19
source: 做法库 #100
trigger_keywords:
  - writeFileSync
  - 回读
  - 落盘
  - 假绿
  - grep 验证
  - 写着成功
symptom: "写文件报成功、**同进程回读也对**，但另起进程 grep 到的还是旧串（登记表期望串 9→11 改了两遍才生效）"
fix_action: "改完关键文件必须用一条**独立的 grep 命令**确认；只信同进程回读 ＝ 假绿"
---
