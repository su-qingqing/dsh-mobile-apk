---
key: shell-eats-backticks
confidence: high
first_seen: 2026-09-19
source: 记忆 0mu78d2zc（闸门标记：摆过 6 次）＋ 本轮实测
trigger_keywords:
  - node -e
  - 反引号
  - backtick
  - heredoc
  - <<
  - writeFileSync
  - 长文本
symptom: "用 node -e \"…\" 或双引号定界的 heredoc 塞含反引号的代码：bash 先把反引号当命令替换**真的执行掉** ⇒ 报 SyntaxError: Unterminated string constant / Unexpected identifier，而文件根本没写"
fix_action: "一律用 <<'EOF'（**引号定界符**）heredoc；补丁脚本写成 .cjs 文件。看到 node -e 就停手"
---
判据：`node -e` 后面跟超过一行的东西 = 红灯。
