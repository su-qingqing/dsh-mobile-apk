---
key: silent-default-high
confidence: high
first_seen: 2026-09-19
source: MisakaNet docs/trust-semantics.md 铁律 1（按我们语境改写）＋ 双证_经验账本.mjs 的 M4 用例
trigger_keywords:
  - 默认值
  - 缺失
  - 未知
  - fallback
  - 一律
  - 视为
symptom: "遇到『缺失/读不懂』就默认往**高**里算（默认算通过、默认算已装、默认算有证据）⇒ 假绿。同族实测：清单只数一种格式却当成『全』；fs.writeFileSync 报成功却没落盘；记忆合并说『已写入』其实没写进去"
fix_action: "**证据永不假设** —— 缺失/畸形/读不懂**一律算最低级**；把『未知』显示成未知，不要显示成通过"
---
这是本账本里唯一的『元规则』：上面每一条几乎都能归到它名下。
