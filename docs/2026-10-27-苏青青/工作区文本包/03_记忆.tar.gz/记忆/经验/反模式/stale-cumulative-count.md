---
key: stale-cumulative-count
confidence: high
first_seen: 2026-09-19
source: 记忆 0mu7g64ih
trigger_keywords:
  - 已拆完
  - 待拆
  - 进度
  - 累计数
  - 百分比
  - 在办件数
symptom: "表里的『累计数』是某一批落地**之前**写的，之后没人回头改 ⇒ 外部件拆解总表 §C 写『已拆完 3 件／待拆 9 件』，真值是 8／7"
fix_action: "报进度前从产物反推真数，不从上一行抄；报出去的每个数字都要能指到一条命令"
---
