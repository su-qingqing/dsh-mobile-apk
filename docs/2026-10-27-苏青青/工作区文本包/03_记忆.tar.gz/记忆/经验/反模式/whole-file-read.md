---
key: whole-file-read
confidence: medium
first_seen: 2026-09-19
source: 做法库 #99
trigger_keywords:
  - cat
  - 整篇
  - read
  - fetch
  - README
  - 上游
symptom: "为摸清一个机制整篇读上游 README（约 10k token），其中九成是安装/设置/代理/troubleshooting，与『只搬机制不装壳』无关"
fix_action: ">5KB 先 grep 定位；只取需要的段（比如只要那张 Tools 表），要细节再定点取"
---
