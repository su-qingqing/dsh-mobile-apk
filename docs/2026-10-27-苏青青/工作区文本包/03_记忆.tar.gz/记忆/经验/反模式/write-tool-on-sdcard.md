---
key: write-tool-on-sdcard
confidence: high
first_seen: 2026-09-19
source: 工作区 AGENTS.md 硬事实
trigger_keywords:
  - write 工具
  - edit 工具
  - write /storage
  - edit /storage
  - 硬链接
  - EACCES
not_keywords:
  - "ls "
  - "cat "
  - "grep "
  - "stat "
  - "head "
  - "tail "
symptom: "用 write/edit 工具写 /storage/emulated/0 ⇒ EACCES: permission denied, link …（该文件系统不支持硬链接）"
fix_action: "用 bash heredoc 写；$DSH_HOME 下同样。改任何文件前先 cp 一份 .bak-<MMDD>-前<标记>"
---
