// A/B：同一句话、同一个目标，旧版 v2.6 vs 新版 v2.7 —— 看「踩坑热度」有没有真的改变排序
import { rmSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const MEMDB = '/storage/emulated/0/3/.dsh-meow/memory.db'
const WS = '/storage/emulated/0/3/.dsh-kickoff/testws'
const LED = WS + '/hits-ab.json'
const OLD = '/storage/emulated/0/3/.dsh-kickoff/gate-old-v26.mjs'
const NEW = '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/node_modules/@dsh-user/dsh-kickoff-gate/lib/index.js'

async function run(p, sid) {
  try { rmSync(LED) } catch (e) { /* 忽略 */ }
  const { apply } = await import(pathToFileURL(p).href + '?t=' + Date.now())
  const L = {}
  const ctx = {
    get: () => undefined,
    on: (n, f) => { (L[n] = L[n] || []).push(f); return () => {} },
    effect: (f) => { f(); return () => {} },
    logger: { warn: () => {}, info: () => {} },
  }
  apply(ctx, { workspace: WS, memoryDb: MEMDB, lessonCacheMs: 0, hitLedger: LED })
  const allow = async () => ({ kind: 'allow' })
  const accept = async () => ({ kind: 'accept' })
  await L['agent/pre-step'][0]({ agent: { id: sid }, messages: [{ content: [{ type: 'text', text: '我们的记忆并没有落到实处，我们在以前的坑照样踩，要让它真正起作用' }] }] }, allow)
  const r = await L['tools/post-execute'][0](
    { name: 'bash', arguments: { command: 'node 神经/体检.mjs > _backup/报告.txt' }, agent: { id: sid } },
    { isError: false, content: [{ type: 'text', text: '原始' }] }, accept)
  const b = ((r && r.content) || [])[1]
  return b ? b.text : '(无检索块)'
}
console.log('########## 旧版 v2.6 ##########')
console.log(await run(OLD, 'AB-OLD'))
console.log('########## 新版 v2.7 ##########')
console.log(await run(NEW, 'AB-NEW'))
