// CDP 真实手势点按 + 回读（绕过 React 对非受信 click 的处理）
import { createRequire } from 'node:module'
const require = createRequire('/data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/')
const WebSocket = require('ws')
const list = await (await fetch('http://127.0.0.1:9222/json')).json()
const page = list.find((t) => t.type === 'page' && /3080/.test(t.url)) || list[0]
const ws = new WebSocket(page.webSocketDebuggerUrl)
let id = 0; const pending = new Map()
const send = (method, params) => new Promise((res) => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params })) })
ws.on('message', (raw) => { const m = JSON.parse(raw.toString()); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) } })
await new Promise((r) => ws.on('open', r))
const ev = async (expr) => (await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true })).result?.result?.value

const sel = process.argv[2] || '[aria-label="内核状态"]'
const box = JSON.parse(await ev(`(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return 'null';const r=e.getBoundingClientRect();return JSON.stringify({x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)})})()`))
if (!box) { console.error('找不到元素', sel); process.exit(2) }
console.log('命中坐标', JSON.stringify(box))
await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: box.x, y: box.y, button: 'left', clickCount: 1, buttons: 1 })
await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: box.x, y: box.y, button: 'left', clickCount: 1, buttons: 0 })
await new Promise((r) => setTimeout(r, 2000))
const read = process.argv[3]
if (read) console.log(await ev(read))
ws.close(); process.exit(0)
