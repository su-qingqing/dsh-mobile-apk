// 按「文字前缀」找到面板里最深（最小）的那张卡，发真实手势点它，再回读。
import { createRequire } from 'node:module'
const require = createRequire('/data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/')
const WebSocket = require('ws')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const list = await (await fetch('http://127.0.0.1:9222/json')).json()
const page = list.find((t) => t.type === 'page' && /3080/.test(t.url)) || list[0]
const ws = new WebSocket(page.webSocketDebuggerUrl)
let id = 0; const pending = new Map()
const send = (m, p) => new Promise((res) => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method: m, params: p })) })
ws.on('message', (raw) => { const x = JSON.parse(raw.toString()); if (x.id && pending.has(x.id)) { pending.get(x.id)(x); pending.delete(x.id) } })
await new Promise((r) => ws.on('open', r))
const ev = async (e) => (await send('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true })).result?.result?.value
const name = process.argv[2] || '注入实况'
const box = JSON.parse(await ev(`(()=>{
  const p=[...document.querySelectorAll('div')].find(d=>d.style&&d.style.zIndex==='70');
  if(!p) return 'null';
  const all=[...p.querySelectorAll('div')].filter(x=>x.innerText&&x.innerText.indexOf(${JSON.stringify(name)})===0);
  if(!all.length) return 'null';
  all.sort((a,b)=>{const ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();return ra.width*ra.height-rb.width*rb.height});
  const r=all[0].getBoundingClientRect();
  return JSON.stringify({x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2),w:Math.round(r.width),h:Math.round(r.height)})
})()`))
if (!box) { console.log('⚠ 找不到卡：' + name); process.exit(2) }
console.log('命中卡片', JSON.stringify(box))
await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: box.x, y: box.y, button: 'left', clickCount: 1, buttons: 1 })
await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: box.x, y: box.y, button: 'left', clickCount: 1, buttons: 0 })
await sleep(1200)
const t = await ev(`(()=>{const p=[...document.querySelectorAll('div')].find(d=>d.style&&d.style.zIndex==='70');return p?p.innerText.slice(0,420):'(面板关了)'})()`)
console.log('---- 点后面板前 420 字 ----')
console.log(t)
ws.close(); process.exit(0)
