// 面板 A/B/C/D 改动的活体验证：重载页面 → 真手势点图标 → 读回真实 DOM
import { createRequire } from 'node:module'
const require = createRequire('/data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/')
const WebSocket = require('ws')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const pick = async () => {
  const l = await (await fetch('http://127.0.0.1:9222/json')).json()
  return l.find((t) => t.type === 'page' && /3080/.test(t.url)) || l[0]
}
const mk = (p) => {
  const ws = new WebSocket(p.webSocketDebuggerUrl)
  let id = 0; const pending = new Map()
  const send = (m, params) => new Promise((res) => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method: m, params })) })
  ws.on('message', (raw) => { const x = JSON.parse(raw.toString()); if (x.id && pending.has(x.id)) { pending.get(x.id)(x); pending.delete(x.id) } })
  return { ws, send, open: new Promise((r) => ws.on('open', r)) }
}
let C = mk(await pick()); await C.open
await C.send('Page.enable', {}); await C.send('Page.reload', { ignoreCache: true })
C.ws.close(); await sleep(8000)
C = mk(await pick()); await C.open
const ev = async (e) => (await C.send('Runtime.evaluate', { expression: e, returnByValue: true, awaitPromise: true })).result?.result?.value
const tapAt = async (x, y) => {
  await C.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1, buttons: 1 })
  await C.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1, buttons: 0 })
}
const PROBE = `(()=>{
  const b = document.querySelector('[aria-label="内核状态"]');
  const p = [...document.querySelectorAll('div')].find(d => d.style && d.style.zIndex === '70');
  const rect = (e)=>{ if(!e) return null; const r=e.getBoundingClientRect(); return {top:Math.round(r.top), bottom:Math.round(r.bottom), right:Math.round(window.innerWidth-r.right)} };
  const card = (name)=>{ if(!p) return null; const c=[...p.children].find(x=>x.innerText && x.innerText.indexOf(name)===0); if(!c) return null; const r=c.getBoundingClientRect(); return {x:Math.round(r.left+r.width/2), y:Math.round(r.top+r.height/2)} };
  return JSON.stringify({btn:rect(b), panel:rect(p), injCard:card('注入实况'), txt: p? p.innerText : '(面板没开)'})
})()`

console.log('=== 1) 点之前 ===')
console.log(await ev(PROBE))
console.log('=== 2) 真手势点图标 ===')
const b = JSON.parse(await ev(PROBE)).btn
if (!b) { console.log('⚠ 找不到内核状态按钮'); process.exit(2) }
const bc = await ev('(()=>{const e=document.querySelector(\'[aria-label="内核状态"]\');const r=e.getBoundingClientRect();return JSON.stringify({x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)})})()')
const bxy = JSON.parse(bc)
await tapAt(bxy.x, bxy.y); await sleep(1800)
const s2 = await ev(PROBE)
console.log(s2)
console.log('=== 3) 点「注入实况」卡片（换成触摸设备上真正走得通的路子）===')
const card = JSON.parse(s2).injCard
if (card) { await tapAt(card.x, card.y); await sleep(1200); console.log(await ev(PROBE)) } else console.log('⚠ 卡片没找到')
C.ws.close(); process.exit(0)
