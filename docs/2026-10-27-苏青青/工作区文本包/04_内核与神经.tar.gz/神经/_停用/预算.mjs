#!/usr/bin/env node
// M1 · 实时配额（新件 v0.2 · 2026-09-18）
// 来源：对照单 002（qwen3.8-max 建议把 quota 提到第一位）+ 内核 #50（步数×上下文才是钱）
// 形态：**独立只读工具**，不装插件、不改任何现有文件、零网络。
// 它回答一句话：**这一轮现在该不该继续跑？**
// 用法: node 神经/预算.mjs [sessionId]   （缺省 = 最近活跃的那个会话）
const CFG = {
  步数软线: 20,    // #50 的产物线（越线要在回复末尾报一行）
  步数硬线: 40,    // 到这里该换窗口接力
  轮数硬线: 10,    // #50 熔断：≥10 轮未收敛
  成本熔断: 10.0,  // ¥（#50 · 老板 2026-09-18 夜上调：¥2 → ¥10）
  // ↓ v0.2：真 token 计价（元/百万 token）——先按 DeepSeek 公开价档填，**可随时改**；缓存读通常约为输入价的 1/10
  价: { 输入: 2.0, 输出: 8.0, 缓存读: 0.2 },
  单价估算: 0.02,  // ¥/步 粗估（仅当日志里取不到 usage 时兜底）
}
import fs from 'node:fs'
import path from 'node:path'
// ★ 2026-09-23（十七号窗）：输出被截断（`… | head` / `| tail` 提前退出 ⇒ 管道另一头没了）时，
//   写入会抛 EPIPE。不接住的话进程会**卡在那里**⇒ 看起来像"仪器坏了/量不到"，实为调用姿势。
//   这里只做**安静退出**：不改任何判据、不改任何数字。实测：不接管道 456ms 出数；接 `head` 时曾卡死 >120s。
process.stdout.on('error', (e) => { if (e && (e.code === 'EPIPE' || e.code === 'ERR_STREAM_DESTROYED')) process.exit(0) })
process.stderr.on('error', () => {})
import { execFileSync } from 'node:child_process'
const HOME = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const ROOT = path.join(HOME, 'sessions')

function newestSession() {
  if (!fs.existsSync(ROOT)) return null
  let best = null
  for (const ws of fs.readdirSync(ROOT)) {
    const d = path.join(ROOT, ws)
    if (!fs.statSync(d).isDirectory()) continue
    for (const s of fs.readdirSync(d)) {
      const f = path.join(d, s, 'session.v3.jsonl.zstd')
      if (fs.existsSync(f)) { const m = fs.statSync(f).mtimeMs; const isRoot = s.startsWith('session-'), bestIsRoot = best && best.id.startsWith('session-'); if (!best || (isRoot && !bestIsRoot) || (isRoot === !!bestIsRoot && m > best.m)) best = { id: s, f, m, bytes: fs.statSync(f).size } }
    }
  }
  return best
}

const arg = process.argv[2]
const target = arg
  ? (() => { for (const ws of fs.readdirSync(ROOT)) { const f = path.join(ROOT, ws, arg, 'session.v3.jsonl.zstd'); if (fs.existsSync(f)) return { id: arg, f, bytes: fs.statSync(f).size } } return null })()
  : newestSession()
if (!target) { console.error('找不到会话日志'); process.exit(2) }

let text = ''
try { text = execFileSync('zstd', ['-dc', target.f], { encoding: 'utf8', maxBuffer: 256 * 1024 * 1024, timeout: 60000 }) }
catch (e) { console.error('解压失败（多帧 zstd 需 CLI）:', String(e.message).slice(0, 120)); process.exit(3) }

const lines = text.split('\n').filter(Boolean)
let calls = 0, steps = 0, turns = 0, chars = text.length
let u = { in: 0, out: 0, cache: 0, n: 0 }   // v0.2：真 token usage
for (const l of lines) {
  try {
    const j = JSON.parse(l); const t = j.type || (j.event && j.event.type) || ''
    if (t === 'tool/call') calls++
    else if (t === 'step/end' || t === 'step/start') steps++
    else if (t === 'turn/start') turns++
    const us = j.data && j.data.usage
    if (us && typeof us.inputTokens === 'number') {
      u.in += us.inputTokens || 0; u.out += us.outputTokens || 0
      u.cache += us.cacheReadTokens || 0; u.n++
    }
  } catch { /* 坏帧跳过 */ }
}
const stepsReal = Math.round(steps / 2) // step/start 与 step/end 各一份
/* v0.2.1 修：原式写 `(u.in - u.cache)` ⇒ 实测算出 **¥-19.57**（负数）。
   真因：usage 里 `inputTokens` 是**本次新增输入**，`cacheReadTokens` 是**另计的缓存命中量**（不是 input 的子集）。
   拿实测数字自证：input 141,124 而 cache 11,393,024 —— 缓存比输入大 80 倍，减法必然为负。 */
const costReal = u.n > 0
  ? (u.in / 1e6) * CFG.价.输入 + (u.out / 1e6) * CFG.价.输出 + (u.cache / 1e6) * CFG.价.缓存读
  : null
const cost = costReal !== null ? costReal : calls * CFG.单价估算
const verdict = []
/* 2026-09-18 夜他纠正后：**不按步数开新窗口**（会造成本地窗口繁多、碎片散化；且开窗打断缓存更贵）。
   步数只报数，不劝换窗；换窗口由"任务告一段落 / 换主线"两条判据触发，且由他点。 */
if (calls >= CFG.步数硬线) verdict.push(`🟡 步数 ${calls}（已很多）⇒ **继续跑是默认**；只在"任务告一段落/换主线"时才提换窗口，由他点`)
else if (calls >= CFG.步数软线) verdict.push(`🟡 步数 ${calls} ≥ 软线 ${CFG.步数软线} ⇒ 注意别开新的探索支线`)
else verdict.push(`🟢 步数 ${calls} < 软线 ${CFG.步数软线} ⇒ 正常继续`)
if (turns >= CFG.轮数硬线) verdict.push(`🟡 轮数 ${turns} ≥ ${CFG.轮数硬线} ⇒ #50：**停下来交一次底**（产物/证据/未决项），不必回滚、不必开窗`)
if (cost >= CFG.成本熔断) verdict.push(`🔴 估算成本 ≈¥${cost.toFixed(2)} ≥ 熔断线 ¥${CFG.成本熔断} ⇒ 停手交付`)
else verdict.push(`🟡 成本 ≈¥${cost.toFixed(2)}${costReal !== null ? '（**真 token 真值**）' : '（粗估）'}`)
if (costReal !== null && costReal < 0) { verdict.push('🔴 成本算出负数 ⇒ **仪器坏了**，先查 usage 口径，别信这个数'); }
if (costReal !== null) {
  console.log(`\n  token 真值：新增输入 ${u.in.toLocaleString()}（其中缓存命中 ${u.cache.toLocaleString()}）｜输出 ${u.out.toLocaleString()}｜共 ${u.n} 条 usage 记录`)
  console.log(`  计价：输入 ¥${CFG.价.输入}/M ｜输出 ¥${CFG.价.输出}/M ｜缓存读 ¥${CFG.价.缓存读}/M`)
}

console.log(`预算体检 · 会话 ${target.id.slice(0, 24)}…`)
console.log(`  工具调用 ${calls} 次 ｜ 轮 ${turns} ｜ 日志 ${(target.bytes / 1024).toFixed(0)}KB / ${lines.length} 帧`)
console.log(`  判据：软线 ${CFG.步数软线} / 硬线 ${CFG.步数硬线} 步 · 熔断 ¥${CFG.成本熔断} 或 ${CFG.轮数硬线} 轮`)
for (const v of verdict) console.log('  ' + v)
console.log('\n（M1 v0.2：真 token 计价 + 自检（负数即报仪器坏）、零网络。下一步可加 token 真值估算与「越线自动提示」——进试验场验证后再谈装闸门。）')
// 出口码：只有**真超成本熔断**才算 1（步数/轮数只提示）
process.exit(cost >= CFG.成本熔断 ? 1 : 0)
