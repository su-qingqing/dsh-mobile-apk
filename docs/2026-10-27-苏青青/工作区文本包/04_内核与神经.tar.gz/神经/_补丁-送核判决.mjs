import fs from 'node:fs'
const p = '神经/送核.mjs'
let s = fs.readFileSync(p, 'utf8')
const a1 = "x.状态 + (x.回话落点 ? ' ｜ ' + x.回话落点 : ''))"
const b1 = "x.状态 + (x.回话落点 ? ' ｜ ' + x.回话落点 : '') + (x.状态 === '成功' ? (x.判决 ? ' ｜ ✅已判' : ' ｜ ⚪未判') : ''))"
const a2 = "    process.exit(0)\n  } else if (动词 === '送') {"
const b2 = [
  "    process.exit(0)",
  "  } else if (动词 === '判') {",
  "    const 任务 = process.argv[3]; const 判 = 参('判'); const 落 = 参('落')",
  "    if (!任务 || !判) { console.log('用法：送核.mjs 判 <任务名> --判 \"<我的判断>\" [--落 \"<文件:行>\"]'); process.exit(2) }",
  "    const t = 读台账(); const 组 = (t.单 || []).filter(x => x.任务 === 任务 && x.状态 === '成功')",
  "    const 末 = 组[组.length - 1]",
  "    if (!末) { console.log('⛔ 台账里没有「' + 任务 + '」的成功记录 ⇒ 先送再判'); process.exit(3) }",
  "    末.判决 = 判; if (落) 末.落地 = 落; 末.判于 = new Date().toISOString()",
  "    写台账(t)",
  "    console.log('✅ 已判：' + 任务 + '\\n   判：' + 判 + (落 ? '\\n   落：' + 落 : ''))",
  "    process.exit(0)",
  "  } else if (动词 === '待判') {",
  "    const t = 读台账(); const 未 = (t.单 || []).filter(x => x.状态 === '成功' && !x.判决)",
  "    console.log(未.length ? '⚪ 送过但没判的：' + 未.length + ' 条\\n' + 未.map(x => '  · ' + x.at + ' ｜ ' + x.任务 + ' ｜ ' + (x.回话落点 || '')).join('\\n') : '✅ 全部判过（送核三件套② 没欠账）')",
  "    process.exit(未.length ? 1 : 0)",
  "  } else if (动词 === '送') {",
].join('\n')
for (const [a, b, 名] of [[a1, b1, '账行'], [a2, b2, '判/待判分支']]) {
  const n = s.split(a).length - 1
  if (n !== 1) { console.log('❌ ' + 名 + ' 匹配数=' + n); process.exit(1) }
  s = s.replace(a, b); console.log('✅ ' + 名 + ' 已改')
}
fs.writeFileSync(p, s)
