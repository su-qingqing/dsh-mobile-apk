// pins 体检：抓「会变读数」与「条文全文」—— 老板 1021 令「pins 只放指针/警报」
// 用法：node 神经/pins体检.mjs [--json]
// 判据（Q3 回执 + 老板归层三问）：pins 里不许出现会变的读数（字节数/改于时间/条数），
//   条文全文要回真源（附录乙/红线本），pins 只留指针（路径＋取件时机）。
import fs from 'node:fs';

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3';
const P = WS + '/台账/接续/每轮必读.json';

const 会变 = [
  [/\d{3,}\s*B\b/, '字节数'],
  [/改于\s*\d{2}-\d{2}\s*\d{2}:\d{2}/, '改于时间'],
  [/（\d+\s*条）/, '条数'],
  [/\d+\s*条未决/, '未决条数'],
  [/\d+\s*次/, '次数'],
];
// 条文全文的特征：单条 ≥ 800B 且含「：」解释结构、不是单行指针
const 是条文 = (s) => Buffer.byteLength(s) >= 800 && !/^[^\n]{0,200}$/.test(s);

const j = JSON.parse(fs.readFileSync(P, 'utf8'));
const pins = j.pins || [];
const 结果 = [];
pins.forEach((p, i) => {
  const s = typeof p === 'string' ? p : JSON.stringify(p);
  const hits = 会变.filter(([re]) => re.test(s)).map(([, n]) => n);
  const 条文 = 是条文(s);
  if (hits.length || 条文) 结果.push({ i, 字节: Buffer.byteLength(s), 读数: hits, 条文, 头: s.replace(/\s+/g, ' ').slice(0, 70) });
});

if (process.argv.includes('--json')) {
  console.log(JSON.stringify({ 条数: pins.length, 总字节: Buffer.byteLength(JSON.stringify(pins)), 问题: 结果 }, null, 2));
} else {
  console.log(`pins ${pins.length} 条 · ${Buffer.byteLength(JSON.stringify(pins))}B`);
  for (const x of 结果) console.log(`  🔴 [${x.i}] ${x.字节}B ${x.读数.length ? '读数:' + x.读数.join('/') : ''} ${x.条文 ? '条文全文' : ''} :: ${x.头}`);
  console.log(结果.length ? `\n🔴 ${结果.length}/${pins.length} 条要处理（读数清掉或条文搬真源）` : `\n✅ ${pins.length} 条全是指针`);
}
process.exit(结果.length ? 1 : 0);
