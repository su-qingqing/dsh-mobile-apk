#!/usr/bin/env node
/**
 * 三档.mjs —— A4 · 三档路由表（**软拆解：只贴标签，一个字都不搬**）
 *
 * 老板原话：「法律里面**有些东西是增加效率的，有些东西是生死的红线**」。
 * 三档（内核已有的分法）：
 *   **红线** ＝ 常驻注入（永远在场·**薄，就那几条**）
 *   **判断** ＝ 身份层（我读情境自己判 —— 判据，不是条文）
 *   **效率** ＝ 外挂工具（命令，按需取 —— 无限，反正在抽屉里）
 *
 * 产出：`台账/接续/三档路由表.md`（B4 瘦身的输入）—— 一行一条 `路径|条号|档位|理由`
 * 源：内核/内核.md ＋ $DSH_HOME/AGENTS.md ＋ 工作区 AGENTS.md ＋ 记忆库 user/rules(active)
 * 判据：① **标的条数 ＝ 源条数**（逐条比对 id 集合，不是只比数） ② **红线 >15 条 ⇒ 报警**
 * 退路：新文件删掉即退。
 *
 * 用法：生成 ｜ 判（默认） ｜ 速览 ｜ selftest ｜ 隐藏入参 --表 <路径>（供自测）
 * 退出码：0 绿 ｜ 1 红 ｜ 2 用法错
 */
import fs from 'node:fs'
import path from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import { spawnSync } from 'node:child_process'

// ⚠️ 这台机器上 `process.execPath` **不是 node，是 Android 的 linker64**（2026-09-22 实测）
// ⇒ 拿它去起子进程必挂（报 bad ELF magic）。这里显式找真 node。
const NODE_BIN = (() => {
  for (const p of [process.env.DSH_NODE, '/data/data/com.dsharnessmobile.shell/files/usr/bin/node']) if (p && fs.existsSync(p)) return p
  const w = spawnSync('sh', ['-c', 'command -v node'], { encoding: 'utf8' })
  return ((w.stdout || '').trim()) || 'node'
})()

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const HOME = process.env.DSH_HOME || ''
const 表路径 = (() => { const i = process.argv.indexOf('--表'); return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : path.join(WS, '台账/接续/三档路由表.md') })()
const DB = path.join(WS, '.dsh-meow/memory.db')
const 上限红线 = 15

const 净 = (s) => String(s).replace(/\s+/g, ' ').trim()

// ───────────────────────── 源提取 ─────────────────────────
function 源() {
  const rows = []
  const add = (p, id, t) => rows.push({ p, id: String(id), t: 净(t) })
  // S1 内核条文（判据：条数必须 == 指纹基线 rules）
  const kf = path.join(WS, '内核/内核.md')
  const seen = new Map()
  for (const l of fs.readFileSync(kf, 'utf8').split('\n')) {
    const m = l.match(/^(\d+)\.\s+(.*)$/)
    if (!m) continue
    let id = m[1]
    const n = (seen.get(id) || 0) + 1; seen.set(id, n)
    if (n > 1) id = id + 'b'
    add('内核/内核.md', id, m[2])
  }
  // S2 / S3 两份 AGENTS.md（只取 `- ` 行）
  for (const [p, f] of [['$DSH_HOME/AGENTS.md', path.join(HOME, 'AGENTS.md')], ['AGENTS.md', path.join(WS, 'AGENTS.md')]]) {
    if (!fs.existsSync(f)) continue
    fs.readFileSync(f, 'utf8').split('\n').forEach((l, i) => { if (/^- /.test(l)) add(p, i + 1, l.replace(/^- /, '')) })
  }
  // S4 / S5 记忆库（active）
  const db = new DatabaseSync(DB)
  for (const t of ['user', 'rules']) {
    for (const r of db.prepare(`SELECT id,title,content FROM ${t} WHERE status='active' ORDER BY id`).all()) {
      add('记忆库/' + t, r.id, (r.title || '') + ' ' + r.content)
    }
  }
  return rows
}

// ───────────────────────── 贴档位（可审的规则表） ─────────────────────────
// 顺序＝优先级：**红线 > 效率 > 判断**（红线永远赢：它必须在场）
const 红线表 = [
  ['红线-重启', /绝不自作主张重启|绝不主动重启|重启必须\S{0,8}他本人|重启必须\*\*他本人\*\*/, '重启只能他本人动手（不可逆：09-14 引擎崩了 35 分钟进不去）'],
  ['红线-装配树', /dsh\.profile\.bundles|装配树|duplicate loader|headless-bad|--from-profile|裸跑 ?`?dsh --profile/, '装配树＝整棵树挂的死法（09-14 事故：41 次崩溃启动）'],
  ['红线-合规①项目隔离', /项目隔离表|物理隔离|个人项目与工作项目/, '合规①：个人项目与工作项目**物理隔离**（设备／账户／仓库）'],
  ['红线-合规②开源许可', /GPL|AGPL|开源代码使用前审查|保留版权与许可/, '合规②：开源代码**用前审许可**（🔴 GPL/AGPL 传染＝不许进；认不出＝不可用）'],
  ['红线-合规③绕过防护', /绕过防护|伪造 ?UA|破解加密|验证码|批量导出非公开数据/, '合规③：**不碰任何"绕过防护"的逻辑**（司法实践中直接认定非法手段）'],
  ['红线-窗口权限', /会话窗口的开|他本人的权限|只有我去新开的/, '窗口开／关／切换＝他本人的权限（我只许只读看窗）'],
  ['红线-不自动', /东西不要自己冒出来|不自动[:：]|自动弹出/, '东西不许自己冒出来'],
  ['红线-生产测试', /有风险的测试|不许在他的工作区间/, '不许在他的生产区间做有风险的测试'],
  ['红线-退路', /改任何文件前先备份|改前先 ?undo_snapshot|先 ?undo_snapshot/, '改前必留退路（改动必须能 30 秒退回去）'],
  ['红线-身份', /我叫苏青青|名字在文件里|谁问「你是谁」都是/, '身份：换窗／换模型／换目录都不变'],
]
// 权威序：同一条红线的多份副本里，**只让最权威的那一份占"红线"**（内核 > 全局 > 工作区 > 记忆库）
const 权威序 = (p) => (p === '内核/内核.md' ? 0 : p === '$DSH_HOME/AGENTS.md' ? 1 : p === 'AGENTS.md' ? 2 : 3)
const 命中族 = (r) => { for (let i = 0; i < 红线表.length; i++) if (红线表[i][1].test(r.t)) return i; return -1 }

function 贴全部(rows) {
  const 候选 = rows.map((r) => ({ ...r, _族: 命中族(r) }))
  const 权威 = new Map(), 份数 = new Map()
  for (const r of 候选) {
    if (r._族 < 0) continue
    份数.set(r._族, (份数.get(r._族) || 0) + 1)
    const cur = 权威.get(r._族)
    if (!cur || 权威序(r.p) < 权威序(cur.p)) 权威.set(r._族, r)
  }
  return 候选.map((r) => {
    const key = r.p + '|' + r.id
    if (人工[key]) return { ...r, 档: 人工[key][0], 由: 人工[key][1] }
    if (r._族 >= 0) {
      const a = 权威.get(r._族), n = 份数.get(r._族)
      if (a === r) return { ...r, 档: '红线', 由: 红线表[r._族][2] + (n > 1 ? '（**族内另有 ' + (n - 1) + ' 份副本** ⇒ B4 合并成一条）' : '') }
      return { ...r, 档: '判断', 由: '**同族副本**：同一红线已在 ' + a.p + '|' + a.id + ' ⇒ 重复抄写、不该再占常驻，B4 删并' }
    }
    return { ...r, ...贴档(r) }
  })
}

// 人工兜底：机器判错的行，在这里点名改（每条都要写理由 —— 这是我自己的判断，不是机器的）
const 人工 = {
  // 例：'内核/内核.md|77': ['红线', '合规三红线之一，必须在场'],
}

function 贴档(r) {
  const key = r.p + '|' + r.id
  if (人工[key]) return { 档: 人工[key][0], 由: 人工[key][1], 人工: true }
  // 效率：这行**载荷就是命令/仪器指针**（去掉它我不会少一条判据）⇒ 归抽屉
  const 义务词 = /必须|不许|绝不|一律|只能|禁止|必跑|红线|铁律|⚠️/
  if (义务词.test(r.t)) return { 档: '判断', 由: '含义务词 ⇒ 是判据不是指针，读情境自己判', 人工: false }
  const 引号 = [...r.t.matchAll(/`([^`]+)`/g)].map((m) => m[1]).filter((x) => /^(node|dsh|bash|adb|pnpm|tar|zstd|sqlite3|git)\b/.test(x) || /\.(mjs|sh|json|md)\b/.test(x))
  const 裸 = r.t.match(/node [\w\/\u4e00-\u9fa5.]+\.mjs/g) || []
  const n = 引号.length + 裸.length
  const 命令字 = 引号.join('').length + 裸.join('').length
  if (n >= 2) return { 档: '效率', 由: '一行两条以上命令 ⇒ 这是索引/清单行：按需取，不该常驻', 人工: false }
  if (n >= 1 && 命令字 >= 20) return { 档: '效率', 由: '主体就是一条命令/一个入口：命令进抽屉，时机留身份层', 人工: false }
  return { 档: '判断', 由: '读情境自己判（判据不是条文）', 人工: false }
}

// ───────────────────────── 生成 / 判 ─────────────────────────
const 表头 = (统计) => `# 三档路由表 · 0922 架构迭代包 A4

> **老板原话**：「法律里面**有些东西是增加效率的，有些东西是生死的红线**」。
> 三档：**红线**＝常驻注入（永远在场·**薄，就那几条**）｜**判断**＝身份层（我读情境自己判）｜**效率**＝外挂工具（命令，按需取）。
> ⚠️ 这是**软拆解**：**只贴标签，一个字都不搬**。这是 **B4 瘦身的输入**。退路＝**删掉本文件即退**。
> 生成：\`node 神经/三档.mjs 生成\` ｜ 判：\`node 神经/三档.mjs 判\`

## 一、机器判据

| 判据 | 值 | 结论 |
|---|---|---|
| **标的条数 ＝ 源条数** | 源 **${统计.源}** ／ 标 **${统计.标}** | ${统计.源 === 统计.标 ? '✅' : '❌ 对不上'} |
| **红线 ≤ ${上限红线} 条**（按行） | **${统计.红线}** 条 | ${统计.红线 <= 上限红线 ? '✅ 够薄' : '❌ **报警：红线胖了，这套就白改**'} |
| 其中**同族副本**（被抄了几份） | **${统计.副本}** 条 | ${统计.副本 ? '⚠️ 同一红线被抄成多份 ⇒ **B4 合并成一条**（这正是常驻注入变胖的真凶）' : '✅ 每族只一处'} |
| 其中**含命令的行**（给 B4 的读数） | **${统计.含命令}** 条 | 这些行的**命令可以剥进抽屉**（做法库／工具按需取），**判据留在身份层** —— 这是 B4 瘦身的主战场 |

**档位分布**：红线 **${统计.红线}** ｜ 判断 **${统计.判断}** ｜ 效率 **${统计.效率}**（合计 ${统计.源}）

**各源明细**

| 源 | 条数 |
|---|---|
${统计.分源.map(([p, n]) => `| \`${p}\` | ${n} |`).join('\n')}

## 二、红线这 ${统计.红线} 条是谁（他只要看这一节）

${统计.红线清单.length ? 统计.红线清单.map((x) => `- \`${x.p}|${x.id}\` —— ${x.由}｜「${x.t.slice(0, 40)}…」`).join('\n') : '（无）'}

## 三、逐条标签（机器读：一行一条 \`路径|条号|档位|理由\`）

\`\`\`
`

function 生成() {
  const rows = 源()
  const 贴 = 贴全部(rows)
  const 统计 = 算统计(rows, 贴)
  const out = 表头(统计) + 贴.map((x) => `${x.p}|${x.id}|${x.档}|${x.由}`).join('\n') + '\n```\n'
  fs.mkdirSync(path.dirname(表路径), { recursive: true })
  fs.writeFileSync(表路径, out)
  console.log('✅ 已生成 ' + path.relative(WS, 表路径) + '：' + 贴.length + ' 条 ｜ 红线 ' + 统计.红线 + ' ｜ 判断 ' + 统计.判断 + ' ｜ 效率 ' + 统计.效率)
  if (统计.红线 > 上限红线) { console.log('❌ **报警：红线 ' + 统计.红线 + ' 条 > ' + 上限红线 + '** —— 红线一胖，这套就白改'); return 1 }
  return 0
}

function 算统计(rows, 贴) {
  const 分源 = []
  for (const r of rows) { const f = 分源.find((x) => x[0] === r.p); if (f) f[1]++; else 分源.push([r.p, 1]) }
  const 红线清单 = 贴.filter((x) => x.档 === '红线')
  const 副本 = 贴.filter((x) => /同族副本/.test(x.由)).length
  const 含命令 = 贴.filter((x) => /`[^`]+`|node 工具\//.test(x.t)).length
  return { 副本, 含命令, 族: 红线清单.length, 源: rows.length, 标: 贴.length, 分源, 红线: 红线清单.length, 判断: 贴.filter((x) => x.档 === '判断').length, 效率: 贴.filter((x) => x.档 === '效率').length, 红线清单 }
}

function 读表() {
  if (!fs.existsSync(表路径)) return null
  const out = []
  for (const l of fs.readFileSync(表路径, 'utf8').split('\n')) {
    const m = l.match(/^([^|]+)\|([^|]+)\|(红线|判断|效率)\|(.+)$/)
    if (m) out.push({ p: m[1], id: m[2], 档: m[3], 由: m[4] })
  }
  return out
}

function 判() {
  const rows = 源()
  const 表 = 读表()
  if (!表) { console.log('❌ 表不在：' + 表路径 + ' ⇒ 先 `node 神经/三档.mjs 生成`'); return 1 }
  const 源集 = new Set(rows.map((r) => r.p + '|' + r.id))
  const 表集 = new Set(表.map((r) => r.p + '|' + r.id))
  const 漏 = [...源集].filter((x) => !表集.has(x))
  const 多 = [...表集].filter((x) => !源集.has(x))
  const 红线 = 表.filter((x) => x.档 === '红线').length
  let red = 0
  console.log('【三档 · 判】')
  console.log('- 源 ' + rows.length + ' 条 ／ 标 ' + 表.length + ' 条 ' + (漏.length === 0 && 多.length === 0 ? '✅ **一条不漏、一条不多**' : '❌'))
  if (漏.length) { console.log('  ❌ 漏标 ' + 漏.length + ' 条：' + 漏.slice(0, 5).join(' ／ ')); red++ }
  if (多.length) { console.log('  ❌ 多标 ' + 多.length + ' 条（源里没有）：' + 多.slice(0, 5).join(' ／ ')); red++ }
  const 副本 = 表.filter((x) => /同族副本/.test(x.由)).length
  console.log('- 同族副本 ' + 副本 + ' 条（同一红线被抄成多份 ⇒ B4 合并）')
  console.log('- 档位分布：红线 ' + 红线 + ' ｜ 判断 ' + 表.filter((x) => x.档 === '判断').length + ' ｜ 效率 ' + 表.filter((x) => x.档 === '效率').length)
  if (红线 > 上限红线) { console.log('  ❌ **报警：红线 ' + 红线 + ' 条 > ' + 上限红线 + '** —— 红线一胖，这套就白改'); red++ }
  else console.log('  ✅ 红线 ' + 红线 + ' 条 ≤ ' + 上限红线 + '，够薄')
  console.log(red === 0 ? '✅ 判据全绿' : '❌ 有 ' + red + ' 处红')
  return red === 0 ? 0 : 1
}

function 速览() {
  const 表 = 读表()
  if (!表) { console.log('（还没生成）'); return 1 }
  console.log('红线 ' + 表.filter((x) => x.档 === '红线').length + ' 条：')
  for (const x of 表.filter((x) => x.档 === '红线')) console.log('  ' + x.p + '|' + x.id + ' —— ' + x.由)
  return 0
}

function selftest() {
  const T = path.join(HOME || '/tmp', 'tmp', '三档自测-' + process.pid)
  fs.rmSync(T, { recursive: true, force: true }); fs.mkdirSync(T, { recursive: true })
  const 真表 = 表路径
  const 临时 = path.join(T, '表.md')
  let pass = 0, fail = 0
  const t = (n, c, ex = '') => { if (c) { pass++; console.log('  ✅ ' + n) } else { fail++; console.log('  ❌ ' + n + (ex ? ' — ' + ex : '')) } }
  const run = (a) => spawnSync(NODE_BIN, [path.join(WS, '神经/三档.mjs'), ...a, '--表', 临时], { encoding: 'utf8', cwd: WS })
  let r = run(['生成'])
  t('生成能跑（rc=0）', r.status === 0, 'rc=' + r.status + ' ' + ((r.stderr || '') + (r.error ? r.error.message : '')).slice(0, 200))
  const 原 = fs.readFileSync(临时, 'utf8')
  t('产出里有表头与红线节', /标的条数 ＝ 源条数/.test(原) && /## 二、红线这/.test(原))
  t('判：刚生成的表 ⇒ 全绿 rc=0', run(['判']).status === 0)
  // 反证①：抽掉一行 ⇒ 必须红
  const 行 = 原.split('\n'); const i = 行.findIndex((l) => /^[^|]+\|[^|]+\|(红线|判断|效率)\|/.test(l))
  const 砍 = 行.filter((_, j) => j !== i).join('\n')
  fs.writeFileSync(临时, 砍)
  r = run(['判']); t('反证①：**漏标一条 ⇒ 必须红**（rc=1 且点名"漏标"）', r.status === 1 && /漏标/.test(r.stdout), 'rc=' + r.status)
  // 反证②：塞 16 条红线 ⇒ 必须报警
  let k = 0
  const 塞 = 原.split('\n').map((l) => { if (k < 16 && /^[^|]+\|[^|]+\|(判断|效率)\|/.test(l)) { k++; return l.replace(/\|(判断|效率)\|/, '|红线|') } return l }).join('\n')
  fs.writeFileSync(临时, 塞)
  r = run(['判']); t('反证②：**红线 >15 ⇒ 必须报警**（rc=1）', r.status === 1 && /报警/.test(r.stdout), 'rc=' + r.status)
  fs.writeFileSync(临时, 原)
  fs.rmSync(T, { recursive: true, force: true })
  console.log('\n' + (fail === 0 ? '✅ 全绿' : '❌ 有红') + ' ' + pass + '/' + (pass + fail))
  return fail === 0 ? 0 : 1
}

// ───────────────────────── 主流程 ─────────────────────────
const cmd = process.argv[2] || '判'
let rc = 2
if (cmd === '生成') rc = 生成()
else if (cmd === '判') rc = 判()
else if (cmd === '速览') rc = 速览()
else if (cmd === 'selftest') rc = selftest()
else console.error('用法：生成 ｜ 判（默认） ｜ 速览 ｜ selftest')
process.exit(rc)
