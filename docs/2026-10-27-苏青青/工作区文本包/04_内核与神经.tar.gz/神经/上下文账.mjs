#!/usr/bin/env node
/**
 * 上下文账 — 给"效率"量体重（内核 #50 重设计 · 2026-09-23 老板：「你要重新设计一下效率的问题」）
 * 用法：node 神经/上下文账.mjs 量 ｜ 判 <单条KB>,<本段KB>,<本窗MB> ｜ selftest
 * 口径：成本 ≈ 单条字节 × 它之后的步数（每步重发整段上下文）⇒ 该管的不是"调用次数"，是"重量×存活步数"。
 * 档：单条 >8KB 提示落盘 ｜ 单条 >32KB 硬上限 ｜ 单段新增 >120KB 拆段 ｜ 本窗累计 >24MB 该换窗。
 */
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const 档 = { 单条: 8 * 1024, 单条硬: 32 * 1024, 段: 120 * 1024, 交接: 18 * 1024 * 1024, 窗: 24 * 1024 * 1024 }
const 交接参数 = { 极限万: 30, 每步万: 0.3, 交接步: 6 }

export function 统计(bytes) {
  const 总 = bytes.reduce((a, b) => a + b, 0)
  const 大 = bytes.filter((x) => x > 档.单条)
  return {
    总, 条数: bytes.length, 单条最重: bytes.length ? Math.max(...bytes) : 0,
    大块数: 大.length, 大块字节: 大.reduce((a, b) => a + b, 0),
    超硬: bytes.filter((x) => x > 档.单条硬).length,
    中位: bytes.length ? bytes.slice().sort((a, b) => a - b)[Math.floor(bytes.length / 2)] : 0,
  }
}

/** 交接余量（老板 2026-09-23 令：「你不能说到了极限再告诉我，在极限前面留一点余量，能够完成一个跨窗口的交接」）
 *  余额 < 一次交接的 1.5 倍 ⇒ 先落交接单、再换窗。极限 30 万 token 是**我们的经验风险线**，不是厂商宣称的窗口大小。 */
export function 交接判({ 现在万 = 0, 每步万 = 交接参数.每步万, 交接步 = 交接参数.交接步, 极限万 = 交接参数.极限万 } = {}) {
  const 交接需要 = 每步万 * 交接步
  const 余额 = 极限万 - 现在万
  const 还能干 = Math.max(0, Math.floor(余额 / Math.max(每步万, 1e-9)))
  const 该交接 = 余额 < 交接需要 * 1.5
  const 说 = 该交接
    ? ['🚩 **该开始交接了**：现在 ' + 现在万 + ' 万 ／ 极限 ' + 极限万 + ' 万 ⇒ 余额只剩 ' + 余额.toFixed(1) + ' 万，一次交接要 ≈ ' + 交接需要.toFixed(1) + ' 万 ⇒ **先落交接单，再换窗**（不许等撞线才说）']
    : ['✅ 还有余量：现在 ' + 现在万 + ' 万 ⇒ 余额 ' + 余额.toFixed(1) + ' 万，够干 ≈ ' + 还能干 + ' 步；余额掉到 ' + (交接需要 * 1.5).toFixed(1) + ' 万以下我就先叫交接']
  return { 交接需要, 余额, 还能干, 该交接, 说 }
}

export function 判档({ 单条最重 = 0, 本段新增 = 0, 本窗累计 = 0 }) {
  const 说 = []
  if (单条最重 > 档.单条硬) 说.push(`⛔ 单条 ${(单条最重 / 1024).toFixed(0)}KB 超 32KB 硬上限 ⇒ 这条本应先落盘、正文只留摘要`)
  else if (单条最重 > 档.单条) 说.push(`⚠️ 单条 ${(单条最重 / 1024).toFixed(0)}KB 超 8KB ⇒ 先落盘，正文 ≤1.5KB 摘要＋路径`)
  if (本段新增 > 档.段) 说.push(`✂️ 本段新增 ${(本段新增 / 1024).toFixed(0)}KB 超 120KB ⇒ 拆段（不是砍活）`)
  if (本窗累计 > 档.交接) 说.push('🚩 本窗累计 ' + (本窗累计 / 1048576).toFixed(1) + 'MB 超 18MB ⇒ **该准备交接**：先把交接单落下来，别再开新重活（老板 2026-09-23 令：不许等撞线才说）')
  if (本窗累计 > 档.窗) 说.push(`🔁 本窗累计 ${(本窗累计 / 1048576).toFixed(1)}MB 超 24MB ⇒ 该换窗（换窗由老板点）`)
  return { 建议: 说.length ? 说 : ['✅ 都在档内'], 该拆: 本段新增 > 档.段, 该换: 本窗累计 > 档.窗, 大块: 单条最重 > 档.单条, 该交接: 本窗累计 > 档.交接 }
}

function 找日志() {
  const home = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
  const 根 = path.join(home, 'sessions')
  const sid = process.env.DSH_SESSION_ID || ''
  for (const 项目 of fs.readdirSync(根)) {
    const d = path.join(根, 项目, sid)
    if (!sid || !fs.existsSync(d)) continue
    const f = fs.readdirSync(d).filter((x) => x.startsWith('session')).sort().pop()
    if (f) return path.join(d, f)
  }
  return null
}

function 量() {
  const f = 找日志()
  if (!f) { console.log('❌ 找不到本窗会话日志（DSH_SESSION_ID 没设？）'); process.exit(3) }
  const r = spawnSync('zstd', ['-dc', f], { maxBuffer: 512 * 1024 * 1024, encoding: 'buffer' })
  if (r.status !== 0) { console.log('❌ 解压失败：' + String(r.stderr || '').slice(0, 200)); process.exit(3) }
  const 行 = r.stdout.toString('utf8').split('\n').filter(Boolean)
  const bytes = 行.map((l) => Buffer.byteLength(l, 'utf8'))
  const s = 统计(bytes)
  const 重 = 行.map((l, i) => [bytes[i], l]).sort((a, b) => b[0] - a[0]).slice(0, 3)
  const 样本 = path.resolve(process.cwd(), '台账/接续/上下文样本.json')
  // ★ 1021 修根（第 1 轮验出：本段新增永远 0 KB ⇒ 拆段门永不响）：
  //   原来只「读」样本、从不「写回」⇒ 上次永远是旧值/0。
  //   修法：第一次没有样本 ⇒ 本段新增记 0（不误报）；有样本 ⇒ 算真差值；**算完把这次的总量写回**。
  let 上次 = null
  try { const j = JSON.parse(fs.readFileSync(样本, 'utf8')); 上次 = Number.isFinite(j.原始字节) ? j.原始字节 : null } catch {}
  const 本段新增 = 上次 === null ? 0 : Math.max(0, s.总 - 上次)
  console.log('### 上下文账 · ' + path.basename(f))
  console.log(`  本窗原始 ${(s.总 / 1048576).toFixed(2)} MB ｜ 记录 ${s.条数} 条 ｜ 中位 ${(s.中位 / 1024).toFixed(1)}KB ｜ 平均 ${(s.总 / s.条数 / 1024).toFixed(1)}KB`)
  console.log(`  >8KB 的 ${s.大块数} 条（占字节 ${(s.大块字节 / 1048576).toFixed(2)} MB ＝ ${(s.大块字节 / s.总 * 100).toFixed(0)}%）｜ >32KB 的 ${s.超硬} 条`)
  console.log(`  本段新增（对上次采样）${(本段新增 / 1024).toFixed(0)} KB`)
  console.log('  —— 最重 3 条 ——')
  for (const [n, l] of 重) {
    const t = (l.match(/"type":"([a-z/-]+)"/) || [])[1] || '?'
    console.log(`   ${(n / 1024).toFixed(0)} KB ｜ ${t} ｜ ${l.replace(/\s+/g, ' ').slice(0, 90)}`)
  }
  const p = 判档({ 单条最重: s.单条最重, 本段新增, 本窗累计: s.总 })
  console.log('  —— 判 ——')
  for (const x of p.建议) console.log('   ' + x)
  // ★ 1021：把这次的总字节写回样本 —— 没有这一步，下一跑的「本段新增」永远是 0
  try {
    fs.mkdirSync(path.dirname(样本), { recursive: true })
    fs.writeFileSync(样本, JSON.stringify({ 原始字节: s.总, at: new Date().toISOString(), 条数: s.条数 }))
  } catch (e) { console.log('   ⚠️ 样本写不回去：' + String(e.message || e).slice(0, 80)) }
  const 万 = 估万(行)
  if (万 !== null) { const jj = 交接判({ 现在万: 万 }); console.log('  —— 交接余量（老板 2026-09-23 令：不许等撞线才说）——'); console.log('   ' + jj.说[0]) }
  fs.writeFileSync(样本, JSON.stringify({ 原始字节: s.总, at: new Date().toISOString().slice(0, 16).replace('T', ' ') }, null, 2))
  process.exit(p.该换 || p.该拆 || p.该交接 ? 1 : 0)
}

/** 从会话日志行里估「现在多少万 token」（最近 3 条 usage 的 cacheRead 均值，与换窗公式同口径） */
export function 估万(行) {
  const us = []
  for (const l of 行) { let j; try { j = JSON.parse(l) } catch { continue } const u = j && j.data && j.data.usage; if (u && typeof u.cacheReadTokens === 'number') us.push(u.cacheReadTokens) }
  if (us.length < 3) return null
  return Math.round(us.slice(-3).reduce((a, b) => a + b, 0) / 3 / 1000) / 10
}

function 交接() {
  const f = 找日志()
  if (!f) { console.log('❌ 找不到本窗会话日志（DSH_SESSION_ID 没设？）'); process.exit(3) }
  const r = spawnSync('zstd', ['-dc', f], { maxBuffer: 512 * 1024 * 1024, encoding: 'buffer' })
  if (r.status !== 0) { console.log('❌ 解压失败：' + String(r.stderr || '').slice(0, 200)); process.exit(3) }
  const 行 = r.stdout.toString('utf8').split('\n').filter(Boolean)
  const 万 = 估万(行)
  if (万 === null) { console.log('❌ 用量记录太少（' + 行.length + ' 行），算不出上下文'); process.exit(3) }
  const j = 交接判({ 现在万: 万 })
  console.log('### 交接余量 · ' + path.basename(f))
  console.log('  现在 ' + 万 + ' 万 token ／ 极限 ' + 交接参数.极限万 + ' 万（**我们的经验风险线**，不是厂商宣称的窗口大小）')
  console.log('  一次交接 ≈ ' + j.交接需要.toFixed(1) + ' 万（' + 交接参数.交接步 + ' 步 × 每步 ' + 交接参数.每步万 + ' 万）｜ 余额 ' + j.余额.toFixed(1) + ' 万 ｜ 够干 ≈ ' + j.还能干 + ' 步')
  for (const x of j.说) console.log('  ' + x)
  process.exit(j.该交接 ? 1 : 0)
}

function selftest() {
  let 过 = 0, 共 = 0
  const 试 = (名, 得, 期) => { 共++; if (JSON.stringify(得) === JSON.stringify(期)) { 过++; console.log('  ✅ ' + 名) } else console.log('  ❌ ' + 名 + ' 得=' + JSON.stringify(得) + ' 期=' + JSON.stringify(期)) }
  const s1 = 统计([100, 9000, 40000])
  试('统计：大块数（>8KB）', s1.大块数, 2)
  试('统计：超硬（>32KB）', s1.超硬, 1)
  试('统计：单条最重', s1.单条最重, 40000)
  试('判：全在档内 ⇒ 不拆不换且说"都在档内"', 判档({ 单条最重: 1000, 本段新增: 1000, 本窗累计: 1000 }).建议, ['✅ 都在档内'])
  试('判：单条 40KB ⇒ 命中硬上限', 判档({ 单条最重: 40000 }).大块, true)
  试('判：本段新增 200KB ⇒ 该拆', 判档({ 本段新增: 200 * 1024 }).该拆, true)
  试('判：本窗 25MB ⇒ 该换', 判档({ 本窗累计: 25 * 1048576 }).该换, true)
  试('判：本段 119KB ⇒ 不该拆（边界）', 判档({ 本段新增: 119 * 1024 }).该拆, false)
  试('交接判：现在 29 万 ⇒ 该交接（余额 1 万 < 1.8×1.5）', 交接判({ 现在万: 29 }).该交接, true)
  试('交接判：现在 25 万 ⇒ 还不该交接（余额 5 万）', 交接判({ 现在万: 25 }).该交接, false)
  试('交接判：现在 25 万 ⇒ 够干约 16 步', 交接判({ 现在万: 25 }).还能干, 16)
  试('判档：本窗 19MB ⇒ 该交接（提前档）', 判档({ 本窗累计: 19 * 1048576 }).该交接, true)
  试('判档：本窗 17MB ⇒ 不该交接（边界）', 判档({ 本窗累计: 17 * 1048576 }).该交接, false)
  console.log(`自检：${过}/${共} ${过 === 共 ? '✅' : '❌'}`)
  process.exit(过 === 共 ? 0 : 1)
}

const [cmd, arg] = process.argv.slice(2)
if (cmd === 'selftest') selftest()
else if (cmd === '量' || !cmd) 量()
else if (cmd === '交接') 交接()
else if (cmd === '判' && arg) {
  const [a = 0, b = 0, c = 0] = arg.split(',').map((x) => Number(x) * 1024)
  const p = 判档({ 单条最重: a, 本段新增: b, 本窗累计: Number(arg.split(',')[2] || 0) > 1024 ? Number(arg.split(',')[2]) * 1048576 : c })
  console.log(p.建议.join('\n'))
} else { console.log('用法：node 神经/上下文账.mjs 量 ｜ 判 <单条KB>,<本段KB>,<本窗MB> ｜ selftest'); process.exit(2) }
