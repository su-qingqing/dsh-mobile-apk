#!/usr/bin/env node
// ═══ 上下文门 · 1001 ③「门收敛」M4：**报数那几道 → 1 个入口** ═══
//
// 出处：`台账/体检/1001-门梳理.md` §五 M4 —— 并的：`压缩计.mjs 行`＋`上下文账.mjs 量`＋`停手线.mjs 测`＋`步数表.mjs`
//   （`打烊 §四之四` 里那两行同源，保持不变）。
// ★ **回程闸（spill）不并**（门梳理原话）：它是**改写结果**，其余几道是**报数** ⇒ 混一个入口＝把"改数据"和"看一眼"混在一起。
// ★ 老板 0929 护栏：**改入口、不改判据、不删文件** —— 4 个子件一行没动。
//
// 用法：
//   node 神经/上下文门.mjs 现状 [会话id]   # 压缩计 ＋ 上下文账 ＋ 停手线 ⇒ 一行"现状"
//   node 神经/上下文门.mjs 步数 [会话id]   # 步数表（拆轮/换窗判决）
//   node 神经/上下文门.mjs 全   [会话id]
//   node 神经/上下文门.mjs selftest
// 退出码（口径写死）：0 = **仪器都读到了**（哪怕它判"该换窗/该拆轮"——那是**告警**，另印 ⚠️ 行）／1 = 有仪器**读不到/崩/超时**（尺子坏了）／2 = 用法错。
//   ★ 为什么告警≠红：`上下文账/步数表` 用 rc=1 表示"该换窗了"——**那是结论不是故障**；混一个 rc ⇒ 门账里永远红 ⇒ 没人再看。
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const WS = '/storage/emulated/0/3'
const NODE = process.env.DSH_NODE || '/data/data/com.dsharnessmobile.shell/files/usr/bin/node'
const T = (p) => path.join(WS, p)
const 会话 = () => process.argv.slice(3).find((a) => !a.startsWith('--')) || ''

const 子 = {
  压缩: { 名: '压缩计 行', 文件: T('神经/压缩计.mjs'), 参: (s) => (s ? ['行', s] : ['行']), 超时: 120000 },
  上下文: { 名: '上下文账 量', 文件: T('神经/上下文账.mjs'), 参: (s) => ['量', ...(s ? [s] : [])], 超时: 120000 },
  停手线: { 名: '停手线 测', 文件: T('神经/停手线.mjs'), 参: () => ['测'], 超时: 120000 },
  步数: { 名: '步数表', 文件: T('神经/步数表.mjs'), 参: (s) => (s ? [s] : []), 超时: 180000 },
}

function 跑(c, 参) {
  const t0 = Date.now()
  const r = spawnSync(NODE, [c.文件, ...参], { cwd: WS, encoding: 'utf8', timeout: c.超时, maxBuffer: 32 * 1024 * 1024 })
  const out = String(r.stdout || '') + String(r.stderr || '')
  const 净 = out.split('\n').filter((l) => !/开工闸门|现成素材|同一 id|情境\||引擎替你查的|相关 \d/.test(l)).map((l) => l.trim()).filter(Boolean)
  return { rc: r.status === null ? -1 : r.status, 秒: ((Date.now() - t0) / 1000).toFixed(1), 净, out }
}
// 尺子坏了 ＝ 超时/被杀(rc -1) 或 零输出 或 rc==3（各件的"读不到"约定）
const 尺坏了 = (r) => r.rc === -1 || r.净.length === 0 || r.rc === 3

if (process.argv[2] === 'selftest') {
  let bad = 0
  const chk = (c, m) => { if (!c) bad++; console.log((c ? '✅ ' : '❌ ') + m) }
  for (const [k, c] of Object.entries(子)) chk(fs.existsSync(c.文件), `子件在盘：${k} ⇒ ${path.relative(WS, c.文件)}`)
  const r0 = spawnSync(NODE, [process.argv[1], '没有这个面'], { encoding: 'utf8' })
  chk(r0.status === 2, '错面 ⇒ rc=2（现 ' + r0.status + '）')
  const r1 = 跑(子.压缩, ['行'])
  chk(!尺坏了(r1) && /【压缩】/.test(r1.out), '真跑一门（压缩计 行）有【压缩】行：' + (r1.净.slice(-1)[0] || '').slice(0, 60))
  const r2 = 跑(子.上下文, ['量'])
  chk(!尺坏了(r2), '真跑一门（上下文账 量）非零输出（rc=' + r2.rc + '＝告警也可能）')
  chk(解上下文(r2.out) !== null, '取数口径：上下文账正则能读出"余额/步数"')
  chk(解步数('尾巴里自动压缩 4 次 ｜ 尾巴里工具调用共 389 次') !== null, '取数口径：步数表正则能读出两个数')
  console.log(bad ? `\n❌ ${bad} 条不过` : '\n✅ 上下文门自证全过（入口合并 · 子件判据未动 · 回程闸不并）')
  process.exit(bad ? 1 : 0)
}

function 解压缩(o) { return (o.match(/【压缩】[^\n]*/) || [null])[0] }
function 解上下文(o) {
  const m = o.match(/现在\s*([\d.]+)\s*万\s*⇒\s*余额\s*([\d.]+)\s*万，够干\s*≈\s*(\d+)\s*步/)
  return m ? { 现: m[1], 余: m[2], 步: m[3] } : null
}
function 解停手(o) { const m = o.match(/★\s*\*\*(\d+)\s*条只增不减\*\*/); return m ? { 只增: m[1] } : null }
function 解步数(o) {
  const m = o.match(/自动压缩\s*(\d+)\s*次.*?工具调用共\s*(\d+)\s*次/)
  return m ? { 压: m[1], 调: m[2], 判: /该拆轮|该换窗/.test(o) ? '该拆轮/换窗' : '还能走' } : null
}

const 面 = process.argv[2] || '现状'
const s = 会话()
if (面 === 'help' || 面 === '--help') { console.error('用法：node 神经/上下文门.mjs <现状|步数|全|selftest> [会话id]'); process.exit(2) }
const 面表 = 面 === '全' ? ['现状', '步数'] : [面]
if (!面表.every((m) => ['现状', '步数'].includes(m))) { console.error('没这个面：' + 面 + '（有：现状／步数／全）'); process.exit(2) }
console.log(`══ 上下文门（一个入口 · ${面表.join('＋')}）══  ★ 回程闸（改写结果）**不并进来** —— 门梳理原话`)
let 坏 = 0
const 汇总 = []
if (面表.includes('现状')) {
  for (const k of ['压缩', '上下文', '停手线']) {
    const c = 子[k], r = 跑(c, c.参(k === '压缩' ? s : ''))
    if (尺坏了(r)) { 坏++; console.log(`  ❌ ${c.名.padEnd(12)} rc=${r.rc} ${r.秒}s —— 尺子坏了（读不到/崩/超时）`) ; continue }
    const 告警 = /\*\*红\*\*|⚠️|该换窗|过换窗线|该拆轮/.test(r.out)
    console.log(`  ${告警 ? '⚠️' : '✅'} ${c.名.padEnd(12)} rc=${r.rc} ${r.秒}s  ${r.净.slice(-1)[0].slice(0, 100)}`)
  }
  const 压 = 解压缩(跑(子.压缩, 子.压缩.参(s)).out)
  const 上 = 解上下文(跑(子.上下文, ['量']).out)
  const 停 = 解停手(跑(子.停手线, ['测']).out)
  if (压) 汇总.push(压.replace('【压缩】', '压缩：').slice(0, 120))
  if (上) 汇总.push(`交接余量 ${上.余} 万（够 ≈${上.步} 步 ｜ 现 ${上.现} 万）`)
  if (停) 汇总.push(`停手线：${停.只增} 条只增不减`)
  console.log(`  ━━ 本窗上下文/成本现状：${汇总.length ? 汇总.join(' ｜ ') : '（这次没读出数）'} ━━`)
}
if (面表.includes('步数')) {
  const c = 子.步数, r = 跑(c, c.参(s))
  if (尺坏了(r)) { 坏++; console.log(`  ❌ ${c.名.padEnd(12)} rc=${r.rc} ${r.秒}s —— 尺子坏了`) }
  else {
    const d = 解步数(r.out)
    console.log(`  ${d && d.判 !== '还能走' ? '⚠️' : '✅'} ${c.名.padEnd(12)} rc=${r.rc} ${r.秒}s  ${d ? `自动压缩 ${d.压} 次 ｜ 工具调用 ${d.调} 次 ｜ 判决：${d.判}` : r.净.slice(-1)[0].slice(0, 90)}`)
  }
}
console.log(坏 ? `\n❌ ${坏} 把尺子坏了（读不到/崩/超时）⇒ 先修尺子（告警另计，见 ⚠️ 行）` : '\n✅ 仪器都读到了（"该换窗/该拆轮"是**告警不是故障**，见 ⚠️ 行）')
process.exit(坏 ? 1 : 0)
