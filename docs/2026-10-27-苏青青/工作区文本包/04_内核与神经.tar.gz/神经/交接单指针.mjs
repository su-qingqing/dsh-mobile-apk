/**
 * 交接单指针闸 —— 判据：`台账/接续/交接单_最新.md` **必须**就是最新那张交接单。
 *
 * 病根（2026-09-29 实测）：`交接单_最新.md` 是 pins 里点名的「**接活第一件事**」那一页，
 *   可它是**手工复制**的 —— 我这一轮写完新交接单（`交接单_0929-1950_….md`）却**忘了同步指针**，
 *   于是下一窗开窗会读到**上一张旧页**，而**没有任何东西看得见**。
 *   ⇒ 这就是「指针/改名型动作没有判据」这一类（与链断同族：「有人该做，没人盯」）。
 *
 * 契约（照抄 `神经/轮末自检.mjs`）：**只观察、只报告，绝不拦、绝不改盘**。
 * 用法：node 神经/交接单指针.mjs        （人跑／给轮末自检调）
 *       node 神经/交接单指针.mjs selftest （阴性：指针过期必须报红）
 */
import fs from 'node:fs';
import path from 'node:path';

const WS = '/storage/emulated/0/3';
const 指针 = '台账/接续/交接单_最新.md';

/** 取一张表的首行（认页名用）；读不到 ⇒ null */
const 首行 = (abs) => { try { return (fs.readFileSync(abs, 'utf8').split('\n')[0] || '').trim() } catch { return null } };

/**
 * 判据本体。
 * ⇒ { ok, 指针首行, 最新首行, 最新文件, 说, 一行, 红 }
 */
export function 查(工作区 = WS) {
  const dir = path.join(工作区, '台账/接续');
  const 指针绝对 = path.join(工作区, 指针);
  let 候选 = [];
  try {
    候选 = fs.readdirSync(dir)
      .filter((f) => /^交接单_.*\.md$/.test(f))
      .filter((f) => !/\.bak-/.test(f) && !/^交接单_模板/.test(f) && f !== '交接单_最新.md')
      .map((f) => ({ 名: f, t: (() => { try { return fs.statSync(path.join(dir, f)).mtimeMs } catch { return 0 } })() }))
      .sort((a, b) => b.t - a.t);
  } catch { }
  if (!候选.length) {
    return { ok: null, 说: '台账/接续 下读不到任何 `交接单_*.md` ⇒ **认不出，不猜**', 一行: '交接单指针：认不出（无候选页）' };
  }
   const 最新 = 候选[0];
  const 指针行 = 首行(指针绝对);
  const 最新行 = 首行(path.join(dir, 最新.名));
  if (!指针行) return { ok: false, 红: 指针 + ' **不在**', 最新文件: 最新.名, 最新首行: 最新行, 说: '指针页**不在**（`' + 指针 + '`）⇒ 新窗开局读不到交接单', 一行: '交接单指针 ❌ 不在' };
  const same = (a, b) => !!a && !!b && a.replace(/\s+/g, ' ').trim() === b.replace(/\s+/g, ' ').trim();
  if (!same(指针行, 最新行)) {
    return {
      ok: false, 红: '指针过期',
      指针首行: 指针行, 最新首行: 最新行, 最新文件: 最新.名,
      说: '`' + 指针 + '` 指向的不是最新那张（最新＝`' + 最新.名 + '`）⇒ **下一窗会读到旧页**',
      一行: '交接单指针 ❌ 过期（指针：' + 指针行.slice(0, 26) + '… ／ 最新：' + 最新.名.slice(0, 30) + '）',
      修法: 'cp ' + path.join('台账/接续', 最新.名) + ' ' + 指针,
    };
  }
  return { ok: true, 指针首行: 指针行, 最新文件: 最新.名, 说: '指针＝最新页（' + 最新.名 + '）', 一行: '交接单指针 ✅ 同步' };
}

// ── 命令行 ────────────────────────────────────────────────────────────────
const 是入口 = process.argv[1] && process.argv[1].endsWith('交接单指针.mjs');
if (是入口 && process.argv[2] === 'selftest') {
  const T = [];
  const ok = (名, 条件, 注 = '') => T.push([名, !!条件, 注]);
  const os = await import('node:os');
  const 现场 = fs.mkdtempSync(path.join(os.tmpdir(), 'jd-'));
  fs.mkdirSync(path.join(现场, '台账/接续'), { recursive: true });
  // 阳性①：指针＝最新 ⇒ 绿
  fs.writeFileSync(path.join(现场, 指针), '# 交接单 0929-1950 · 新 留\n', 'utf8');
  fs.writeFileSync(path.join(现场, '台账/接续/交接单_0929-1950_新.md'), '# 交接单 0929-1950 · 新 留\n', 'utf8');
  fs.writeFileSync(path.join(现场, '台账/接续/交接单_0929-1848_旧.md'), '# 交接单 0929-1848 · 旧 留\n', 'utf8');
  const t0 = Date.now() / 1000 - 100;
  fs.utimesSync(path.join(现场, '台账/接续/交接单_0929-1848_旧.md'), t0, t0);
  ok('阳性① 指针＝最新页 ⇒ 绿', (() => { const r = 查(现场); return r.ok === true })());
  // 阴性②（真反证）：指针停在旧页 ⇒ 必须报红
  fs.writeFileSync(path.join(现场, 指针), '# 交接单 0929-1848 · 旧 留\n', 'utf8');
  ok('反证② 指针停在旧页 ⇒ 报红（这一条锁的就是 0929 那次漏同步）', (() => { const r = 查(现场); return r.ok === false && /过期/.test(r.红 || '') })());
  // 边界③：没有任何候选页 ⇒ 认不出，不猜（ok=null）
  const 空 = fs.mkdtempSync(path.join(os.tmpdir(), 'jd2-'));
  fs.mkdirSync(path.join(空, '台账/接续'), { recursive: true });
  ok('边界③ 无候选页 ⇒ 认不出（ok=null，不假绿也不假红）', (() => { const r = 查(空); return r.ok === null })());
  let 过 = 0;
  for (const [名, 好, 注] of T) { console.log((好 ? '  ✅ ' : '  ❌ ') + 名 + (注 ? '  ← ' + 注 : '')); if (好) 过++ }
  console.log('\n' + (过 === T.length ? '✅ 交接单指针 自检通过 ' + 过 + '/' + T.length : '❌ ' + 过 + '/' + T.length));
  process.exit(过 === T.length ? 0 : 1);
} else if (是入口) {
  const r = 查();
  console.log('【交接单指针】' + r.一行);
  console.log('  ' + r.说);
  if (r.修法) console.log('  修法：' + r.修法);
  process.exit(r.ok === false ? 1 : 0);
}
