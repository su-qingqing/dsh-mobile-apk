#!/usr/bin/env node
// ── 交接牌（跨窗）· 写 / 看 ─────────────────────────────────────────
// 用法：node 神经/交接牌.mjs 写 "<主观预告>"   ｜  看
// 落点：台账/接续/交接牌.json（新窗开工一屏【交接牌】格读它）
// 【四模块耦合】法＝本文件（判据只此一处）｜记忆＝上一窗收尾／换窗之前｜神经＝**已接**（`工具/开工/离场.mjs:118` 那道检查：牌龄早于本轮起点 && 超 60 秒容差 ⇒ 当场叫我写；强度＝**sensor 只报不拦**）｜动作＝没写 ⇒ 新窗那格报「未读到」并说明"可能没打烊"
//
// ★ 1013-10-13 第 57 刀 · **改根**（过时注释）：原来这里写着「神经＝⚠️ **挂点未接**（孤儿件，待接进轮末自检／离场）」——
//   那句是 **10-09 的老话，早就不成立了**：1012 那窗已经把它接进 `离场.mjs`（正是为了治老板那句
//   「上一个窗口就已经交接清楚了，但**连续性从上面出了问题**」）。
//   ⚠️ **过时的注释比没有注释更坏**：我 1013 读到它时**差点又去"接一遍挂点"** —— 这就是书 D.8 说的
//   「你打算信任的那些表示，与它们的对象有**显式、可信的对应**」没做到（第 6 处）。
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
const 根 = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const p = 根 + '/台账/接续/交接牌.json'
const [子, ...另] = process.argv.slice(2)
function 客观() {
  // ★ 抓「含【压缩】的那一行」，并把【压缩】前面的前缀（如 `一行:` / `· `）切掉 —— 1009 夜修（前一版抓第一行，拿到的是压缩计标题行）
  try {
    const 行 = execFileSync('node', [根 + '/神经/压缩计.mjs'], { encoding: 'utf8', timeout: 60000 }).split('\n').map((x) => x.trim())
    const 读 = (行.find((x) => x.includes('【压缩】')) || 行.find((x) => x) || '').replace(/^[^【]*/, '')
    return 读.slice(0, 190) || '（压缩计没吐读数）'
  } catch (e) {
    // ★ 1009 修（记忆 `0muj14rkv` 的同坑）：`压缩计.mjs` **在"该换窗"时会退非零** ⇒ `execFileSync` 抛异常，
    //   但它的 stdout 还在 `e.stdout` 里 ⇒ 不许一抛就当"读不出"（那就是"该响的时候恰好哑了"）。
    const 出 = (e && e.stdout) ? String(e.stdout) : ''
    const 行 = 出.split('\n').map((x) => x.trim())
    const 读 = (行.find((x) => x.includes('【压缩】')) || 行.find((x) => x) || '').replace(/^[^【]*/, '')
    return 读.slice(0, 190) || '（读不出压缩计 —— 不是"没压过"）'
  }
}
if (子 === '写') {
  const 旧 = existsSync(p) ? JSON.parse(readFileSync(p, 'utf8')) : {}
  // ★ 1012 修（读数与设备实际不一致 · 红线 10）：原来用 `toISOString()` ＝ **UTC**，而全系统别处（库一屏／打烊单／
  //   轮末）都是**本地时间** ⇒ 牌刚写完就显示成 8 小时前，下一窗会误判成"旧牌"。改成显式本地时间，格式不变。
  const _本 = (() => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 19).replace('T', ' ') })()
  const 新 = { 说明: 旧.说明 || '跨窗交接牌：上一窗收尾写牌，新窗开窗被动看见。', at: _本, 主观: 另.join(' ').trim() || '（没写主观预告）', 客观: 客观() }
  writeFileSync(p, JSON.stringify(新, null, 1)); console.log('✅ 牌已写 · ' + 新.at + ' ｜ 客观：' + 新.客观)
} else {
  if (!existsSync(p)) { console.log('⚠️ 没有牌'); process.exit(1) }
  const j = JSON.parse(readFileSync(p, 'utf8')); console.log('at ' + j.at + '\n主观：' + j.主观 + '\n客观：' + j.客观)
}
