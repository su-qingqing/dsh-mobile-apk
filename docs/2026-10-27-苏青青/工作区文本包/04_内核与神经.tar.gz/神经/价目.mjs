#!/usr/bin/env node
/**
 * 价目单 —— **唯一**的价目真源（1018 建 · 老板令「做成长期任务，然后开跑」）
 *
 * 为什么要有它：1018 审判发现「同一件事五套算法」——
 *   会话报表.mjs／单价.mjs／换窗公式.mjs／掉档账.mjs／钱账按天.mjs 各写各的价目，
 *   其中 换窗公式.mjs 把缓存命中算成 ¥0.2/百万（官方 ¥0.02）⇒ **高估 8 倍**（1017 审 1 已实证）。
 *
 * 它是什么：把 `单价上限.json` 的「官方分档价目」读出来，提供 `折算(四桶, 档)`。
 *   · **价目不在本文件里写死**（改价改 JSON，不改代码）
 *   · 时段自动判（北京时间周一至周五 9:00-12:00、14:00-18:00＝高峰，其余半价）
 *
 * 它不是什么：不读日志、不算 token（token 由 provider 真报）；**钱只许经它折算**。
 *
 * 用法：
 *   node 神经/价目.mjs                 # 印价目 + 当前时段 + 一例折算
 *   node 神经/价目.mjs 自测             # 三组数手算对照（全对才 exit 0）
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const 本目录 = path.dirname(fileURLToPath(import.meta.url))
const 源文件 = path.join(本目录, '单价上限.json')
const 全 = JSON.parse(fs.readFileSync(源文件, 'utf8'))
export const 价目 = 全['官方分档价目']
if (!价目) throw new Error('价目单：单价上限.json 里没有「官方分档价目」段 —— 拒绝用猜的价钱')

/** 元/百万 token；档 ∈ 空闲｜高峰 */
export const 每百万 = {
  命中: 价目['输入_缓存命中'],
  未命中: 价目['输入_缓存未命中'],
  输出: 价目['输出'],
}

/** 北京时间判时段（周末全天空闲；工作日 9-12、14-18 高峰） */
export function 时段(t = new Date()) {
  const 京 = new Date(t.getTime() + 8 * 3600e3)
  const 周 = 京.getUTCDay()
  if (周 === 0 || 周 === 6) return '空闲'
  const 时 = 京.getUTCHours() + 京.getUTCMinutes() / 60
  return (时 >= 9 && 时 < 12) || (时 >= 14 && 时 < 18) ? '高峰' : '空闲'
}

/** 四桶（token 数）→ 元；四桶 = { 未命中, 命中, 输出 } */
export function 折算(四桶, 档 = 时段()) {
  const p = 每百万
  return (
    ((四桶.未命中 || 0) / 1e6) * p.未命中[档] +
    ((四桶.命中 || 0) / 1e6) * p.命中[档] +
    ((四桶.输出 || 0) / 1e6) * p.输出[档]
  )
}

/** 每百万 token 的混合价（诊断用，不许拿它当账单） */
export function 混合价(档 = 时段()) {
  return { 命中: 每百万.命中[档], 未命中: 每百万.未命中[档], 输出: 每百万.输出[档] }
}

// ── CLI ────────────────────────────────────────────────────────────
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  if (process.argv[2] === '自测') {
    let 过 = 0
    let 挂 = 0
    const 试 = (名, 实, 期) => {
      const ok = Math.abs(实 - 期) < 1e-9
      console.log(`${ok ? '✅' : '❌'} ${名}：实 ${实} ／ 期 ${期}`)
      ok ? 过++ : 挂++
    }
    // 手算基准：空闲 命中 0.02 未命中 1 输出 4（元/百万）
    试('空闲 1M 未命中', 折算({ 未命中: 1e6 }, '空闲'), 1)
    试('空闲 1M 命中', 折算({ 命中: 1e6 }, '空闲'), 0.02)
    试('空闲 1M 输出', 折算({ 输出: 1e6 }, '空闲'), 4)
    试('高峰 1M 未命中', 折算({ 未命中: 1e6 }, '高峰'), 2)
    试('四桶混合 1000万/5000万/100万（空闲）', 折算({ 未命中: 1e7, 命中: 5e7, 输出: 1e6 }, '空闲'), 10 + 1 + 4)
    试('零桶', 折算({}, '空闲'), 0)
    console.log(`\n自测 ${过} 过 / ${挂} 挂`)
    process.exitCode = 挂 ? 1 : 0
  } else {
    console.log('价目（元/百万 token）· 出处：' + 价目._出处)
    console.log(JSON.stringify(每百万, null, 1))
    const 档 = 时段()
    console.log(`现在（${new Date().toISOString()}）判为：**${档}**`)
    console.log('一例：未命中 100 万／命中 5000 万／输出 100 万 ⇒ ¥' + 折算({ 未命中: 1e6, 命中: 5e7, 输出: 1e6 }, 档).toFixed(4))
  }
}
