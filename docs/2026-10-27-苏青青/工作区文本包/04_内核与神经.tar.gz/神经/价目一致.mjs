#!/usr/bin/env node
/**
 * 价目一致核（1018 收口 · 老板令「做成长期任务，然后开跑」）
 *
 * 判据（一句话）：**同一件事只许一套价目**。具体三条机器判：
 *   ① 五件算钱件都必须 `from './价目.mjs'` 取价目（不许自己写常数）
 *   ② 五件源码里不许出现"价目形态"的手写常数（`价X = 0.02`／`{ 未命中: 1 / 1e6` 这类）
 *   ③ 价目单自测必须全过（6/6）
 *
 * 用法：node 神经/价目一致.mjs         # 全绿 exit 0
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

const 本目录 = path.dirname(fileURLToPath(import.meta.url))
const 工作区 = path.resolve(本目录, '..')
const 五件 = ['会话报表.mjs', '单价.mjs', '换窗公式.mjs', '掉档账.mjs', '钱账按天.mjs']

let 坏 = 0
const 记 = (ok, 名, 读 = '') => {
  if (!ok) 坏++
  console.log(`${ok ? '✅' : '❌'} ${名}${读 ? '  · ' + 读 : ''}`)
}

// ① 五件都 import 价目单
for (const f of 五件) {
  const p = path.join(本目录, f)
  const s = fs.readFileSync(p, 'utf8')
  const 引 = /from\s+['"]\.\/价目\.mjs['"]/.test(s)
  记(引, `${f} 从 价目.mjs 取价目`)
}

// ② 没有手写价目常数（扫"看起来像单价"的赋值）
const 坏样式 = [
  /const\s+价\w*\s*=\s*\{\s*未命中\s*:\s*[\d.]/,
  /const\s+价\w*\s*=\s*\{\s*新入\s*:\s*[\d.]/,
  /const\s+P_万\s*=\s*0?\.\d+/,
  /const\s+价命中\s*=\s*0?\.\d+/,
]
for (const f of 五件) {
  const s = fs.readFileSync(path.join(本目录, f), 'utf8')
  const 命中 = 坏样式.filter((r) => r.test(s))
  记(命中.length === 0, `${f} 无手写价目常数`, 命中.length ? 命中.map(String).join(' / ') : '')
}

// ③ 价目单自测
try {
  const out = execFileSync('node', [path.join(本目录, '价目.mjs'), '自测'], { encoding: 'utf8' })
  const m = out.match(/自测 (\d+) 过 \/ (\d+) 挂/)
  记(m && m[2] === '0', '价目单自测全过', m ? `${m[1]} 过 / ${m[2]} 挂` : out.slice(0, 80))
} catch (e) {
  记(false, '价目单自测全过', String(e.stdout || e.message).slice(0, 120))
}

console.log(`\n${坏 === 0 ? '✅ 价目一致（五件一套价）' : `❌ ${坏} 处不一致`}`)
process.exitCode = 坏 ? 1 : 0
