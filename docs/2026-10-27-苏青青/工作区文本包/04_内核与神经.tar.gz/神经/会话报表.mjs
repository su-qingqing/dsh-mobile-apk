/**
 * 会话报表 · 给任意一个会话算 token 总账 ＋ 「谁把上下文堆起来的」＋ 真钱（老板 1005 夜令：拆 188M 的大头）
 * 用法：node 神经/会话报表.mjs <session.v3.jsonl.zstd 路径>
 * 找会话：list_windows(all) 拿标题与 id ⇒ $DSH_HOME/sessions/<projectKey>/<id>/session.v3.jsonl.zstd
 * 读法：execFileSync("zstd",["-dc",f])（多帧！zlib.zstdDecompressSync 只解第一帧 ⇒ 会误判成空文件，记忆 0muj2k5xf）
 * usage 落点：嵌在 assistant/message（每步）与 compaction/summary 的 data.usage 里，要递归找
 * 价目：deepseek-flash 官方分档（空闲 ¥0.02 命中 / ¥1 未命中 / ¥4 输出 每百万 · 高峰翻倍）
 *      出处：api-docs.deepseek.com/zh-cn/quick_start/pricing/ ＋ 落库 单价上限.json「官方分档价目」
 * 分法：未命中按「首次新增字节」分、命中按「重发量」分（贡献 = 字节 × 之后重发次数）
 */
import { execFileSync } from 'node:child_process'
import { 每百万 } from './价目.mjs'
const f = process.argv[2]
const 全 = execFileSync('zstd', ['-dc', f], { maxBuffer: 1200 * 1024 * 1024 }).toString()
const 行 = 全.split('\n').filter((x) => x.trim())
const 找usage = (o, 深) => {
  if (!o || typeof o !== 'object' || 深 > 6) return null
  const u = o.usage
  if (u && typeof u === 'object' && ('totalTokens' in u || 'inputTokens' in u)) return u
  for (const k of Object.keys(o)) { const r = 找usage(o[k], 深 + 1); if (r) return r }
  return null
}
let 步 = 0, miss = 0, hit = 0, out = 0
const 字节 = {}, 贡献 = {}, 每行 = []
for (let i = 0; i < 行.length; i++) {
  const L = 行[i]; let j; try { j = JSON.parse(L) } catch { continue }
  const t = j.type || '?'
  字节[t] = (字节[t] || 0) + L.length; 每行.push([t, L.length])
  const u = 找usage(j, 0)
  if (u) { 步++; miss += u.inputTokens || 0; hit += u.cacheReadTokens || 0; out += u.outputTokens || 0 }
}
const N = 每行.length
for (let i = 0; i < N; i++) { const [t, n] = 每行[i]; 贡献[t] = (贡献[t] || 0) + n * (N - i) }
// 真价目（deepseek-flash · 空闲时段 · 官方页 2026）
const 价命中 = 每百万.命中.空闲 / 1e6, 价未命中 = 每百万.未命中.空闲 / 1e6, 价输出 = 每百万.输出.空闲 / 1e6   // 1018 收口：价目只从 价目.mjs 取
const Σ原 = Object.values(字节).reduce((a, b) => a + b, 0)
const 重发 = {}; let Σ重 = 0
for (const t of Object.keys(字节)) { 重发[t] = Math.max(0, (贡献[t] || 0) - 字节[t]); Σ重 += 重发[t] }
const 万 = (x) => (x / 1e4).toFixed(0)
const 元 = (x) => '¥' + x.toFixed(2)
console.log('【总账】' + 步 + ' 步 ｜ 未命中输入 ' + 万(miss) + ' 万 ｜ 命中输入 ' + 万(hit) + ' 万 ｜ 输出 ' + 万(out) + ' 万')
const 钱miss = miss * 价未命中, 钱hit = hit * 价命中, 钱out = out * 价输出
console.log('  未命中 ' + 万(miss) + ' 万 × ¥1/百万     = ' + 元(钱miss) + '  ← 每步新写进去的内容')
console.log('  命中   ' + 万(hit) + ' 万 × ¥0.02/百万  = ' + 元(钱hit) + '  ← 重读历史（93.5% 的那块）')
console.log('  输出   ' + 万(out) + ' 万 × ¥4/百万     = ' + 元(钱out))
console.log('  ── 合计 ' + 元(钱miss + 钱hit + 钱out) + '（全空闲价）｜ 若全高峰 ' + 元((钱miss + 钱hit + 钱out) * 2) + ' ｜ 每步 ' + 元((钱miss + 钱hit + 钱out) / 步))
console.log('【每块的钱】（未命中按"首次新增字节"分、命中按"重发量"分）')
const 排 = Object.keys(字节).map((t) => {
  const m = miss * (字节[t] / Σ原), h = hit * (重发[t] / Σ重)
  const 钱 = m * 价未命中 + h * 价命中
  return [t, m, h, 钱, 字节[t], 贡献[t]]
}).sort((a, b) => b[3] - a[3]).slice(0, 9)
let 和 = 0
for (const [t, m, h, 钱, 原, 贡] of 排) {
  和 += 钱
  console.log('  ' + t.padEnd(19) + ' 钱 ' + 元(钱).padStart(7) + ' ｜ 未命中 ' + 万(m).padStart(5) + ' 万 ｜ 命中 ' + 万(h).padStart(5) + ' 万 ｜ 原始 ' + (原 / 1048576).toFixed(1) + ' MB ｜ 贡献占比 ' + ((贡 / Object.values(贡献).reduce((a, b) => a + b, 0)) * 100).toFixed(1) + '%')
}
console.log('  前九块小计 ' + 元(和) + ' ｜ 输出钱 ' + 元(钱out) + '（全部是我生成的字）')
