#!/usr/bin/env node
/**
 * 内核体检（可复用）—— 回答一个问题：**内核现在到底有没有在工作？**
 *
 * 用法：node /storage/emulated/0/3/神经/体检.mjs
 * 口径：**只报机械可核的事实**（文件、哈希、计数、日志、端口）。
 *       "行为有没有照做"不在这里判 —— 那要由他和会话记录来判。
 * 依据：内核 #36（指纹）/ #38（注入配给）/ #39（命中记账）/ #42（变更日志）/ #47（定期体检）/ #48（自检行）
 */
import { readFileSync, existsSync, statSync } from 'node:fs'

const WS = '/storage/emulated/0/3'
const HOME = '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const K = WS + '/内核'
let pass = 0, fail = 0
const say = (n, ok, extra) => { ok ? pass++ : fail++; console.log('  ' + (ok ? '✅' : '❌') + ' ' + n + (extra ? '  — ' + extra : '')) }
const read = (p) => { try { return readFileSync(p, 'utf8') } catch { return null } }
const json = (p) => { try { return JSON.parse(readFileSync(p, 'utf8')) } catch { return null } }
const get = async (u) => { try { const r = await fetch(u); return await r.json() } catch (e) { return null } }

console.log('\n内核体检 · ' + new Date().toISOString().slice(0, 16).replace('T', ' ') + '\n')

console.log('── 一、身份与可验证性（#36 / #42 / #48）──')
{
  const k = read(K + '/内核.md') || ''
  const rules = k.split('\n').filter((l) => /^\d+\.\s/.test(l)).length
  // ★ 2026-09-18 修（交付测试 bug#9「预置结论标签」）：原来把 49 写死在**标签**里，
  // 内核长到 50 条时它会印出「= 49（实测 50）」—— 自己打自己脸却不报错。
  // 现改成：**真值取基线**（指纹基线.json 的 rules），标签由数据产生。
  const base0 = json(K + '/指纹基线.json')
  say('内核.md 条数 = ' + rules + '（基线记 ' + (base0 ? base0.rules : '?') + '）',
    !!(base0 && base0.rules === rules) || (!base0 && rules > 0))
  say('总纲已立（〇、总纲 → 原始需求_0917.md）', k.includes('〇、总纲') && existsSync(K + '/原始需求_0917.md'))
  const base = base0
  const panel = await get('http://127.0.0.1:3080/api/dsh-kernel/state')
  const drift = panel && panel.integrity ? panel.integrity.drift : null
  say('指纹基线 hashCore = ' + (base ? base.hashCore : '?') + '，面板 drift=' + drift,
    base && panel && panel.hashCore === base.hashCore && drift === false)
  // ★ 1008 改根（假红 · 同族第 9 次）：老板 1002 令「**以后不再往在办台账挂待办件**」⇒「进行中」这一节**按令该空**。
  //   原判据 ledgerRows>0 等于**要求它非空** ⇒ 报红一个「按令该空」的东西＝假红。改成判「读得到基线 ＋ 字段在且是数字」。
  say('台账在办可读（基线记 ' + (base ? base.ledgerRows : '?') + ' 行 · 1002 令后此节按令可空）', !!(base && typeof base.ledgerRows === 'number'))
  // ★ 2026-09-22（0921 开工包 P2）：**身份面也要有人看着** —— $DSH_HOME/AGENTS.md 每会话注入，
  //   「我叫苏青青」＋四条红线锚写在那儿；它被改了，以前没有任何东西会响（裸奔）。
  const djb2 = (s) => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(16) }
  const AGENTSF = (process.env.DSH_HOME || HOME) + '/AGENTS.md'
  const ANCH = [['身份行', '我叫苏青青'], ['主模型', '我是**用户的 AI 主模型**'], ['重启红线', '绝不自作主张重启引擎'], ['不自己冒出来', '东西不要自己冒出来']]
  const agNow = read(AGENTSF)
  const agMiss = agNow === null ? ['读不到 ' + AGENTSF] : ANCH.filter((a) => !agNow.includes(a[1])).map((a) => a[0])
  const agDrift = !!(base && base.agentsHash && agNow && base.agentsHash !== djb2(agNow))
  say('身份面 AGENTS.md 身份锚 ' + (ANCH.length - agMiss.length) + '/' + ANCH.length + (agMiss.length ? ' ✘缺：' + agMiss.join('、') : '') + (agDrift ? ' ⚠ 指纹变了（有意改的 ⇒ 跑一次 基线.mjs 重记；不是你改的 ⇒ 报警）' : ''),
    agNow !== null && agMiss.length === 0 && !agDrift)
  const log = read(K + '/变更日志.md') || ''
  const entries = (log.match(/^## \d{4}-\d{2}-\d{2}/gm) || []).length
  say('变更日志条目数 = ' + entries + '（含「谁点的头」）', entries >= 6 && log.includes('谁点的头'))
}
console.log('\n── 二、两层记忆（#38 / #39 / #47）──')
{
  const panel = await get('http://127.0.0.1:3080/api/dsh-kernel/state')
  const hk = panel && panel.inject ? panel.inject.hitTopK : null
  // ★ 1008 修假红：原判据写死「≥1 才绿、0 报红（理由＝老板 09-20 判过不许是 0）」——
  //   那条口径**已被老板 1007 覆盖**：他点头把 hitTopK 改「按需」＝**显式写 0**（真源 `台账/接续/待你决.md` C 条，六步已走完）。
  //   ⇒ 判据改成「**这一项有没有被显式配置**」：显式写 0 或 N 都合规；没写（走插件默认 2）才提示。
  say('注入配给制 hitTopK = ' + hk + '（显式配置即合规；老板 1007 点头＝按需 0。★ 体检不再自定"不许是 0"）', typeof hk === 'number')
  const dbPath = WS + '/.dsh-meow/memory.db'
  say('记忆库文件在', existsSync(dbPath), (statSync(dbPath).size / 1024 | 0) + 'KB')
  try {
    const { DatabaseSync } = await import('node:sqlite')
    const db = new DatabaseSync(dbPath, { readOnly: true })
    const one = (sql) => { try { return db.prepare(sql).get() } catch { return null } }
    const c = one("select (select count(*) from soul) soul,(select count(*) from user) u,(select count(*) from rules) r,(select count(*) from project) p,(select count(*) from topic) t,(select count(*) from fact) f,(select count(*) from lesson) l")
    const total = c.soul + c.u + c.r + c.p + c.t + c.f + c.l
    say('七层计数 soul/user/rules/project/topic/fact/lesson = ' + [c.soul, c.u, c.r, c.p, c.t, c.f, c.l].join('/') + '  合计 ' + total, total > 0)
    const hit = one("select (select count(*) from lesson where status='active') a,(select count(*) from lesson where status='active' and hit_count=0) z")
    const pct = Math.round(hit.z * 100 / (hit.a || 1))
    console.log('  ℹ️  #39 命中记账：lesson active ' + hit.a + ' 条，**零命中 ' + hit.z + ' 条（' + pct + '%）** ← "数据一直在，只是没人看"')
    const d = one('select count(*) c from dream_log')
    say('#47 定期体检跑过 ' + d.c + ' 次（dream_log）', d.c >= 5, d.c < 5 ? '偏少' : '')
    db.close()
  } catch (e) { say('记忆库可读', false, String(e.message)) }
}
console.log('\n── 三、闸门：按流程干活（C）──')
{
  const gate = read(HOME + '/kickoff-gate.log') || ''
  // ★ 2026-09-18 修（原为假绿）：旧版取日志**尾巴**的最后一条 apply(v2*)，会把**自测隔离实例**
  //   （workspace=…/.dsh-kickoff/testws）的 apply(v2.8) 当成生产版本 ⇒ 报「本进程 v2.8」而生产其实还是 v2.6。
  //   现在只认 workspace === 生产工作区 的行，并把「文件版本」拿来对照 ⇒ 顺便变成**欠重启检测器**。
  const prodApplies = [...gate.matchAll(/apply\((v[\d.]+)\)[^\n]*workspace=(\S+)/g)].filter((m) => m[2] === '/storage/emulated/0/3')
  const vNow = prodApplies.length ? prodApplies[prodApplies.length - 1][1] : '(日志里没有生产 apply 记录)'
  const gateSrc = read(HOME + '/profiles/web/node_modules/@dsh-user/dsh-kickoff-gate/lib/index.js') || ''
  const fm = gateSrc.match(/say\('apply\((v[\d.]+)\)/)
  const vFile = fm ? fm[1] : '(读不到文件版本)'
  say('闸门 · 生产进程 ' + vNow + ' ／ 文件里 ' + vFile, prodApplies.length > 0 && vNow === vFile,
    vNow !== vFile ? '⚠️ **文件比生产新 ⇒ 欠一次重启**才生效（守 #13：重启由你本人做）' : '')
  const afterProd = gate.slice(gate.lastIndexOf('apply(' + vNow + ')'))
  say('生产那条 apply 之后没有被 disposed', !afterProd.includes('disposed'))
  const n = (re) => (gate.match(re) || []).length
  console.log('  ℹ️  历史累计：DENY ' + n(/DENY/g) + ' · PASS ' + n(/PASS/g) + ' · RETRIEVE ' + n(/RETRIEVE/g) + ' · fail-open ' + n(/fail-open/g))
  say('检索真的跑过（RETRIEVE > 0）', n(/RETRIEVE/g) > 0)
  say('装配行在 cordis.patch.yml 里', (read(HOME + '/profiles/web/cordis.patch.yml') || '').includes('kickoff-gate'))
}
console.log('\n── 四、跨窗口（A：凌驾于窗口之上）──')
{
  say('跨窗口固化插件 window-peek 在', existsSync(HOME + '/profiles/web/node_modules/@dsh-user/dsh-window-peek'))
  say('官方 agent-team 9 工具已装配', (read(HOME + '/profiles/web/cordis.patch.yml') || '').includes('agent-team'))
}
console.log('\n── 五、算力与身份（#49 / #27 显示=实际）──')
{
  /* ★ 2026-09-18：用户主动停用了本地 1.7B（原话「那玩意儿目前来说没什么用」）。
     停用是**他的决定**，不是故障 —— 体检不许把它报成红字（红字滥用 = 狼来了，真故障就没人信了）。
     判据：装配行被注释 = 停用态。 */
  const yml = read(HOME + '/profiles/web/cordis.patch.yml') || ''
  const lkOff = !/^\s*- id: local-kernel\s*$/m.test(yml)
  if (lkOff) {
    console.log('  ℹ️  本地那个我（1.7B）：**你 2026-09-18 主动停用** —— 不是故障，不计入红字。')
    console.log('      要开回来：删掉 cordis.patch.yml 里 local-kernel 那 7 行的 "# " 前缀，再重启一次即可。')
  } else {
    const st = await get('http://127.0.0.1:3080/api/dsh-local-kernel/status')
    say('本地那个我在线（/health ok）', !!st && st.ok === true, st ? String(st.model || '').split('/').pop() : '')
    const s = read(HOME + '/settings.yaml') || ''
    const m = s.match(/local-kernel[\s\S]{0,400}?id:\s*([\w.\-]+)/)
    const dn = s.match(/displayName:\s*(本地内核[^\n]*)/)
    const actual = st && st.model ? String(st.model).split('/').pop() : ''
    const claim = m ? m[1] : '?'
    // #27：显示的必须=实际的。名字里去掉 'qwen' 再比（qwen3-4b vs qwen3-1.7b 能区分）
    const norm = (x) => String(x).toLowerCase().replace(/^qwen/, '').replace(/\.gguf$/, '')
    say('#27 路由名与实际一致（写 ' + claim + ' / 实际 ' + actual + '）',
      !!actual && norm(actual).indexOf(norm(claim)) === 0,
      dn ? dn[1] : '')
  }
}
console.log('\n── 结论 ──')
console.log('  机械项通过 ' + pass + ' / ' + (pass + fail) + (fail === 0 ? '  · 全绿' : '  · 有 ' + fail + ' 项不过（见上面 ❌）'))
console.log('  ⚠️ 本工具只报机械事实；"行为有没有照做"（B 不重复踩坑）要看会话记录与时间。\n')
