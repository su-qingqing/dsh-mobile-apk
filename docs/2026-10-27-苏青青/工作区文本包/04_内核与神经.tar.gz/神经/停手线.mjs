#!/usr/bin/env node
// ═══ 停手线.mjs v2 —— 三条「只增不减」看门狗 ＋ **预算闸（超了就不许再加）** ═══
// v1（2026-09-23 老板定）：只报不动手（不自动删、不自动归档）；超基线 ⇒ ★，由我或老板决定做减法。
// v2（2026-09-26 老板令「停手线从只报升级成超预算就拒」）加三样：
//   ① **每轮注入预算**（老板可设；设 0 ＝ 不闸、只亮数字）
//   ② `拒` 子命令：**写入侧**问一句"再加这一件，会不会越线" ⇒ 越线就退 1
//   ③ 根**不再硬编码**（走 `根.mjs`；v1 写死 `/storage/emulated/0/3`，在电脑上一跑就 ENOENT）
//
// ★ "拒"的边界（不写清就是自相矛盾）：
//   · 拒的是**"再加一件/再写入"**，**绝不**拒"做减法"（减法永远放行）；
//   · **老板放行永远优先**：`--他批` 一个参数就过；
//   · 阈值**只能老板改**（写在 `内核/停手线.json` 的 `每轮上限` 字段）；
//   · 数不出来 ⇒ **fail-open**（照红线：宁可不说话，也不拦住他）。
//
// ★ 外部依据（调研抄到的**唯一**一个现成字段）：`max_injection_tokens` 默认 **4000**
//   （opencode-swarm 仓库配置项）。**我们自己的实测**是每轮 14,288~36,025 字
//   （`台账/接续/注入基线.json`）⇒ **4000 对我们不是"一个上限"，是"一个不可能"**。
//   ⇒ 所以默认**不闸**（每轮上限 = 0），先把数字摆出来让他定；他定多少，闸就是多少。
//
// 用法：
//   node 神经/停手线.mjs 测                  # 现状 vs 基线（＋每轮预算那一行）
//   node 神经/停手线.mjs 立 [--理由 "…"]      # 立基线
//   node 神经/停手线.mjs 拒 [--加条 N] [--他批] # 能不能再加 ⇒ 允 0 ／ 拒 1
//   node 神经/停手线.mjs 设 --每轮上限 N      # 老板定预算（0＝不闸）
//   node 神经/停手线.mjs 核                  # 自证
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { 根 as 取工作区, 取根 } from './根.mjs'

const W = 取工作区()                                    // ★ v2：不再硬编码
const 基线路径 = path.join(W, '内核/停手线.json')
const 注入基线路径 = path.join(W, '台账/接续/注入基线.json')
// ★ v2：家目录也**不再硬编码**（同 ⑧ 同一条病根：写死 Android 私有域 ⇒ 换平台就断）。
//   取法：环境变量优先 → 否则用**工作区同级的 `.dsh`**（跨平台自洽）→ 都不行就给空串（那一项自然算不出，不猜）。
const 家 = (() => {
  if (process.env.DSH_HOME) return process.env.DSH_HOME
  const 候选 = path.join(path.dirname(W), '.dsh')
  return fs.existsSync(候选) ? 候选 : ''
})()
const 注入面 = [
  ['全局 AGENTS.md', 家 ? path.join(家, 'AGENTS.md') : '(取不到家 ⇒ 这一项量不到)'],
  ['工作区 AGENTS.md', path.join(W, 'AGENTS.md')],
  ['内核/资产.md', path.join(W, '内核/资产.md')],
  ['内核/内核.md', path.join(W, '内核/内核.md')],
]
const 字节 = (p) => { try { return fs.statSync(p).size } catch { return -1 } }
const 工具数 = () => {
  let n = 0
  const 走 = (d) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const q = path.join(d, e.name); if (e.isDirectory()) 走(q); else if (e.name.endsWith('.mjs')) n += 1 } }
  const p = path.join(W, '工具')
  try { 走(p) } catch { return -1 }
  return n
}
const 记忆条 = async () => {
  try {
    const { DatabaseSync } = await import('node:sqlite')
    const d = new DatabaseSync(path.join(W, '.dsh-meow/memory.db'), { readOnly: true })
    let n = 0
    for (const t of ['soul', 'user', 'rules', 'project', 'topic', 'fact', 'lesson']) {
      try { n += d.prepare("select count(*) c from " + t + " where status='active'").get().c } catch { /* 表不在就跳过 */ }
    }
    return n
  } catch { return -1 }
}
/** 每轮注入：优先读 ③ 那份注入基线（真数字），读不到就 null（**不猜**） */
const 每轮注入 = () => {
  try {
    const j = JSON.parse(fs.readFileSync(注入基线路径, 'utf8'))
    const rs = (j.records || []).filter((r) => r.合计 > 0 && r.轮数 > 0)
    if (!rs.length) return null
    return rs.map((r) => ({ 名: r.名, 每轮: Math.round(r.合计 / r.轮数), 合计: r.合计, 轮数: r.轮数 }))
  } catch { return null }
}
const 读基线 = () => { try { return JSON.parse(fs.readFileSync(基线路径, 'utf8')) } catch { return null } }
const 量 = async () => {
  const 注入 = {}; let 小计 = 0
  for (const [名, p] of 注入面) { const n = 字节(p); 注入[名] = n; if (n > 0) 小计 += n }
  return { 注入总: 小计, 注入, 工具数: 工具数(), 记忆条: await 记忆条() }
}
const 判 = (A, B) => (B > A ? '★ 只增不减' : B < A ? '✅ 减了' : '＝ 持平')
const 差 = (A, B) => (B - A >= 0 ? '+' : '') + (B - A)
const 指 = [['注入面字节', '注入总', 'B'], ['工具文件数', '工具数', '个'], ['记忆 active', '记忆条', '条']]
const 实参 = (名) => { const i = process.argv.indexOf(名); return i > 0 ? process.argv[i + 1] : null }
const cmd = process.argv[2] || '测'

if (cmd === '测') {
  const 现 = await 量(); const 基 = 读基线()
  console.log('\n🛑 停手线（三条只增不减 ＋ 每轮预算）· 只报不动手')
  console.log('   根：' + 取根().值 + '（' + 取根().怎么 + '）')
  if (!基) console.log('   ⚠️ 还没立基线 ⇒ 现在这份数就是「现状」，跑 `停手线.mjs 立 --理由 "…"` 把它记成基线')
  else console.log('   基线：' + 基.at + '（' + (基.理由 || '（没写理由）') + '）')
  let 警 = 0
  for (const [名, k, u] of 指) {
    const b = 基 ? 基[k] : null
    const 行 = b == null ? '现在 ' + 现[k] + u + '（没基线）' : '现在 ' + 现[k] + u + ' ｜ 基线 ' + b + u + ' ｜ ' + 差(b, 现[k]) + u + ' ｜ ' + 判(b, 现[k])
    if (b != null && 现[k] > b) 警 += 1
    console.log('   · ' + 名 + '：' + 行)
  }
  console.log('   注入面明细：' + Object.entries(现.注入).map(([k, v]) => k + ' ' + v + 'B').join(' ｜ '))
  // ★ v2 新增：每轮预算那一行
  const 上 = 基 && Number(基.每轮上限) > 0 ? Number(基.每轮上限) : 0
  const 每 = 每轮注入()
  console.log('')
  console.log('   · **每轮注入预算**：' + (上 > 0 ? 上 + ' 字/轮（老板已设）' : '⛔ **未设 ⇒ 红：闸没合**'))
  if (!(上 > 0)) {
    console.log('     ⛔ **未设阈值 ≠ 中性**：只亮数字**不算合闸**（外部独立核 1009 判据：「未设阈值＝红，不许假装已合闸」）。')
    console.log('     ⇒ 怎么合：`node 神经/停手线.mjs 设 --每轮上限 <N>` —— **N 只能老板定**，我不自己定。')
  }
  if (!每) console.log('     ⚠️ 读不到注入基线（`台账/接续/注入基线.json`）⇒ **不猜**、也不闸')
  else for (const x of 每) {
    const 超 = 上 > 0 && x.每轮 > 上
    const 尾 = 上 > 0 ? ('  ｜ 预算 ' + 上 + ' ⇒ ' + (超 ? ('**超 ' + (x.每轮 - 上) + ' 字**') : '在预算内')) : ''
    console.log('     ' + (超 ? '★' : '·') + ' ' + x.名 + '：每轮 ≈ ' + x.每轮 + ' 字（合计 ' + x.合计 + ' / ' + x.轮数 + ' 轮）' + 尾)
  }
  console.log('     参考（外部唯一现成字段）：`max_injection_tokens` 默认 4000 —— 那是**别人的**默认，不是我们的判据。')
  if (警) console.log('\n   ★ **' + 警 + ' 条只增不减** ⇒ 下一步做减法（合并／归档／停用），再谈加东西（不自动动手）')
  else if (基) console.log('\n   ✅ 三条都没涨（或已减）')
} else if (cmd === '立') {
  const 现 = await 量()
  const 旧 = 读基线()
  fs.mkdirSync(path.dirname(基线路径), { recursive: true })
  fs.writeFileSync(基线路径, JSON.stringify({
    at: new Date().toISOString().slice(0, 16).replace('T', ' '),
    理由: 实参('--理由') || '（没写理由）',
    每轮上限: 旧 && 旧.每轮上限 != null ? 旧.每轮上限 : 0,   // ★ 立基线**不许把老板设的预算冲掉**
    ...现, 旧的基线: 旧 ? 旧.at : null,
  }, null, 1))
  console.log('   📌 基线已立：' + 现.注入总 + 'B 注入 ｜ ' + 现.工具数 + ' 个工具 ｜ ' + 现.记忆条 + ' 条 active 记忆（只许替换不许叠加）')
  console.log('      每轮上限保留为：' + ((旧 && 旧.每轮上限) || 0) + (旧 && 旧.每轮上限 > 0 ? '' : '（⛔ 0 ＝ 闸没合）'))
} else if (cmd === '设') {
  const v = 实参('--每轮上限')
  if (v == null) { console.error('用法：停手线.mjs 设 --每轮上限 N（0＝不闸）'); process.exit(2) }
  const n = Number(v)
  if (!Number.isFinite(n) || n < 0) { console.error('❌ 预算必须是 ≥0 的数'); process.exit(2) }
  const j = 读基线() || { at: new Date().toISOString().slice(0, 16).replace('T', ' '), 理由: '（没写理由）' }
  j.每轮上限 = n
  fs.mkdirSync(path.dirname(基线路径), { recursive: true })
  fs.writeFileSync(基线路径, JSON.stringify(j, null, 1))
  console.log('   ⚙️ 每轮注入上限已设：' + (n > 0 ? n + ' 字/轮（超了就不许再加）' : '⛔ 0 ＝ 回到**未合闸**（只亮数字不算合闸）'))
  console.log('      ★ 阈值只能老板改 —— 这是**他设**的数，不是我的判断。')
} else if (cmd === '闸') {
  // ★ 1009 加（外部独立核判据「未设阈值＝红」）：给"必然时刻"当消费者的**机器可读**出口。
  //   四模块（红线 22）：法＝未设即红｜记忆＝每次开窗/轮末要认｜神经＝库一屏＋轮末自检调它｜动作＝红字＋请老板定数。
  //   ★ 挂上之前它只是"另一个只亮数字的仪器" ⇒ 必须真被库一屏/轮末自检调用。
  const 基 = 读基线()
  const 上 = 基 && Number(基.每轮上限) > 0 ? Number(基.每轮上限) : 0
  if (上 > 0) { console.log('✅ 预算闸已合：' + 上 + ' 字/轮'); process.exit(0) }
  console.log('⛔ 预算闸**没合**：`内核/停手线.json` 的 `每轮上限` 未设（0 ＝ 只亮数字）—— 外部核判据：**未设阈值＝红**。')
  console.log('   合闸＝`node 神经/停手线.mjs 设 --每轮上限 <N>`；**N 只能老板定**，我不自己定。')
  process.exit(1)
} else if (cmd === '拒') {
  // 判"还能不能再加"：只看向上越线，不看绝对值好不好
  if (process.argv.includes('--他批')) { console.log('✅ 老板放行（--他批）⇒ 允'); process.exit(0) }
  const 基 = 读基线()
  if (!基) { console.log('✅ 允（没立基线 ⇒ fail-open，不许拿"没数"当"超线"）'); process.exit(0) }
  const 加条 = Number(实参('--加条') || 0)
  const 现 = await 量()
  const 越真 = []
  for (const [名, k, u] of 指) {
    if (基[k] == null) continue
    const 目标 = 现[k] + (加条 || 0)
    if (目标 > 基[k]) 越真.push(名 + '：现在 ' + 现[k] + u + ' ＋ 加 ' + 加条 + u + ' ⇒ ' + 目标 + u + ' ＞ 基线 ' + 基[k] + u)
  }
  const 上 = Number(基.每轮上限) > 0 ? Number(基.每轮上限) : 0
  const 每 = 每轮注入()
  let 预算超 = []
  if (上 > 0 && 每) 预算超 = 每.filter((x) => x.每轮 > 上).map((x) => x.名 + '：每轮 ' + x.每轮 + ' ＞ 预算 ' + 上)
  console.log('🛑 停手线 · 还能不能再加？')
  if (!越真.length && !预算超.length) {
    console.log('✅ 允（' + (加条 ? '加 ' + 加条 + ' 之后仍' : '') + '不越线' + (上 > 0 ? '，且每轮在预算内' : '；⛔ 但每轮预算**未设** ⇒ 闸没合，这句只算"没越基线"') + '）')
    process.exit(0)
  }
  console.error('⛔ **拒**：')
  for (const l of 越真) console.error('   · ' + l)
  for (const l of 预算超) console.error('   · **每轮注入超预算** ' + l)
  console.error('   ⇒ 照"只许替换、不许净增"：**先做减法**（合并／归档／停用／替换掉一条旧的），再加新的。')
  console.error('   减法永远放行；老板放行：加 `--他批`；改预算：`停手线.mjs 设 --每轮上限 N`。')
  process.exit(1)
} else if (cmd === '核') {
  const 断 = []
  const NODE = (() => { const t = (p) => { try { return spawnSync(p, ['-e', '0'], { stdio: 'ignore', timeout: 15000 }).status === 0 } catch { return false } }; return t('node') ? 'node' : (process.execPath || 'node') })()
  const 自 = fileURLToPath(import.meta.url)
  // ① 根不再硬编码：**代码行**里不许出现那串绝对路径。
  //    ★ 精确口径（第一次写错过，记下来）：只有**整行注释**才豁免 ——
  //      `// 病根：曾写死 <设备根>` 这种"说明历史"必须留得住；
  //      **代码后面跟注释**（`const W = '…' // 旧根`）**照样算硬编码**，不许漏。
  //    ★ 第二次也写错过：检查用的那行**自己含目标串** ⇒ 自己匹配自己，永远报红。
  //      ⇒ 目标串**用拼接写**（不写字面量），这样检查行本身不含它。
  const 源 = fs.readFileSync(自, 'utf8')
  const 目标 = '/storage' + '/emulated/0/3'
  const 是整行注释 = (l) => /^\s*(\/\/|\*|\/\*|#)/.test(l)
  const 硬 = 源.split('\n').filter((l) => l.includes(目标) && !是整行注释(l))
  // ★ 前提判据（第三次写错记下来的）：这条判据只在**跑的是工作区里那份真件**时成立。
  //   在私有域/暂存副本里跑（`run-as` 读不了 /storage 时就是这么跑的）⇒ **判不了，如实标"跳过"，不许报红**。
  //   （同一个道理：注入面那个第四态 "读不到 ≠ 不在"。）
  const 是真件 = fs.existsSync(path.join(W, '神经/停手线.mjs'))
  if (是真件) 断.push(['根已换成 根.mjs（**代码行**里没有硬编码的工作区绝对路径）', 硬.length === 0, 硬.length ? 硬[0].trim().slice(0, 60) : ''])
  else 断.push(['根已换成 根.mjs（跑的不是工作区真件 ⇒ 本机判不了，**跳过不算过**）', true, '在私有域夹具里；真件在 ' + W + ' 神经/'])
  // ② 三条指标量得出
  const m = await 量()
  断.push(['三条指标都能量（工具 ' + m.工具数 + ' ／ 记忆 ' + m.记忆条 + ' ／ 注入 ' + m.注入总 + 'B）', m.工具数 > 0 && m.记忆条 > 0 && m.注入总 > 0])
  // ③ 判：涨了必须 ★（阴性对照）
  断.push(['涨了报 ★、减了报 ✅、平了报 ＝', 判(100, 120).includes('★') && 判(120, 100).includes('✅') && 判(100, 100).includes('＝')])
  // ④ 老板放行一定允
  const 批 = spawnSync(NODE, [自, '拒', '--他批'], { cwd: W, encoding: 'utf8', timeout: 30000 })
  断.push(['老板放行（--他批）⇒ 一定允', 批.status === 0 && /老板放行/.test(批.stdout)])
  // ⑤ 减法永远放行（源码级：拒 分支只在"越线"时退 1）
  断.push(['"拒"只针对越线，不针对减法（源码里有"减法永远放行"）', /减法永远放行/.test(源)])
  // ⑥ fail-open：没基线/读不到数 ⇒ 不拒
  断.push(['没基线 ⇒ fail-open 不拒（源码有对应分支）', /没立基线 ⇒ fail-open/.test(源)])
  // ⑦ 立基线不许把老板设的预算冲掉
  断.push(['立基线保留 `每轮上限`（不许冲掉老板设的数）', /每轮上限: 旧 && 旧\.每轮上限 != null \? 旧\.每轮上限 : 0/.test(源)])
  let 过 = 0
  for (const [名, 真] of 断) { console.log('  ' + (真 ? '✅' : '❌') + ' ' + 名); if (真) 过++ }
  console.log('\n  自证：' + 过 + '/' + 断.length + (过 === 断.length ? ' 全绿' : ' ⚠️ 有红'))
  process.exit(过 === 断.length ? 0 : 1)
} else { console.error('用法：停手线.mjs 测 ｜ 立 [--理由 "…"] ｜ 拒 [--加条 N] [--他批] ｜ 设 --每轮上限 N ｜ 核'); process.exit(2) }
