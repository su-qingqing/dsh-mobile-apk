#!/usr/bin/env node
/**
 * 入法.mjs —— 「对话 → 内核」的**增量补入管道**（③ 内核模块缺的第 7 件 · 开工卡 0922-合规三红线与三模块收口）
 *
 * 它是什么（人话）：把「一条新经验/新红线」从"我知道"变成"内核里有它"，并且**一路上把理由、出处、
 *   判据、产物、反例都钉进去** —— 不用我手工拼字符串、也不会漏掉变更日志和指纹重算。
 * 为什么有它：三模块缺口审核 §三 #7：「新经验**只能躺在窗口里** …… #45 只是**提醒我**，不是管道」。
 *   同一族毛病（手工拼字符串改内核、改完忘记重算基线/记日志）到 09-22 已多次 ⇒ 做成一条命令。
 *
 * 用法（**默认干跑**，加 --apply 才真写）：
 *   node 神经/入法.mjs 查
 *   node 神经/入法.mjs 草稿 "<事项>" --类 红线|坑 [--原话 "…"] [--出处 "…"] [--判据 "…"]
 *        [--为什么 "…"] [--产物 "…"] [--反例 "…"] [--适用面 "…"]
 *   node 神经/入法.mjs 落 <草稿文件> [--apply] [--重]        # --重＝明知重名也要插（不推荐）
 *   node 神经/入法.mjs selftest                              # 在 $DSH_HOME/tmp 里端到端自测，不碰真内核
 * 退出码：0 = 干跑通过 / 已写入 ｜ 1 = 不许写（重名／编号撞车／锚点不唯一／语法不过） ｜ 2 = 用法错
 *
 * 它**不自己造写面**：真写交给 `工具/文件/补丁.mjs`（断言锚点唯一 → 语法查 → 备份 → 覆盖 + 读回 + 乐观锁）。
 * 回滚：`cp 内核/_backup/内核.md.bak-<MMDD>-前<标记> 内核/内核.md` ＋ 删变更日志尾段 ＋ 重跑 `node 神经/基线.mjs`
 */
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'

const WS = '/storage/emulated/0/3'
const KERNEL = WS + '/内核/内核.md'
const CHANGELOG = WS + '/内核/变更日志.md'
const DRAFT_DIR = WS + '/台账/接续/入法'
const ANCHOR = '---\n\n## 附:内核不装什么'
const H = fs.existsSync(WS + '/内核') ? '' : ''
let NODE = 'node'
try { const m = await import(new URL('../工具/文件/挑node.mjs', import.meta.url).href); if (m.NODE) NODE = m.NODE } catch {}

// ── 内核正文的读法 ────────────────────────────────────────────────────────
// ★ 条数口径与 `神经/基线.mjs:44` **一字不差**（`/^\d+\.\s/`）—— 判据只有一个真源。
//   ⚠️ 本窗实测教训：我第一版只认 `<数字>. **`（加粗标题）⇒ 数出 **61**，而真值是 **74** ——
//   差的 13 条是**短式条文**（`5. 我有平板的手和眼(设备控制)…` `7. 全程中文。` 这种没有加粗的）。
//   ⇒ 两个口径并存 = 同一件事两个数 = 迟早有人拿错的那个。
const 条数口径 = (t) => (t.match(/^\d+\.\s/gm) || []).length
export function 读条文(text) {
  const out = []
  const re = /^(\d{1,3})\.\s+(.+)$/gm
  let m
  while ((m = re.exec(text)) !== null) {
    const 标题 = m[2].replace(/\*\*/g, '').replace(/（[^）]*入法理由[\s\S]*$/, '').trim()
    out.push({ n: Number(m[1]), 标题, at: m.index, line: text.slice(0, m.index).split('\n').length })
  }
  return out
}
export function 统计(text) {
  const rules = 读条文(text)
  const seen = new Map()
  for (const r of rules) seen.set(r.n, (seen.get(r.n) || 0) + 1)
  const 重号 = [...seen.entries()].filter(([, c]) => c > 1).map(([n, c]) => n + '×' + c)
  const 已标注 = (text.match(/入法理由/g) || []).length
  return { 条数: 条数口径(text), 抽到: rules.length, 最大号: rules.reduce((a, r) => Math.max(a, r.n), 0), 重号, 已标注, rules }
}
function 锚点位置(text) {
  const i = text.lastIndexOf(ANCHOR)
  return i < 0 ? -1 : i
}
function 归一(s) { return String(s || '').replace(/[\s　*「」【】（）()：:，,。.、A-Za-z0-9]/g, '') }

// ── 草稿 ───────────────────────────────────────────────────────────────
const 参数 = (argv) => {
  const o = {}
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a.startsWith('--')) { o[a.slice(2)] = (argv[i + 1] && !argv[i + 1].startsWith('--')) ? argv[++i] : true }
  }
  return o
}
function 出草稿(事项, o) {
  if (!事项) { console.error('用法：node 神经/入法.mjs 草稿 "<事项>" --类 红线|坑 …'); process.exit(2) }
  const 类 = o.类 === '红线' ? '红线' : (o.类 === '坑' ? '坑' : null)
  if (!类) { console.error('❌ 必须 --类 红线|坑（内核只收这两种：①重复踩的坑 ②他亲口的红线）'); process.exit(2) }
  const 缺 = ['出处', '判据', '适用面'].filter((k) => !o[k])
  if (缺.length) { console.error('❌ 这三格必填（#42 五步）：' + 缺.join('、')); process.exit(2) }
  const 正文 = [
    '{{编号}}. **' + 事项 + '**（入法理由' + (类 === '红线' ? '②：' : '①：') + (o.原话 ? '老板原话「' + o.原话 + '」' : o.出处) + '）。',
    '    **判据**：' + o.判据,
    '    **为什么**：' + (o.为什么 || '（待补：说不出「不做会怎样」就不该入法 —— 审核 §纪律）'),
    '    **产物**：' + (o.产物 || '**条文级·暂无产物**（诚实标注：它现在拦不住我，只提醒）'),
    '    **反例**：' + (o.反例 || '（待补）'),
    '    **适用面**：' + o.适用面,
  ].join('\n')
  const 案 = 事项.replace(/[\/\\:*?"<>|\s]/g, '_').slice(0, 30)
  const d = new Date()
  const 名 = String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0') + '-' + 案
  const p = DRAFT_DIR + '/' + 名 + '.md'
  if (!fs.existsSync(DRAFT_DIR)) fs.mkdirSync(DRAFT_DIR, { recursive: true })
  const 文本 = [
    '# 入法草稿 · ' + 事项,
    '',
    '> 由 `神经/入法.mjs 草稿` 生成（' + new Date().toISOString().slice(0, 19) + '）。落法：`node 神经/入法.mjs 落 ' + path.relative(WS, p) + ' --apply`',
    '',
    '## 机器读这几行（别改格式）',
    '- 事项: ' + 事项,
    '- 类: ' + 类,
    '- 出处: ' + o.出处,
    '- 原话: ' + (o.原话 || '—'),
    '',
    '## 条文（{{编号}} 由「落」按当时最大号填；下面这段就是将来进内核的原文）',
    '',
    '```内核条文',
    正文,
    '```',
    '',
    '## 落之前自查（#42 五步）',
    '1. 「不做会怎样」说得出来吗？说不出 ⇒ 别落（审核 §纪律）。',
    '2. 「产物」那格是路径或命令吗？不是 ⇒ 老实写"条文级·暂无产物"（#51）。',
    '3. 「判据」是机器能判的吗？不是 ⇒ 同上，别写成"我自觉"。',
    '',
  ].join('\n')
  fs.writeFileSync(p, 文本)
  console.log('✅ 草稿：' + p)
  console.log('   事项：' + 事项 + ' ｜ 类：' + 类 + ' ｜ 出处：' + o.出处)
  console.log('   落法：node 神经/入法.mjs 落 ' + path.relative(WS, p) + ' --apply')
  return p
}

// ── 落 ─────────────────────────────────────────────────────────────────
function 解析草稿(p) {
  const t = fs.readFileSync(p, 'utf8')
  const g = (k) => { const m = t.match(new RegExp('^- ' + k + ': *(.*)$', 'm')); return m ? m[1].trim() : '' }
  const blk = t.match(/```内核条文\n([\s\S]*?)\n```/)
  if (!blk) throw new Error('草稿里找不到 ```内核条文 段')
  return { 事项: g('事项'), 类: g('类'), 出处: g('出处'), 原话: g('原话'), 正文: blk[1] }
}
function 造个补丁(root, 编号, 草, dry) {
  const kp = root + '/内核/内核.md'
  const cp = root + '/内核/变更日志.md'
  const ktext = fs.readFileSync(kp, 'utf8')
  const 统 = 统计(ktext)
  const i = 锚点位置(ktext)
  if (i < 0) throw new Error('内核里找不到锚点 `' + ANCHOR.replace(/\n/g, '\\n') + '`')
  // 重名闸（归一后包含 ⇒ 判重）：同一条不许进两次
  const 重 = 统.rules.filter((r) => 归一(r.标题).includes(归一(草.事项).slice(0, 12)))
  if (重.length) throw new Error('内核里已经有同名的条文：' + 重[0].n + '. ' + 重[0].标题 + ' ⇒ 拒插（要插请 --重）')
  if (统.重号.length) console.log('⚠️ 内核已有重号：' + 统.重号.join('、') + '（本轮不新增重号：新号取最大号+1）')
  const 正文 = 草.正文.replace('{{编号}}', String(编号)).replace(/\n+$/, '')
  const 旧 = ANCHOR
  const 新 = 正文 + '\n\n' + ANCHOR
  const day = new Date()
  const 标记 = (草.__标记前缀 || '') + '入法' + String(day.getMonth() + 1).padStart(2, '0') + String(day.getDate()).padStart(2, '0') + '第' + 编号 + '条'
  const 日志头 = '## ' + day.toISOString().slice(0, 10) + ' · 入法第 ' + 编号 + ' 条：' + 草.事项
  const 日志段 = [
    '', '', 日志头, '',
    '- 来源：' + (草.原话 && 草.原话 !== '—' ? '老板原话「' + 草.原话 + '」' : 草.出处),
    '- 类：' + (草.类 === '红线' ? '②他亲口的红线（直接够格入法，不必等踩两次）' : '①重复踩的坑'),
    '- 走的是管道：`神经/入法.mjs 落 ' + (草.__path || '台账/接续/入法/…') + '`（备份 → 插条 → 语法查 → 读回 → 重算基线）',
    '- 条数：' + 统.条数 + ' → ' + (统.条数 + 1),
    '- 回退：`cp 内核/_backup/内核.md.bak-' + String(day.getMonth() + 1).padStart(2, '0') + String(day.getDate()).padStart(2, '0') + '-前' + 标记 + ' 内核/内核.md` ＋ 删本段 ＋ `node 神经/基线.mjs`',
  ].join('\n')
  const ctext = fs.readFileSync(cp, 'utf8')
  const tail = ctext.replace(/\s+$/, '')
  const spec = [
    // minLines 现算＝「改动前的行数」：**插入只会变长** ⇒ 变短就是写坏了（不写死 100，假内核/真内核都适用）
    { file: kp, edits: [{ from: 旧, to: 新 }], musts: ['我叫苏青青', 草.事项], minLines: ktext.split('\n').length, mark: 标记 },
    { file: cp, edits: [{ from: tail.slice(-120), to: tail.slice(-120) + 日志段 }], musts: [草.事项], minLines: ctext.split('\n').length, mark: 标记 },
  ]
  return { spec, 编号, 统, 标记, 正文 }
}

function 落(draftPath, o) {
  if (!draftPath || !fs.existsSync(draftPath)) { console.error('用法：node 神经/入法.mjs 落 <草稿文件> [--apply]'); process.exit(2) }
  const 草 = 解析草稿(draftPath)
  草.__path = path.relative(WS, draftPath)
  if (o.__自测) 草.__标记前缀 = '自测勿用-'   // ⚠️ 自测写的是假内核：备份名必须自带「别拿去回滚」
  const APPLY = !!o.apply
  const root = o.__root || WS
  const kp = root + '/内核/内核.md'
  let 前言
  try {
    前言 = null
    const ktext = fs.readFileSync(kp, 'utf8')
    const 统 = 统计(ktext)
    const 重 = 统.rules.filter((r) => 归一(r.标题).includes(归一(草.事项).slice(0, 12)))
    if (重.length && !o.重) { console.error('❌ 内核里已经有同名条文：' + 重[0].n + '. ' + 重[0].标题 + ' ⇒ 拒插（同名不许进两次；确实要插就 --重 并说明为什么）'); process.exit(1) }
    const r = 造个补丁(root, 统.最大号 + 1, 草, !APPLY)
    const specPath = (process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh') + '/tmp/入法-spec-' + Date.now() + '.json'
    fs.writeFileSync(specPath, JSON.stringify(r.spec, null, 1))
    console.log('【入法】' + 草.事项 + ' ⇒ 第 ' + r.编号 + ' 条（' + 统.条数 + ' → ' + (统.条数 + 1) + '）｜标记 ' + r.标记)
    const out = execFileSync(NODE, [WS + '/工具/文件/补丁.mjs', specPath, ...(APPLY ? ['--apply'] : [])], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
    console.log(out.trim())
    if (APPLY) {
      const 后 = 统计(fs.readFileSync(kp, 'utf8'))
      const hit = 后.rules.find((x) => x.n === r.编号 && 归一(x.标题).includes(归一(草.事项).slice(0, 8)))
      if (!hit) { console.error('❌ 读回核对失败：内核里找不到刚插的第 ' + r.编号 + ' 条'); process.exit(1) }
      console.log('✅ 读回核对：第 ' + r.编号 + ' 条在第 ' + hit.line + ' 行 ｜ 条数 ' + 后.条数 + '（最大号 ' + 后.最大号 + '）｜已标注 ' + 后.已标注)
      const b = execFileSync(NODE, [WS + '/神经/基线.mjs'], { encoding: 'utf8', cwd: WS, stdio: ['ignore', 'pipe', 'pipe'] })
      console.log('【基线】' + b.trim().split('\n').slice(-1)[0])
    } else {
      console.log('（干跑：一个字节都没写；要真写加 --apply）')
    }
  } catch (e) {
    const so = (e.stdout ? String(e.stdout) : '') + (e.stderr ? String(e.stderr) : '')
    console.error('❌ ' + (e.message || e) + (so.trim() ? '\n--- 下层输出 ---\n' + so.trim() : ''))
    process.exit(1)
  }
}

// ── 自测（端到端，全在 $DSH_HOME/tmp 里，不碰真内核）────────────────────
function selftest() {
  const TMP = (process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh') + '/tmp/入法自测'
  fs.rmSync(TMP, { recursive: true, force: true })
  fs.mkdirSync(TMP + '/内核', { recursive: true })
  const 假内核 = [
    '# 内核（自测用的假内核）', '', '- 我叫苏青青（自测）', '', '---', '',
    '1. **第一条：测试用**（入法理由①：自测）。', '    **判据**：x', '',
    '2. **第二条：测试用**（入法理由①：自测）。', '    **判据**：x', '',
    '2. **重号的那条**（入法理由①：自测故意造的重号）', '',
    '---', '', '## 附:内核不装什么', '', '自测。', '',
  ].join('\n')
  fs.writeFileSync(TMP + '/内核/内核.md', 假内核)
  fs.writeFileSync(TMP + '/内核/变更日志.md', '# 变更日志\n\n## 2026-09-22 · 自测起点\n\n- 占位\n')
  const C = []
  const ok = (名, 条件, 附) => { C.push((条件 ? '  ✅ ' : '  ❌ ') + 名 + (附 && !条件 ? ' —— ' + 附 : '')); return 条件 }

  // ① 草稿
  const d = 出草稿('自测红线条文', { 类: '红线', 出处: '自测', 原话: '自测原话', 判据: '跑一条命令看退出码', 产物: '工具/合规/合规查.mjs', 反例: '自称做了', 适用面: '自测' })
  ok('① 草稿生成', fs.existsSync(d))
  const 草 = 解析草稿(d)
  ok('② 草稿解析（五格齐）', 草.正文.includes('{{编号}}') && 草.正文.includes('**判据**') && 草.正文.includes('**产物**') && 草.正文.includes('**适用面**'))

  // ② 干跑不写
  const before = fs.readFileSync(TMP + '/内核/内核.md', 'utf8')
  try { 落(d, { __root: TMP, __自测: true }) } catch (e) { /* 干跑里基线会失败，允许 */ }
  ok('③ 干跑不改内核', fs.readFileSync(TMP + '/内核/内核.md', 'utf8') === before)

  // ③ 真落（在假内核上；基线会去真工作区跑，忽略它的报错）
  let 落了 = false
  try { 落(d, { __root: TMP, apply: true, __自测: true }); 落了 = true } catch (e) { /* 抛错＝正常（基线在假 root 之后仍会跑） */ }
  const after = fs.readFileSync(TMP + '/内核/内核.md', 'utf8')
  const 统2 = 统计(after)
  ok('④ 条数 3 → 4', 统2.条数 === 4, '实际 ' + 统2.条数)
  ok('⑤ 新条编号＝最大号+1＝3（**不撞重号 2**）', 统2.rules.some((r) => r.n === 3 && r.标题.includes('自测红线条文')), 统2.rules.map((r) => r.n).join(','))
  ok('⑥ 插在锚点之前（附件节还在后面）', after.indexOf('自测红线条文') < after.indexOf('## 附:内核不装什么'))
  ok('⑦ 变更日志新增一段', fs.readFileSync(TMP + '/内核/变更日志.md', 'utf8').includes('入法第 3 条'))

  // ④ 重复落 ⇒ 必须拒
  let 拒了 = false
  const 旧exit = process.exit
  process.exit = (c) => { if (c) 拒了 = true; throw new Error('__exit' + c) }
  try { 落(d, { __root: TMP, apply: true, __自测: true }) } catch (e) { 拒了 = true }
  process.exit = 旧exit
  ok('⑧ 同名再落 ⇒ 拒（不写第二遍）', 拒了 && 统计(fs.readFileSync(TMP + '/内核/内核.md', 'utf8')).条数 === 4)

  // ⚠️ 本窗踩到的真坑：安全写 的备份名**只取 basename** ⇒ 自测写假内核时，备份落在真 `_backup/内核.md.bak-…`
  //    ⇒ 将来一条「cp _backup/内核.md.bak-… 内核/内核.md」的回滚命令**会把真内核换成假内核**。
  //    所以自测必须自己收尾：删掉自己造的那两份（并只删「内容里带『自测』」的，不碰别人的）。
  const 清 = []
  try {
    for (const f of fs.readdirSync(WS + '/_backup')) {
      if (!f.includes('自测勿用-')) continue   // 备份名形如「内核.md.bak-0922-前自测勿用-入法0922第3条」⇒ 前缀在中间
      const fp = WS + '/_backup/' + f
      const t = fs.readFileSync(fp, 'utf8')
      if (t.includes('自测')) { fs.unlinkSync(fp); 清.push(f) }
    }
  } catch (e) { console.log('  ⚠️ 自测备份清理失败：' + e.message) }
  console.log(C.join('\n'))
  console.log('  🧹 已清掉自测留下的假的 _backup 备份 ' + 清.length + ' 份' + (清.length ? '：' + 清.join('、') : ''))
  const pass = C.filter((x) => x.startsWith('  ✅')).length
  console.log('\n' + (pass === C.length ? '✅ 自检 ' + pass + '/' + C.length + ' 全过' : '❌ 自检 ' + pass + '/' + C.length) + '（假内核在 ' + TMP + '）')
  process.exitCode = pass === C.length ? 0 : 1
}

// ── 入口 ───────────────────────────────────────────────────────────────
const argv = process.argv.slice(2)
const cmd = argv[0]
const o = 参数(argv.slice(1))
if (cmd === '查') {
  const t = fs.readFileSync(KERNEL, 'utf8')
  const s = 统计(t)
  console.log('【内核】条数 ' + s.条数 + ' ｜ 最大号 ' + s.最大号 + ' ｜ 已标注「入法理由」 ' + s.已标注 + ' 处')
  console.log('【重号】' + (s.重号.length ? '⚠️ ' + s.重号.join('、') + '（历史遗留；入法一律取「最大号+1」回避）' : '✅ 无'))
  console.log('【锚点】' + (锚点位置(t) < 0 ? '❌ 找不到 `--- ## 附:内核不装什么`' : '✅ 第 ' + t.slice(0, 锚点位置(t)).split('\n').length + ' 行之前插条'))
  console.log('【下一条编号】' + (s.最大号 + 1))
  console.log('【草稿目录】' + DRAFT_DIR)
  console.log('【收件箱索引】' + DRAFT_DIR + '/草稿台账.md（哪份草稿落了哪一条）')
} else if (cmd === '草稿') { 出草稿(argv[1], o) }
else if (cmd === '落') { 落(argv[1], o) }
else if (cmd === 'selftest') { selftest() }
else { console.log('用法：node 神经/入法.mjs 查 ｜ 草稿 "<事项>" --类 红线|坑 … ｜ 落 <草稿> [--apply] ｜ selftest'); process.exit(2) }
