#!/usr/bin/env node
// 写意图对账 · 「账本记的」和「盘上真改的」对不对得上（2026-09-27 立 · 老板令「钩子重挂」的交接侧那一格）
// ════════════════════════════════════════════════════════════════════════════
// 【为什么要有它】老板 09-27 原话：「**你说那个（轮末）自检只能保当前窗……保不了交接那边的问题吧，
//   保不了新窗口那边吧**」。查下来：这本账**没有任何交接/开工侧在读**（只有轮末自检、沙盒在用）
//   ⇒ 光把钩子修好还不够，得有东西**在交接侧把它念出来**。这就是那件东西。
// 【判据】拿两把尺子对撞：① 账本（写意图.jsonl）近 24h 记了几条 ② 盘上（工具/台账/内核/记忆）近 24h 真改过几件
//   账=0 且 盘=0 ⇒ ✅ 无事（**阴性**，不许滥报红）
//   账>0        ⇒ ✅ 钩子在记（印末条：时间/工具/路径/会话）
//   账=0 且 盘>0 ⇒ ❌ 账本比盘旧（钩子没记）—— 若钩子修复还没重启，这句就是预期现象，指引写在下边
// 【用法】
//   node 神经/写意图对账.mjs          # 全量（账本 ＋ 盘上扫描）
//   node 神经/写意图对账.mjs --快      # 只读账本，一行（给开工一屏用，零扫描）
//   node 神经/写意图对账.mjs selftest  # 自测（临时根，四条含两条反证）
// 环境：写意图账=<路径>、对账工作区=<目录> —— 自测用它们切到临时根，不碰生产
// ════════════════════════════════════════════════════════════════════════════
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'

const 工作区 = process.env.对账工作区 || '/storage/emulated/0/3'
const 账本 = process.env.写意图账 || path.join(工作区, '台账/接续/写意图.jsonl')
const 窗口 = 24 * 3600 * 1000
const 自噪声 = new Set(['写意图.jsonl', '轮末自检.上次'])

const 本地 = (t) => {
  const d = new Date(t + 8 * 3600 * 1000) // UTC → 本地（本机 UTC+8）
  return d.toISOString().replace('T', ' ').slice(5, 16)
}

function 读账() {
  if (!fs.existsSync(账本)) return { 在: false, 条: [], 错: '账本文件不在：' + 账本 }
  const 行 = fs.readFileSync(账本, 'utf8').split('\n').filter((l) => l.trim())
  const 条 = []
  let 坏 = 0
  for (const l of 行) { try { 条.push(JSON.parse(l)) } catch { 坏++ } }
  return { 在: true, 条, 坏 }
}

function 扫盘(上限 = 4000) {
  const 根 = ['工具', '台账', '内核', '记忆'].map((d) => path.join(工作区, d))
  const 今 = Date.now() - 窗口
  const 出 = []
  let 数 = 0
  const 走 = (p) => {
    if (数 > 上限) return
    let 列 = []
    try { 列 = fs.readdirSync(p, { withFileTypes: true }) } catch { return }
    for (const e of 列) {
      const f = path.join(p, e.name)
      if (e.isDirectory()) {
        if (e.name === '_backup' || e.name === 'node_modules' || e.name.startsWith('_自测')) continue
        走(f)
      } else {
        数++
        if (e.name.includes('.bak-')) continue
        if (自噪声.has(e.name)) continue
        let st
        try { st = fs.statSync(f) } catch { continue }
        if (st.mtimeMs >= 今) 出.push({ f: path.relative(工作区, f), t: st.mtimeMs })
      }
    }
  }
  for (const d of 根) 走(d)
  return 出.sort((a, b) => b.t - a.t)
}

function 快() {
  const { 在, 条, 错 } = 读账()
  if (!在) return { 行: '【改过哪些】写意图账读不到：' + 错, 红: false }
  const 近 = 条.filter((x) => Date.now() - Date.parse(x.at || 0) < 窗口)
  const 末 = 条[条.length - 1]
  const 行 = '【改过哪些】写意图账 ' + 条.length + ' 条 ／ 末条 ' + (末 ? 本地(Date.parse(末.at)) : '无') + ' ／ 近24h ' + 近.length + ' 条'
    + (近.length ? '（' + 近.map((x) => x.tool || x.kind || '?').join('、').slice(0, 60) + '）' : '  ⚠️ 近24h 一条没记 ⇒ 对账：node 神经/写意图对账.mjs')
  return { 行, 红: 近.length === 0 }
}

function 全量() {
  const { 在, 条, 坏 } = 读账()
  console.log('写意图对账 · 工作区 ' + 工作区)
  console.log('  账本：' + 账本)
  if (!在) { console.log('  ❌ 账本文件不在 ⇒ 钩子从没记过（或路径不对）'); return 1 }
  const 近 = 条.filter((x) => Date.now() - Date.parse(x.at || 0) < 窗口)
  const 末 = 条[条.length - 1]
  console.log('  账本：' + 条.length + ' 条' + (坏 ? '（另有 ' + 坏 + ' 行解析不了）' : '') + ' ／ 末条 ' + (末 ? 本地(Date.parse(末.at)) : '无') + ' ／ 近24h ' + 近.length + ' 条')
  const 按 = (键) => {
    const m = new Map()
    for (const x of 近) { const k = 键(x); if (k) m.set(k, (m.get(k) || 0) + 1) }
    return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, v]) => k + '×' + v).join(' ／ ') || '（无）'
  }
  if (近.length) {
    console.log('  近24h 按工具：' + 按((x) => x.tool || x.kind))
    console.log('  近24h 按会话：' + 按((x) => x.who))
  }
  const 盘 = 扫盘()
  console.log('  盘上：近24h 真改过 ' + 盘.length + ' 件（工具/台账/内核/记忆，去掉 _backup 与 .bak-）')
  if (盘.length) console.log('    最近几件：' + 盘.slice(0, 5).map((x) => x.f).join(' ／ '))
  let rc = 0
  if (!近.length && !盘.length) console.log('  ✅ 无事：盘上没动过、账本也没记 —— 阴性（不许滥报红）')
  else if (近.length) console.log('  ✅ 账本在记（末条 ' + 本地(Date.parse(末.at)) + '）')
  else {
    console.log('  ❌ 账本比盘旧：盘上近24h 改了 ' + 盘.length + ' 件，账本一条没记 ⇒ 钩子没记账')
    console.log('     · 若钩子那三处修复**还没重启**，这就是预期现象（重启后判据：改一个文件 ⇒ 账本多一行 kind:tool）')
    console.log('     · 若已重启仍这样 ⇒ 看 $DSH_HOME/kickoff-gate.log 有没有 fail-open ／ 回读 _hooks（做法库 §四十八）')
    rc = 1
  }
  return rc
}

function 自测() {
  const 临 = '/storage/emulated/0/3/神经/_写意图对账自测'
  fs.rmSync(临, { recursive: true, force: true })
  fs.mkdirSync(path.join(临, '台账/接续'), { recursive: true })
  fs.mkdirSync(path.join(临, '工具'), { recursive: true })
  fs.mkdirSync(path.join(临, '内核'), { recursive: true })
  const 账 = path.join(临, '台账/接续/写意图.jsonl')
  const 我 = process.argv[1]
  const 跑 = (env) => {
    try {
      return { rc: 0, 出: execFileSync('node', [我, '全量'], { env: { ...process.env, 对账工作区: 临, 写意图账: 账, ...env }, encoding: 'utf8' }) }
    } catch (e) { return { rc: e.status === undefined ? 1 : e.status, 出: String((e.stdout || '') + (e.stderr || '')) } }
  }
  const 判 = []
  const 记 = (名, 过, 说) => { 判.push(过); console.log(`${过 ? '✅' : '❌'} ${名} —— ${说}`) }

  // ① 阴性：盘上没动过、账本空 ⇒ 绿
  fs.writeFileSync(账, '')
  const r1 = 跑({})
  记('① 阴性：盘没动、账空 ⇒ 绿', r1.rc === 0 && r1.出.includes('无事'), 'rc=' + r1.rc)

  // ② 盘上有新改动、账本空 ⇒ 红
  fs.writeFileSync(path.join(临, '工具/新改的.mjs'), 'x')
  const r2 = 跑({})
  记('② 盘有新改动、账空 ⇒ 红且说清', r2.rc === 1 && r2.出.includes('账本比盘旧'), 'rc=' + r2.rc)

  // ③ 账本有近 24h 条目 ⇒ 绿，并印末条/按工具/按会话
  fs.writeFileSync(账, JSON.stringify({ at: new Date().toISOString(), kind: 'tool', tool: 'write', p: '/x/a.md', who: 'session-abc' }) + '\n')
  const r3 = 跑({})
  记('③ 账本有今天条目 ⇒ 绿 ＋ 印按工具/按会话', r3.rc === 0 && r3.出.includes('write×1') && r3.出.includes('session-abc×1'), 'rc=' + r3.rc)

  // ④ 反证：账本文件不在 ⇒ 红并点名路径
  fs.rmSync(账)
  const r4 = 跑({})
  记('④ 反证：账本不在 ⇒ 红并点名', r4.rc === 1 && r4.出.includes('账本文件不在'), 'rc=' + r4.rc)

  const 过 = 判.filter(Boolean).length
  console.log(`\n${过 === 判.length ? '全绿' : '有红'}：${过}/${判.length}`)
  fs.rmSync(临, { recursive: true, force: true })
  return 过 === 判.length ? 0 : 1
}

const 主 = process.argv[2] || '全量'
if (主 === '快' || 主 === '--快') { const r = 快(); console.log(r.行); process.exit(0) }
else if (主 === 'selftest' || 主 === '自测' || 主 === '--自测') process.exit(自测())
else if (主 === '全量' || 主 === '查') process.exit(全量())
else { console.log('用法：全量 ｜ --快 ｜ selftest'); process.exit(2) }
