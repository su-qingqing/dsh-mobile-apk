#!/usr/bin/env node
/** 冻结预检 — 改文件通道的**第七道保护**（2026-09-23 老板裁决后加；这道门就是当天该拦住我的那道）
 * 病根：我改内核 #50 前只 `grep -c` 看了"命中 3 处"这个**数字**，没读那 3 处是什么 ⇒ 断了两根冻结针。
 * 所以这道门第一件事不是拦，是**把清单内容打出来**（针／类／为什么冻），再按类判：
 *   · 不许动   ⇒ 针所在那一行必须**逐字不变**
 *   · 只能加   ⇒ 针所在那一行只能**往后追加**（新行必须以旧行开头）
 *   · 两处同改 ⇒ 允许改，但针在两处都要在（改一处就得改另一处）
 * 针在旧文里有、新文里没了 ⇒ 一律**断针 ⇒ 拒写**（退出码 3＝fail-closed）。
 * 匹配：绝对路径相等 **或** 同名（清单里有相对/绝对两种写法；同名也算 ⇒ 宁可多拦）。
 * 用法：node 神经/冻结预检.mjs 查 <文件> [--旧 <旧文文件> --新 <新文文件>] ｜ selftest
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'   // ★ 1013 加：判「是主程序」只许用它（见下面那段教训）
const WS = '/storage/emulated/0/3'
const 清单路径 = WS + '/台账/冻结清单.json'

const 同名 = (a, b) => path.basename(a) === path.basename(b)
function 取行(文, 针) {
  const i = 文.indexOf(针)
  if (i < 0) return null
  const s = 文.lastIndexOf('\n', i) + 1
  let e = 文.indexOf('\n', i)
  if (e < 0) e = 文.length
  return 文.slice(s, e)
}

export function 预检(目标, 旧文, 新文, 清单) {
  const T = 目标.startsWith('/') ? 目标 : path.join(WS, 目标)
  const 全部 = (清单 && 清单.items) || []
  const 命中 = 全部.filter((it) => {
    const f = it.file.startsWith('/') ? it.file : path.join(WS, it.file)
    return f === T || 同名(f, T)
  })
  const 说明 = [], 断针 = []
  if (!命中.length) return { 条目: [], 断针: [], 放行: true, 说明: ['冻结预检：不在清单里（' + 全部.length + ' 条都核过）'] }
  for (const it of 命中) 说明.push('冻结条目 [' + it.cls + '] 针：' + String(it.needle).slice(0, 40) + ' ｜ 为什么冻：' + (it.why || '（没写原因）'))
  for (const it of 命中) {
    const 旧有 = 旧文.includes(it.needle), 新有 = 新文 ? 新文.includes(it.needle) : true
    if (!旧有) { 说明.push('· 针不在旧文里（已被改过或不属于这份）⇒ 这次不判：' + String(it.needle).slice(0, 24)); continue }
    if (!新有) { 断针.push({ 针: it.needle, 类: it.cls, 因: '新内容里**针不见了**' }); continue }
    if (!新文 || 新文 === 旧文) continue
    const 旧行 = 取行(旧文, it.needle), 新行 = 取行(新文, it.needle)
    if (it.cls === '不许动' && 旧行 !== 新行) 断针.push({ 针: it.needle, 类: it.cls, 因: '类=不许动，但它所在那一行被改写了' })
    else if (it.cls === '只能加' && 旧行 !== null && 新行 !== null && !新行.startsWith(旧行)) 断针.push({ 针: it.needle, 类: it.cls, 因: '类=只能加，但针前面/中间的内容被动了' })
    else if (it.cls === '两处同改') 说明.push('· 这根针是**两处同改** ⇒ 另一处也要一起改，别只改一处：' + String(it.needle).slice(0, 24))
  }
  return { 条目: 命中, 断针, 放行: 断针.length === 0, 说明 }
}

function selftest() {
  let 过 = 0, 共 = 0
  const 试 = (名, 得, 期) => { 共++; if (JSON.stringify(得) === JSON.stringify(期)) { 过++; console.log('  ✅ ' + 名) } else console.log('  ❌ ' + 名 + ' 得=' + JSON.stringify(得) + ' 期=' + JSON.stringify(期)) }
  const 清单 = { items: [{ file: '内核/内核.md', needle: '我叫苏青青', cls: '不许动', why: '身份定义' }] }
  const 旧 = '头\n我叫苏青青，店长\n尾\n'
  试('不在清单里 ⇒ 放行（阴性）', 预检('/storage/emulated/0/3/台账/在办.md', 旧, '头\n改了\n尾\n', 清单).放行, true)
  试('不许动·整行不变 ⇒ 放行', 预检('内核/内核.md', 旧, '新头\n我叫苏青青，店长\n尾\n', 清单).放行, true)
  试('不许动·整行被改写 ⇒ 断针', 预检('内核/内核.md', 旧, '头\n我是苏青青，店长\n尾\n', 清单).断针.length, 1)
  试('针不见了 ⇒ 断针', 预检('内核/内核.md', 旧, '头\n尾\n', 清单).断针.length, 1)
  试('同名匹配（清单写相对、目标给绝对）⇒ 命中', 预检('/data/x/内核.md', 旧, 旧, 清单).条目.length, 1)
  const 清单2 = { items: [{ file: '内核/内核.md', needle: '临界点', cls: '只能加', why: '公式这条不许丢' }] }
  const 旧2 = 'a\n临界点由公式算\nb\n'
  试('只能加·往后追加 ⇒ 放行', 预检('内核/内核.md', 旧2, 'a\n临界点由公式算（数字可更新）\nb\n', 清单2).放行, true)
  试('只能加·动了中间 ⇒ 断针', 预检('内核/内核.md', 旧2, 'a\n由公式算临界点\nb\n', 清单2).断针.length, 1)
  console.log(`自检：${过}/${共} ${过 === 共 ? '✅' : '❌'}`)
  process.exit(过 === 共 ? 0 : 1)
}

const [, , cmd, ...rest] = process.argv
// ★ 2026-09-23 补：只有**当主程序跑**才许执行 CLI —— 被 改文件.mjs `import` 时若照跑，
//   `process.exit(2)` 会把宿主进程一起退掉（实测把改文件通道堵死，4 次补丁静默不落地）。
// ★★ 1013 修（**静默假绿 · 由全机自测体检抓出，比红更值钱**）：
//   原写法 `path.resolve(new URL(import.meta.url).pathname)` —— 本机路径**带中文**（`神经/…`），
//   而 `URL.pathname` 返回的是**百分号编码**（`/…/3/%E5%B7%A5%E5%85%B7/%E5%86%85…`），
//   与 `process.argv[1]` 的明文**恒不相等** ⇒ `是主程序` **恒 false** ⇒
//   **`selftest` 与 `查` 两个分支都不进**：跑 121ms、**stdout 一个字没有、退出码 0**
//   ⇒ 任何人只看 rc 都会以为它是绿的，**而它一行断言都没执行**。
//   ⚠️ **这条坑我早记过、还栽了第二次**：记忆 `0mv189a6a` 写着「判『是主』只许 `fileURLToPath`」，
//      `0mv1egfhj` 更是「**同一天先记、后照踩**」的实证 ⇒ **"记了"没有拦住我**（内核 #51）。
//   ⇒ 正解（按记忆里那条判据）：**`fileURLToPath(import.meta.url)`**，别用 `.pathname`。
//   它是谁写的／什么条件会回来：苏青青（原版）／苏青青（1013 修）；**条件＝有人图省事又写 `.pathname`**。
//   ★ 类级机器面：**目前没有**（全机只此一件用这个写法，1013 grep 现算 ＝ 1）——
//     要真拦住复发，得给「仪器 CLI 尾巴」立一条判据；**本条如实标：条文级·不可靠**（红线 23 的写法）。
const 是主程序 = (() => {
  try {
    const 本件 = fs.realpathSync(fileURLToPath(import.meta.url))
    const 在跑 = path.resolve(process.argv[1] || '')
    if (在跑 === 本件) return true
    // 兜底：本机 `/storage/emulated/0` 是 FUSE，realpath 可能与 argv[1] 有一层软链差；
    // 两向都试，**但绝不放行"两个都解析不出来"**（那是原来的病）。
    try { return fs.realpathSync(在跑) === 本件 } catch { return false }
  } catch { return false }
})()
const flag = (n) => { const i = rest.indexOf(n); return i >= 0 ? rest[i + 1] : '' }
if (是主程序 && cmd === 'selftest') selftest()
else if (是主程序 && cmd === '查') {
  const 目标 = rest[0]
  if (!目标) { console.log('用法：冻结预检.mjs 查 <文件> [--旧 <文件> --新 <文件>] ｜ selftest'); process.exit(2) }
  const rd = (f) => (f ? fs.readFileSync(f.startsWith('/') ? f : path.join(WS, f), 'utf8') : '')
  const 旧文 = flag('--旧') ? rd(flag('--旧')) : (fs.existsSync(目标) ? fs.readFileSync(目标.startsWith('/') ? 目标 : path.join(WS, 目标), 'utf8') : '')
  const 新文 = flag('--新') ? rd(flag('--新')) : 旧文
  const r = 预检(目标, 旧文, 新文, JSON.parse(fs.readFileSync(清单路径, 'utf8')))
  for (const x of r.说明) console.log('  ' + x)
  if (!r.放行) { for (const x of r.断针) console.log('  ❌ 断针：' + x.因 + ' ｜ 针：' + String(x.针).slice(0, 30)); console.log('  ⇒ 拒写。正规出口：请老板裁 ⇒ `node 工具/台账/冻结.mjs 校验 --基线` 接针（或先留样）'); process.exit(3) }
  console.log('  ✅ 没断针（' + r.条目.length + ' 条冻结条目）')
} else if (是主程序) { console.log('用法：冻结预检.mjs 查 <文件> [--旧 <文件> --新 <文件>] ｜ selftest'); process.exit(2) }
