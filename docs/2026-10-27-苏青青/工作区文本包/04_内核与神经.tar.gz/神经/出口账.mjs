#!/usr/bin/env node
// 出口账.mjs · 1010 建（外部独立核 qwen3.8-max 判决第 7 条「必须同批做**出口观察账**」／目标句里「只增不减」的那一面）
//
// 病根：系统只会**加**东西（`台账/接续/诚实边界.json` 里标「新建」的件 = 131 件），**没有出口** ——
//   没人消费的件永远躺着；"三项只增不减"那项读数于是只会越来越难看，而且**退哪一件没人知道**。
//
// 判据（**只许现读**，内核 #68）：消费方一律从 `神经/连续体检.mjs` 的 `查件()` 拿 —— 本文件不重写判据。
// 口径（核的原话）：做"**观察账**"，**别做"零净增硬考核"** —— 那会逼出假动作（分类搬家／拆件假减／线前清理／改定义）。
// ⚠️ 「复核期 30 天」「退休条件」是**我定的口径、不是老板定的** ⇒ 要让他看见并可否决。
//
// ★ 1010 首跑实测的**降噪**（第一次跑出 96/131「候选退休」⇒ 一眼看出是假阳性）：
//   `台账/` 下的 .md/.json/.txt 是**档案**（交接单／打烊单／方案书／回执）—— 它们**天生就"没人消费"**，
//   因为它们是**记录**不是**零件**。⇒ 单列一类「档案」，不算候选退休。**真该退的是工具件**。
//
// 用法：
//   node 神经/出口账.mjs 扫      # 扫「新建」件 ⇒ 谁消费它 ⇒ 落盘 `台账/接续/出口观察账.md`
//   node 神经/出口账.mjs 一屏    # 只印一行（**绿时零字**：没有"无人消费"的工具件就不出字）
//   node 神经/出口账.mjs 销 <件> <理由>   # 销掉一件（写 `台账/接续/出口账销.json`）
import fs from 'node:fs'
import path from 'node:path'
import { 查件, 取索引 } from './连续体检.mjs'

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const 复核期天 = 30                                   // ★ 我定（老板可改）
const 销账路 = '台账/接续/出口账销.json'

function 读销账() {
  // ★ 1010 · 账文件**自己保证自己在盘上**：原来"读不到就返回空账" ⇒ 连续体检把 `出口账销.json` 判成
  //   **悬空**（"运行时才会被创建的文件"＝判据的又一个假红源）。正解＝第一次读就落一份空账。
  const p = path.join(WS, 销账路)
  try { return JSON.parse(fs.readFileSync(p, 'utf8')) } catch {
    try { fs.writeFileSync(p, JSON.stringify({ _说明: '出口账销账：件 → {at,理由}（空＝一件都没销）。由 `神经/出口账.mjs 销` 或"第一次读"自动建。', 件: {} }, null, 1)) } catch { }
    return { 件: {} }
  }
}

function 新建件() {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(WS, '台账/接续/诚实边界.json'), 'utf8'))
    const 销 = 读销账().件 || {}
    return Object.keys(j.项 || {})
      .filter((k) => /新建/.test((j.项[k] && j.项[k].状态) || ''))
      .filter((k) => !销[k])
  } catch { return [] }
}

// ★ 1010 · ⑦（外部核第 7 条）**三字段登记：新增件必带** ① 消费方 ② 复核周期 ③ 退休条件。
//   病根：原来"复核期 30 天"是**全表一个常数**、退休条件只是一句总说明 ⇒ 逐件问"谁在用、多久看一次、
//   什么条件退"没人答得上（观察账退化成一张分类表）。核的原话是"**新增件必带**"⇒ **不做全库硬考核**
//   （那正是核点名的假动作温床）。老件靠复核时补、不追旧账。
const 三字段路 = '台账/接续/出口三字段.json'
const 生效起 = Date.parse('2026-10-10T00:00:00+08:00')   // ★ 我定（老板可改）：从**北京时间**今天 0 点起生效
//   ⚠️ 必须用**时间戳**、不许拿 'YYYY-MM-DD' 字符串比：mtime 的 ISO 是 UTC，凌晨会差一整天（当场踩过）
function 读三() {
  // 照 `读销账()` 的教训：**账文件自己保证自己在盘上**（否则连续体检会把它判成"运行时才建＝悬空"）
  const p = path.join(WS, 三字段路)
  try { return JSON.parse(fs.readFileSync(p, 'utf8')).件 || {} } catch {
    try { fs.writeFileSync(p, JSON.stringify({ _说明: '出口三字段：件 → {用(消费方),周期(天),退(退休条件),记于,谁}。写入口＝`出口账.mjs 登记 <件> --用 "…" --周期 N --退 "…"`。', 生效起, 件: {} }, null, 1)) } catch { }
    return {}
  }
}

function 扫() {
  const 索引 = 取索引(WS)
  const 三 = 读三()
  return 新建件().map((f) => {
    let r = null
    try { r = 查件(f, WS, 索引) } catch { r = null }
    const 真调用 = r ? r.真调用.length : 0
    const 嘴 = r ? r.嘴.length : 0
    const 不在盘 = !r || r.悬空.some((s) => /件不在盘上/.test(s.说 || ''))
    const 是档案 = /^台账\//.test(f) && !/\.(mjs|js|sh)$/.test(f)
    const 判 = 不在盘 ? '已消失' : 是档案 ? '档案' : (真调用 || 嘴) ? '在用' : '候选退休'
    const t = 三[f] || null
    // 缺格判据：**只问生效起之后动过的件**（老件不追）；登记了但字段空 ⇒ 也报
    let 新件 = false
    try { 新件 = /^工具\//.test(f) && fs.statSync(path.join(WS, f)).mtimeMs >= 生效起 } catch { 新件 = false }
    const 缺失 = t ? (!t.用 ? '缺消费方' : !t.退 ? '缺退休条件' : (!t.周期 ? '缺复核周期' : '')) : (新件 ? '缺三字段' : '')
    return { 件: f, 真调用, 嘴, 判, 复核期: (t && t.周期) || 复核期天, 用: (t && t.用) || '', 退: (t && t.退) || '', 缺失, 有登记: !!t }
  })
}

function 一屏(列) {
  const 退休 = 列.filter((x) => x.判 === '候选退休')
  const 缺 = 列.filter((x) => x.缺失)
  const 段 = []
  if (退休.length) 段.push('⚠️ ' + 退休.length + ' 件工具没人消费')
  if (缺.length) 段.push('⚠️ ' + 缺.length + ' 件缺「消费方／复核周期／退休条件」')
  if (!段.length) return ''                          // **绿时零字**
  return '出口账 ' + 段.join(' ｜ ') + '（在册 ' + 列.length + ' 件）⇒ `node 神经/出口账.mjs 扫` 看是哪几件；补登记 `… 登记 <件> --用 "…" --周期 N --退 "…"`'
}

const cmd = process.argv[2] || '一屏'
const 列 = 扫()

// ★ ⑦ 的**出口**（记忆 `0mu7dxuu7`：只提醒、没出口 ＝ 永远响的噪音）：登记三字段 ⇒ 那条提醒才会消失。
if (cmd === '登记') {
  const 件 = process.argv[3]
  if (!件) { console.log('用法：出口账.mjs 登记 <件> --用 "谁消费它" --周期 <天> --退 "什么条件退休"'); process.exit(2) }
  const a = process.argv.slice(4)
  const 取 = (k) => { const i = a.indexOf(k); return i >= 0 ? String(a[i + 1] || '') : '' }
  const 用 = 取('--用'), 退 = 取('--退'), 周期 = Number(取('--周期')) || 复核期天
  读三()                                            // 保证账文件在盘上（照 读销账 的教训）
  const p = path.join(WS, 三字段路)
  const j = JSON.parse(fs.readFileSync(p, 'utf8'))
  j.件[件] = { 用, 周期, 退, 记于: new Date().toISOString().slice(0, 10), 谁: '苏青青' }
  fs.writeFileSync(p, JSON.stringify(j, null, 1))
  console.log('✅ 已登记 ' + 件 + '（用：' + 用 + ' ｜ 周期 ' + 周期 + ' 天 ｜ 退：' + 退 + '）')
  process.exit(0)
}

if (cmd === '一屏') {
  const s = 一屏(列)
  if (s) console.log(s)
  process.exit(0)
}

if (cmd === '扫') {
  const 数 = (k) => 列.filter((x) => x.判 === k).length
  const 缺数 = 列.filter((x) => x.缺失).length
  console.log('出口账 · 在册 ' + 列.length + ' 件（诚实边界里标「新建」的）⇒ 在用 ' + 数('在用') + ' ｜ 候选退休 ' + 数('候选退休') + ' ｜ 档案 ' + 数('档案') + ' ｜ 已消失 ' + 数('已消失') + ' ｜ 缺三字段 ' + 缺数)
  for (const x of 列.filter((y) => y.判 === '候选退休')) console.log('  ⚠️ ' + x.件 + '（真调用 ' + x.真调用 + '｜嘴 ' + x.嘴 + '）')
  for (const x of 列.filter((y) => y.缺失)) console.log('  ⚠️ 缺「' + x.缺失 + '」：' + x.件 + ' ⇒ 补 `node 神经/出口账.mjs 登记 ' + x.件 + ' --用 "谁消费它" --周期 N --退 "什么条件退休"`')
  const 净 = (s) => String(s || '').replace(/\|/g, '/')
  const 行 = ['# 出口观察账 · ' + new Date().toLocaleString('zh-CN') + '（机器生成 · 只读）', '',
    '判据：消费方一律现读 `神经/连续体检.mjs` 的 `查件()`（内核 #68）｜口径：**只报不拦**（核的原话：做观察账，别做零净增硬考核）',
    '分类：**工具件**（工具/**）才判"在用／候选退休"；`台账/` 下的 md/json/txt 是**档案**（记录不是零件）⇒ 单列不算负债',
    '★ 三字段（外部核第 7 条「新增件必带」）：**消费方／复核周期／退休条件** —— 逐件登记在 `台账/接续/出口三字段.json`；',
    '　 生效起 ' + new Date(生效起).toLocaleString('zh-CN') + '（**只问生效起之后动过的工具件**，老件靠复核时补 ⇒ 不做全库硬考核）',
    '复核期默认 ' + 复核期天 + ' 天／退休条件：在用 ⇒ 留；候选退休 ⇒ 登记复核人，或销（`出口账.mjs 销 <件> <理由>`）', '',
    '| 件 | 判定 | 真调用 | 嘴 | 复核期(天) | 消费方 | 退休条件 | 缺失 |', '|---|---|---|---|---|---|---|---|']
  for (const x of 列) 行.push('| ' + x.件 + ' | ' + x.判 + ' | ' + x.真调用 + ' | ' + x.嘴 + ' | ' + x.复核期 + ' | ' + 净(x.用) + ' | ' + 净(x.退) + ' | ' + (x.缺失 || '') + ' |')
  行.push('', '读数：在用 ' + 数('在用') + ' ｜ 候选退休 ' + 数('候选退休') + ' ｜ 档案 ' + 数('档案') + ' ｜ 已消失 ' + 数('已消失') + ' ｜ 缺三字段 ' + 缺数)
  const 落 = path.join(WS, '台账/接续/出口观察账.md')
  fs.writeFileSync(落, 行.join('\n') + '\n')
  console.log('已落盘 ' + 落)
  process.exit(0)
}

// ★ 1010 · `权重` 子命令（**老板 1010 令**：「你的推荐，但是不要删，就是说很久没用的东西就放那里，
//   等我哪天要删的时候再根据这个时间使用的权重再删」）⇒ 本子命令**只出清单、绝不删、绝不搬**。
//   权重 = 岁数(天) ÷ (1 + 被引用次数)：**越久没人动、越没人提 ⇒ 权重越大 ⇒ 将来删的优先级越高**。
//   引用数用**一次遍历建索引**（不逐件 grep —— 记忆 `0musd4s72`：循环 grep 300 秒超时）。
if (cmd === '权重') {
  const 今 = Date.now(), 天 = 86400000
  const 引 = new Map()
  const 文本后缀 = /\.(mjs|js|md|json|sh|txt|yml|yaml)$/
  const 走 = (目录, 深 = 0) => {
    if (深 > 3) return
    let 名 = []; try { 名 = fs.readdirSync(目录, { withFileTypes: true }) } catch { return }
    for (const e of 名) {
      const p = path.join(目录, e.name)
      if (e.isDirectory()) { if (!/node_modules|\.git|_tmp/.test(e.name)) 走(p, 深 + 1); continue }
      if (!文本后缀.test(e.name)) continue
      try { if (fs.statSync(p).size > 2_000_000) continue } catch { continue }
      let t = ''; try { t = fs.readFileSync(p, 'utf8') } catch { continue }
      for (const m of t.matchAll(/[A-Za-z0-9_\u4e00-\u9fa5.\-]{2,60}\.(?:mjs|js|md|json|sh|txt|png|log)/g)) {
        const b = path.basename(m[0]); 引.set(b, (引.get(b) || 0) + 1)
      }
    }
  }
  for (const r of ['工具', '台账', '内核', '记忆', '调研']) 走(path.join(WS, r))
  const 候 = []
  const 收 = (目录) => {
    let 名 = []; try { 名 = fs.readdirSync(目录, { withFileTypes: true }) } catch { return }
    for (const e of 名) {
      if (e.name === '.nomedia') continue
      const p = path.join(目录, e.name)
      let st; try { st = fs.statSync(p) } catch { continue }
      候.push({ 件: path.relative(WS, p), 字节: st.isDirectory() ? 0 : st.size, 目录: st.isDirectory(), 岁数: (今 - st.mtimeMs) / 天 })
    }
  }
  收(path.join(WS, '_tmp')); 收(path.join(WS, '工具/_tmp')); 收(path.join(WS, '_pkg'))
  for (const x of 候) { x.引用 = 引.get(path.basename(x.件)) || 0; x.权重 = x.岁数 / (1 + x.引用) }
  候.sort((a, b) => b.权重 - a.权重)
  const KB = (n) => n ? Math.round(n / 1024) + 'KB' : '目录'
  const 行 = ['# 退休权重 · ' + new Date().toLocaleString('zh-CN') + '（机器生成 · **只出清单，不删不搬**）', '',
    '**老板 1010 令**：「你的推荐，但是不要删，就是说很久没用的东西就放那里，等我哪天要删的时候再根据这个时间使用的权重再删」',
    '', '权重 = **岁数(天) ÷ (1 + 被引用次数)** —— 越久没人动、越没人提 ⇒ 越大 ⇒ 将来删的优先级越高。',
    '候选场 ＝ `_tmp/` · `工具/_tmp/` · `_pkg/`（共 ' + 候.length + ' 件）。引用数＝该文件名在工作区正文里出现的次数（一次遍历建索引）。', '']
  const 段 = (名, a) => {
    if (!a.length) return
    行.push('## ' + 名 + '（' + a.length + ' 件）', '', '| 权重 | 岁数 | 引用 | 体量 | 件 |', '|---|---|---|---|---|')
    for (const x of a.slice(0, 40)) 行.push('| ' + x.权重.toFixed(1) + ' | ' + Math.round(x.岁数) + '天 | ' + x.引用 + ' | ' + KB(x.字节) + ' | `' + x.件 + '` |')
    行.push('', a.length > 40 ? '（本节只列前 40 件；本节共 ' + a.length + ' 件）' : '')
  }
  // ⚠️ 首跑实测：**绝对天数阈值（180/60）在当前数据下没用** —— 543 件里**最老的才 24 天**（工作区历史短），
  //   全被判成"还新"、零区分度。⇒ 改用**相对分位**（前 15%／15~50%／后 50%）；等盘上真老了再换回绝对天数。
  const 位 = (r) => Math.floor(候.length * r)
  段('一、最该动（权重前 15% —— 越久没人动、越没人提的排最前）', 候.slice(0, 位(0.15)))
  段('二、次之（15%~50%）', 候.slice(位(0.15), 位(0.5)))
  段('三、还新（后 50%，先别动）', 候.slice(位(0.5)))
  const 落 = path.join(WS, '台账/接续/退休权重_1010.md')
  fs.writeFileSync(落, 行.join('\n') + '\n')
  const 最老 = 候.length ? Math.round(Math.max(...候.map((x) => x.岁数))) : 0
  console.log('退休权重 · 候选 ' + 候.length + ' 件（最老的 ' + 最老 + ' 天）｜ 最该动 ' + 位(0.15) + ' ｜ 次之 ' + (位(0.5) - 位(0.15)) + ' ｜ 还新 ' + (候.length - 位(0.5)))
  for (const x of 候.slice(0, 12)) console.log('  ' + x.权重.toFixed(1).padStart(8) + '  ' + Math.round(x.岁数) + '天 ｜ 引用 ' + x.引用 + ' ｜ ' + KB(x.字节) + ' ｜ ' + x.件)
  console.log('已落盘 ' + 落)
  process.exit(0)
}

if (cmd === '销') {
  const 件 = process.argv[3]
  const 理由 = process.argv.slice(4).join(' ') || '（没写理由 —— 补上）'
  if (!件) { console.error('用法：出口账.mjs 销 <件> <理由>'); process.exit(2) }
  const j = 读销账(); j.件 = j.件 || {}; j.件[件] = { at: new Date().toISOString(), 理由 }
  fs.writeFileSync(path.join(WS, 销账路), JSON.stringify(j, null, 1))
  console.log('已销：' + 件 + '（' + 理由 + '）')
  process.exit(0)
}

console.log('用法：出口账.mjs 扫 ｜ 一屏 ｜ 销 <件> <理由>')
