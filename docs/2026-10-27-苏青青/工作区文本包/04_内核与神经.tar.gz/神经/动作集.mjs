#!/usr/bin/env node
// 「动作集」· 一条命令看全（2026-09-19 ⑥号窗建）
// 它是干嘛的：把**散落各处的动作指令**收拢成**一层**，苏青青每轮开工先核它在不在，再照动作走。
//   · **工具动作 22 条** ＝ `工具/台账/流程定义.mjs`（真实命令/判据/退路/出处）
//   · **行为动作**（条数现数）＝ `神经/动作集定义.mjs`（说话与汇报／动手纪律／干活与交付／跨窗口）
// 用法：node 神经/动作集.mjs 印|核|查 <词> [--seg A|B|C|D]
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const { FLOW, SEG_ORDER } = await import(path.join(HERE, '../工具/台账/流程定义.mjs'));
const { ACTS_BEHAVIOR, SEG } = await import(path.join(HERE, '动作集定义.mjs'));
const cmd = process.argv[2] || '核';
const arg = process.argv[3] || '';
const segOf = id => String(id).slice(0, 1);
const out = [];
const P = s => out.push(s);

if (cmd === '印' || cmd === '查') {
  let beh = ACTS_BEHAVIOR.slice();
  if (cmd === '查' && arg) beh = beh.filter(a => (a.id + a.txt + a.judge + a.viol + a.src).includes(arg));
  P('# 动作集 · 行为动作（' + beh.length + '/' + ACTS_BEHAVIOR.length + ' 条）\n');
  for (const s of Object.keys(SEG)) {
    const g = beh.filter(a => segOf(a.id) === s); if (!g.length) continue;
    P('## ' + s + ' · ' + SEG[s] + '\n');
    for (const a of g) P('**' + a.id + '** ' + a.txt + '\n  · 判据：' + a.judge + '\n  · 违反长什么样：' + a.viol + '\n  · 出处：' + a.src + '\n');
  }
  if (cmd === '印') {
    P('# 动作集 · 工具动作（' + FLOW.length + ' 条 · 定义在 工具/台账/流程定义.mjs）\n');
    for (const s of SEG_ORDER) { P('## ' + s); for (const a of FLOW.filter(x => x.seg === s)) P('- **' + a.name + '** — ' + a.when + '（' + a.cmd + '）'); P(''); }
  }
} else if (cmd === '补入') {
  const actName = process.argv[3], text = process.argv[4]
  if (!actName || !text) { console.log('用法：node 神经/动作集.mjs 补入 <动作名> "<细分项>"'); process.exit(2) }
  const f = path.join(HERE, '../工具/台账/流程定义.mjs'), bak = f + '.bak-0919-前补入'
  const src = fs.readFileSync(f, 'utf8')
  fs.writeFileSync(bak, src)
  const ls = src.split('\n')
  const si = ls.findIndex(l => l.includes('export const SUB = {'))
  if (si < 0) { console.log('❌ SUB 段不在（它是细分项的落点）'); process.exit(2) }
  const isKey = l => /^\s*'/.test(l) && /\)?:\s*\[/.test(l) === false && /':\s*\[/.test(l)
  const ki = ls.findIndex((l, i) => i > si && /^\s*'/.test(l) && l.includes("'" + actName + "':"))
  const countSub = () => {
    const cur = fs.readFileSync(f, 'utf8').split('\n')
    const k = cur.findIndex((l, i) => i > si && /^\s*'/.test(l) && l.includes("'" + actName + "':"))
    if (k < 0) return 0
    let n = 0
    for (let i = k + 1; i < cur.length && !/^\s*\]/.test(cur[i]); i++) if (cur[i].trim()) n++
    return n
  }
  const nBefore = countSub()
  if (ki < 0) {
    let ei = -1
    for (let i = ls.length - 1; i > si; i--) if (ls[i].trim() === '};') { ei = i; break }
    if (ei < 0) { console.log('❌ 找不到 SUB 段的收尾 };'); process.exit(2) }
    ls.splice(ei, 0, " '" + actName + "': [", "  '" + text + "',", ' ],')
  } else {
    ls.splice(ki + 1, 0, "  '" + text + "',")
  }
  fs.writeFileSync(f, ls.join('\n'))
  const self = []
  const out = fs.readFileSync(f, 'utf8')
  self.push(['SUB 段还在', out.includes('export const SUB = {')])
  self.push(['文本真在 SUB 里', out.includes(text)])
  let imported = null
  try { imported = (await import('file://' + f + '?v=' + Date.now())).SUB; self.push(['能 import（语法过）', true]) }
  catch (e) { self.push(['能 import（语法过）', false]) }
  self.push(['条数真涨 1', countSub() === nBefore + 1])
  if (imported && imported[actName]) self.push(['读回来能看见它', (imported[actName] || []).some(x => x.includes(text.slice(0, 24)))])
  const bad = self.filter(x => !x[1])
  if (bad.length) { fs.writeFileSync(f, src); console.log('❌ 自证失败 ⇒ 已自动还原：' + bad.map(x => x[0]).join(' ／ ')); process.exit(1) }
  console.log('✅ 已补入「' + actName + '」的细分项（现在共 ' + countSub() + ' 条）｜四项自证全过｜备份 ' + bak)
} else if (cmd === '记坑') {
  // fix#2 写入端（2026-09-19 ⑥号窗）：新踩的坑**当场落进定义** —— 以前只有"打烊清单里我手填一行"，
  // 而那份 md 根本不回写 PITS，下一窗也读不到 ⇒ 坑清单三段全断（闭环诊断_0919 §2）。
  // 安全三件：先备份 → 插入 → `node --check`，语法不过立刻还原。
  const t = String(arg || '').toUpperCase(), text = process.argv[4] || '';
  const { TORDER, PITS: _P0 } = await import(path.join(HERE, '时序定义.mjs'));
  if (!t || !TORDER.includes(t) || !text) { console.log('用法：node 神经/动作集.mjs 记坑 <T0..T6> "<这一条坑>"'); process.exit(2) }
  const nBefore = (_P0[t] || []).length   // 真值取自"写之前"那次 import（准确，不靠数行）
  const { execFileSync } = await import('node:child_process');
  const f = path.join(HERE, '时序定义.mjs'), bak = f + '.bak-0919-前记坑';
  fs.copyFileSync(f, bak);
  const src = fs.readFileSync(f, 'utf8');
  // ⚠️ 锚点必须**限定在 PITS 里面**：`  T2: [` 这种短锚点会先命中时序表 `T` 的 `T2:`，
  //    于是坑被塞进错的对象，而且 `node --check` **照样过** ⇒ 静默改错地方（2026-09-19 实测，本工具自己栽过一次）。
  const p0 = src.indexOf('export const PITS = {');
  if (p0 < 0) { console.log('⛔ 时序定义.mjs 里找不到 `export const PITS = {` ⇒ 没写'); process.exit(1) }
  const anchor = '  ' + t + ': [';
  const i = src.indexOf(anchor, p0);
  if (i < 0) { console.log('⛔ PITS 里找不到锚点 ' + anchor + ' ⇒ 没写（没动任何文件）'); process.exit(1) }
  const out2 = src.slice(0, i + anchor.length) + '\n       ' + JSON.stringify(text) + ',' + src.slice(i + anchor.length);
  fs.writeFileSync(f, out2);
  // 自证两件（写完必须回头核，不许只看"没报错"）：① 新坑真的在 PITS 段里 ② 时序表 T 没被碰坏
  const tSeg = out2.slice(out2.indexOf('export const PITS = {'));
  const tOk = new RegExp('\\n  ' + t + ": \\['" + t + ' · ').test(out2.slice(0, out2.indexOf('export const PITS = {')));
  const pOk = tSeg.includes(JSON.stringify(text));
  let synOk = true;
  try { execFileSync('node', ['--check', f], { stdio: 'pipe' }) } catch { synOk = false }
  if (!synOk || !tOk || !pOk) {
    fs.copyFileSync(bak, f);
    console.log('⛔ 自证不过（语法' + (synOk ? '过' : '挂') + '／时序表' + (tOk ? '好' : '**被碰坏**') + '／新坑' + (pOk ? '在' : '**不在**') + '）⇒ **已自动还原**（备份 ' + path.basename(bak) + '）');
    process.exit(1)
  }
  // 条数必须**真的涨 1**，不涨就还原（本工具第一版少了这条自证 ⇒ 报 ✅ 而文件其实没变）
  let nAfter = -1;
  try { const m2 = await import(path.join(HERE, '时序定义.mjs') + '?v=' + Date.now()); nAfter = (m2.PITS[t] || []).length } catch {}
  if (nAfter !== nBefore + 1) {
    fs.copyFileSync(bak, f);
    console.log('⛔ 条数没涨（写前 ' + nBefore + ' → 写后 ' + nAfter + '）⇒ **已自动还原**（备份 ' + path.basename(bak) + '）');
    process.exit(1)
  }
  console.log('✅ 已回写 ' + t + '（自证：语法过／时序表没被碰／新坑在 PITS 段里／条数 ' + nBefore + ' → ' + nAfter + '）｜ 备份 ' + path.basename(bak));
  console.log('   新增：' + text);
  process.exit(0)
} else if (cmd === '判') {
  // ★ 2026-09-22 新档（三模块缺口 #3：39 条行为动作**只有 1 条**能机器判 ⇒ 靠自觉）：
  //   把 `动作判据.mjs` 的三档判据**真跑一遍**。判不了的**明码标出来**，不许混进绿（内核 #71）。
  const { JUDGES, KIND } = await import(path.join(HERE, '动作判据.mjs'));
  const { execFileSync } = await import('node:child_process');
  const WS = path.resolve(HERE, '..');
  let green = 0, red = 0, inst = 0, none = 0;
  const reds = [];
  for (const a of ACTS_BEHAVIOR) {
    const j = JUDGES[a.id];
    if (!j) { P('  ⚪ ' + a.id + ' —— **没有判据条目**（漏了）'); none++; continue }
    if (j.k === 'none') { none++; continue }
    if (j.k === 'inst') { inst++; continue }
    let ok = false, note = '';
    try {
      execFileSync('bash', ['-c', j.cmd], { cwd: WS, timeout: 120000, stdio: 'pipe' });
      ok = true;
    } catch (e) { note = String((e && e.message) || '').split('\n')[0].slice(0, 80) }
    if (ok) green++; else { red++; reds.push(a.id + ' → ' + j.cmd + ' ｜ ' + note) }
  }
  P('\n=== 行为动作·判据体检（39 条三档）===');
  P('  ✅ 无参可跑·绿 ' + green + ' ｜ 🔴 无参可跑·红 ' + red + ' ｜ ⚙️ 有仪器需入参 ' + inst + ' ｜ ⚪ **判不了（条文级·不可靠）** ' + none);
  for (const r of reds) P('  🔴 ' + r);
  P('  ⚪ 那 ' + none + ' 条**别指望判据** —— 出路是**挂到必然时刻**（内核 #58／靠自觉队列）；硬塞判据＝造假绿。');
  P('  （档位定义与理由在 `神经/动作判据.mjs`；改判据＝改那份）');
  console.log(out.join('\n'));
  process.exit(red > 0 ? 1 : 0);
} else if (cmd === '封层') {
  // 封层基线：**把"上限"从"当前列表长度"改成"冻结文件里的那一份"**（2026-09-22 · 补三模块缺口 #4）
  // 为什么必须这样：旧版 `核` 打印的「上限 = 行为动作 N 条」里 N 是**现算的** ⇒ 我每加一条它就跟着涨，
  // 自指口径 ⇒ **永远不会红**（内核 #8：仪器静默失效）。现在基线是文件，加一条就红。
  const 理由 = process.argv.includes('--理由') ? process.argv[process.argv.indexOf('--理由') + 1] : ''
  if (!理由 || 理由.startsWith('--')) {
    P('❌ 刷新封层**必须给理由**：node 神经/动作集.mjs 封层 --理由 "为什么必须加/删一条"');
    P('（没有理由就刷新 ⇒ 「只许替换、不许净增」这条规矩等于没有）');
    process.exitCode = 2;
  } else {
    const f = path.join(HERE, '动作集封层.json');
    const 旧 = fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : null;
    const 新 = { at: new Date().toISOString().slice(0, 10), 理由, 规矩: '行为动作只许替换或合并，不许净增；工具动作同上',
      行为动作: ACTS_BEHAVIOR.map(a => a.id), 工具动作: FLOW.map(a => a.name) };
    fs.writeFileSync(f, JSON.stringify(新, null, 1) + '\n');
    P('✅ 封层已刷新：' + f);
    P('  · 行为动作 ' + (旧 ? 旧.行为动作.length + ' → ' : '') + 新.行为动作.length + ' 条 ｜ 工具动作 ' + (旧 ? 旧.工具动作.length + ' → ' : '') + 新.工具动作.length + ' 条');
    P('  · 理由：' + 理由);
    P('  · ⚠️ 刷新封层＝**开封**：这一笔要在台账留痕（照规矩，理由得是"替换/合并"而不是"我想加"）');
  }
} else if (cmd === '时点' || cmd === '坑') {
  const { T, TORDER, MAP, PITS, DUP } = await import(path.join(HERE, '时序定义.mjs'));
  const at = x => MAP[x] || '（没排）';
  const which = (arg || '').toUpperCase();
  if (cmd === '坑') {
    const list = which ? [which] : TORDER;
    for (const t of list) { P('## ' + (T[t] ? T[t][0] : t) + '\n' + (T[t] ? '> ' + T[t][1] + '\n' : ''));
      for (const p of (PITS[t] || [])) P('- ⚠️ ' + p); P(''); }
    // 命中记账（内核 #39 的老办法）：**真跑过一次就记一笔** —— 轮末 `打烊.mjs` 照这本账数
    // 「本窗按步查坑跑了几次」。不靠扫会话日志猜（那会把"我写文件时正文里带的字样"也数进去，实测虚高）。
    try {
      const ledger = path.join(HERE, '../工具/台账/轮末/查坑记账.jsonl');
      fs.mkdirSync(path.dirname(ledger), { recursive: true });
      fs.appendFileSync(ledger, JSON.stringify({ at: new Date().toISOString(), T: which || 'ALL', sid: process.env.DSH_SESSION_ID || '' }) + '\n');
    } catch {}
  } else {
    P('# 动作集 · 时序（' + TORDER.length + ' 个时点 · 工具 ' + FLOW.length + ' ＋ 行为 ' + ACTS_BEHAVIOR.length + ' 条 + 贯穿 ' + ACTS_BEHAVIOR.filter(a => at(a.id) === 'ALL').length + ' 条）\n');
    P('> 规则：**上一步没跑完，不进退下一步**（守内核「一轮只干一件事」）。每一步开头**先跑 `动作集.mjs 坑 <T>`** 把这一步的坑摆出来。\n');
    for (const t of TORDER) {
      const tools = FLOW.filter(a => at(a.name) === t).map(a => a.name);
      const beh = ACTS_BEHAVIOR.filter(a => at(a.id) === t).map(a => a.id + ' ' + a.txt);
      P('## ' + T[t][0] + '　`坑 ' + (PITS[t] || []).length + ' 条`');
      P('> ' + T[t][1]);
      if (tools.length) P('- **工具动作**：' + tools.join('、'));
      if (beh.length) P('- **行为动作**：' + beh.join('；'));
      P('');
    }
    const all = ACTS_BEHAVIOR.filter(a => at(a.id) === 'ALL').map(a => a.id + ' ' + a.txt);
    P('## 贯穿全程（' + all.length + ' 条）—— 任何时点都成立\n');
    for (const x of all) P('- ' + x);
    P('\n## 已知重合对（当初一条条加留下的）—— 怎么干**以工具层为权威**\n');
    P('| 行为层（何时必须做） | 工具层（怎么做） | 权威 |\n|---|---|---|');
    for (const [b, n, w] of DUP) P('| ' + b + ' | ' + n + ' | ' + w + ' |');
  }
} else {
  // 核：条数 / 重复 id / 缺格 / 两类是否都读得到
  const ids = ACTS_BEHAVIOR.map(a => a.id);
  const dup = ids.filter((x, i) => ids.indexOf(x) !== i);
  const keys = ['id', 'txt', 'judge', 'viol', 'src'];
  const bad = ACTS_BEHAVIOR.filter(a => keys.some(k => !a[k])).map(a => a.id);
  const noSrc = ACTS_BEHAVIOR.filter(a => a.src && !/AGENTS\.md|记忆 |做法库|内核|总库|公约|原话/.test(a.src)).map(a => a.id);
  const fkeys = ['name', 're', 'seg', 'when', 'who', 'cmd', 'judge', 'out', 'show', 'fail', 'miss', 'src'];
  const fbad = FLOW.filter(a => fkeys.some(k => !a[k])).map(a => a.name);
  P('【动作集 · 核】' + new Date().toLocaleString('zh-CN'));
  P('- 工具动作 **' + FLOW.length + '** 条（工具/台账/流程定义.mjs）｜行为动作 **' + ACTS_BEHAVIOR.length + '** 条（神经/动作集定义.mjs）｜**合计 ' + (FLOW.length + ACTS_BEHAVIOR.length) + ' 条**');
  P('- 重复 id：' + (dup.length ? '❌ ' + dup.join(',') : '✅ 无'));
  P('- 行为动作缺格：' + (bad.length ? '❌ ' + bad.join(',') : '✅ 无'));
  P('- 工具动作缺格：' + (fbad.length ? '❌ ' + fbad.join(',') : '✅ 无'));
  P('- 出处看着不像能回源的：' + (noSrc.length ? '⚠️ ' + noSrc.join(',') : '✅ 无'));
  // ★ 2026-09-22（三模块缺口 #4 · 封层）：对**冻结基线**判"净增/净减"，不再拿当前长度当上限
  let 封层ok = true
  {
    const f = path.join(HERE, '动作集封层.json')
    if (!fs.existsSync(f)) {
      P('- 封层：❌ 没有基线文件 `神经/动作集封层.json` ⇒ 先 `动作集.mjs 封层 --理由 "…"` 冻一次')
      封层ok = false
    } else {
      const b = JSON.parse(fs.readFileSync(f, 'utf8'))
      const nowB = ids, nowT = FLOW.map(a => a.name)
      const 增B = nowB.filter(x => !b.行为动作.includes(x)), 减B = b.行为动作.filter(x => !nowB.includes(x))
      const 增T = nowT.filter(x => !b.工具动作.includes(x)), 减T = b.工具动作.filter(x => !nowT.includes(x))
      P('- 封层（基线 ' + b.at + ' · 理由：' + b.理由 + '）：行为 **' + b.行为动作.length + ' → ' + nowB.length + '** ｜ 工具 **' + b.工具动作.length + ' → ' + nowT.length + '**')
      P('  · 新增：' + (((增B.length + 增T.length)) ? '❌ ' + 增B.concat(增T).join('、') : '✅ 无'))
      P('  · 删除：' + (((减B.length + 减T.length)) ? '⚠️ ' + 减B.concat(减T).join('、') + '（删允许，但要在台账留痕）' : '✅ 无'))
      if (增B.length + 增T.length) {
        P('  ⇒ **净增 = 破封层**：新增一条必须**同时替换或合并一条**（只许替换、不许净增）。')
        P('     真要加 ⇒ `node 神经/动作集.mjs 封层 --理由 "用哪条换了哪条"` **显式开封**，并在台账留痕。')
        封层ok = false
      }
    }
  }
  let ok = 封层ok && !dup.length && !bad.length && !fbad.length;
  try { const { MAP } = await import(path.join(HERE, '时序定义.mjs'));
    const noT = [...FLOW.map(a=>a.name), ...ACTS_BEHAVIOR.map(a=>a.id)].filter(x=>!MAP[x]);
    P('- 没排时点的：' + (noT.length ? '❌ ' + noT.join(',') : '✅ 无（' + (FLOW.length + ACTS_BEHAVIOR.length) + ' 条都在时间轴上）'));
  } catch { P('- 时点：⚠️ 读不到 时序定义.mjs') }

  // ★ 2026-09-20（段 3 · 判据层）：报「命令可判 / 只有文字」—— 别再靠我自评
  {
    // ★ 1009 夜统一口径（老板令：我自己发现两处打架 ⇒ 别停下等，做掉）：
    //   旧口径＝按 `judge` 字段里有没有 `node `／`.mjs` 字样数 ⇒ 15；
    //   与 `神经/动作判据.mjs` 的三档表（cmd 8 + inst 12）⇒ 20 **对不上**。
    //   ⇒ 改成**读那份三档表**（判据只此一处，改判据＝改那份；这里不另立口径）。
    const beh = Object.values(ACTS_BEHAVIOR || {})
    let A = 0
    try {
      const 判文 = fs.readFileSync(path.join(HERE, '动作判据.mjs'), 'utf8')
      // ★ 1009 夜收严：要求**行首 id ＋ k 字段**（真条目行的形状），不再裸找字样
      //   （教训：判据写成「正文里找字样」⇒ 注释／说明里出现同字样就多算。见记忆 0mujujvb3）
      A = (判文.match(/^\s+[A-Z]\d+: \{ k: '(?:cmd|inst)'/gm) || []).length
    } catch { A = -1 }   // 读不到 ⇒ 明码 -1（不许装作 0，假绿比不报更坏）
    console.log('- 判据形式：**命令可判 ' + A + ' / ' + beh.length + ' 条**（其余 ' + (beh.length - A) + ' 条＝**条文级·不可靠**，不许当真判据用）')
    console.log('- 封层：行为动作**上限 ' + beh.length + ' 条**；**新增一条 ⇒ 必须替换或合并一条**（只许替换、不许净增）')
  }
  // ★ 2026-09-22 · 外部核第四种做法：**覆盖率与"每轮拉起"同源** —— 不再另数一层
  try {
    const Z = await import(path.join(HERE, '自举.mjs'))
    const k = Z.核()
    P('- **自举覆盖（与"每轮拉起"同源）**：有触发 **' + k.有触发 + ' / 总 ' + k.总 + ' 条**')
    // ── ★★ 2026-10-13 迭代2.0（门/动作这一刀）：上面那行是**纸面绿** —— 它判的是"触发条件写没写"。
    //   本机实测（1013）：93 个动作点里**有可跑命令的只有 34 条**；`流程/跑.mjs 核` 标"死" 59 条。
    //   判据（书）：**有触发而没有消费者 ＝ 挂着不跑**（＝ 1001 那句「摆 ≠ 拦」）。
    //   ⇒ **并列报出来**，别让"93/93"单独冒充覆盖。真源 `台账/接续/流程真值.md`（`流程/跑.mjs 核` 生成）。
    //   回退：删掉下面这 6 行即可（本刀只加报数，不改任何判据、不加门）。
    try {
      const 真值路 = path.join(HERE, '../工具/台账/接续/流程真值.md')
      const 真值文 = fs.readFileSync(真值路, 'utf8')
      // ★ 2026-10-13 收口（补我自己引的隐患）：这份真值是**手工跑出来的**（`流程/跑.mjs 核`）⇒ 会陈，
      //   本行必须**自带年龄**，陈了就明说，别让一个几小时前的读数冒充现状。
      //   ⚠️ 年龄取**文件系统 mtime**，不取文件头那句日期 —— 实测两者不一致
      //   （头写 10-12 18:26 ／ mtime 实为 10-13 02:26）⇒ 头部那句不可信，文件系统才是真值。
      const 小时 = (Date.now() - fs.statSync(真值路).mtimeMs) / 3600000
      const 龄 = 小时 < 1 ? Math.max(1, Math.round(小时 * 60)) + ' 分钟前' : 小时.toFixed(1) + ' 小时前'
      const m真 = 真值文.match(/\|\s*工具动作（流程定义）\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|/)
      P(m真
        ? '- ★ **真消费者（实跑口径，与上面那行不是一回事）**：有可跑命令 **' + m真[2] + ' / ' + m真[1] + '** ⇒ **其余 ' + (Number(m真[1]) - Number(m真[2])) + ' 件靠人记得跑**（纸面触发 ≠ 有人跑｜这份真值 ' + 龄 + (小时 > 12 ? ' ⇒ **陈了，先跑** `node 工具/流程/跑.mjs 核` **刷它**' : '') + '）'
        : '- ★ **真消费者**：⚠️ 读不出（`流程真值.md` 表头变了？）—— **这不是"全绿"**')
    } catch { P('- ★ **真消费者**：⚠️ 读不到 `台账/接续/流程真值.md` ⇒ 先跑 `node 工具/流程/跑.mjs 核` —— **这不是"全绿"**') }
    P('  · 没写触发（⇒ **永远不可能被拉起**）：' + (k.没写.length ? '❌ ' + k.没写.length + ' 条 → ' + k.没写.join('、') : '✅ 0 条'))
    P('  · 漂（触发表里写了、动作集里没这个名字 ⇒ **假装覆盖**）：' + (k.漂.length ? '❌ ' + k.漂.join('、') : '✅ 0 条'))
    P('  · 重名：' + (k.重名.length ? '❌ ' + k.重名.join('、') : '✅ 0 条') + ' ｜ 恒（真正贯穿的，上限 6）：' + k.恒.length + ' 条')
    if (k.没写.length || k.漂.length || k.重名.length) ok = false
  } catch (e) { P('- 自举覆盖：⚠️ 读不到 神经/自举.mjs（' + String((e && e.message) || e).slice(0, 50) + '）') }

  P(ok ? '\n✅ 动作集完整（' + (FLOW.length + ACTS_BEHAVIOR.length) + ' 条）—— **第一步动作 D01：先确认这一行在，再照动作走**' : '\n❌ 动作集不完整 ⇒ 先修它，别急着干活');
  process.exitCode = ok ? 0 : 1;
}
console.log(out.join('\n'));
