#!/usr/bin/env node
/**
 * 单价 · 闸 ＋ 常驻尺 ＋ 钱账（2026-09-28 · 老板令：「单价最高 0.05」「得留把尺子」）
 * ─────────────────────────────────────────────────────────────────────────
 *   node 神经/单价.mjs 查        # 改任何推高单价的东西之前跑它（线价 vs 上限，红/绿）
 *   node 神经/单价.mjs 账        # ★ 每步／每轮／本窗花多少钱（老板 0928：「明确给我们来说……花多少钱就 OK 了嘛」）
 *   node 神经/单价.mjs 常驻      # 常驻面尺子：现在多少字/占比、每加 1,000 字的钱、三条线在哪
 *   node 神经/单价.mjs 任务 --步 4000 --均 500000
 * ★ 它是闸、不是刹车（老板原话「不能为了省钱连工作不干了吧」）：长任务/深上下文允许单步超，
 *   看的是分布（任务平均每步）；长期任务按 JSON 里的例外只标记、不拦。
 * 不写死：上限值／判据／例外／尺子的线 全在 `神经/单价上限.json`。
 */
import fs from 'node:fs'
import { execFileSync } from 'node:child_process'
import { 每百万 } from './价目.mjs'

const 工作区 = '/storage/emulated/0/3'
const HOME = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const PRESET = HOME + '/.agent-presets/suqingqing/agent.cordis.yml'
const CFGP = 工作区 + '/神经/单价上限.json'
const A = process.argv.slice(2)
const 子 = A[0] || '查'
const K = (k) => { const i = A.indexOf(k); return i >= 0 ? A[i + 1] : null }
const 数 = (s) => (s == null ? null : String(s).includes('万') ? parseFloat(s) * 1e4 : parseFloat(s))
const 字 = (x) => [...x].length
const 小 = (x) => '¥' + x.toFixed(4)

const cfg = JSON.parse(fs.readFileSync(CFGP, 'utf8'))
const 上限 = cfg['上限每步']
const 判据 = cfg['判据'] === '峰价' ? '峰价' : cfg['判据'] === '分布' ? '分布' : '线价'
const 口径 = cfg['口径'] === '账单' ? '账单' : '保守'
const 系数 = Number(cfg['峰线系数']) || 1.48
const 钱 = (tok, k = 口径) => (k === '账单' ? (tok / 1e6) * 0.0908 : 0.012 + (每百万.命中.空闲 / 100) * (tok / 1e4))  // 1018 收口：缓存读用官方 ¥0.02/百万（旧值 0.002/万＝¥0.2/百万，高 10 倍）

if (子 === '账') {
  console.log('⚠️ 本格已弃用（老板 2026-10-14 令：「老的那个不要了，换成新的」）—— 它按**自己编的价目表**算（混合均价 ¥0.0908/M ＋ 拟合式），不是官方分档价目。')
  console.log('   ⇒ 要真账：跑 cost_now（provider 报的用量）或 node 神经/钱账按天.mjs（官方分档 · 按天）。下面是旧口径，仅作参照。\n')
  let t = ''
  // ⚠️ 子进程别用 execSync（要 sh，DSH 内置 node 的 PATH 里没有）也别用 process.execPath（＝linker64，报 bad ELF magic）—— 用候选解释器路径逐个试
  const 脚本 = 工作区 + '/神经/耗量.mjs'
  for (const 解释器 of [process.env.DSH_NODE, '/data/data/com.dsharnessmobile.shell/files/usr/bin/node', '/usr/bin/node', 'node'].filter(Boolean)) {
    try { t = execFileSync(解释器, [脚本], { encoding: 'utf8', maxBuffer: 1 << 28 }); break } catch (e) { t = String(e.stdout || ''); if (t.length > 100) break }
  }
  const m轮 = t.match(/轮\s*(\d+)\s*｜\s*步\s*(\d+)/)
  const m合 = t.match(/合计：新入\s*([\d,]+)\s*｜\s*出\s*([\d,]+)[^｜]*｜\s*缓存读\s*([\d,]+)/)
  if (!m轮 || !m合) { console.log('⚠️ 解析不到耗量.mjs 的真账（形状变了？）'); process.exit(1) }
  const 去 = (x) => parseFloat(String(x).replace(/,/g, ''))
  const 轮 = +m轮[1], 步 = +m轮[2], 总 = 去(m合[1]) + 去(m合[2]) + 去(m合[3])
  const 保守 = 0.012 * 步 + 0.002 * (总 / 1e4), 账单 = (总 / 1e6) * 0.0908
  const f = (x) => '¥' + x.toFixed(x < 1 ? 3 : 2)
  console.log('── 钱账（本窗真账 token → 两口径）')
  console.log('   本窗 ' + 轮 + ' 轮 ｜ ' + 步 + ' 步 ｜ 总 ' + (总 / 1e4).toFixed(0) + ' 万 token')
  console.log('   ★ **每步**：保守 ' + f(保守 / 步) + ' ｜ 账单 ' + f(账单 / 步))
  console.log('   ★ **每轮**（' + (步 / 轮).toFixed(1) + ' 步/轮）：保守 ' + f(保守 / 轮) + ' ｜ 账单 ' + f(账单 / 轮))
  console.log('   ★ **本窗合计**：保守 ' + f(保守) + ' ｜ 账单 ' + f(账单))
  console.log('   目标（上限 ' + f(上限) + '/步 · 保守口径）：' + (保守 / 步 <= 上限 ? '✅ 达标' : '❌ 未达标') + '（余量 ' + f(上限 - 保守 / 步) + '/步）')
  process.exit(0)
}

if (子 === '常驻') {
  const c = cfg['常驻尺'] || {}, k = Number(c['字token']) || 1.88
  const 每步 = 数(K('--每步')) || Number(c['每步上下文']) || 67260
  const 窗 = Number(c['窗口步数']) || 1700
  let 总 = 0
  console.log('── 常驻面尺子（每轮原样重发的那部分）')
  for (const [名, p] of [['全局（红线本）', HOME + '/AGENTS.md'], ['工作区', 工作区 + '/AGENTS.md']]) {
    let n = 0
    try { n = 字(fs.readFileSync(p, 'utf8')) } catch (e) { console.log('   ⚠ ' + 名 + ' 读不到：' + e.message) }
    总 += n
    console.log('   ' + 名 + ' '.repeat(Math.max(1, 14 - 名.length)) + String(n).padStart(5) + ' 字')
  }
  const tok = Math.round(总 / k), 占 = (tok / 每步) * 100, 千 = 1000 / k
  console.log('   合计 ' + 总 + ' 字 ≈ ' + tok + ' token（按 ' + k + ' 字/token）⇒ 占每步 ' + 每步.toLocaleString() + ' token 的 ' + 占.toFixed(1) + '%')
  const 增保 = 0.002 * (千 / 1e4), 增账 = (千 / 1e6) * 0.0908
  console.log('   每加 1,000 字 ⇒ 每步 保守 ¥' + 增保.toFixed(5) + ' / 账单 ¥' + 增账.toFixed(6) + ' ｜ ' + 窗 + ' 步窗 ⇒ 保守 ¥' + (增保 * 窗).toFixed(2) + ' / 账单 ¥' + (增账 * 窗).toFixed(2))
  for (const [名, 键] of [['注意线', '注意线'], ['该精简线', '该精简线'], ['必须精简线', '必须精简线']]) {
    const p = Number(c[键]) || 0
    console.log('   ' + 名 + ' ' + (p * 100).toFixed(0) + '% ⇒ ' + Math.round(每步 * p).toLocaleString() + ' token ≈ ' + Math.round(每步 * p * k).toLocaleString() + ' 字')
  }
  const 注 = Number(c['注意线']) || 0.1, 该 = Number(c['该精简线']) || 0.15, 必 = Number(c['必须精简线']) || 0.25
  console.log(占 <= 注 * 100
    ? '\n✅ 现在 ' + 占.toFixed(1) + '% ⇒ 不是大头：加 10,000 字也只 ≈ ¥' + (增账 * 10 * 窗).toFixed(2) + '/窗（账单口径）'
    : 占 <= 该 * 100 ? '\n🟡 现在 ' + 占.toFixed(1) + '% ⇒ 已过注意线：加之前先算一次钱'
      : 占 <= 必 * 100 ? '\n🟠 现在 ' + 占.toFixed(1) + '% ⇒ 过该精简线：该动手精简了' : '\n🔴 现在 ' + 占.toFixed(1) + '% ⇒ 过必须精简线')
  console.log('   ★ 老板 0928：「常驻面就 6,000 来字每一轮，**那个不是大头**，大头是**重复注入**」；「剩下的钱都没必要再省了」')
  process.exit(0)
}

if (子 === '任务') {
  const 步 = 数(K('--步')) || 4000, 均 = 数(K('--均')) || 500000, d = cfg['分布判据'] || {}
  const 限 = d['任务平均每步上限'] || 上限, 平均 = 钱(均, 口径)
  const ex = d['长任务自动例外'] && (步 >= (d['长任务自动例外']['步数≥'] || 1e9) || 均 >= (d['长任务自动例外']['峰值上下文≥'] || 1e18))
  console.log('── 一个 ' + 步.toLocaleString() + ' 步、平均每步 ' + 均.toLocaleString() + ' token 的任务')
  console.log('   每步 保守 ' + 小(钱(均, '保守')) + ' / 账单 ' + 小(钱(均, '账单')))
  console.log('   合计 保守 ¥' + (钱(均, '保守') * 步).toFixed(0) + ' / 账单 ¥' + (钱(均, '账单') * 步).toFixed(0))
  console.log('   判据（任务平均每步 ≤ ' + 小(限) + '）：' + (平均 <= 限 ? '✅ 在限内' : ex ? '⚠️ 超限 ⇒ **命中长任务例外：只标记、不拦**' : '❌ 超限且非长任务'))
  process.exit(0)
}

// ── 查（默认）────────────────────────────────────────────────────────────
let 线 = 数(K('--线'))
if (!线) {
  const t = fs.readFileSync(PRESET, 'utf8').split('\n').filter((l) => /^\s*thresholdRatio:/.test(l)).pop()
  const r = t ? parseFloat(t.split(':')[1]) : NaN
  线 = Math.round(r * (数(K('--窗口')) || 1e6))
}
const 用 = Math.round(线 * (判据 === '峰价' ? 系数 : 1))
const 命 = (cfg['例外'] || []).filter((e) => e && e['依据'] && ('放宽到' in e))
const 放宽 = 命.length ? Math.max(...命.map((e) => Number(e['放宽到']) || 0)) : 0
const 价 = 钱(用)
const 过 = 价 <= 上限 || 价 <= 放宽
console.log('── 单价闸 · 每步 ' + 小(价) + ' / 上限 ' + 小(上限) + '（' + 口径 + '口径 · ' + 判据 + '）' + (判据 === '峰价' ? '（已乘峰线系数 ' + 系数 + '）' : ''))
console.log('   线 ' + 用.toLocaleString() + ' token ｜ 账单口径参考 ' + 小(钱(用, '账单')) + ' ｜ 依据：' + (cfg['依据'] || '（缺）'))
const d = cfg['分布判据'] || {}
console.log('   ★ 分布判据：任务/窗口**平均每步** ≤ ' + 小(d['任务平均每步上限'] || 上限) + '（单步峰值允许超 —— 长任务按例外只标记、不拦）')
if (!过) { console.log('❌ 常态超上限：' + 小(价) + ' > ' + 小(上限) + ' ⇒ 要么降线／瘦常驻，要么按例外加一条带依据的'); process.exit(1) }
console.log('✅ 常态在限内（余量 ' + 小(上限 - 价) + '）')
if (命.length) console.log('⚠️ 命中例外 ' + 命.length + ' 条（放宽到 ' + 小(放宽) + '）：' + 命.map((e) => e['什么']).join(' ｜ '))
console.log('\n绿：这个配置可以落（改动＝改文件＋重启＝他的手）｜**它是闸不是刹车：不许为省钱砍活**')
process.exit(0)
