#!/usr/bin/env node
// 历史面 · 「每轮灌进去的历史」真账 v2（2026-09-27 · 老板令：「这几个得去治，主要应该是治历史」）
// ════════════════════════════════════════════════════════════════════════════
// 治的是**历史**（每步随请求重发的 message 数组），不是系统提示词那一小块。
// v2 换模型：**活份模型**（不再拿"最后一次压缩之后"当近似）。
//   日志里有引擎自己的真值：`compaction/summary.shadowedSeqs`＝每次压缩**杀死哪些 seq**、
//   `shadowedTokenCount`＝这一刀砍掉多少 token、`assistant/message.usage`＝这一步请求真花多少 token。
//   ⇒ 逐事件维护"此刻还活着的上下文"，再把「类→字」与「引擎自报 token」最小二乘对上：得到**实测** α／β。
//
// 四节（全部可从日志重跑）：
//   ① 累计注入：一类一共往里灌了多少字（谁在反复注入）——⚠️ 累计写入 ≠ 每步存活
//   ② 占比：平均每步存活多少字、按类；＋末态活份构成
//   ③ 标定：请求输入 token ≈ α ＋ β×存活字（α＝常驻固定＝系统提示词＋工具定义；β＝每字 token，实测）
//   ④ 压缩节律：几步一压、每刀砍多少 token、压缩自己又花多少
//
// 判据：会话日志 `session.v3.jsonl.zstd`（多帧 zstd 逐帧解）。自检：usage 样本数／未归类占比／末态活份>0。
// 用法：node 神经/历史面.mjs [会话片段] [--出=台账/降本/历史面_0927.json]
// ════════════════════════════════════════════════════════════════════════════
import fs from 'node:fs'
import { 找日志, 解多帧 } from '/storage/emulated/0/3/神经/注入计量.mjs'

const 参数 = process.argv.slice(2)
const 出 = ((参数.find(a => a.startsWith('--出')) || '').split('=')[1]) || ''
const L = 找日志(参数.find(a => !a.startsWith('--')) || '')
const { 文本 } = 解多帧(fs.readFileSync(L.文件))
const 事件 = []
for (const line of 文本.split('\n')) {
  if (!line.trim()) continue
  let e; try { e = JSON.parse(line) } catch { continue }
  事件.push(e)
}
if (!事件.length) { console.log('🔴 一个事件都没解出来 ⇒ 停（先查身份：run-as com.dsharnessmobile.shell）'); process.exit(2) }

// ★ 只取「真的会随请求重发的那部分」：content 里的 text ＋ tool-call 参数。
//   **排除 reasoning（思考）与 stream（流式增量，与 message 内容重复）** —— 2026-09-27 实测：
//   末条 assistant/message 里 content[0] type=reasoning 6349 字、正文字符只 187 字；data.stream[11] 是同一份内容的增量块。
//   把这两样算进去 ⇒ 存活字虚高约 4 倍、标定 β 被压到 0.16（假账）。取文必须按"报文"口径。
const 取文 = (e) => {
  const d = e.data || {}
  const 收 = []
  const 吃 = (arr) => {
    if (typeof arr === 'string') { 收.push(arr); return }
    if (!Array.isArray(arr)) return
    for (const p of arr) {
      if (typeof p === 'string') { 收.push(p); continue }
      if (!p || typeof p !== 'object') continue
      const t = p.type || ''
      if (t === 'reasoning' || t === 'thinking') continue
      if (typeof p.text === 'string') 收.push(p.text)
      else if (p.input !== undefined) 收.push(JSON.stringify(p.input))
      else if (p.arguments !== undefined) 收.push(typeof p.arguments === 'string' ? p.arguments : JSON.stringify(p.arguments))
      else if (Array.isArray(p.content)) 吃(p.content)
    }
  }
  if (e.type === 'compaction/summary') 吃(d.summary)
  else if (e.type === 'assistant/message' || e.type === 'tool/result') 吃(d.message && d.message.content)
  else 吃(d.content)
  return 收.join('')
}
const 数 = (x) => (typeof x === 'number' && isFinite(x) ? x : 0)
// 用量的那一个对象（位置不固定：data.usage / data.message.usage —— 与 耗量.mjs 同判据）
const 用量 = (d) => {
  for (const o of [d.usage, d.message && d.message.usage, d.result && d.result.usage]) {
    if (o && o.inputTokens !== undefined && o.outputTokens !== undefined) return o
  }
  return null
}
const 中位 = (a) => { const s = [...a].sort((x, y) => x - y); return s.length ? s[s.length >> 1] : 0 }

// ── 分类器：按"内容头像"认这是谁灌进来的 ──
const 类 = (e) => {
  const t = 取文(e)
  if (e.type === 'compaction/summary') return 'compaction 摘要（引擎自己写的）'
  if (e.type === 'assistant/message') return '我自己说的话（assistant）'
  if (e.type === 'tool/result') return t.includes('【开工闸门') ? '工具结果＋开工闸门卡' : '工具结果（原文）'
  if (e.type !== 'user/message') return null
  if (t.startsWith('This is an automatically generated checkpoint')) return 'checkpoint 压缩摘要'
  if (t.startsWith('===== 长期记忆')) return '长期记忆注入'
  if (t.startsWith('[meow-memory-dream]')) return 'dream 记忆整理任务'
  if (t.startsWith('<system-reminder>')) {
    if (t.includes('skill catalog')) return '技能目录'
    if (t.includes('workspace instructions')) return '工作区 AGENTS.md'
    return 'AGENTS.md 更新通知'
  }
  if (t.startsWith('Current runtime context')) return '运行时快照（每轮必读行）'
  if (t.startsWith('可能相关的记忆')) return '记忆检索注入'
  if (/^(Background )?[Aa]gent .* (sent a message|finished)/.test(t.slice(0, 200))) return '子代理消息/回执'
  if (t.length > 200) return '老板的长指令（真人输入）'
  return '其他（短消息）'
}

// ── ① 累计注入 ──
const 统 = new Map()
for (const e of 事件) {
  const k = 类(e); if (!k || k.startsWith('compaction 摘要')) continue
  const n = 取文(e).length
  const o = 统.get(k) || { 条: 0, 字: 0, 最长: 0 }
  o.条++; o.字 += n; o.最长 = Math.max(o.最长, n); 统.set(k, o)
}
const 总注入 = [...统.values()].reduce((s, o) => s + o.字, 0)
const 步总 = 事件.filter(e => e.type === 'step/start').length
if (!步总) { console.log('🔴 步数 0 ⇒ 停'); process.exit(2) }

console.log('══ 历史面 v2 · 每轮灌进去的历史（活份模型）══')
console.log('会话 ' + L.会话.slice(0, 22) + ' ｜ ' + (fs.statSync(L.文件).size / 1048576).toFixed(1) + ' MB ｜ 事件 ' + 事件.length + ' ｜ 步 ' + 步总)
console.log('\n── ① 累计注入（一类一共灌了多少字；⚠️累计写入 ≠ 每步存活，见 ②）──')
console.log('  总字/累计   条   均字   最长   这一类')
for (const [k, o] of [...统.entries()].sort((a, b) => b[1].字 - a[1].字)) {
  console.log(String(o.字).padStart(11) + String(o.条).padStart(6) + Math.round(o.字 / o.条).toString().padStart(7) + String(o.最长).padStart(8) + '   ' + k)
}
console.log('  合计 **' + 总注入 + ' 字**累计')

// ── ②③ 活份模型 ──
const 活 = new Map()          // seq → { k, n }
let 活字 = 0
const 样本 = []               // { 活字, 入, 出 }
const 步类 = new Map()        // 类 → { 字, 次 }
const 压明细 = []
const 数中文 = (s) => (s.match(/[\u3400-\u9fff\u3000-\u303f\uff00-\uffef]/g) || []).length
const 加 = (seq, k, n, c) => { if (seq == null) return; 活.set(seq, { k, n, c: c || 0 }); 活字 += n }
const 删 = (seq) => { const o = 活.get(seq); if (o) { 活字 -= o.n; 活.delete(seq) } }
const 按类 = () => { const m = new Map(); for (const o of 活.values()) { const x = m.get(o.k) || { 字: 0, cjk: 0 }; x.字 += o.n; x.cjk += (o.c || 0); m.set(o.k, x) } return m }

for (const e of 事件) {
  const d = e.data || {}
  if (e.type === 'compaction/summary') {
    for (const s of (d.shadowedSeqs || [])) 删(s)
    const u = 用量(d)
    压明细.push({ 阴条: (d.shadowedSeqs || []).length, 阴token: 数(d.shadowedTokenCount), 入: u ? 数(u.inputTokens) : 0, 出: u ? 数(u.outputTokens) : 0 })
    continue
  }
  if (e.type === 'compaction/prune') { for (const s of (d.shadowedSeqs || [])) 删(s); continue }
  if (e.type === 'user/message' || e.type === 'tool/result') {
    const k = 类(e); if (k) { const t = 取文(e); 加(e.seq, k, t.length, 数中文(t)) }
    continue
  }
  if (e.type === 'assistant/message') {
    const u = 用量(d)
    if (u) {
      样本.push({ 活字, 入: 数(u.inputTokens) + 数(u.cacheReadTokens), 出: 数(u.outputTokens) })
      for (const [k, v] of 按类()) { const o = 步类.get(k) || { 字: 0, cjk: 0, 次: 0 }; o.字 += v.字; o.cjk += v.cjk; o.次++; 步类.set(k, o) }
    }
    { const t = 取文(e); 加(e.seq, '我自己说的话（assistant）', t.length, 数中文(t)) }
  }
}
if (!样本.length) { console.log('🔴 一条 usage 都没读到 ⇒ 标定做不了，停（不许拿"估法"顶）'); process.exit(2) }

const 样本数 = 样本.length
const 活均 = 样本.reduce((s, x) => s + x.活字, 0) / 样本数
console.log('\n── ② 占比：平均每步存活（' + 样本数 + ' 步样本 · 平均 ' + Math.round(活均) + ' 字）──')
console.log('  平均字   占比   平均条   这一类')
// ⚠️ 逐类 token 一律用全窗混合比 0.706（＝回归 β 0.740 扣掉常驻实测后反推）；**不许按中文／ASCII 分块各算各的** ——
// 分块模型（中文 0.50／ASCII 0.24）算出来的总量只有回归值的一半 ⇒ 报文里的 JSON 外壳＋转义把「可见字」放大 ≈2 倍。中文占一列只作事实，不作换算系数。
const 比 = () => 0.706
const 类行 = [...步类.entries()].map(([k, o]) => ({ k, 字: o.字 / 样本数, 条: o.次 / 样本数, 中文占: o.字 ? o.cjk / o.字 : 0 })).sort((a, b) => b.字 - a.字)
const 均字总 = 类行.reduce((s, x) => s + x.字, 0)
console.log('   字/步    占比   token/步  混合比  中文占  条/步  这一类')
for (const x of 类行) console.log(Math.round(x.字).toString().padStart(8) + (x.字 / 均字总 * 100).toFixed(1).padStart(7) + '%' + Math.round(x.字 * 比(x.中文占)).toString().padStart(9) + 比(x.中文占).toFixed(2).padStart(8) + (x.中文占 * 100).toFixed(0).padStart(7) + '%' + x.条.toFixed(1).padStart(8) + '   ' + x.k)
const 混token总 = 类行.reduce((s, x) => s + x.字 * 比(x.中文占), 0)
console.log('  活份合计 ' + Math.round(均字总) + ' 字/步 ⇒ **混合模型 ' + Math.round(混token总) + ' token/步**（回归口径见 ③）｜末态 ' + 活字 + ' 字 ／ ' + 活.size + ' 条')
for (const [k, v] of [...按类().entries()].sort((a, b) => b[1].字 - a[1].字)) console.log('      末态 ' + String(v.字).padStart(8) + ' 字（' + Math.round(v.字 * 比()) + ' token）  ' + k)

// ── ③ 标定 ──
const xs = 样本.map(x => x.活字), ys = 样本.map(x => x.入)
const mx = xs.reduce((a, b) => a + b, 0) / 样本数, my = ys.reduce((a, b) => a + b, 0) / 样本数
let sxy = 0, sxx = 0
for (let i = 0; i < 样本数; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2 }
const β = sxx ? sxy / sxx : 0, α = my - β * mx
let ssres = 0, sstot = 0
for (let i = 0; i < 样本数; i++) { const p = α + β * xs[i]; ssres += (ys[i] - p) ** 2; sstot += (ys[i] - my) ** 2 }
const R2 = sstot ? 1 - ssres / sstot : 0
console.log('\n── ③ 标定（实测 · 引擎自报 usage 对"存活字"最小二乘）──')
console.log('  请求输入 token ≈ **' + Math.round(α) + '** ＋ **' + β.toFixed(3) + ' × 存活字**（R² ' + R2.toFixed(3) + ' · 样本 ' + 样本数 + '）')
console.log('  ⇒ 常驻固定 α ＝ ' + Math.round(α) + ' token/步（系统提示词＋工具定义，**与历史无关**）')
console.log('  ⇒ 1 字 ≈ ' + β.toFixed(3) + ' token；1 token ≈ ' + (β ? (1 / β).toFixed(2) : '?') + ' 字（本窗口径）')
console.log('  ⇒ 中位每步存活 ' + 中位(样本.map(x => x.活字)) + ' 字 ⇒ 历史 ≈ ' + Math.round(β * 中位(样本.map(x => x.活字))) + ' token ＋ 常驻 ' + Math.round(α) + ' ＝ ' + Math.round(α + β * 中位(样本.map(x => x.活字))) + ' token')

// ── ④ 压缩节律 ──
if (压明细.length) {
  const 阴 = 压明细.map(x => x.阴token).filter(x => x)
  const 压入 = 压明细.reduce((s, x) => s + x.入, 0), 压出 = 压明细.reduce((s, x) => s + x.出, 0)
  console.log('\n── ④ 压缩节律 ──')
  console.log('  真写摘要 ' + 压明细.length + ' 次 ／ 步 ' + 步总 + ' ⇒ **' + (步总 / 压明细.length).toFixed(1) + ' 步压一次**')
  console.log('  每刀砍掉（引擎自报 shadowedTokenCount）：中位 ' + 中位(阴) + ' ／ 均 ' + Math.round(阴.reduce((a, b) => a + b, 0) / (阴.length || 1)) + ' token（样本 ' + 阴.length + '/' + 压明细.length + '）')
  console.log('  压缩自己花的：输入 ' + 压入 + ' ＋ 输出 ' + 压出 + ' ＝ **' + (压入 + 压出) + ' token**（' + 压明细.length + ' 次，独立于每步请求）')
  console.log('  ⚠️ 因果别倒读：压缩把旧历史换成短摘要（**砍掉的是旧历史**），它不制造历史 —— 历史是我每步灌进去的（见 ①②）')
}

// ── 自检 ──
const 消息数 = 事件.filter(e => e.type.includes('message')).length
const 未归 = 事件.filter(e => e.type.includes('message') && 类(e) === null).length
const 末 = 样本[样本.length - 1]
console.log('\n── ③b 模型自检（不许只看 R²）──')
console.log('  末样本：存活 ' + 末.活字 + ' 字 ⇒ 预测 ' + Math.round(α + β * 末.活字) + ' token ／ 引擎自报 ' + 末.入 + ' token（差 ' + (末.入 ? ((α + β * 末.活字) / 末.入 * 100 - 100).toFixed(1) : '?') + '%）')
const 增长 = 样本.slice(-40).map((x, i, a) => i ? (x.入 - a[i - 1].入) / Math.max(1, x.活字 - a[i - 1].活字) : null).filter(x => x !== null && isFinite(x) && x > 0)
console.log('  近 40 步边际比（Δtoken/Δ字）中位 ' + (增长.length ? 中位(增长).toFixed(3) : '—') + '（越接近 β 越可信）')

console.log('\n── 自检 ──')
console.log('  ' + (样本数 >= 10 ? '✅' : '⚠️') + ' usage 样本 ' + 样本数 + ' 条（≥10 才算标定可信）')
console.log('  ' + (未归 === 0 ? '✅' : '⚠️') + ' 未归类消息 ' + 未归 + '／' + 消息数 + ' 条（' + (未归 / Math.max(1, 消息数) * 100).toFixed(1) + '%）')
console.log('  ' + (活字 > 0 ? '✅' : '🔴') + ' 末态活份 ' + 活.size + ' 条 ／ ' + 活字 + ' 字（0 ⇒ 模型没跑对，别下结论）')
console.log('  ⚠️ 本仪器只报「灌了多少、带了多少」，**不说该删哪一类**：删＝价值判断，要老板点头；回退＝不改任何东西（只读日志）')

if (出) {
  fs.writeFileSync(出, JSON.stringify({
    算于: new Date().toISOString(), 会话: L.会话, 事件: 事件.length, 步: 步总, usage样本: 样本数,
    标定: { α: Math.round(α), β: Number(β.toFixed(4)), R2: Number(R2.toFixed(4)) },
    平均每步存活字: Math.round(活均), 平均每步token_混合模型: Math.round(类行.reduce((s, x) => s + x.字 * 比(x.中文占), 0)), 按类: 类行.map(x => ({ 类: x.k, 平均字: Math.round(x.字), 平均条: Number(x.条.toFixed(2)), 平均token: Math.round(x.字 * 比(x.中文占)), 中文占: Number(x.中文占.toFixed(2)) })),
    累计注入: [...统.entries()].map(([k, o]) => ({ 类: k, 条: o.条, 字: o.字 })),
    压缩: {
      次: 压明细.length,
      每刀中位token: 中位(压明细.map(x => x.阴token).filter(x => x)),
      压缩自花token: 压明细.reduce((a, x) => a + x.入 + x.出, 0),
    },
  }, null, 1))
  console.log('  （机器可读落盘：' + 出 + '）')
}
