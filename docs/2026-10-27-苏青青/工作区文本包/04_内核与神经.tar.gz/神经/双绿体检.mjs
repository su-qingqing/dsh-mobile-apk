/**
 * 双绿体检 —— 把「双绿反向测试」从条文做成**门**（2026-09-27）
 *
 * 老板九样里的第一样。做法库 #286：**双绿 ≠ 一个绿** ——
 *   ① 阳性对照绿  ② 反着弄坏它，**必须变红且点名**  ③ 特异性 ＋ 干净命令对照。
 *
 * 本器只判**有没有做反向那一半**（粗判，看的是自检里的反证字样），不判"反证写得对不对"。
 * ⚠️ 它自带双绿：正证（真文件里数得出反向）＋ 反证（拿掉反向字样必须报红）。
 *
 * 用法：node 神经/双绿体检.mjs [--全]   自检：node 神经/双绿体检.mjs selftest
 */
import fs from 'node:fs';
import path from 'node:path';

const ROOT = '/storage/emulated/0/3';
const 反证词 = /反证|阴性|反向|必须红|不许|假红|负对照|negative/i;
const 自检词 = /selftest|自检|self-test/;

export function 扫(目录 = path.join(ROOT, '工具')) {
  const 有自检 = [], 有反向 = [], 两样都无 = [];
  const 走 = (d) => {
    let es = [];
    try { es = fs.readdirSync(d, { withFileTypes: true }) } catch { return }
    for (const e of es) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (e.name !== 'node_modules') 走(p); continue }
      if (!e.name.endsWith('.mjs')) continue;
      const rel0 = path.relative(ROOT, p);
      if (/dsh-mobile-apk|node_modules|\/test\/|\/scripts\/|\/dist\/|\/build\/|sabotage|_停用|_双证|_旧|\.bak/.test(rel0)) continue;
      let s = '';
      try { s = fs.readFileSync(p, 'utf8') } catch { continue }
      const rel = path.relative(ROOT, p);
      const 有检 = 自检词.test(s);
      const 有反 = 反证词.test(s);
      if (!有检 && !有反) { 两样都无.push(rel); continue }
      if (有检) 有自检.push(rel);
      if (有反) 有反向.push(rel);
      // 有自检但一句反证都没有 ⇒ 红（这正是"单绿"）
      if (有检 && !有反) 两样都无.push(rel + '  ← 有自检但**没有一句反证**（单绿）');
    }
  };
  走(目录);
  return { 有自检, 有反向, 单绿: 两样都无 };
}

function 主() {
  const { 有自检, 有反向, 单绿 } = 扫();
  const 真单绿 = 单绿.filter((x) => x.includes('←'));
  console.log('双绿体检 ｜ 扫 ' + path.join(ROOT, '工具'));
  console.log('  有自检   ' + String(有自检.length).padStart(3) + ' 个');
  console.log('  有反证   ' + String(有反向.length).padStart(3) + ' 个');
  console.log('  ❌ 单绿   ' + String(真单绿.length).padStart(3) + ' 个  ← 有自检、却一句反证都没有');
  for (const x of 真单绿.slice(0, 12)) console.log('        ' + x);
  if (真单绿.length > 12) console.log('        …还有 ' + (真单绿.length - 12) + ' 个');
  console.log('\n  ⚠️ 粗判：看的是自检里**有没有反证字样**，不判"反证写得对不对"。');
  process.exit(真单绿.length ? 1 : 0);
}

if (process.argv[2] === 'selftest') {
  const T = [];
  const ok = (n, c, 注 = '') => T.push([n, !!c, 注]);
  // 正证：真盘上数得出东西（不是空跑）
  const r = 扫();
  ok('正证：真有带自检的工具', r.有自检.length > 0, '有自检 ' + r.有自检.length);
  ok('正证：真有带反证的工具', r.有反向.length > 0, '有反证 ' + r.有反向.length);
  ok('正证：本器自己算一个（它自己就有反证字样）', r.有反向.some((x) => x.includes('双绿体检')));
  // 反证：造一个"有自检、没一句反证"的假文件 ⇒ 必须点名报红
  const 假夹 = '/data/data/com.dsharnessmobile.shell/files/home/tmp/双绿假-' + process.pid;
  fs.mkdirSync(假夹, { recursive: true });
  fs.writeFileSync(假夹 + '/单绿样本.mjs', "if(process.argv[2]==='selftest'){console.log('ok')}\n");
  const r2 = 扫(假夹);
  ok('反证：有自检无反证 ⇒ 被点名为单绿', r2.单绿.some((x) => x.includes('单绿样本')));
  fs.rmSync(假夹, { recursive: true, force: true });
  // 阴性：空目录 ⇒ 一条都不报（不许瞎报）
  const 空夹 = '/data/data/com.dsharnessmobile.shell/files/home/tmp/双绿空-' + process.pid;
  fs.mkdirSync(空夹, { recursive: true });
  ok('阴性：空目录 ⇒ 零条（不许瞎报）', 扫(空夹).单绿.length === 0);
  fs.rmSync(空夹, { recursive: true, force: true });
  let 过 = 0;
  for (const [n, c, 注] of T) { console.log((c ? '  ✅ ' : '  ❌ ') + n + (注 ? '  ← ' + 注 : '')); if (c) 过++ }
  console.log('\n' + (过 === T.length ? '✅ 双绿体检 自检通过 ' + 过 + '/' + T.length : '❌ ' + 过 + '/' + T.length));
  process.exit(过 === T.length ? 0 : 1);
}
主();
