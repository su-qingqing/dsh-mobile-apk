// 神经/口吻门.mjs —— 行为语义门（老板 1021「星星的用法跟以前不一样」· 外核 Q2）
// 判据不写死在代码里：一律读 `内核/口吻合约.json`（改合约＝改判据，不用改脚本）。
// 用法：
//   node 神经/口吻门.mjs 判 "<文本>"      判一段文本（换行分段）
//   node 神经/口吻门.mjs 自测              正反双证（好的过、坏的不过）
//   node 神经/口吻门.mjs 合约              印合约摘要
import fs from 'node:fs';
import path from 'node:path';

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3';
const 合约档 = () => path.join(WS, '内核/口吻合约.json');

export function 读合约() {
  try { return JSON.parse(fs.readFileSync(合约档(), 'utf8')) } catch { return null }
}

/** 判一段文本（换行分段）。返回 { pass, violations, 读数 } */
export function 判(文本, 合约) {
  const c = 合约 || 读合约();
  if (!c) return { pass: false, violations: ['合约读不出：内核/口吻合约.json'], 读数: null };
  const 行 = String(文本 || '').split('\n').map((s) => s.trim()).filter(Boolean);
  const 段数 = 行.length;
  if (!段数) return { pass: true, violations: [], 读数: { 段数: 0 } };

  const 星数 = 行.reduce((a, s) => a + (s.match(/★/g) || []).length, 0);
  const 带星 = 行.filter((s) => /★/.test(s)).length;
  const 五星段 = 行.filter((s) => (s.match(/★/g) || []).length >= 5).length;
  const 句首星 = 行.filter((s) => /^[★＊*]/.test(s)).length;
  const 读数 = {
    段数,
    带星率: (100 * 带星) / 段数,
    均星: 星数 / 段数,
    五星段率: (100 * 五星段) / 段数,
    句首星段: 句首星,
  };

  const v = [];
  const [低, 高] = c.star.healthy.带星率;
  const [均低, 均高] = c.star.healthy.均星;
  const [, 五高] = c.star.healthy.五星段率;
  if (读数.带星率 < 低) v.push(`STAR_MISSING：带星率 ${读数.带星率.toFixed(0)}% < ${低}%（★ 没被用）`);
  if (读数.带星率 > 高) v.push(`STAR_INFLATION：带星率 ${读数.带星率.toFixed(0)}% > ${高}%（★ 变断句符号）`);
  if (读数.均星 > 均高) v.push(`STAR_INFLATION：均 ${读数.均星.toFixed(2)} 颗/段 > ${均高}`);
  if (读数.五星段率 > 五高) v.push(`STAR_INFLATION：5+ 颗段 ${读数.五星段率.toFixed(0)}% > ${五高}%`);
  // 句首★：老窗里行首 `// ★ 2026-09-18 实测` 是正常的（一篇里偶发一颗）⇒ 只在**高密度**时才判"当项目符号"
  if (读数.句首星段 / 段数 > 0.3) v.push(`STAR_AS_BULLET：${读数.句首星段}/${段数} 段把 ★ 当项目符号（>30%）`);

  const 文 = String(文本 || '');
  for (const p of c.tone.ban_phrases) if (文.includes(p)) v.push(`TONE_BAN：出现禁用语气「${p}」`);
  for (const p of c.address.deny) if (文.includes(p)) v.push(`ADDR_DENY：出现禁用称呼「${p}」`);

  return { pass: v.length === 0, violations: v, 读数 };
}

// ── CLI ──
const 是直接跑 = /口吻门\.mjs$/.test(process.argv[1] || '');
if (是直接跑) {
  const [cmd, ...rest] = process.argv.slice(2);
  if (cmd === '合约') {
    const c = 读合约();
    console.log(c ? JSON.stringify({ id: c.id, 健康: c.star.healthy, 红: c.star.红, 禁: c.star.禁 }, null, 1) : '合约读不出');
  } else if (cmd === '判') {
    const r = 判(rest.join(' '));
    console.log(JSON.stringify(r, null, 1));
    process.exit(r.pass ? 0 : 1);
  } else if (cmd === '自测') {
    const 例 = [
      ['正证·老窗 17% 带星 0.39 颗', '★ 2026-09-18 实测：帧率从 60 掉到 16\n正常一行没有星\n又一行没有星\n' + Array(3).fill('普通一行').join('\n'), true],
      ['反证·新窗 65% 带星 4.8 颗', Array(10).fill('★ 写文件。★★ 然后跑。★ 好。★★★ 快。★ 报告。').join('\n'), false],
      ['反证·一颗不打（缺失）', Array(10).fill('普通一行没有星').join('\n'), false],
      ['反证·句首当项目符号', '★ 第一\n★ 第二\n★ 第三\n普通\n普通', false],
      ['反证·禁用称呼', '★ 风险在这儿\n亲，你看一下', false],
    ];
    let 过 = 0;
    console.log('══ 口吻门 · 自测（正反双证）══');
    for (const [名, 文, 该过] of 例) {
      const r = 判(文);
      const ok = r.pass === 该过;
      if (ok) 过++;
      console.log(`  ${ok ? '✅' : '❌'} ${名} ⇒ ${r.pass ? '过' : '不过'}（该${该过 ? '过' : '不过'}）｜ ${r.violations.join('; ') || '无'}`);
    }
    console.log(过 === 例.length ? `\n✅ 自测全绿（${过}/${例.length}）` : `\n❌ 有红（${过}/${例.length}）`);
    process.exit(过 === 例.length ? 0 : 1);
  } else {
    console.log('用法：判 "<文本>" ｜ 自测 ｜ 合约');
  }
}
