// 「工具回程闸」· 输出侧收窄 · 2026-09-22（0922 架构迭代包 B3）
// 要解决：**工具吐出来的东西无差别进上下文**（本窗 109 次调用 0.29MB，大输出直接灌进上下文）。
// 老板诊断的对称关系：**输入靠路由收窄（B1）／输出靠回程收窄（B3）** —— 同一处的两端。
//
// 三条纪律：
//   ① 大输出（> limit，默认 4000 字符）⇒ **落盘**，上下文里只留一句「在哪、多大、怎么看」
//   ② 小输出**不许**落盘（多一道转手＝多一次取件成本；反证用例守着它）
//   ③ fail-open：落盘失败 ⇒ **原样返回**（绝不吞内容 —— 宁可灌进来，也不许凭空少东西）
//
// 只落「工具自己吐的那几个零件」（按引用相等识别 `原封`）⇒ **插件追加的简报/检索/状态行原样保留**。
import fs from 'node:fs'
import path from 'node:path'

export const 上限默认 = 4000
// ★ 五修（外部核 qwen3.8-max 红队 Q2/Q3 采纳）：把"没落盘"的成因做成**枚举**，不要留给调用方去猜字符串。
//   红队点名的五类：认领失败／未超线／无目录／回读不一致／异常 —— 原来最后一类在调用方那儿掉回"回没说话"黑洞。
//   「该报警」 也**在这里算完**（判断权归唯一知情方）⇒ 调用方那边不许再自己拼一把尺子（这次的假警报就是两把尺子打架）。
export const 码 = { 落盘: '落盘', 空: '空', 无可落: '无可落', 认领失败: '认领失败', 未超线: '未超线',
  无目录: '无目录', PROC: 'proc', 回读不一致: '回读不一致', 异常: '异常' }
const 指针头 = '〔回程·大输出落盘〕'

export function 指针(文件, 字符) {
  return 指针头 + '在哪=' + 文件 + ' ｜ 多大=' + 字符 + ' 字符' +
    ' ｜ 怎么看=`read ' + 文件 + '`（要末段用 `tail -c 3000 ' + 文件 + '`）' +
    ' ｜ ⚠️ 内容没丢，只在盘上 —— 别凭"没看见"下结论'
}

// ★ 2026-09-22 五修（**假警报**）：真机日志里 34 条 `SPILL-SKIP 估=18094 原因=回没说话` **全是假警** ——
//   报警那把尺子量的是 `r.content` 全长，而它**含插件自己追加的 ≈18K 开工简报**；扣掉简报后工具本身只有
//   4~169 字，本来就该原样返回。全量日志：成功落盘 **1** 次、报警 **34** 次，34 条逐条对得上"估 − 简报字数
//   = 4~169"。后果：这条哨兵**只在插件自己加了东西时才响**，真正的"该拦没拦"反而看不见，上一轮据此把
//   "闸坏了"写成交接单的下一轮第一件事 —— 白查一轮。
//   两条修法都落在本函数里：
//   ① 把「哪些零件是我有权落的」算完就**当场下结论**，结论（`该落件数/总件数/总字/认领失败`）回给调用方，
//      **调用方不许再自己另算一把尺子**（这次就是两把尺子打架）；
//   ② **每一支"没落盘"都必须给 `原因`** —— 报错要能自证报错在哪一步。原来那一支没有 `原因` ⇒ 日志写
//      "回没说话"，把"行为正确"和"认领失败"糊成同一句话。
export function 回({ parts = [], 原封 = null, sid = 'unknown', limit = 上限默认, dir = '' } = {}) {
  try {
    // ★ 2026-09-22 二修（B3 现场实测：5600 字符原样回来了）：**有些工具吐的是纯字符串**，
    //   原来这里只认 Array.isArray ⇒ 字符串进来当场变成空数组 ⇒ 静默不落盘（闸像是装上了、其实一次都没拦过）。
    const arr = Array.isArray(parts) ? parts
      : (typeof parts === 'string' && parts.length ? [{ type: 'text', text: parts }] : [])
    const mine = Array.isArray(原封) && 原封.length ? new Set(原封) : null
    // 「可落」＝零件里有文本、且不是我自己已经写好的指针
    const 可落 = arr.filter(p => p && typeof p.text === 'string' && p.text.indexOf(指针头) < 0)
    // 「该落」＝可落里**我认得出是我的**那部分（认领靠引用相等；认不出＝不许动它）
    const 该落 = 可落.filter(p => !mine || mine.has(p))
    const 字符 = 该落.reduce((n, p) => n + p.text.length, 0)
    const 总字 = 可落.reduce((n, p) => n + p.text.length, 0)
    const 底 = { 该落件数: 该落.length, 可落件数: 可落.length, 总件数: arr.length, 字符, 总字 }
    const 没落 = (码名, 原因) => Object.assign(
      { parts: arr, 落盘: false, 码: 码名, 认领失败: 码名 === 码.认领失败,
        该报警: 码名 !== 码.空 && 码名 !== 码.无可落 && 码名 !== 码.未超线, 原因 }, 底)
    if (!arr.length) return 没落(码.空, '没有零件（空）')
    if (!可落.length) return 没落(码.无可落, '零件里没有可落的文本（可能都已是指针）')
    if (!该落.length) return 没落(码.认领失败, '认领失败：' + 可落.length +
      ' 个可落零件一个都不认识（零件被复制过 ⇒ 引用不相等）')
    if (字符 <= limit) return 没落(码.未超线, '该落 ' + 字符 + ' 字 ≤ 上限 ' + limit + '，本来就不该落（行为正确）')
    const 正文 = 该落.map(p => p.text).join('\n')
    if (!dir) return 没落(码.无目录, '没有落盘目录')
    // ⚠️ 保险：`/proc` 下建目录在本机会**永久挂起**（2026-09-22 实测）⇒ 绝不往那儿写
    if (/^\/proc(\/|$)/.test(String(dir))) return 没落(码.PROC, '落盘目录在 /proc（会挂起），拒绝')
    fs.mkdirSync(dir, { recursive: true })
    const 文件 = path.join(dir, '回程-' + String(sid).replace(/^session-/, '').slice(0, 8) + '-' +
      new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14) + '-' + Math.random().toString(36).slice(2, 6) + '.txt')
    fs.writeFileSync(文件, 正文, 'utf8')
    const 回读 = fs.readFileSync(文件, 'utf8')
    if (回读 !== 正文) return 没落(码.回读不一致, '回读不一致（不敢替换）')
    const 其余 = arr.filter(p => !该落.includes(p))
    return Object.assign(
      { parts: [{ type: 'text', text: 指针(文件, 字符) }].concat(其余), 落盘: true, 文件,
        码: 码.落盘, 认领失败: false, 该报警: false }, 底)
  } catch (e) {
    return {
      parts: Array.isArray(parts) ? parts : [], 落盘: false, 码: 码.异常, 认领失败: false, 该报警: true,
      字符: 0, 总字: 0, 该落件数: 0, 可落件数: 0, 总件数: 0, 原因: '抛异常：' + String((e && e.message) || e),
    }
  }
}

export function 速览() {
  const dir = (process.env.DSH_HOME || '') + '/tmp'
  let 件 = []
  try { 件 = fs.readdirSync(dir).filter(f => f.startsWith('回程-')) } catch (e) { 件 = [] }
  return '落盘目录 ' + dir + ' ｜ 现存回程件 ' + 件.length + ' 个'
}

const cases = []
function 测(名, 条件, 实际) { cases.push([名, !!条件, 实际]) }

import os from 'node:os'
void os
const 临时 = (process.env.DSH_HOME || '') + '/tmp/selftest-回程'
const 大 = 'x'.repeat(5000), 小 = 'y'.repeat(300)
{
  const r = 回({ parts: [{ type: 'text', text: 大 }], sid: 'session-test', dir: 临时 })
  let 回读 = ''
  try { 回读 = fs.readFileSync(r.文件, 'utf8') } catch (e) { 回读 = '' }
  测('大输出（5000 字符）⇒ 落盘，且盘上能读回原文', r.落盘 === true && 回读 === 大, r.落盘 + '/' + 回读.length)
  测('指针里能看出「在哪、多大、怎么看」', r.落盘 && r.parts[0].text.indexOf(r.文件) > 0 &&
    r.parts[0].text.indexOf('5000 字符') > 0 && r.parts[0].text.indexOf('read ') > 0, (r.parts[0] || {}).text)
  测('原来那一坨 5000 字符不再出现在返回值里', r.落盘 && JSON.stringify(r.parts).length < 600, JSON.stringify(r.parts).length)
}
{
  const 原 = [{ type: 'text', text: 小 }]
  const r = 回({ parts: 原, sid: 'session-test', dir: 临时 })
  测('**反证**：小输出（300 字符）⇒ 不许落盘，且零件一字不改', r.落盘 === false && r.parts === 原, r.落盘)
}
{
  const r = 回({ parts: [{ type: 'text', text: 'z'.repeat(4001) }], sid: 'session-test', dir: 临时 })
  // ★ 2026-09-22 补：字符串形态（B3 现场的真形态候选）也要能落盘 —— 这条就是那次"没拦住"的反证用例
  const rs = 回({ parts: 'q'.repeat(4100), sid: 'session-test', dir: 临时 })
  测('**字符串形态**（工具直接吐字符串）⇒ 同样落盘', rs.落盘 === true && rs.字符 === 4100, rs.落盘 + '/' + rs.字符)
  const r2 = 回({ parts: [{ type: 'text', text: 'z'.repeat(4000) }], sid: 'session-test', dir: 临时 })
  测('边界：4001 字符 ⇒ 落；4000 字符 ⇒ 不落', r.落盘 === true && r2.落盘 === false, r.落盘 + '/' + r2.落盘)
}
{
  const 工具件 = { type: 'text', text: 'q'.repeat(6000) }, 我加的 = { type: 'text', text: '【开工闸门·开工简报】…' }
  const r = 回({ parts: [工具件, 我加的], 原封: [工具件], sid: 'session-test', dir: 临时 })
  测('只落工具那一坨，插件自己追加的行原样保留', r.落盘 === true &&
    r.parts.some(p => p && p.text === 我加的.text) && r.parts.length === 2, r.parts.length)
}
{
  // ⚠️ 2026-09-22 踩坑：这里原来写 `/proc/self/nope` —— **在 Android 上对 /proc 下建目录会永久挂起**
  //   （不抛错、不返回 ⇒ 整个模块体挂死，自测一个字都印不出来）。改用一个**立刻抛 ENOTDIR** 的路径。
  const r = 回({ parts: [{ type: 'text', text: 'w'.repeat(6000) }], sid: 'session-test', dir: '/etc/hosts/x' })
  测('fail-open：落盘目录不可写 ⇒ 原样返回（不吞内容）', r.落盘 === false && r.parts[0].text.length === 6000, r.原因)
}
{
  const 已指针 = { type: 'text', text: 指针头 + '在哪=/x/y ｜ 多大=9000 字符' }
  const r = 回({ parts: [已指针], sid: 'session-test', dir: 临时 })
  测('已经是指针 ⇒ 不重复落盘', r.落盘 === false, r.落盘)
}
// ★ 2026-09-22 五修新增两条：这两条守的正是"假警报"那个坑
{
  const 工具件 = { type: 'text', text: 'z'.repeat(169) }
  const 简报 = { type: 'text', text: '【开工闸门·开工简报】' + 'h'.repeat(18088) }   // 正文长 11＋18088＝18099
  const r = 回({ parts: [工具件, 简报], 原封: [工具件], sid: 'session-test', dir: 临时 })
  测('**反证（假警报的真身）**：工具本身 169 字 ＋ 我加的简报 18099 字 ⇒ 不落盘、**不许报警**，且尺子量的是「该落 169」不是全长',
    r.落盘 === false && r.该报警 === false && r.码 === 码.未超线 && r.字符 === 169 &&
    r.总字 === 169 + 简报.text.length && r.认领失败 === false,
    '落=' + r.落盘 + ' 该报警=' + r.该报警 + ' 码=' + r.码 + ' 该落=' + r.字符 + ' 总=' + r.总字)
}
{
  const 真件 = { type: 'text', text: 'v'.repeat(6000) }
  const 复制件 = { type: 'text', text: 'v'.repeat(6000) }   // 内容一模一样、**引用不同**（引擎复制过零件的模拟）
  const r = 回({ parts: [复制件], 原封: [真件], sid: 'session-test', dir: 临时 })
  测('**反证（真信号）**：可落零件一个都不认识 ⇒ **必须报警**（红队 Q1 点名的真黑洞），且仍原样返回（fail-open 不许破）',
    r.落盘 === false && r.该报警 === true && r.码 === 码.认领失败 && r.认领失败 === true &&
    r.字符 === 0 && r.parts[0].text.length === 6000, r.码 + '／' + r.原因)
}
{
  // dir 给个数字 ⇒ 走到 mkdirSync 时抛 TypeError（不能给空零件，那样会先被「空」那一支早退掉）
  const r = 回({ parts: [{ type: 'text', text: 'e'.repeat(6000) }], sid: 'session-test', dir: 1 })
  测('**反证（红队 Q2 的第五类）**：内部抛异常 ⇒ 也要有码有原因（不再掉回"回没说话"黑洞）且原样返回',
    r.落盘 === false && r.该报警 === true && r.码 === 码.异常 && typeof r.原因 === 'string' &&
    r.原因.indexOf('抛异常') === 0 && r.parts[0].text.length === 6000, r.码 + '／' + r.原因)
}
const 红 = cases.filter(c => !c[1])
for (const [n, ok, 实] of cases) console.log((ok ? '✅ ' : '❌ ') + n + (ok ? '' : '　（实测：' + 实 + '）'))
console.log('\n回程闸 selftest ' + (cases.length - 红.length) + '/' + cases.length + (红.length ? '　**有红，先修**' : ' 全过'))
if (process.argv[1] && /\u56de\u7a0b\.mjs$/.test(process.argv[1])) {
  if (process.argv.includes('selftest')) process.exit(红.length ? 1 : 0)
  console.log(速览())
}
