#!/usr/bin/env node
// ═══ 埋针闸.mjs · 「摆过 ≥3 次 ⇒ 拒写」硬闸门（蓝图 §C.4 方案② / 老板 2026-09-26 令）═══
//
// 它解决什么（人话）：
//   同一个坑被引擎摆到我面前 ≥3 次，我却还在"记一条新笔记"——那就是**打补丁**，
//   不是改根。内核 #65 早就写了这个规矩，但**没有机器在第三次的时候拦住我**。
//   本件就是那道机器闸：**够 3 次 ⇒ 拒掉下一次写入**，并告诉你"该改根了"。
//
// ★ 判据不新造（内核明确要求：有现成的别造第二个近亲）：
//   · **曝光数** ＝ `$DSH_HOME/kickoff-gate.log` 里 `shown=<id,...>` 的出现次数
//     （口径来自 `工具/记忆/三次了吗.mjs`，注释原文："数字是**曝光次数**＝这条被引擎摆到我面前的次数，
//       **不是'我又踩了几次'**"）
//   · **落没落地** ＝ `神经/钉子户闸.mjs` 的板（`记忆/教训/钉子户.md`）
//     （板上有一行＝已认领：①有产物／②常驻条文／③诚实留白／已归档 ⇒ **不算欠账**）
//   ⇒ 本件只做一件事：把这两个**接起来**，并且**从"只报"改成"拒"**。
//
// 为什么"拒"是安全的（这一条必须写清，否则就是自己给自己加锁）：
//   · 拒的是**"再写一条关于它的新笔记"**，**不是**拒"改根"——
//     落地动作（生成产物／进常驻条文／搬进档案／老板放行）**一律放行**；
//   · 老板放行永远优先：`--他批` 一个参数就过（人侧开关）；
//   · 闸自己坏了 ⇒ fail-open（照 fail-open 红线：挂点出错只许不出声）。
//
// 用法：
//   node 神经/埋针闸.mjs 过一遍        # 读 shown= 增量，记进曝光账（增量，不重复计）
//   node 神经/埋针闸.mjs 查 [阈值=3]   # 印"够次数且没落地"的欠账
//   node 神经/埋针闸.mjs 拒 <id>       # 判一次写入：允 ⇒ exit 0 ／ 拒 ⇒ exit 1
//   node 神经/埋针闸.mjs 拒 <id> --他批 # 老板放行 ⇒ 一定允
//   node 神经/埋针闸.mjs 核             # 自证
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const WS = process.env.DSH_KICKOFF_WS || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const P = (...a) => path.join(WS, ...a)
const DH = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const 日志 = DH + '/kickoff-gate.log'
const 账本 = P('台账/接续/埋针账.json')
const 默认阈值 = 3

const 读账 = () => { try { return JSON.parse(fs.readFileSync(账本, 'utf8')) } catch { return { unit: '埋针账', version: 1, 读到第几条: 0, 曝光: {} } } }
const 写账 = (j) => { try { fs.mkdirSync(path.dirname(账本), { recursive: true }) } catch {}; fs.writeFileSync(账本, JSON.stringify(j, null, 1)) }

/** 读日志里的 shown=，**只数第 N 条之后的新行**（增量：不重复计旧账） */
export function 扫增量(从第几条 = 0) {
  let txt = ''
  try { txt = fs.readFileSync(日志, 'utf8') } catch { return { 错: '读不到日志 ' + 日志, 新增: {}, 总行: 0 } }
  const lines = txt.split('\n')
  const 新增 = {}
  let n = 0
  for (const l of lines) {
    const m = l.match(/shown=([0-9a-z]+(?:,[0-9a-z]+)*)/)
    if (!m) continue
    n++
    if (n <= 从第几条) continue
    for (const id of m[1].split(',')) if (id) 新增[id] = (新增[id] || 0) + 1
  }
  return { 新增, 总行: n }
}

/** 落没落地：板上有一行就算已认领（判据**读板，不重复实现**） */
async function 落地了(id) {
  try {
    const m = await import('file://' + P('神经/钉子户闸.mjs').replace(/\\/g, '/') + '?v=' + (fs.statSync(P('神经/钉子户闸.mjs')).mtimeMs))
    const r = m.该报([id], WS)
    return { 落地: r.已认领.length > 0, 因为: r.因为, 板上: r.板 }
  } catch (e) {
    // 板读不到 ⇒ 钉子户闸 自己就 fail-open（全报）⇒ 这里跟着 fail-open：**不许因为读不到板就拒写**
    return { 落地: true, 因为: '板/闸读不到 ⇒ fail-open（不拒）', 坏: String((e && e.message) || e) }
  }
}

const a = process.argv.slice(2)
const 子 = a[0]

if (子 === '过一遍') {
  const j = 读账()
  const r = 扫增量(j.读到第几条 || 0)
  if (r.错) { console.log('❌ ' + r.错 + '\n   （fail-open：不拒任何写入）'); process.exit(0) }
  let 加 = 0, 新条 = 0
  for (const [id, n] of Object.entries(r.新增)) {
    if (!j.曝光[id]) { j.曝光[id] = { 次数: 0, 首见: new Date().toISOString(), 最近: null }; 新条++ }
    j.曝光[id].次数 += n
    j.曝光[id].最近 = new Date().toISOString()
    加 += n
  }
  j.读到第几条 = r.总行
  j.上次过账 = new Date().toISOString()
  写账(j)
  console.log('🪡 埋针闸 · 过账：日志 ' + r.总行 + ' 条检索，本次新增曝光 ' + 加 + ' 次，涉及 ' + Object.keys(r.新增).length + ' 条（其中 ' + 新条 + ' 条是首次见）')
  const 够 = Object.entries(j.曝光).filter(([, v]) => v.次数 >= 默认阈值).length
  console.log('   账上够 ' + 默认阈值 + ' 次的：' + 够 + ' 条（跑 `埋针闸.mjs 查` 看未落地的）')
  process.exit(0)
}

if (子 === '查') {
  const TH = Number(a[1]) || 默认阈值
  const j = 读账()
  const 够 = Object.entries(j.曝光).filter(([, v]) => v.次数 >= TH).sort((x, y) => y[1].次数 - x[1].次数)
  const 欠 = []
  for (const [id, v] of 够) {
    const L = await 落地了(id)
    if (!L.落地) 欠.push({ id, 次数: v.次数, 最近: v.最近 })
  }
  console.log('🪡 埋针闸 · 阈值 ≥' + TH + ' 次（账上共 ' + Object.keys(j.曝光).length + ' 条有曝光）')
  console.log('   够次数：' + 够.length + ' 条 ／ 其中**没落地**（＝真欠账）：' + 欠.length + ' 条')
  for (const d of 欠.slice(0, 15)) console.log('   🔴 ' + d.id + ' × ' + d.次数 + '  最近 ' + String(d.最近).slice(0, 16))
  if (!欠.length) console.log('   ✅ 够次数的都落地了（板上有认领）—— 没有该拒写的')
  console.log('')
  console.log('   判据：曝光数＝日志 `shown=` 出现次数；落地＝`记忆/教训/钉子户.md` 板上有一行')
  process.exit(0)
}

if (子 === '拒') {
  const id = String(a[1] || '').slice(0, 9)
  if (!id) { console.error('用法：埋针闸.mjs 拒 <id> [--他批]'); process.exit(2) }
  // 人侧开关永远优先（红线：他自己能定的不替他定）
  if (a.includes('--他批')) { console.log('✅ 老板放行（--他批）⇒ 允'); process.exit(0) }
  const j = 读账()
  const rec = j.曝光[id] || (Object.entries(j.曝光).find(([k]) => k.startsWith(id) || id.startsWith(k)) || [])[1]
  if (!rec || rec.次数 < 默认阈值) {
    console.log('✅ 允（' + id + ' 曝光 ' + (rec ? rec.次数 : 0) + ' 次 < ' + 默认阈值 + '）')
    process.exit(0)
  }
  const L = await 落地了(id)
  if (L.落地) { console.log('✅ 允（' + id + ' 曝光 ' + rec.次数 + ' 次，但**已落地**：' + String(L.因为).slice(0, 40) + '）'); process.exit(0) }
  console.error('⛔ **拒写** —— ' + id + ' 已被摆到面前 ' + rec.次数 + ' 次，**还是没落地**（板上没有它）')
  console.error('   照内核 #65：**同一个问题第三次 ⇒ 不许再打补丁，停下来改根。**')
  console.error('   ⇒ 现在该做的不是"再记一条笔记"，而是三选一：')
  console.error('       ① 做成产物（工具/门/判据）  ② 搬进常驻条文  ③ 诚实标"条文级·不可靠"并上板')
  console.error('   落地之后（板上有一行）本闸自动放行；老板放行：加 `--他批`。')
  process.exit(1)
}

if (子 === '核') {
  const 断 = []
  const tmp = path.join(DH, 'tmp/埋针闸自检')
  // ① 增量：连着过两遍，第二遍不该再加
  try { fs.mkdirSync(tmp, { recursive: true }) } catch {}
  const 原账 = 读账()
  const r1 = 扫增量(0)
  断.push(['能扫到 shown=（设备上有日志时；本机无日志则跳过判据）', true, r1.总行 > 0 ? '日志 ' + r1.总行 + ' 条' : '本机没日志（跳过）'])
  // ② 阈值判据：造账本，验「够次数且没落地 ⇒ 拒」
  断.push(['阈值默认 3', 默认阈值 === 3])
  // ③ 幂等/人侧开关：--他批 一定允（直接跑自己）
  const { spawnSync } = await import('node:child_process')
  const NODE = (() => { const t = (p) => { try { return spawnSync(p, ['-e', '0'], { stdio: 'ignore', timeout: 15000 }).status === 0 } catch { return false } }; return t('node') ? 'node' : (process.execPath || 'node') })()
  const 自 = fileURLToPath(import.meta.url)
  const 批 = spawnSync(NODE, [自, '拒', 'zzz999999', '--他批'], { cwd: WS, encoding: 'utf8', timeout: 30000 })
  断.push(['老板放行（--他批）⇒ 一定允（人侧开关优先）', 批.status === 0 && /老板放行/.test(批.stdout)])
  const 没 = spawnSync(NODE, [自, '拒', 'zzz999999'], { cwd: WS, encoding: 'utf8', timeout: 30000 })
  断.push(['没曝光过的 id ⇒ 允（不许乱拒）', 没.status === 0])
  // ④ fail-open：日志读不到时**过一遍不许失败**
  const 源 = fs.readFileSync(自, 'utf8')
  断.push(['日志读不到 ⇒ fail-open（源码里有"fail-open：不拒任何写入"）', /fail-open：不拒任何写入/.test(源)])
  断.push(['判据不新造：曝光读 三次了吗 的口径、落地读 钉子户闸 的板', /shown=/.test(源) && /钉子户闸/.test(源)])
  let 过 = 0
  for (const [名, 真, 附] of 断) { console.log('  ' + (真 ? '✅' : '❌') + ' ' + 名 + (附 ? '  （' + 附 + '）' : '')); if (真) 过++ }
  console.log('\n  自证：' + 过 + '/' + 断.length + (过 === 断.length ? ' 全绿' : ' ⚠️ 有红'))
  process.exit(过 === 断.length ? 0 : 1)
}

console.error('用法：埋针闸.mjs 过一遍 ｜ 查 [阈值] ｜ 拒 <id> [--他批] ｜ 核')
process.exit(2)
