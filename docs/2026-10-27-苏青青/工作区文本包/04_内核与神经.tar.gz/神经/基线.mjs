#!/usr/bin/env node
/**
 * 重算内核的内容指纹基线（内核 #36 的落地件）。
 *
 * 用法：node /storage/emulated/0/3/神经/基线.mjs
 * 时机：**改完 内核.md / 内核详解/详解.md / 变更日志.md 之后**跑一次。
 *
 * ★ 口径（2026-09-17 用户拍板收窄）：
 *   hashCore   —— 内核正文三件。**不一致 = 面板红字告警**（只有按 #42 流程才会变，变了必是有事）。
 *   hashLedger —— 台账单独一份。只表明"基线之后又写过"，**不告警**（它是我几乎每轮都在写的活文件）。
 *   hash       —— 旧的"四件合一"口径，留着只为过渡期兼容（还没重启的老面板按它比，避免误报）。
 *
 * 算法必须与 @dsh-user/dsh-kernel-panel/lib/index.js 里的 djb2 逐字一致：
 *   digest = ['kernel:'+…, 'detail:'+…, 'log:'+…, 'ledger:'+…].join('\n')
 *   hash   = djb2（h=5381; h=((h*33)^charCodeAt(i))>>>0）
 */
import { readFileSync, writeFileSync } from 'node:fs'

const KERNEL = '/storage/emulated/0/3/内核'
const OUT = KERNEL + '/指纹基线.json'
const CORE = [
  ['kernel', KERNEL + '/内核.md'],
  ['detail', KERNEL + '/内核详解/详解.md'],
  ['log', KERNEL + '/变更日志.md'],
]
const LEDGER = ['ledger', '/storage/emulated/0/3/台账/在办.md']

const djb2 = (s) => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(16) }
const read = (p) => { try { return readFileSync(p, 'utf8') } catch { return null } }
const part = (pair) => { const t = read(pair[1]); return (typeof t === 'string' && t !== '') ? pair[0] + ':' + t : null }

const coreParts = CORE.map(part).filter(Boolean)
const ledgerPart = part(LEDGER)
const hashCore = djb2(coreParts.join('\n'))
const hashLedger = djb2(ledgerPart === null ? '' : ledgerPart)
const hash = djb2(coreParts.concat(ledgerPart === null ? [] : [ledgerPart]).join('\n'))

let rules = 0
// ★ 2026-09-20（段 2 · 法条层）：**入法标注计数** —— 每次重记指纹都把它显出来，
//   别再靠我想起来去数。标注写法：**（入法理由①重复踩的坑 ／② 老板亲定的红线）**。
let annotated = 0
{
  const t = read(CORE[0][1]) || ''
  for (const ln of t.split('\n')) if (/^\d+\.\s/.test(ln)) rules++
  annotated = (t.match(/入法理由/g) || []).length
}
let ledgerRows = 0
if (ledgerPart !== null) {
  const i = ledgerPart.indexOf('## 进行中')
  const seg = i < 0 ? ledgerPart : ledgerPart.slice(i)
  const j = seg.indexOf('\n## ')
  const body = j < 0 ? seg : seg.slice(0, j)
  for (const ln of body.split('\n')) {
    if (ln.charAt(0) !== '|' || /^\|[\s\-:|]+\|?\s*$/.test(ln)) continue
    const c = ln.split('|').map((x) => x.trim())
    if (c.length < 5 || c[1] === '日期' || c[1] === '事项') continue
    ledgerRows++
  }
}

// ── 身份面基线（2026-09-22 · 0921 开工包 P2 · 老板定「只装基石」）──────────────
// 为什么单列它：内核指纹只管内核正文三件 ⇒ **$DSH_HOME/AGENTS.md 是裸奔的**
//   （它每个会话自动注入、跨工作目录，「我叫苏青青」和四条红线就写在那儿 —— 被改了没有任何东西会响）。
// 口径（老板 2026-09-20 定）：**红线改动＝异常；身份层面改动＝报警；其余只记录，不打扰。**
//   ⇒ 不做「全文一变就报红」（那种红会被我习惯性忽略），只钉**身份锚**；全文只记指纹、不告警。
const AGENTS_PATH = (process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh') + '/AGENTS.md'
const ANCHORS = [
  ['身份行', '我叫苏青青'],
  ['主模型', '我是**用户的 AI 主模型**'],
  ['重启红线', '绝不自作主张重启引擎'],
  ['不自己冒出来', '东西不要自己冒出来'],
]
const agentsText = read(AGENTS_PATH)
const agentsHash = agentsText === null ? null : djb2(agentsText)
// ★ 1013 23:4x 修（独立抽查抓出 · 算法天生多 1）：`split('\n').length` 对**末尾带换行**的文件恒多算 1
//   （实测四条口径：wc -l=71 ／ awk NR=71 ／ 去尾=71 ／ 原法=72）⇒ 去掉末尾那个换行再数，与 `wc -l` 对齐。
const agentsLines = agentsText === null ? 0 : agentsText.replace(/\n$/, '').split('\n').length
const anchorsMissing = agentsText === null ? ANCHORS.map((a) => a[0]) : ANCHORS.filter((a) => !agentsText.includes(a[1])).map((a) => a[0])

const baseline = {
  hashCore,
  hashLedger,
  hash,
  at: new Date().toISOString().slice(0, 16).replace('T', ' '),
  rules,
  annotated,
  ledgerRows,
  agentsHash,
  agentsLines,
  anchors: ANCHORS.length - anchorsMissing.length,
  anchorsTotal: ANCHORS.length,
  anchorsMissing,
  scope: 'core = 内核正文三件（内核.md / 详解 / 变更日志）；台账只显示最后更新，不告警；身份面 = $DSH_HOME/AGENTS.md（锚缺 ⇒ 报警；全文只记指纹，不告警）',
  note: '告警口径只看 hashCore。改动内核正文三件后请重跑本工具，否则面板会红字告警。生成与校验逻辑见 @dsh-user/dsh-kernel-panel/lib/index.js',
}
writeFileSync(OUT, JSON.stringify(baseline, null, 2) + '\n', 'utf8')
console.log('指纹基线已更新（口径收窄后）：')
console.log('  入法标注 = ' + annotated + ' / ' + rules + ' 条（未标的属历史，不追；新增条文必须带）')
console.log('  正文三件 hashCore =', hashCore, '· 内核', rules, '条')
console.log('  台账     hashLedger =', hashLedger, '· 在办', ledgerRows, '行')
console.log('  身份面   $DSH_HOME/AGENTS.md hash = ' + (agentsHash || '读不到') + ' · ' + agentsLines + ' 行 · 身份锚 ' + (ANCHORS.length - anchorsMissing.length) + '/' + ANCHORS.length + (anchorsMissing.length ? '  ✘缺：' + anchorsMissing.join('、') + '（异常！先查这一份）' : ' ✔'))
console.log('  旧口径   hash       =', hash, '（过渡兼容用，老面板按它比）')
console.log('  at =', baseline.at)

// ── 供料方（2026-09-22）：内核指纹一变，「每轮必读」卡片必须跟着变（否则每轮注入的都是陈的）
//   为什么挂这儿：卡片的三样里，「内核条数＋hashCore」正是本脚本刚写下的 ⇒ 这里是它的**唯一真源头**。
try {
  const { execFileSync } = await import('node:child_process')
  execFileSync(process.argv0 || 'node', ['/storage/emulated/0/3/工具/开工/必读卡.mjs'], { stdio: 'ignore', timeout: 60000 })
  console.log('  ✅ 每轮必读卡片已重算（供料方：基线.mjs）')
} catch (e) { console.log('  ⚠️ 每轮必读卡片没重算：' + ((e && e.message) || e)) }
