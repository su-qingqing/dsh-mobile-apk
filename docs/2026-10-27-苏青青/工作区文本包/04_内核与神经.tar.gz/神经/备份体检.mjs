#!/usr/bin/env node
// 备份体检（2026-09-27 · 段C · 老板点名的九样之一「生产区改动的保存跟回退」）
//
// 它回答什么：**改了东西，退路到底在不在。** 对应行为动作 B01「要改的每个文件都有一份 .bak」。
// 为什么要有它：B01 原来只有一句人话判据（"每个文件都有一份 .bak"），机器判不了 ⇒ 靠我记得 ⇒ 换窗即忘。
//
// 两段判据（**只判在不在，不判该不该** —— 内核 #71：判不了的绝不猜）：
//   A 段 · 孤儿备份：`_backup/` 里有这份备份，但**原件已经不在了** ⇒ 🔴 红（备份成了孤魂，
//         说明原件被删/改名而我们不知道 —— 这正是"回退时才发现退不回去"的成因）
//   B 段 · 今天改过却没备份：文件 mtime 是今天、且在 `_backup/` 里能找到它的**更早备份**
//         ⇒ 说明是"又改了一次" ⇒ 🔴 红（改前没留新备份）
//         （从来没备份过的**不报红**：可能是新建件，没有"改前"可言 —— 只列出来供人看）
//
// 备份的两种命名（本仓库实存）：
//   ① `<原名>.bak-<MMDD>-前<标记>`   例：`做法库.md.bak-0926-前加家底做法`
//   ② 路径压平型 `<目录>_<文件>.前<标记>` 例：`工具_内核_动作集定义.mjs.前动工`
//      ⚠️ 压平用的是 `_`，而原文件名里**本来也可能有 `_`** ⇒ 切分有歧义 ⇒ **逐种切法试，任一存在即算找到**（不猜、穷举）
import fs from 'node:fs';
import path from 'node:path';

const ROOT = '/storage/emulated/0/3';
const BK = path.join(ROOT, '_backup');
const 今天 = new Date().toISOString().slice(0, 10).replace(/-/g, '-');   // 本机时区够用
const 今天戳 = new Date();

const 在 = (p) => { try { return fs.statSync(p).isFile(); } catch { return false; } };

// ── 收集 _backup 下所有备份文件 ────────────────────────────────────────────
function 走(dir, out = []) {
  let es = [];
  try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of es) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) 走(p, out);
    else if (e.isFile()) out.push(p);
  }
  return out;
}
const 备份们 = 走(BK);

// ── v2 修（2026-09-27 当场撞到）：v1 假设"备份名里含原始路径" —— **不成立**。
//   实存两种命名都**只有文件名**：\`做法库.md.bak-0926-…\`（原件其实在 \`台账/\` 下）、
//   \`工具_内核_动作集定义.mjs.前动工\`（压平名，\`_\` 既当分隔符又是原文件名里的合法字符 ⇒ 切分有歧义）。
//   ⇒ v1 报 81 条孤儿，**几乎全是假红**（\`全局_AGENTS.md\` 的原件在 \`$DSH_HOME\`，压根不在工作区）。
//   真口径：**按文件名建全盘索引**（工作区 ＋ $DSH_HOME），备份名对得上某个真文件 ⇒ 不算孤儿。
//   ★ 与死指针 v1 是**同一个病**：拿"我以为的路径规则"当判据，而不是拿"盘上真有什么"当判据。
const HOME = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh';
const 名索引 = new Set();
function 建索引(dir, 剩余深度) {
  if (剩余深度 < 0) return;
  let es = [];
  try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of es) {
    if (e.name === 'node_modules' || e.name === '.git' || e.name === '.dsh-sandbox') continue;
    if (e.isFile()) 名索引.add(e.name);
    else if (e.isDirectory()) { 名索引.add(e.name); 建索引(path.join(dir, e.name), 剩余深度 - 1); }
  }
}
建索引(ROOT, 6);
建索引(HOME, 4);
// 备份名去掉后缀标记，就是原件的**文件名**（不是路径）
function 原件名(bkPath) {
  const 基 = path.basename(bkPath);
  return 基.replace(/\.bak-.*$/, '').replace(/\.前.*$/, '');
}
// v3 再加一层：压平名／别名 —— 「台账_做法库.md」的原件叫「做法库.md」，「全局_AGENTS.md」的原件叫「AGENTS.md」。
function 候选名(名) { return [...new Set([名, 名.split('_').pop()])].filter(Boolean); }
const A孤儿 = [];
for (const b of 备份们) {
  const 名 = 原件名(b);
  if (!名) continue;
  const 候选 = 候选名(名);
  if (!候选.some((x) => 名索引.has(x))) A孤儿.push({ 备份: path.relative(ROOT, b), 找的名: 候选.join(' / ') });
}

// ── B 段：今天改过的关键文件 ──────────────────────────────────────────────
const 关键目录 = ['工具', '台账', '内核', '记忆', '路由层'];
const 今天改过 = [];
function 扫(dir) {
  let es = [];
  try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of es) {
    if (e.name === 'node_modules' || e.name === '.git' || e.name === '_backup') continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { 扫(p); continue; }
    if (!e.isFile()) continue;
    if (!/\.(mjs|md|json|jsonl|sh|yml)$/.test(e.name)) continue;
    let st; try { st = fs.statSync(p); } catch { continue; }
    if (st.mtime.toDateString() === 今天戳.toDateString()) 今天改过.push({ 路径: path.relative(ROOT, p), mtime: st.mtime });
  }
}
for (const d of 关键目录) 扫(path.join(ROOT, d));

// 这份文件以前被备份过吗？
function 有备份(rel) {
  const 基 = path.basename(rel);
  const 压平 = rel.replace(/\//g, '_');
  return 备份们.some(b => {
    const n = path.basename(b);
    return n.startsWith(基 + '.bak-') || n.startsWith(基 + '.前') ||
           n.startsWith(压平 + '.bak-') || n.startsWith(压平 + '.前') ||
           n.startsWith(压平 + '.') ;
  });
}
// v5 修（2026-09-27 · 第四次）：v4 的 B 段「今天改过、备份区一份都没有」仍然判不准 ——
//   实测 `birthtime` 在 /storage 上**不可用**（AGENTS.md 这种老文件也报 birth=今天，且恒等于 mtime），
//   ⇒ **「新建」和「漏备份」分不出来** ⇒ 那 18 条里多数是新建件，红得没道理。
//   真判据（直接回答老板那句「改动的保存跟回退」）：**备份的内容是不是"改前的样子"**。
//     有备份、任一份内容 ≠ 当前  ⇒ 有退路 ✅
//     有备份、但全部都 == 当前    ⇒ 🔴 改了却没留"改前"（等于没退路）
//     一份备份都没有              ⇒ ⚪ 分不清（可能是新建件）—— **不判红**，只列出来
import crypto from "node:crypto";
const md5 = (f) => { try { return crypto.createHash("md5").update(fs.readFileSync(f)).digest("hex"); } catch { return null; } };
const B没退路 = [];      // 🔴 有历史备份，但没有一份是"改前"
const B分不清 = [];      // ⚪ 一份备份都没有
for (const x of 今天改过) {
  const 全 = path.join(ROOT, x.路径);
  const 我 = md5(全);
  const 基 = path.basename(x.路径);
  const 压平 = x.路径.replace(/\//g, "_");
  const 相关 = 备份们.filter((b) => { const n = path.basename(b);
    return n.startsWith(基 + ".bak-") || n.startsWith(基 + ".前") ||
           n.startsWith(压平 + ".bak-") || n.startsWith(压平 + ".前") || n.startsWith(压平 + "."); });
  if (!相关.length) { B分不清.push(x.路径); continue; }
  const 有改前 = 相关.some((b) => md5(b) !== 我);
  if (!有改前) B没退路.push(x.路径 + "（" + 相关.length + " 份备份，内容都跟现在一模一样）");
}
const B该备而没新的 = B没退路;
const B从来没备 = B分不清;
// ── 出数 ─────────────────────────────────────────────────────────────────
console.log('══ 备份体检 ══');
console.log('  _backup 里 ' + 备份们.length + ' 个文件 ｜ 今天改过（工具/台账/内核/记忆）' + 今天改过.length + ' 个');
console.log('');
console.log('  A 段 · 孤儿备份（备份在、全盘找不到同名原件）：' + A孤儿.length + ' 条' + (A孤儿.length ? '  🔴' : '  ✅'));
for (const x of A孤儿.slice(0, 12)) console.log('     ' + x.备份 + '  ← 全盘找不着叫「' + x.找的名 + '」的文件');
console.log('');
console.log('  B 段 · 改了却没留“改前”（有备份但内容全是现状）：' + B该备而没新的.length + ' 条' + (B该备而没新的.length ? '  🔴' : '  ✅'));
for (const x of B该备而没新的.slice(0, 12)) console.log('     ' + x);
if (B从来没备.length) {
  console.log('');
  console.log('  · 一份备份都没有（**不判红**：birthtime 不可用，分不清是新建还是漏备）：' + B从来没备.length + ' 条');
  for (const x of B从来没备.slice(0, 8)) console.log('     ' + x);
}
console.log('');
console.log('⚠️ 本器只判「备份在不在」，**不判该不该改**（内核 #71）。退出码：A 段或 B 段有红 ⇒ 1。');
process.exit(A孤儿.length || B该备而没新的.length ? 1 : 0);
