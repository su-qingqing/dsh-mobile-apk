// ═══ 0926 本批 · 一键复验（重启后跑这个，机器出判据，不靠嘴说）═══
// 用法（平板，run-as 身份）：
//   run-as com.dsharnessmobile.shell sh -c 'LD_LIBRARY_PATH=$P/usr/lib $P/usr/bin/node 神经/复验0926.mjs'
// 退出码：0＝全绿 ／ 1＝有红（每一条红都给出"怎么办"）
import fs from 'node:fs'
import { execFileSync } from 'node:child_process'

const H = '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const 项 = []
const 加 = (名, 值, 判, 怎么办) => 项.push({ 名, 值, 判, 怎么办 })

// ── 中转快照（**由包装脚本 `_backup/0926-提示词分层/复验.sh` 在 shell 层准备好**）──
//   ★ 为什么不在本脚本里做：实测 run-as 起的 sh 子进程权限不够（cp /storage 会 Permission denied），
//     中转**只能由 adb shell 那一层做**。所以这里只"读现成的"，读不到就诚实说"没快照"。
const 快照 = (名) => {
  try { return fs.readFileSync('/data/local/tmp/_vf_' + 名, 'utf8') } catch { return null }
}

// ── 0. 引擎进程 ────────────────────────────────────────────────────────────
let 启动了多久秒 = null, 进程行 = '（读不到）'
try {
  const out = execFileSync('/system/bin/ps', ['-A', '-o', 'PID,ELAPSED,NAME'], { encoding: 'utf8' })
  进程行 = (out.split('\n').find((l) => /dsharness/.test(l)) || '').trim() || '❌ 没有这个进程'
  const t = 进程行.split(/\s+/)[1] || ''
  const 段 = t.split(':').map(Number)
  启动了多久秒 = 段.length === 3 ? 段[0] * 3600 + 段[1] * 60 + 段[2] : (段.length === 2 ? 段[0] * 60 + 段[1] : null)
} catch (e) { }
加('引擎进程', 进程行, 'info')

// ── 1. ★ 预设是否已装配（最硬的那条判据）────────────────────────────────
try {
  const st = fs.statSync(H + '/.agent-presets/suqingqing/agent.cordis.yml')
  const 预设m = st.mtimeMs
  const 字节 = st.size
  if (启动了多久秒 !== null) {
    const 启动时刻 = Date.now() - 启动了多久秒 * 1000
    const 差分钟 = Math.round((预设m - 启动时刻) / 60000)
    const 已装配 = 差分钟 <= 0
    加('★预设是否已装配', '预设 mtime 比引擎启动' + (差分钟 > 0 ? '晚 ' + 差分钟 + ' 分钟' : '早 ' + (-差分钟) + ' 分钟') + '（' + 字节 + ' B）',
      已装配 ? '✅ 已装配（本次启动读的是新版）' : '❌ 还没装配（引擎启动早于改动 ⇒ 要重启）',
      已装配 ? '' : '重启引擎（老板手动）')
  } else 加('★预设是否已装配', '读不到运行时长', '⚠️ 判不了', '手动看 pid 变没变')
} catch (e) { 加('★预设是否已装配', '读不到: ' + e.code, '❌', '检查预设文件在不在') }

// ── 2. 全局 AGENTS.md / 工作区 AGENTS.md 的体量与关键内容 ────────────────
//   实测修正（2026-09-26 第一次真跑）：
//     ① 身份锚在文里是 `- **我叫苏青青**` ⇒ 正则要容 `**`
//     ② 工作区那份 run-as 读不了 ⇒ **走中转**（不许拿"读不到"当"没有"）
//     ③ 三处关键内容**不是每份都该有**：全局那份管身份＋红线；工作区那份管硬事实
const 全局该有 = [
  ['身份锚', /我叫\*{0,2}苏青青/],
  ['红线1 绝不自己重启', /绝不自作主张重启引擎/],
  ['红线5 补条 读写失败先怀疑身份', /读写失败先怀疑身份/],
]
const 工作区该有 = [
  ['记忆库真源（新硬事实）', /记忆库的真源只有一个/],
  ['开工第一件事', /开工第一件事/],
  ['两个身份别混用', /两个身份别混用/],
]
for (const [名, 读法, 该有] of [
  ['全局 AGENTS.md', () => fs.readFileSync(H + '/AGENTS.md', 'utf8'), 全局该有],
  ['工作区 AGENTS.md', () => 快照('ws_agents.md'), 工作区该有],
]) {
  let 文 = null
  try { 文 = 读法() } catch { 文 = null }
  if (文 === null) {
    加(名, '读不到（私有区直读失败／没快照）', '❌',
      '① 私有区走 run-as ② /storage 那份要**先跑包装脚本**造快照：sh 3/_backup/0926-提示词分层/复验.sh')
    continue
  }
  const 缺 = 该有.filter(([, re]) => !re.test(文)).map(([k]) => k)
  加(名, Buffer.byteLength(文, 'utf8') + ' B／' + 文.split('\n').length + ' 行',
    缺.length === 0 ? '✅ 在，关键内容齐' : '❌ 缺: ' + 缺.join('／'),
    缺.length ? '从 3/_backup/0926-提示词分层/ 取回那一份原样' : '')
}

// ── 3. ★ lastPrompt 修复是否生效（看日志里 cached 的字符数）───────────────
try {
  const 文 = fs.readFileSync(H + '/kickoff-gate.log', 'utf8')
  const 行s = 文.split('\n')
  const cached = 行s.filter((l) => l.includes('PROMPT cached')).map((l) => ({ 行: l, chars: Number((l.match(/chars=(\d+)/) || [])[1] || 0) }))
  const skip = 行s.filter((l) => l.includes('PROMPT skip'))
  const 若 = cached.filter((c) => c.chars === 1133).length
  const 其他 = cached.filter((c) => c.chars !== 1133).length
  加('日志总行数', String(行s.length), 'info')
  加('★lastPrompt：1133 字符的缓存次数', String(若) + ' 次（其余 ' + 其他 + ' 次是别的长度）',
    'info', '')
  加('  └ 跳过留痕 PROMPT skip', String(skip.length) + ' 次',
    skip.length > 0 ? '✅ 修复已在跑（空着不拿系统提示充数）' : '⚠️ 还没出现过（要么没触发、要么还没重启）',
    skip.length > 0 ? '' : '重启后若长时间为 0，看 PROMPT cached 的 chars 是否还是 1133')
  // 1133 之后有没有出现"合理长度"的缓存（说明它开始缓存他的话了）
  const 尾 = cached.slice(-5).map((c) => c.chars)
  加('  最近 5 次缓存的 chars', 尾.join('、') || '（没有）',
    尾.length && 尾.every((c) => c !== 1133) ? '✅ 最近不再被 1133 盖住' : '⚠️ 最近仍见 1133',
    '')
} catch (e) { 加('日志', '读不到: ' + e.code, '❌', '') }

// ── 4. 影子：真账 + 退役进度（走中转，run-as 读不了 /storage）────────────
const 路由 = '/storage/emulated/0/3/工具/路由层'
{
  const 文 = 快照('shadow.jsonl')
  if (文 === null) 加('影子真账', '没快照（run-as 读不了 /storage，正常）', 'info',
    '要看就跑包装脚本：sh 3/_backup/0926-提示词分层/复验.sh')
  else {
    const n = 文.split('\n').filter((x) => x.trim())
    const 轮 = n.map((l) => { try { return JSON.parse(l) } catch { return null } }).filter((x) => x && x.轮 !== undefined)
    const 空 = 轮.filter((x) => x.输入质量 && x.输入质量 !== 'ok').length
    加('影子真账', 文.length + ' B／' + 轮.length + ' 轮（空输入 ' + 空 + '）／' + n.length + ' 行',
      轮.length === 0 ? '✅ 干净起点（等引擎真跑）' : '✅ 有真数据了',
      '')
    加('  └ 退役进度', 轮.length + '/100' + (轮.length >= 100 ? ' ★到点' : '（还差 ' + (100 - 轮.length) + ' 轮）'), 'info', '')
  }
}

console.log('════════ 0926 本批 · 复验 · ' + new Date().toISOString().slice(0, 19) + ' ════════')
let 红 = 0
for (const x of 项) {
  const 标 = x.判.startsWith('✅') ? '✅' : x.判.startsWith('❌') ? '❌' : x.判.startsWith('⚠️') ? '⚠️' : '  '
  if (x.判.startsWith('❌')) 红++
  console.log('  ' + 标 + ' ' + x.名.padEnd(30) + ' ' + x.值)
  if (x.判.startsWith('✅') || x.判.startsWith('❌') || x.判.startsWith('⚠️')) console.log('      ' + x.判)
  if (x.怎么办) console.log('      ⇒ ' + x.怎么办)
}
console.log('')
console.log(红 === 0 ? '★★ 全绿：本批机器判据全过' : '★★ 有 ' + 红 + ' 条红 —— 见上面每条的「⇒ 怎么办」')
console.log('')
console.log('（人话三问仍请老板顺手验：①你是谁 ②重启的规矩 ③记忆库在哪一份）')
process.exit(红 === 0 ? 0 : 1)
