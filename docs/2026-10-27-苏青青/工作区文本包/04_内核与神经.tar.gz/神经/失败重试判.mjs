#!/usr/bin/env node
// ── 失败重试判（B07 体检门）──────────────────────────────────────────────────
// 行为规矩 B07：「同一条路失败两次就停，讲清不通的原因再换路」
//   ⇒ 判据：**同一个调用键（工具名 ＋ 规范化参数）+ 连续失败 ≥3 次** ＝ 违规。
//   用法：node 神经/失败重试判.mjs [会话日志路径] [--静]
//         不给路径 ⇒ 自己找本工作区**最新**那份会话日志。
//   退出码：0 = 全绿 ｜ 1 = 有违规 ｜ 2 = 没东西可查（**不是通过**）。
//
// 【四模块耦合】
//   法（判据住在哪）：本文件。判据只有这一处，别处不许重写。
//     ① 事件源：会话日志（多帧 zstd）里的 `tool/call` 与 `tool/result`（真日志实测确认，见下）。
//     ② 调用键 ＝ sha256(工具名 + '\n' + 参数对象按键排序后的 JSON) 前 16 位。
//     ③ 失败标记 ＝ result 的 `data.message.content[0].isError === true`，
//        或带 `data.error`（实测二者同时出现；取「或」以免漏）。
//   记忆（什么时候用它）：怀疑「是不是在同一条路上撞了好几次」时；
//     收轮／开工想核「这一窗有没有违反 B07」时；`--静` 版专给挂点用。
//   神经（怎么自己响、挂在哪个必然时刻）：**本轮只落了产物、挂点还没接**
//     （本任务只许写两个文件）⇒ 现在是**孤儿件**，需要有人把它挂上，建议：
//       ① 挂「开工一屏／轮末自检」：`node 神经/失败重试判.mjs <本窗日志> --静`
//          —— `--静` 就是为挂点设计的（绿时零字，只靠退出码）。
//       ② 读它落盘的 `台账/接续/失败重试判.json`（别重算判据）。
//   动作（没做到怎么办）：红了 ⇒ 停手，把「不通的原因」写成一句话给他/给下一窗，
//     再换路（不许原地第 4 次）；并把这条记进坑账。孤儿状态本身也要如实说。
//
// 【诚实的边界说明】它是「**体检门**」，不是「闸」——
//   它在工作区里**离线读日志**，只能**事后发现**，**拦不住正在发生的重复**。
//   真拦住要挂进引擎的调用链（那是另一个工程）。
//
// 【事件格式（1009 用真日志查过，不是猜的）】
//   tool/call   : data.name（工具名）／data.arguments（**JSON 字符串**）／data.callId／data.turn／data.step
//   tool/result : data.message.source.callId（对上 call）／data.message.content[0].isError（布尔）
//                 ／data.message.content[0].content[].text（正文）／（有些还带 data.error）
//   样本（95cf8a5c…）：
//     {"type":"tool/call","seq":21,"time":1791546864491,"data":{"turn":1,"step":1,
//       "callId":"call_00_5rnT4qltd6Q8jw3IDOUA0163","name":"read","arguments":"{\"file_path\":\"…\"}"}}
//     {"type":"tool/result","seq":22,"time":…,"data":{"turn":1,"step":1,"message":{
//       "source":{"kind":"tool","callId":"call_00_5rnT4qltd6Q8jw3IDOUA0163"},
//       "content":[{"type":"tool-result","toolCallId":"…","content":[{"type":"text","text":"…"}],"isError":false}]}}}
import { readFileSync, writeFileSync, readdirSync, statSync, existsSync } from 'node:fs'
import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
import { join } from 'node:path'

const z = createRequire(import.meta.url)('node:zlib')
const M = Buffer.from([0x28, 0xb5, 0x2f, 0xfd])

// 多帧 zstd 解压（照 `神经/工具面核.mjs` 的写法：`zstdDecompressSync` 只解第一帧）
function 解多帧(buf) {
  const pos = []; let i = 0
  while (i <= buf.length - 4) { const j = buf.indexOf(M, i); if (j < 0) break; pos.push(j); i = j + 1 }
  const 片段 = []
  for (let n = 0; n < pos.length; n++) {
    const s = pos[n]; const e = n + 1 < pos.length ? pos[n + 1] : buf.length
    try { 片段.push(z.zstdDecompressSync(buf.subarray(s, e))) } catch {}
  }
  return Buffer.concat(片段).toString('utf8')
}

// 规范化：对象按键排序，递归（数组保序 —— 数组的顺序是语义的一部分）
function 规范(v) {
  if (Array.isArray(v)) return v.map(规范)
  if (v && typeof v === 'object') {
    const o = {}
    for (const k of Object.keys(v).sort()) o[k] = 规范(v[k])
    return o
  }
  return v
}
function 调用键(名, 参数串) {
  let a
  try { a = JSON.parse(参数串) } catch { a = String(参数串 ?? '') }   // 参数不是合法 JSON ⇒ 退化成原串，照样能比
  const 串 = 名 + '\n' + JSON.stringify(规范(a))
  return createHash('sha256').update(串).digest('hex').slice(0, 16)
}
function 参数摘要(参数串) {
  return String(参数串 ?? '').replace(/\s+/g, ' ').slice(0, 80)
}
function 时刻(t) {
  const n = typeof t === 'number' ? t : Date.parse(t)
  if (!Number.isFinite(n)) return String(t ?? '')
  const d = new Date(n)
  const p = (x) => String(x).padStart(2, '0')
  return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds())
}

// ── 找本工作区最新的会话日志（不给路径时用）─────────────────────────────────
function 默认日志() {
  const home = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
  const slug = '--' + process.cwd().replace(/^\//, '').replace(/\//g, '-') + '--'
  // ★ 1010 修 P1「串台」：旧逻辑取"mtime 最新" ⇒ 多窗并行时会看**别人的窗**（铁证：同一条红被两个窗各记一次）。
  //   现在优先认本窗（引擎给的 DSH_SESSION_ID）；认不出才退回老逻辑。
  const 本窗 = process.env.DSH_SESSION_ID || ''
  if (本窗) {
    for (const 候选 of ['session-' + 本窗, 本窗]) {
      const f0 = ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd'].map((x) => join(home, 'sessions', slug, 候选, x)).find((x) => existsSync(x))
      if (f0) return f0
    }
  }
  const 根 = join(home, 'sessions', slug)
  if (!existsSync(根)) return null
  let 最好 = null, 最好时 = 0
  for (const d of readdirSync(根)) {
    const f = ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd'].map((x) => join(根, d, x)).find((x) => existsSync(x))
    try { const m = statSync(f).mtimeMs; if (m > 最好时) { 最好时 = m; 最好 = f } } catch {}
  }
  return 最好
}

const 静 = process.argv.includes('--静')
const 参数 = process.argv.slice(2).filter((a) => !a.startsWith('--'))
const 日志 = 参数[0] || 默认日志()

// ── 沙盒改道（红线 19④）：认 DSH_KICKOFF_WS ⇒ 账写假区；**不设 ⇒ 逐字不变** ──────
// 为什么补这一处：1009 夜自测时发现它会往生产 `台账/接续/失败重试判.json` 落盘，
// 而"自测把生产写脏"是红线 19④ 点名的老病（0929 影子账实犯）⇒ 记分本必须认改道。
const 根 = process.env.DSH_KICKOFF_WS || null
const 落账路径 = 根
  ? 根 + '/台账/接续/失败重试判.json'
  : new URL('../工具/台账/接续/失败重试判.json', import.meta.url)

// ── 没东西可查（含读不到）⇒ 退出码 2，且**必须印出来**（不许当成通过）──────────
function 空仓(原因) {
  console.log('⚠️ ' + 原因)
  console.log('⚠️ **这不是通过，是没东西可查。**')
  落盘(null, 原因)
  process.exit(2)
}
function 落盘(违规, 备注, 统计) {
  try {
    const 明细 = (违规 || []).slice(0, 10).map((v) => ({
      调用键: v.键, 工具: v.名, 参数摘要: v.参数摘要, 连续失败: v.次数,
      首次seq: v.首, 末次seq: v.末,
      首次时刻: v.首时, 末次时刻: v.末时,                     // epoch 毫秒（机器读）
      首次时刻人读: 时刻(v.首时), 末次时刻人读: 时刻(v.末时),     // HH:MM:SS 本机（人读）
    }))
    const 现在 = new Date()
    const pp = (x) => String(x).padStart(2, '0')
    const 体 = {
      at: new Date().toISOString().slice(0, 16).replace('T', ' '),   // UTC（与 工具名体检.json 同口径）
      at本机: 现在.getFullYear() + '-' + pp(现在.getMonth() + 1) + '-' + pp(现在.getDate()) + ' ' + 时刻(现在.getTime()),
      日志: 日志 || '',
      // ⚠️ 别写 `!违规`：**空数组也是真值** —— 那会把「0 条违规」印成「违规」（本件当场踩过，已改）
      状态: (违规 && 违规.length) ? '违规' : (备注 === '通过' ? '通过' : '没东西可查'),
      原因: 备注 && 备注 !== '通过' ? 备注 : undefined,   // 只给「没东西可查」用；undefined 会被 JSON.stringify 丢掉
      违规数: (违规 && 违规.length) ? 违规.length : 0,
      扫到: 统计 || { 调用: 0, 结果: 0, 出错: 0 },
      明细,
      备注: '同一个调用键（工具名＋规范化参数）连续失败 ≥3 次 ⇒ 违规（B07）。中文正文统一用「」，不用直引号。',
    }
    const 文 = JSON.stringify(体, null, 1)
    JSON.parse(文)   // ⚠️ 写完必须验一次（我们真踩过这个坑：手拼 JSON 里的直引号把文件写坏）
    writeFileSync(落账路径, 文)
  } catch (e) {
    console.log('（落盘失败，不影响本次结论：' + e.message + '）')
  }
}

if (!日志) 空仓('没给日志路径，也自动找不到本工作区的会话日志。')
if (!existsSync(日志)) 空仓('读不到日志：' + 日志)

let 文本
try { 文本 = 解多帧(readFileSync(日志)) } catch (e) { 空仓('日志解不开：' + e.message) }

// ── 扫事件 ────────────────────────────────────────────────────────────────
const 调用表 = new Map()      // callId → { 键, 名, 参数摘要, seq }
const 结果序 = []             // [{ callId, 出错, seq, 时刻 }]
let 调用数 = 0
for (const 行 of 文本.split('\n')) {
  if (!行.trim().startsWith('{')) continue
  let e; try { e = JSON.parse(行) } catch { continue }
  if (e.type === 'tool/call') {
    const d = e.data || {}
    if (!d.name) continue
    调用数++
    调用表.set(d.callId, { 键: 调用键(d.name, d.arguments), 名: d.name, 参数摘要: 参数摘要(d.arguments), seq: e.seq })
  } else if (e.type === 'tool/result') {
    const m = (e.data || {}).message || {}
    const callId = m.source?.callId ?? m.content?.[0]?.toolCallId
    const 出错 = m.content?.[0]?.isError === true || !!(e.data || {}).error
    结果序.push({ callId, 出错, seq: e.seq, 时刻: e.time })
  }
}
if (!结果序.length) 空仓('这个会话里一条 tool/result 都没有（工具调用 ' + 调用数 + ' 条）—— 新窗还没请求过，或这一窗没使过工具。')

// ── 连败判据 ──────────────────────────────────────────────────────────────
const 连败 = new Map()        // 键 → { 次数, 首, 首时, 末, 末时 }
const 违规 = []
const 记录 = (v) => 违规.push(v)
for (const r of 结果序) {
  const c = 调用表.get(r.callId)
  if (!c) continue                       // 对不上的 call（压缩/迁移过的老日志）⇒ 不猜、不判
  const s = 连败.get(c.键)
  if (r.出错) {
    if (!s) 连败.set(c.键, { 次数: 1, 首: r.seq, 首时: r.时刻, 末: r.seq, 末时: r.时刻, 开着的: null, 名: c.名, 参数摘要: c.参数摘要 })
    else {
      s.次数++; s.末 = r.seq; s.末时 = r.时刻
      if (s.次数 === 3) {   // ★ 第 3 次 = 违规成立；之后只把这条违规养长（同一个连败段 = 一条违规）
        s.开着的 = { 键: c.键, 名: c.名, 参数摘要: c.参数摘要, 次数: 3, 首: s.首, 首时: s.首时, 末: r.seq, 末时: r.时刻 }
        记录(s.开着的)
      } else if (s.开着的) { s.开着的.次数 = s.次数; s.开着的.末 = r.seq; s.开着的.末时 = r.时刻 }
    }
  } else if (s) 连败.delete(c.键)   // 中间成功过一次 ⇒ 连败清零（下一个失败重新数）
}
const 出错数 = 结果序.filter((r) => r.出错).length
const 统计 = { 调用: 调用数, 结果: 结果序.length, 出错: 出错数 }

落盘(违规, 违规.length ? null : '通过', 统计)

// ── 输出 ──────────────────────────────────────────────────────────────────
const 头 = '失败重试判（B07 体检门） · ' + 日志
if (!违规.length) {
  if (!静) {
    console.log('✅ ' + 头)
    console.log('   扫到：工具调用 ' + 统计.调用 + ' 条 ／ 结果 ' + 统计.结果 + ' 条 ／ 其中出错 ' + 统计.出错 + ' 条')
    console.log('   0 条违规 —— 没有「同一个调用键连续失败 ≥3 次」。')
    console.log('   （绿=没发现，不等于这条路一定对；它是体检门，拦不住正在发生的重复。）')
  }
  process.exit(0)
}
console.log('⛔ ' + 头)
console.log('   违规 ' + 违规.length + ' 条：同一个调用键**连续失败 ≥3 次**（B07：同一条路失败两次就停）')
console.log('   扫到：工具调用 ' + 统计.调用 + ' 条 ／ 结果 ' + 统计.结果 + ' 条 ／ 其中出错 ' + 统计.出错 + ' 条')
console.log('')
违规.slice(0, 10).forEach((v, i) => {
  console.log('   #' + (i + 1) + '  ' + v.名 + '  ' + v.参数摘要)
  console.log('       连续失败 ' + v.次数 + ' 次 ｜ 首次 seq ' + v.首 + '（' + 时刻(v.首时) + '）｜ 末次 seq ' + v.末 + '（' + 时刻(v.末时) + '）｜ 键 ' + v.键)
})
if (违规.length > 10) console.log('   … 还有 ' + (违规.length - 10) + ' 条，全量见 台账/接续/失败重试判.json')
console.log('')
console.log('   ⇒ 事已发生（离线读日志）：去把「不通的原因」写成一句话再换路，别在原地第 4 次。')
console.log('   ⇒ 想真拦住 ⇒ 得挂进引擎调用链；现在这道是体检门，不是闸。')
process.exit(1)
