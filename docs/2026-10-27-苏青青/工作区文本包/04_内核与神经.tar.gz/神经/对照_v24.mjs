// 旧版(v2.3) vs 新版(v2.4) 跑同一张命令表 —— 只跑"新用例全过"不算数
const WS = '/storage/emulated/0/3'
const MEMDB = WS + '/.dsh-meow/memory.db'
const SID = 'CMP-NOCARD'
const allow = async () => ({ kind: 'allow' })
const load = async (path) => {
  const { apply } = await import(path)
  const L = {}
  const ctx = { get: () => undefined, on: (n, f) => { (L[n] = L[n] || []).push(f); return () => {} },
    effect: (f) => { f(); return () => {} }, logger: { warn: () => {}, info: () => {} } }
  apply(ctx, { workspace: WS, memoryDb: MEMDB, lessonCacheMs: 0 })
  return (cmd) => L['tools/pre-execute'][0]({ name: 'bash', arguments: { command: cmd } }, allow)
}
const oldPre = await load(WS + '/.dsh-kickoff/gate-old-v23.mjs')
const newPre = await load('/data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/node_modules/@dsh-user/dsh-kickoff-gate/lib/index.js')
const k = async (f, c) => ((await f(c)).kind === 'deny' ? 'deny' : 'allow')
const cases = [
  ['rm 豁免(无重定向)', 'rm -f _backup/x', 'allow'],
  ['rm 豁免 + 2>/dev/null', 'rm -f _backup/x 2>/dev/null', 'allow'],
  ['rm -rf 豁免目录', 'rm -rf 台账/_tmp', 'allow'],
  ['cp → 豁免', 'cp a.md 台账/b.md', 'allow'],
  ['cp → 豁免 + 2>/dev/null', 'cp a.md 台账/b.md 2>/dev/null', 'allow'],
  ['mv 豁免 + 2>/dev/null', 'mv 台账/a.md 台账/b.md 2>/dev/null', 'allow'],
  ['chmod 豁免 + 2>/dev/null', 'chmod 644 台账/a.md 2>/dev/null', 'allow'],
  ['touch 豁免 + 2>/dev/null', 'touch 台账/x.md 2>/dev/null', 'allow'],
  ['mkdir 豁免 + 2>/dev/null', 'mkdir -p 台账/_d 2>/dev/null', 'allow'],
  ['rmdir 豁免 + 2>/dev/null', 'rmdir 台账/_d 2>/dev/null', 'allow'],
  ['ln 豁免 + 2>/dev/null', 'ln -s 台账/a.md 台账/b.lnk 2>/dev/null', 'allow'],
  ['truncate 豁免 + 2>/dev/null', 'truncate -s 0 台账/x.md 2>/dev/null', 'allow'],
  ['truncate 豁免(无重定向)', 'truncate -s 0 台账/x.md', 'allow'],
  ['tee 豁免 + 2>/dev/null', 'echo x | tee 台账/x.md 2>/dev/null', 'allow'],
  ['sed -i 豁免 + 2>/dev/null', "sed -i 's/a/b/' 台账/x.md 2>/dev/null", 'allow'],
  ['sed -i 豁免(无重定向)', "sed -i 's/a/b/' 台账/x.md", 'allow'],
  ['install → 豁免 + 2>/dev/null', 'install a.md 台账/b.md 2>/dev/null', 'allow'],
  ['只读 ls + 2>/dev/null', 'ls 台账/ 2>/dev/null', 'allow'],
  ['重定向 → 豁免 + 2>/dev/null', 'echo hi > 台账/x.md 2>/dev/null', 'allow'],
  ['dd of=豁免 + 2>/dev/null', 'dd if=/dev/zero of=台账/x.md bs=1 count=0 2>/dev/null', 'allow'],
  ['【对照】rm 非豁免 + 2>/dev/null', 'rm -f /storage/emulated/0/3/非豁免.txt 2>/dev/null', 'deny'],
  ['【对照】rm 非豁免(无重定向)', 'rm -f 桌宠项目/x.js', 'deny'],
  ['【对照】sed -i 非豁免', "sed -i 's/a/b/' 桌宠项目/x.js", 'deny'],
]
let fixed = 0, regress = 0, stillBad = 0
console.log('期望  旧版  新版  命令')
for (const [label, cmd, want] of cases) {
  const o = await k(oldPre, cmd); const n = await k(newPre, cmd)
  const oOk = o === want, nOk = n === want
  if (!oOk && nOk) fixed++
  if (oOk && !nOk) regress++
  if (!oOk && !nOk) stillBad++
  const mark = (!oOk && nOk) ? '🔧' : (oOk && !nOk) ? '⚠️回归' : (!nOk ? '❌仍未修' : '  ok ')
  console.log(mark + '  ' + want.padEnd(5) + o.padEnd(6) + n.padEnd(6) + label)
}
console.log('\n修好 ' + fixed + ' 条 ｜ 回归 ' + regress + ' 条 ｜ 仍未修 ' + stillBad + ' 条 ｜ 共 ' + cases.length + ' 条')
