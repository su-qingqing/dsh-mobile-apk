// 寻key.mjs —— 【壳体一重整配置，手写的 key/provider 就没了】时的找回手艺（2026-10-07 实测有效一次：找回 providers.bailian 片段与 3 把候选 key）
// 用法：node 神经/寻key.mjs            # 全盘找 BAILIAN_API_KEY 痕迹（值打码）
//       node 神经/寻key.mjs 验 <key文件>  # 拿候选 key 打一发最小请求验有效性（flash·3 token）
// 工具/临时/找key.mjs —— 在会话日志里找 BAILIAN_API_KEY 的落地痕迹（只印"哪条会话哪一行 + 打码"）
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'

const H = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const ROOT = path.join(H, 'sessions')
const 打码 = s => s.replace(/(sk-[A-Za-z0-9_-]{4})[A-Za-z0-9_-]+/g, '$1…打码')
let 命中 = 0, 扫 = 0
for (const ws of fs.readdirSync(ROOT)) {
  const p1 = path.join(ROOT, ws); let st1; try { st1 = fs.statSync(p1) } catch { continue }
  if (!st1.isDirectory()) continue
  for (const sid of fs.readdirSync(p1)) {
    const dir = path.join(p1, sid); let st2; try { st2 = fs.statSync(dir) } catch { continue }
    if (!st2.isDirectory()) continue
    for (const f of fs.readdirSync(dir)) {
      const fp = path.join(dir, f); let st3
      try { st3 = fs.statSync(fp) } catch { continue }
      if (!st3.isFile() || st3.size < 200) continue
      // 只看 09-30 之后动过的
      if (st3.mtimeMs < Date.parse('2026-09-30T00:00:00Z')) continue
      let txt = ''
      try {
        const buf = fs.readFileSync(fp)
        txt = f.endsWith('.zstd') || f.endsWith('.zst') ? zlib.zstdDecompressSync(buf).toString('utf8') : buf.toString('utf8')
      } catch { continue }
      扫++
      const 行 = txt.split('\n')
      for (let i = 0; i < 行.length; i++) {
        if (!/BAILIAN_API_KEY/.test(行[i])) continue
        // 只要"像真值"的行（带 sk- 或 长度>20 的值），不要记忆库那种描述
        const m = 行[i].match(/BAILIAN_API_KEY["'\s:=]+([A-Za-z0-9_\-]{12,})/)
        const 像真值 = !!m
        命中++
        console.log((像真值 ? '★疑似真值 ' : '·仅提及 ') + ws + '/' + sid.slice(0, 8) + ' ' + f + ' L' + (i + 1) +
          ' ｜ ' + 打码(行[i].slice(0, 220)))
        if (命中 > 40) { console.log('（截断）'); process.exit(0) }
      }
    }
  }
}
console.log('\n扫了 ' + 扫 + ' 个日志文件，命中 ' + 命中 + ' 行')
