#!/usr/bin/env node
// 工具用量 · 全机（跨**全部**会话）统计两件事（2026-09-27 立）
// ════════════════════════════════════════════════════════════════════════════
// ① 每件工具**被调用过几次**、在**几个会话**里被用过 —— 判据＝日志里 `tool/call` 的 `data.name`
// ② 每件工具的**定义占多少字节/步** —— 判据＝该会话最后一条 `request/header` 的 `data.header.tools`
//
// 【为什么必须单独立这一件】活份账里的"0 调用"只统计**本窗**。本窗没用 ≠ 别的窗没用。
//   要决定"关掉哪一行（按需挂载）"，必须在全部会话上看 —— 否则就是拿本窗的孤证当全机结论。
//
// 【用法】
//   node 神经/工具用量.mjs              # 全部会话
//   node 神经/工具用量.mjs 0b98df7d     # 只看含该片段的会话
//   node 神经/工具用量.mjs --顶=80      # 表里最多印几行（默认 40）
//
// 【自检（会打印，读不到就明说，绝不静默印 0）】
//   ① 读到几个会话、几个声明清单、多少帧／跳了多少帧、多少坏行
//   ② 基准会话的件数必须 > 0，否则报红并停（"没读到数据"不等于"没有工具"）
//   ③ 跳帧 / 坏行 > 0 ⇒ 明确标"读数可能不全"
//
// 单位：这里的"字节"＝ `JSON.stringify(工具定义)` 的 UTF-8 字节数（不是汉字个数）。
// ════════════════════════════════════════════════════════════════════════════
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'

const MAGIC = Buffer.from([0x28, 0xb5, 0x2f, 0xfd])   // zstd 帧魔数
const HOME = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const 参数 = process.argv.slice(2)
const 顶 = Number(((参数.find(a => a.startsWith('--顶')) || '').split('=')[1]) || 0) || 40
const 片段 = 参数.find(a => !a.startsWith('--')) || ''
const 出 = ((参数.find(a => a.startsWith('--出')) || '').split('=')[1]) || ''   // --出=<path>：把家族/零调用落成机器可读 JSON

/** 逐帧解开多帧 zstd（`zstdDecompressSync` 只解第一帧且不报错 —— 实测坑） */
function 解多帧(buf) {
  const pos = []; let i = 0
  while (i <= buf.length - 4) { const j = buf.indexOf(MAGIC, i); if (j < 0) break; pos.push(j); i = j + 1 }
  const 片段s = []; let 帧 = 0, 跳 = 0
  for (let n = 0; n < pos.length; n++) {
    const s = pos[n], e = n + 1 < pos.length ? pos[n + 1] : buf.length
    try { 片段s.push(zlib.zstdDecompressSync(buf.subarray(s, e))); 帧++ } catch { 跳++ }
  }
  return { 文本: Buffer.concat(片段s).toString('utf8'), 帧, 跳 }
}

/** 全部会话日志（每个 workspace 下的每个会话目录里最新的那个 .jsonl.zstd） */
function 全会话() {
  const root = path.join(HOME, 'sessions')
  const 出 = []
  let ws列表 = []
  try { ws列表 = fs.readdirSync(root) } catch { return 出 }
  for (const ws of ws列表) {
    const d = path.join(root, ws)
    try { if (!fs.statSync(d).isDirectory()) continue } catch { continue }
    for (const s of fs.readdirSync(d)) {
      const dir = path.join(d, s)
      try { if (!fs.statSync(dir).isDirectory()) continue } catch { continue }
      let 最 = null
      for (const fn of fs.readdirSync(dir)) {
        if (!fn.endsWith('.jsonl.zstd')) continue
        const f = path.join(dir, fn)
        try { const m = fs.statSync(f).mtimeMs; if (!最 || m > 最.m) 最 = { f, m } } catch { }
      }
      if (最) 出.push({ ws, s, f: 最.f, m: 最.m })
    }
  }
  return 出.sort((a, b) => b.m - a.m)
}

const 全部 = 全会话()
const 会话 = 全部.filter(c => !片段 || c.s.includes(片段) || c.ws.includes(片段))

const 调 = new Map()        // 工具名 → 调用次数
const 谁用 = new Map()      // 工具名 → Set(会话短名)
const 声明 = []             // 每个会话最后一份工具清单
let 帧 = 0, 跳 = 0, 行 = 0, 坏行 = 0

for (const c of 会话) {
  let 文
  try { 文 = 解多帧(fs.readFileSync(c.f)) } catch { continue }
  帧 += 文.帧; 跳 += 文.跳
  let 最后 = null
  for (const ln of 文.文本.split('\n')) {
    if (!ln.trim()) continue
    let e; try { e = JSON.parse(ln) } catch { 坏行++; continue }
    行++
    if (e.type === 'tool/call') {
      const n = (e.data && e.data.name) || '?'
      调.set(n, (调.get(n) || 0) + 1)
      if (!谁用.has(n)) 谁用.set(n, new Set())
      谁用.get(n).add(c.s.slice(0, 16))
    } else if (e.type === 'request/header') 最后 = e
  }
  if (最后) {
    const tools = (最后.data && 最后.data.header && 最后.data.header.tools) || []
    const 字节 = new Map(); let 总 = 0
    for (const t of tools) {
      const n = t.name || (t.function || {}).name || '?'
      const b = Buffer.byteLength(JSON.stringify(t))
      字节.set(n, b); 总 += b
    }
    声明.push({ s: c.s, ws: c.ws, 件数: tools.length, 字节, 总 })
  }
}

console.log('══ 工具用量 · 全机（跨全部会话）══')
console.log('会话目录 ' + 全部.length + ' 个 ｜ 本次统计 ' + 会话.length + ' 个' + (片段 ? '（片段「' + 片段 + '」）' : '') +
  ' ｜ 解出帧 ' + 帧 + '（跳 ' + 跳 + '）｜ 事件行 ' + 行 + '（坏行 ' + 坏行 + '）')
console.log('读到工具清单的会话：' + 声明.length + ' 个')

if (!声明.length) {
  console.log('🔴 一个工具清单都没读到 ⇒ **别下任何结论**（先查是不是路径/身份问题：run-as com.dsharnessmobile.shell 才读得到私有区）')
  process.exit(2)
}

console.log('\n── 声明表（各会话最后一份工具清单）──')
console.log('  件数'.padStart(5) + '  总字节'.padStart(10) + '  会话')
for (const d of 声明.slice(0, 顶)) {
  console.log(String(d.件数).padStart(6) + String(d.总).padStart(10) + '  ' + d.s.slice(0, 20))
}
if (声明.length > 顶) console.log('  …（共 ' + 声明.length + ' 个，只印前 ' + 顶 + '）')

const 基准 = 声明[0]
if (!基准.件数) { console.log('🔴 基准会话件数 0 ⇒ 停（读数不可用）'); process.exit(2) }
console.log('\n基准（最近一个会话）＝ ' + 基准.s.slice(0, 20) + ' ｜ ' + 基准.件数 + ' 件 ｜ ' + 基准.总 + ' 字节/步')

// ── 一、按调用次数排 ──
const 名单 = [...new Set([...基准.字节.keys(), ...调.keys()])]
  .map(n => ({ n, b: 基准.字节.get(n) || 0, c: 调.get(n) || 0, s: (谁用.get(n) || new Set()).size }))
  .sort((a, b) => b.c - a.c || b.b - a.b)
console.log('\n── 一、全机调用次数（降序；字节＝基准会话里的定义大小）──')
console.log('  调用'.padStart(6) + '  会话'.padStart(5) + '  字节'.padStart(8) + '  工具')
for (const x of 名单.slice(0, 顶)) {
  console.log(String(x.c).padStart(6) + String(x.s).padStart(6) + String(x.b).padStart(8) + '  ' + x.n)
}
if (名单.length > 顶) console.log('  …（共 ' + 名单.length + ' 件，只印前 ' + 顶 + '）')

// ── 二、家族汇总（名字第一段下划线之前）──
const 家族 = new Map()
for (const x of 名单) {
  const f = x.n.includes('_') ? x.n.split('_')[0] + '_*' : x.n
  const g = 家族.get(f) || { 件: 0, 字节: 0, 调用: 0, 零: 0 }
  g.件++; g.字节 += x.b; g.调用 += x.c; if (!x.c) g.零++
  家族.set(f, g)
}
console.log('\n── 二、家族汇总（基准里声明的家族）──')
console.log('  件数  零调用件数  字节/步  调用次数  家族')
for (const [f, g] of [...家族.entries()].sort((a, b) => b[1].字节 - a[1].字节)) {
  console.log(String(g.件).padStart(6) + String(g.零).padStart(12) + String(g.字节).padStart(10) + String(g.调用).padStart(10) + '  ' + f)
}

// ── 三、全机零调用 ──
const 零 = 名单.filter(x => !x.c && x.b > 0).sort((a, b) => b.b - a.b)
const 零字节 = 零.reduce((s, x) => s + x.b, 0)
console.log('\n── 三、**全机 0 调用**（在 ' + 会话.length + ' 个会话里一次都没用过）──')
for (const x of 零) console.log(String(x.b).padStart(8) + 'B  ' + x.n)
console.log('  合计 ' + 零.length + ' 件 ／ ' + 零字节 + ' 字节/步 ＝ 基准总字节的 ' + (零字节 / 基准.总 * 100).toFixed(1) + '%')

// ── 五、门控候选（家族级 · 给"要不要按需挂载"用的绝对量；**不做建议**）──
// ★ 门事实（真源：`$DSH_HOME/profiles/web/node_modules/@dsh-android/dsh-android-bridge/lib/capability-gate.js`
//   —— 常驻 facade 工具 ＋ agent 作用域 `tools.restrict` 掩蔽目标工具组；facade 调用时解挡）
//   实测样板：解锁 android 组的会话比本窗多 27 件 ≈ ＋25,933 字节/步 ⇒ 「门能省多少」是量出来的，不是估的。
const 有门 = f => f.startsWith('android_') || f.startsWith('dev_')
const 族行 = [...家族.entries()].sort((a, b) => b[1].字节 - a[1].字节)
const 有门族 = 族行.filter(([f]) => 有门(f)), 无门族 = 族行.filter(([f]) => !有门(f))
const 加 = (a, k) => a.reduce((s, [, g]) => s + g[k], 0)
console.log('\n── 五、门控候选（家族级 · 绝对量 · 不做建议）──')
console.log('  字节/步   件   调用  门况                             家族')
for (const [f, g] of 族行) {
  console.log(String(g.字节).padStart(9) + String(g.件).padStart(5) + String(g.调用).padStart(7) + '  ' +
    (有门(f) ? '已有门✅ facade=android_capabilities ' : '无门（省＝自建 facade 或删行）') + '  ' + f)
}
console.log('  ── 合计（基准总 ' + 基准.总 + ' 字节/步）──')
console.log('  已在门后的家族：' + 加(有门族, '件') + ' 件 ／ ' + 加(有门族, '字节') + ' 字节/步 ＝ ' +
  (加(有门族, '字节') / 基准.总 * 100).toFixed(1) + '%（门的实测样板）')
console.log('  无门家族合计：  ' + 加(无门族, '件') + ' 件 ／ ' + 加(无门族, '字节') + ' 字节/步 ＝ ' +
  (加(无门族, '字节') / 基准.总 * 100).toFixed(1) + '%（要省＝自建 facade／删行 ⇒ 都要老板点头＋重启）')
const 零族 = 族行.filter(([, g]) => g.零 === g.件)
console.log('  整族 0 调用（' + 零族.length + ' 个家族）：' + (零族.map(([f, g]) => f + '(' + g.字节 + 'B)').join(' ｜ ') || '无'))
if (出) {
  fs.writeFileSync(出, JSON.stringify({
    算于: new Date().toISOString(), 基准: { 会话: 基准.s, 件数: 基准.件数, 总字节: 基准.总 },
    家族: 族行.map(([f, g]) => ({ 家族: f, ...g, 有门: 有门(f) })),
    零调用件: 零.map(x => ({ 名: x.n, 字节: x.b, 会话数: x.s })),
  }, null, 1))
  console.log('  （机器可读落盘：' + 出 + '）')
}

// ── 四、自检 ──
console.log('\n── 四、自检 ──')
console.log('  ' + (声明.length >= 2 ? '✅' : '⚠️') + ' 读到工具清单的会话 ' + 声明.length + ' 个（≥2 才算跨窗）')
console.log('  ' + (跳 === 0 && 坏行 === 0 ? '✅' : '⚠️') + ' 跳帧 ' + 跳 + ' ／ 坏行 ' + 坏行 + (跳 || 坏行 ? ' ⇒ 读数可能不全' : '（完整）'))
console.log('  ✅ 基准件数 ' + 基准.件数 + ' > 0（不是"没读到"被当成"没有"）')
console.log('  ' + (族行.length ? '✅' : '⚠️') + ' 家族表 ' + 族行.length + ' 个（0 ⇒ 汇总没出来，别下结论）')
console.log('  ⚠️ 本表只说"用过几次"，**不说该不该留**：关一行＝能力面变化，要老板点头（回退＝把行加回＋重启）。')
