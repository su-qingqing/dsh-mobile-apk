#!/usr/bin/env node
// ⑨ 四问之 ①③：从会话日志的 `request/header` 直接读**真工具数组**
//   ① 缺席工具是否真不进请求 —— 看数组里到底有什么（真值，不是推断）
//   ③ 取回是否破坏缓存 —— 看数组在**各轮之间是否逐字节稳定**（变了 ⇒ 前缀破 ⇒ 缓存碎）
//
// 【四模块耦合】（红线 22 · 1009 补：上一版只加了体检门，四格漏了）
//   法（判据住在哪）：本文件。① 名字合规判据＝/^[a-zA-Z0-9_-]{1,64}$/（红线 20 的机器面）；
//     ② 真源＝会话日志 request/header 里**引擎真发出去的那份工具数组**（不是我以为的清单）。
//   记忆（什么时候用它）：① 往工具面挂新东西**之前**先验名；② 怀疑前缀缓存被打碎时；
//     ③ 开窗一屏读的 台账/接续/工具名体检.json 就是它落的盘 —— 判据只有这一处，别处不重算。
//   神经（怎么自己响、挂在哪个必然时刻）：--静（**绿时零字**）专给挂点用；已挂＝库.mjs 开窗一屏
//     读它落的 json（只读结论、不重算）。⚠️ **它是体检门、不是闸** —— 引擎对本地注册工具零校验，
//     这个位置**拦不住注册**，只能事后发现（外部核原话：那就改名叫「工具名体检门」，名字要诚实）。
//   动作（没做到怎么办）：不合规 ⇒ 退 1 ＋ 红字；发现即报老板，且**不许为通过而改判据**（要改改红线 20，他裁）。
import { readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
import { 根 } from './根.mjs' // ★ 1009 夜：落盘改走"单一根"（认 DSH_KICKOFF_WS ⇒ 假区隔离；生产默认不变）
const z = createRequire(import.meta.url)('node:zlib')
const M = Buffer.from([0x28, 0xb5, 0x2f, 0xfd])
function 解多帧(buf) {
  const pos = []; let i = 0
  while (i <= buf.length - 4) { const j = buf.indexOf(M, i); if (j < 0) break; pos.push(j); i = j + 1 }
  const 片段 = []
  for (let n = 0; n < pos.length; n++) {
    const s = pos[n]; const e = n + 1 < pos.length ? pos[n + 1] : buf.length
    try { 片段.push(z.zstdDecompressSync(buf.subarray(s, e))) } catch {}
  }
  return Buffer.concat(片段).toString('utf8')
}
// ★ 1013 迭代 3.0 · **Promote 第一步：自动找本窗日志** —— 让它"随手一跑就能出读数"。
//   为什么（书 §4.3.3 原话「**Sometimes you promote the obligation, not the instrument that discovered it**」）：
//   它**不是闸**（拦不住注册），它的产物 `台账/接续/工具名体检.json` 只有在**有人给它日志路径**时才刷新；
//   而路径每次带会话 id ⇒ **没人跑 ⇒ json 过期**（书 §4.4.3："一个没人查的表示＝带 schema 的散文"）。
//   ⇒ 要 Promote 的不是"把它改成闸"，是**把它那一步"能随手跑起来"**（义务＝名字合规，这条才是被拦的对象）。
//   ⚠️ **找不到日志时仍然印用法、rc=2** ——「没东西可查」与「它坏了」必须分开（内核 #71：假红会把真红淹掉）。
function 找最近日志() {
  const S = (process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh') + '/sessions/--storage-emulated-0-3--'
  const 候选 = []
  try {
    for (const d of readdirSync(S)) {
      try {
        const 全 = path.join(S, d)
        if (!statSync(全).isDirectory()) continue
        for (const f of readdirSync(全)) {
          if (!/^session\.v\d+\.jsonl\.zstd$/.test(f)) continue
          const p = path.join(全, f)
          候选.push({ p, t: statSync(p).mtimeMs })
        }
      } catch { /* 单个目录读不到 ⇒ 跳过，不炸 */ }
    }
  } catch { /* 整个 sessions 读不到 ⇒ 回落到"没给路径" */ }
  候选.sort((a, b) => b.t - a.t)
  return 候选.length ? 候选[0].p : ''
}
const 手给 = process.argv.slice(2).find((a) => a && !a.startsWith('--')) || ''
const 日志路径 = 手给 || 找最近日志()
if (!日志路径) {
  console.log('⚠️ 找不到会话日志（也没手给路径）⇒ **不跑**（rc=2）。')
  console.log('   用法：node 神经/工具面核.mjs [<会话日志>]   ← 不传就自动取**最近写过的那一份**')
  console.log('   ★ 这不是"它坏了" —— 是"没东西可查"，**不许当成通过**。')
  process.exit(2)
}
if (!手给) console.log('（没手给路径 ⇒ 自动取最近的一份：' + 日志路径.replace(/^.*\/sessions\//, 'sessions/') + '）\n')
const txt = 解多帧(readFileSync(日志路径))
const lines = txt.split('\n').filter((l) => l.trim().startsWith('{'))
const 快照 = []
for (const l of lines) {
  let e; try { e = JSON.parse(l) } catch { continue }
  if (e.type !== 'request/header') continue
  const t = e.data?.header?.tools
  if (!Array.isArray(t)) continue
  const 名 = t.map((x) => x.name || x.function?.name || '?')
  const 串 = JSON.stringify(t)
  快照.push({ seq: e.seq, 时刻: e.time, 数: 名.length, 名, 哈希: createHash('sha256').update(串).digest('hex').slice(0, 16) })
}
console.log('⚠️ 注意：这些 header 来自**不同会话/不同窗**时，数组本来就该不同；同会话内才谈"稳定"。')
console.log('')
console.log('request/header 带 tools 的：' + 快照.length + ' 条')
for (const s of 快照) console.log('  seq ' + String(s.seq).padStart(5) + '  ' + String(s.时刻).slice(11, 19) + '  ' + String(s.数).padStart(3) + ' 个  哈希 ' + s.哈希)
console.log('')
// ★ 2026-09-26 修（现场撞到的真 bug）：**一条都没有时会抛**（`快照[0].名` 对 undefined 取属性）
//   ⇒ 一个"检查仪器"自己崩了，还崩得看不懂。空快照是**正常情况**（新窗还没说过话）。
//   判据：**"没东西可查"必须印出来，不能抛。**
if (!快照.length) {
  console.log('⚠️ **这个会话里一条 request/header 都没有** ⇒ 它是新窗、还没发生过请求。')
  console.log('   ⇒ 这不是"没问题"，是"没东西可查" —— **不许当成通过**。')
  console.log('   换个有请求的会话再跑（`ls -t $DSH_HOME/sessions/*/session-*/`），或让窗口先说一句话。')
  process.exit(2)
}
const 哈希们 = [...new Set(快照.map((s) => s.哈希))]
const 数们 = [...new Set(快照.map((s) => s.数))]
console.log('★ **不同哈希 ' + 哈希们.length + ' 种** ／ 不同工具数 ' + 数们.length + ' 种（' + 数们.join('、') + '）')
if (哈希们.length === 1) {
  console.log('   ⇒ 工具数组**逐字节稳定** ⇒ 前缀不破 ⇒ 缓存可命中（第③问的正面证据）')
} else {
  console.log('   ⇒ 工具数组**变过 ' + 哈希们.length + ' 次** —— 若这些 header 属于同一会话，就是"每条新工具都会破缓存"的实测')
  // 找出差异
  const A = 快照[0].名, B = 快照[快照.length - 1].名
  const 只A = A.filter((x) => !B.includes(x)), 只B = B.filter((x) => !A.includes(x))
  console.log('   第一次有而最后一次没有：' + (只A.join('、') || '（无）'))
  console.log('   最后一次有而第一次没有：' + (只B.join('、') || '（无）'))
  // 顺序变了吗（集合一样但顺序不同也会破缓存）
  if (!只A.length && !只B.length && A.join('|') !== B.join('|')) console.log('   ★ **集合相同但**顺序变了** ⇒ 照样破缓存（对应 Codex PR#2611 那个坑）')
}
console.log('')
console.log('=== 全部 ' + (快照[0]?.数 || 0) + ' 个工具（按数组顺序）===')
const 名 = 快照[0]?.名 || []
for (let i = 0; i < 名.length; i += 6) console.log('  ' + 名.slice(i, i + 6).map((x) => x.padEnd(26)).join(' '))

// ── ★ 1009 加：**工具名体检门**（外部独立核判断落地）────────────────────────────
//   ★ 为什么叫"体检门"、不叫"注册闸"：引擎对**本地注册工具零校验**（`register()` 不查字符类、
//     wire 层逐字透传；全树唯一校验在 MCP 桥）⇒ **我们这个位置拦不住注册**，只能事后发现。
//     外部核 1009 原话：「如果不能阻止引擎注册，那就不要叫注册闸…改名叫**工具名体检门**。名字要诚实。」
//   ★ 判据（红线 20）：工具名只许 `[a-zA-Z0-9_-]`；带中文/怪字符 ⇒ API **400 把整包请求锯掉**
//     （**不是**"忽略那件工具"）＝**整窗收发全断**（1001 实炸近 2 小时 · 10 个 turn 全灭）。
//   ★ 扫**所有历史快照**的名字（不只第一个）—— 曾经出现过、后来下线的非法名同样是指控证据。
//   ★ `--静` ＝ 绿时零字（给"挂在必然时刻"用：只在红了才出声）。
const 静 = process.argv.includes('--静')
const 全部名 = [...new Set(快照.flatMap((s) => s.名))]
const 非法名 = 全部名.filter((n) => !/^[A-Za-z0-9_-]+$/.test(n))
const 过长名 = 全部名.filter((n) => /^[A-Za-z0-9_-]+$/.test(n) && n.length > 64)
if (非法名.length || 过长名.length) {
  console.log('')
  console.log('⛔ **工具名体检门 · 不合格**（红线 20：工具名＝给大模型的标识符，只许 [a-zA-Z0-9_-]）')
  for (const n of 非法名) console.log('     · 非法字符：' + JSON.stringify(n))
  for (const n of 过长名) console.log('     · 超 64 字符：' + JSON.stringify(n) + '（' + n.length + '）')
  console.log('   ⇒ 后果：不是"那件工具失效"，是 **API 400 锯掉整包请求** —— 他发的我收不到、我发的他看不见。')
  console.log('   ⇒ 处置：改注册名（按"机器读的标识符"起，不按给人的称呼），改完**要重启**才重新装配。')
  process.exitCode = 1
} else if (!静) {
  console.log('')
  console.log('✅ 工具名体检门：' + 全部名.length + ' 个名字全合规')
}

// ★ 结果落盘：给"必然时刻"读（`库.mjs` 一屏只读这个文件、**不重算判据** —— 判据只此一处，
//   见记忆 `0muu6zsae`「判据/校验代码只能有一处」）。带时间戳 ⇒ 读的人能判"陈不陈旧"。
// ★ 1009 夜修（红线 19④ · 病名"自测把生产写脏"）：落盘原来**写死**
//   `new URL('../工具/台账/接续/工具名体检.json', import.meta.url)` ⇒ **不认假区**
//   ⇒ 一做自测就往**生产**那张 json 上写。改用 `根.mjs`：① 认 `DSH_KICKOFF_WS`／`DSH_ROOT`
//   （假区只写假区）② 生产下逐字等于原路径（默认不变）。判据一个字没动。
try {
  writeFileSync(path.join(根(), '台账/接续/工具名体检.json'), JSON.stringify({
    at: new Date().toISOString().slice(0, 16).replace('T', ' '),
    日志: 日志路径, 总数: 全部名.length, 非法: 非法名, 过长: 过长名,
  }, null, 1))
} catch { /* 落盘失败不影响体检本身的结论 */ }
