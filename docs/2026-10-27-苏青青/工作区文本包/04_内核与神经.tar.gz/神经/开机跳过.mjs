#!/usr/bin/env node
/**
 * 开机跳过.mjs —— 把「开机静默跳过」做成一声响（老板 2026-10-01：「我们来优化这个」）
 *
 * 它治的病（B 路体检抓到 · 我在日志里核到原文）：
 *   宿主有「手机版第三方开机隔离（G3）」：`@deepseek-ai/*`、`@dsh-android/*`、
 *   `dsh-undo-savepoint`、`dshmarketplace-plugin` **失败即致命**；**其余（含我们自己的 `@dsh-user/*`）
 *   失败就被静默跳过**，而且**跳过额度只有 8 条**（`dsh-app-boot` 里的 `DSH_MOBILE_BOOT_SKIP_LIMIT`）。
 *   ⇒ **前 8 条坏掉一声不响**（唯一痕迹是引擎日志里一句没人读的 warn），**坏到第 9 条＝整机起不来**。
 *   实况（1001 我自己在 engine.log 核到）：`@dsh-user/dsh-whale-pet`（桌宠）**每次开机都被跳过**，
 *   因为**包不在盘上** —— 而它在装配树里还好好挂着（`cordis.patch.yml:282-283`）。
 *
 * 两条判据（都不靠"我记得"）：
 *   ① **日志面**：引擎日志里 `failed to load during boot and will be skipped` + `Broken: <包名>` 的**真事**；
 *   ② **树面（预测下一次开机）**：装配树里挂着、但盘上没有那个包的**用户面行** ⇒ 下次开机必然被跳过。
 *
 * ★ 2026-10-03 修假红（老板令「先把那个假红修了」）：
 *   病＝**当前 engine.log 已经干净，它却拿轮转日志（engine.log.1/.2）里的旧记录报 `⛔ 已被静默跳过`**
 *   —— 显示与设备实际不一致（撞红线 10）。根因：`日志面()` 把所有轮转日志一锅端、`查()` 不分时间。
 *   修法＝**分级**：命中**当前** `engine.log` ⇒ 报「这次开机被静默跳过」；**只在轮转日志里** ⇒ 报
 *   「🕘 历史痕迹（最近一次开机已干净）」——旧账仍留痕，但不再冒充现状。
 *
 * 用法：node 神经/开机跳过.mjs [查] ｜ selftest
 * 退出码：0 正常；发现"已跳过"或"将要跳过"仍返回 0（**这是只读仪器，不是闸**）；用法错 2。
 */
import fs from 'node:fs'
import path from 'node:path'

const FILES = '/data/data/com.dsharnessmobile.shell/files'
const 家 = process.env.DSH_HOME || FILES + '/home/.dsh'
const 档 = path.join(家, 'profiles', 'web')
const 树 = path.join(档, 'cordis.patch.yml')
const NM = path.join(档, 'node_modules')

// 致命集（G3：这些失败 ⇒ 引擎不启动）；其余＝可跳过池
const 致命 = [/^@deepseek-ai\//, /^@dsh-android\//, /^dsh-undo-savepoint$/, /^dshmarketplace-plugin$/]
const 可跳池 = (名) => !致命.some((r) => r.test(名))

function 读额度() {
  // 从宿主源码读真值（读不到就如实标"没读到"）
  const f = path.join(FILES, 'home/.dsh/profiles/web/node_modules/@deepseek-ai/dsh-app-boot/lib/index.js')
  const 候选 = [f, FILES + '/usr/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-app-boot/lib/index.js']
  for (const p of 候选) {
    try {
      const m = fs.readFileSync(p, 'utf8').match(/DSH_MOBILE_BOOT_SKIP_LIMIT\s*=\s*(\d+)/)
      if (m) return { 值: Number(m[1]), 出处: p }
    } catch {}
  }
  return { 值: 8, 出处: '（源码没读到，用 B 路体检报的 8 —— 未自证）' }
}

function 找日志() {
  const out = []
  try {
    for (const f of fs.readdirSync(FILES)) if (/^engine\.log(\.\d+)?$/.test(f)) out.push(path.join(FILES, f))
  } catch {}
  return out.sort()
}

function 日志面() {
  const 跳过 = new Map() // 包名 -> {次数, 最新, 文件:[]}
  for (const f of 找日志()) {
    let 文 = ''
    try { 文 = fs.readFileSync(f, 'utf8') } catch { continue }
    const 名 = path.basename(f)
    for (const line of 文.split('\n')) {
      if (!/failed to load during boot and will be skipped/.test(line)) continue
      const m = line.match(/Broken:\s*([^\s]+)/)
      if (!m) continue
      const n = m[1]
      const e = 跳过.get(n) || { 次数: 0, 最新: '', 文件: [] }
      e.次数++; e.最新 = 名
      if (!e.文件.includes(名)) e.文件.push(名)
      跳过.set(n, e)
    }
  }
  return 跳过
}

function 树面() {
  let 文 = ''
  try { 文 = fs.readFileSync(树, 'utf8') } catch { return { 行: [], 池: 0, 缺: [] } }
  const 行 = []
  const lines = 文.split('\n')
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/-\s*id:\s*(\S+)/)
    if (!m) continue
    const n2 = (lines[i + 1] || '').match(/name:\s*['"]?([^'"\s]+)['"]?/)
    if (!n2) continue
    const 包 = n2[1].replace(/^['"]|['"]$/g, '')
    if (/^@deepseek-ai\/|^@dsh-android\//.test(包)) continue // 出厂件：致命集／从引擎树解析，不算"盘上缺"
    行.push({ id: m[1], 包, 行号: i + 1 })
  }
  const 池 = 行.filter((r) => 可跳池(r.包))
  // 解析根不只 profile/node_modules 一个：还有 .dsh-module-fallback 与引擎树
  const 根 = [NM, path.join(档, '.dsh-module-fallback'), path.join(NM, '@deepseek-ai/dsh/node_modules')]
  const 在盘 = (名) => 根.some((r) => fs.existsSync(path.join(r, 名)))
  const 缺 = 池.filter((r) => !在盘(r.包))
  // 被禁用的行不算（disabled: true）
  return { 行, 池: 池.length, 缺 }
}

function 查() {
  const 额 = 读额度()
  const 跳 = 日志面()
  const t = 树面()
  console.log('\n🚪 开机跳过体检（G3 静默隔离）')
  console.log('  额度：可跳过池上限 **' + 额.值 + '** 条 ｜ 出处 ' + 额.出处)
  console.log('  装配树：用户面可跳过行 **' + t.池 + '** 条 ⇒ 再坏 ' + Math.max(0, t.池 - 额.值) + ' 条就顶到上限')
  if (跳.size) {
    for (const [n, e] of 跳) {
      const 本次 = e.文件.includes('engine.log')
      if (本次) {
        console.log('  ⛔ **这次开机被静默跳过**：' + n + '（当前 engine.log 里就有，共 ' + e.次数 + ' 次）')
      } else {
        console.log('  🕘 历史痕迹（**最近一次开机已干净**）：' + n + ' —— 只在轮转日志 ' + e.文件.join('／') + ' 里（共 ' + e.次数 + ' 次）⇒ 旧账，别当现状')
      }
    }
  } else console.log('  日志面：最近几份 engine.log 里没有跳过记录（**≠ 没坏过** —— 只覆盖还留着的轮转日志）')
  if (t.缺.length) {
    console.log('  树面预测（**下次开机必然被跳过**）：')
    for (const r of t.缺) console.log('    ⚠️ ' + r.包 + ' ｜ 挂在 cordis.patch.yml:' + r.行号 + ' ｜ **包不在盘上**（' + path.join('node_modules', r.包) + ' 不存在）')
    console.log('    ⇒ 要么把包装回、要么把那两行摘掉（**别让它挂着当稻草人**）')
  } else console.log('  树面：挂着的用户面行，包都在盘上 ✅')
}

function selftest() {
  const 样本 = 'dsh: 2 third-party plugin failed to load during boot and will be skipped; the engine continues. Broken: @dsh-user/dsh-whale-pet (dsh-mobile third-party boot isolation (G3)).'
  const m = 样本.match(/Broken:\s*([^\s]+)/)
  console.log('  解析 Broken 名：' + (m && m[1] === '@dsh-user/dsh-whale-pet' ? '✅' : '❌'))
  console.log('  致命判定：' + (可跳池('@dsh-user/dsh-x') && !可跳池('@deepseek-ai/dsh-x') && !可跳池('dsh-undo-savepoint') ? '✅' : '❌'))
  console.log('  额度正则：' + (/DSH_MOBILE_BOOT_SKIP_LIMIT\s*=\s*(\d+)/.exec('const DSH_MOBILE_BOOT_SKIP_LIMIT = 8')?.[1] === '8' ? '✅' : '❌'))
  // ★ 1003 加：分级判据（本次 vs 历史）—— 假红的反证样本
  const 本次 = { 文件: ['engine.log'] }
  const 历史 = { 文件: ['engine.log.2'] }
  const 判 = (e) => e.文件.includes('engine.log') ? '本次' : '历史'
  console.log('  分级判据：' + (判(本次) === '本次' && 判(历史) === '历史' ? '✅（当前日志⇒本次／只在轮转⇒历史）' : '❌'))
  const ok = m && m[1] === '@dsh-user/dsh-whale-pet' && 可跳池('@dsh-user/dsh-x') && !可跳池('@deepseek-ai/dsh-x') && 判(本次) === '本次' && 判(历史) === '历史'
  console.log('结果：4/4 ' + (ok ? '✅' : '❌'))
}

const 动词 = process.argv[2] || '查'
if (动词 === 'selftest') selftest()
else if (动词 === '查') 查()
else { console.log('用法：node 神经/开机跳过.mjs [查|selftest]'); process.exit(2) }
