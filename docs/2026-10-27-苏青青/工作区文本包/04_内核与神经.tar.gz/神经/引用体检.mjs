#!/usr/bin/env node
/* 引用体检 —— 「我说的路径，盘上真在吗」（2026-10-10 建 · 治老板点名的「幻觉控制」）
 *
 * 【病灶 · 当场事实】我 1010 犯的幻觉里最硬的一类：**说了一个盘上不存在的文件名** ——
 *   我在报表里写了一个**盘上没有的名字**（`台账/接续/` 下的「交接单_1010_两个最大问题.md」），
 *   而真名是 `长期任务_1010_两个最大问题.md`。（⚠️ 这里**故意不写全整条假路径**：写全会让连续体检
 *   把我这句注释当成"真引用"报悬空 —— 1010 建件当天就踩到，当场修。）
 *   老板 1008 原话：「幻觉太严重了，**你又在哪里？以为的东西去当前提**」。
 * 【判据】输入＝**我的回复**（默认取本工作区最近日志的末条回复）⇒ 抽出像工作区路径的串
 *   ⇒ **逐个核在不在盘上**。查无此件 ⇒ 报红（rc=1），可进 `台账/接续/未结红.json` ⇒ 硬停
 *   （**复用既有放行链，不另造门** —— 与 1010 凌晨「悬空进报警」同一口径）。
 * 【复用】读取器**直接借** `报告体检.mjs` 的 `找日志／末条我的回复`（先查已有的，不重造）。
 * 【口径 · 诚实边界】① 只认**带目录前缀**的路径（`工具/…`、`台账/…` 这类）；裸文件名不认（会误伤）。
 *   ② 它只能逮「路径不存在」这一类幻觉；**数字对不对、事有没有做**它管不着（那两类仍需我去核）。
 *   ③ 判据＝盘上真有什么（`existsSync`），不是我以为的清单。
 * 用法：node 神经/引用体检.mjs               # 本工作区最近日志的末条我的回复
 *       node 神经/引用体检.mjs <文件>         # 扫这个文件（如落盘的报告）
 *       node 神经/引用体检.mjs --文本 "…"     # 扫这段文本
 *       node 神经/引用体检.mjs --自测          # 正证＋反证
 */
import fs from 'node:fs'
import path from 'node:path'

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const 前缀 = ['工具', '台账', '内核', '记忆', '调研', '文档', '桌面', '桌宠项目', '插件补丁备份', '_backup', '文档库']
const 式 = new RegExp('(?:' + 前缀.join('|') + ')\\/[\\w\\u4e00-\\u9fa5.\\-\\/]*\\.(?:mjs|js|cjs|md|json|jsonl|sh|ya?ml|txt|png|zst)', 'g')

/** 抽出文本里像工作区路径的串（去重；不做"我以为是路径"的猜测） */
export function 抽路径(t) {
  const 粗 = [...new Set(String(t || '').match(式) || [])]
  // 去掉尾部的分隔符（`工具/x/` 这种目录写法留给下一层判）
  return 粗.map((x) => x.replace(/[.,;，。；]+$/, ''))
}

/** 逐个核存在性：盘上没有的 ⇒ 缺 */
export function 核(文本, ws = WS) {
  const 在 = [], 缺 = []
  for (const p of 抽路径(文本)) (fs.existsSync(path.join(ws, p)) ? 在 : 缺).push(p)
  return { 在, 缺, 合格: 缺.length === 0 }
}

/* ★ 入口守卫（记忆 0mupkb1z6：新仪器被 import 时 process.argv 还是父进程的 ⇒ 会替父进程跑自测并 exit，
   把宿主钩子当场掐断）⇒ 只有本件被直接执行时才跑主流程。 */
const 主入口 = !!process.argv[1] && process.argv[1].endsWith('引用体检.mjs')

if (主入口) {
  const a = process.argv.slice(2)
  if (a.includes('--自测')) {
    // 假路径**动态拼**（写死会让连续体检当成"真引用"报悬空 —— 1010 建件当天实踩）
    const 假 = '我改过 `台账/接续/' + '交接单_1010_两个最大问题.md`，也看了 `神经/引用体检.mjs`。'
    const r1 = 核(假)
    const 真 = '报告门在 `神经/报告体检.mjs`，红线本在 `$DSH_HOME/AGENTS.md`，索引在 `台账/做法库.md`。'
    const r2 = 核(真)
    const 正 = !r1.合格 && r1.缺.some((x) => x.includes('交接单_1010'))
    const 反 = r2.合格 && r2.在.length >= 2
    console.log((正 ? '✅' : '❌') + ' 正证（文本里混一个假路径 ⇒ 必须逮到它）：缺=' + JSON.stringify(r1.缺))
    console.log((反 ? '✅' : '❌') + ' 反证（全是真路径 ⇒ 必须绿）：在=' + r2.在.length + ' 处，缺=' + JSON.stringify(r2.缺))
    process.exit(正 && 反 ? 0 : 1)
  }

  const 文flag = a.indexOf('--文本')
  let 文本 = null, 源 = ''
  if (文flag >= 0) { 文本 = a[文flag + 1] || ''; 源 = '--文本' }
  else if (a[0] && fs.existsSync(a[0])) { 文本 = fs.readFileSync(a[0], 'utf8'); 源 = a[0] }
  else if (a.includes('--报告')) {
    // ★ 扫**最近一份正式报告**（我递给老板的东西 —— 幻觉最贵的地方；轮末自检走这个口）
    const m = await import('./报告体检.mjs')
    const 日志 = m.找日志(WS)
    if (日志) {
      const r0 = m.末条像报告(日志)
      if (r0 && r0.文本) { 文本 = r0.文本; 源 = '最近一份正式报告（倒数第 ' + (r0.倒数第 || '?') + ' 条）' }
      else { 文本 = m.末条我的回复(日志) || ''; 源 = '〔最近没有正式报告 ⇒ 退回末条我的回复〕' }
    }
  }
  else {
    const m = await import('./报告体检.mjs')
    const 日志 = m.找日志(WS)
    if (日志) {
      文本 = m.末条我的回复(日志) || ''
      源 = '本工作区最近日志的末条我的回复（' + path.basename(path.dirname(日志)) + '）'
    }
  }
  if (文本 == null || 文本 === '') { console.log('引用体检·读不到输入（没有日志／文本为空）'); process.exit(2) }
  const r = 核(文本)
  if (r.合格) {
    console.log('引用体检 ✅ 引用的 ' + r.在.length + ' 处路径**全部在盘上**｜源：' + 源)
    process.exit(0)
  }
  console.log('🔴 引用体检：**' + r.缺.length + ' 处路径盘上没有**（源：' + 源 + '）')
  for (const x of r.缺) console.log('    · ' + x)
  console.log('   ⇒ 这是幻觉的硬形态（我说了一个不存在的件）。核对我到底想说什么：`ls` 一下同目录，或改说真名。')
  process.exit(1)
}
