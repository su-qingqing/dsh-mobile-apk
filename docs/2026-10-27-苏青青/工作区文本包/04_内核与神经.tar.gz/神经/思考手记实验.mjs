#!/usr/bin/env node
// ═══ 思考手记实验（老板 1005 夜令：动手做实验，验三条 —— ①成没成 ②省没省钱 ③跟现在比有没有变化）═══
//
// 架构（老板定的）：**桌上的纸条（手记）＋ 墙上的黑板（池子）**；核心不是管子，是**焊点**：
//   把每轮的思考**炼成一句手记**，让下一步接得上 —— 而不是把整段思考原样背来背去。
// 判据（老板亲口）：**人味与思考效率不变，把钱省了**。
//
// 本实验用**多轮**跑（一步的实验已做过：留要点接得上、只留指针断）：
//   任务＝逐步排除（6 人名单，逐轮给排除条件，每轮问"现在还剩谁"）—— 有唯一答案，且**强依赖历轮累积**。
//   两臂**只差一处**：历史里的 `reasoning_content` 带什么 ——
//     A 全量（＝我们现在）：历轮思考原样带上
//     B 手记（＝新案）  ：只带**每轮自己写的『本轮要点』**，整段思考剥掉
//   每轮都要求模型在思考末尾写一行「本轮要点：…」⇒ 抠出来当手记（＝"我自己写的纸条"）。
//
// 纪律：只读研究，不碰生产件；凭证只找不打印；花费约几分钱。

import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs'

const 家 = process.env.HOME || '/data/data/com.dsharnessmobile.shell/files/home'
const DSH = process.env.DSH_HOME || `${家}/.dsh`
const 候选文件 = [`${DSH}/.credentials`, `${家}/.dsh/.credentials`, `${家}/.deepseek`]
try {
  const vault = `${DSH}/undo-snapshots/auto/env-vault`
  if (existsSync(vault)) {
    const vs = readdirSync(vault).filter((f) => f.endsWith('.env')).map((f) => `${vault}/${f}`)
      .sort((a, b) => (statSync(b).mtimeMs || 0) - (statSync(a).mtimeMs || 0))
    候选文件.push(...vs)
  }
} catch { /* ignore */ }
function 找凭据() {
  let key = process.env.DEEPSEEK_API_KEY || ''
  let base = process.env.DEEPSEEK_BASE_URL || ''
  let 来源 = key ? '本进程环境' : ''
  if (!key) {
    for (const f of 候选文件) {
      try {
        if (!existsSync(f)) continue
        const t = readFileSync(f, 'utf8')
        const m = t.match(/DEEPSEEK_API_KEY\s*[=:]\s*["']?([A-Za-z0-9_-]{16,})/)
        if (m) { key = m[1]; 来源 = f; break }
      } catch { /* ignore */ }
    }
  }
  return { key, base, 来源 }
}
const { key: KEY, base: BASE0, 来源 } = 找凭据()
const BASE = (BASE0 || 'https://api.deepseek.com').replace(/\/$/, '')
const MODEL = process.env.DSH_EXP_MODEL || 'deepseek-flash'
if (!KEY) { console.error('✗ 找不到 key'); process.exit(1) }
console.log(`凭据来源：${来源}（长度 ${KEY.length}，不打印）｜${BASE}｜${MODEL}`)

const tools = [{
  type: 'function',
  function: { name: 'noop', description: '占位工具（让请求形态与生产一致）', parameters: { type: 'object', properties: {} } },
}]

async function 发(messages) {
  const r = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${KEY}` },
    body: JSON.stringify({ model: MODEL, messages, tools, reasoning_effort: 'high', max_tokens: 500, stream: false }),
  })
  const txt = await r.text()
  if (!r.ok) throw new Error(`HTTP ${r.status}: ${txt.slice(0, 200)}`)
  const j = JSON.parse(txt)
  return { m: j.choices[0].message, u: j.usage || {} }
}

// ── 案子：6 人，逐轮排除，最后只剩一个 ──
const 名单 = '阿元(男·35岁)、小满(女·28岁)、老周(男·52岁)、林岚(女·45岁)、程野(男·45岁)、苏禾(女·33岁)'
const 各轮 = [
  { 问: `名单：${名单}。\n【第 1 条】凶手不是女性。\n请回答：现在还剩哪些嫌疑人？只列出名字。`, 期望: ['阿元', '老周', '程野'] },
  { 问: '【第 2 条】凶手年龄大于 40 岁。\n请回答：现在还剩哪些嫌疑人？只列出名字。', 期望: ['老周', '程野'] },
  { 问: '【第 3 条】凶手不姓"老"。\n请回答：现在还剩哪些嫌疑人？只列出名字。', 期望: ['程野'] },
]
const 终局 = { 问: '综合前面所有条件，凶手是谁？只回答名字。', 期望: ['程野'] }

const 手记要求 = ''   // ★ 修：不再要求它另写要点（与「只列名字」打架）—— 手记＝它这一轮的正文结论本身

function 抠手记(思考) {
  const m = (思考 || '').match(/本轮要点[：:]\s*([^\n]+)/)
  return m ? m[1].trim() : null
}

async function 跑一臂(臂名) {
  let 历史 = []
  let 累计 = { prompt: 0, completion: 0, reasoning字: 0, 手记字: 0 }
  const 明细 = []
  for (const 轮 of 各轮.concat([终局])) {
    const msgs = [...历史, { role: 'user', content: 轮.问 + (轮 === 终局 ? '' : 手记要求) }]
    const { m, u } = await 发(msgs)
    const 思考 = m.reasoning_content || ''
    const 答 = (m.content || '').trim()
    累计.prompt += u.prompt_tokens ?? 0
    累计.completion += u.completion_tokens ?? 0
    累计.reasoning字 += 思考.length
    const 手记 = 抠手记(思考)
    if (手记) 累计.手记字 += 手记.length
    const 命中 = 轮.期望.filter((x) => 答.includes(x))
    const 对 = 命中.length === 轮.期望.length && !/阿元|小满|老周|林岚|苏禾/.test(答.replace(new RegExp(轮.期望.join('|'), 'g'), '')) === true
    const 判 = 轮.期望.every((x) => 答.includes(x)) && 命中.length === 轮.期望.length ? '✅' : '❌'
    明细.push({ 答: 答.replace(/\n/g, ' ').trim(), 判, 手记: (m.content || '').trim().replace(/\n/g, ' ') })

    const asst = { role: 'assistant', content: m.content || '' }
    if (臂名 === 'A全量') asst.reasoning_content = 思考
    else asst.reasoning_content = `（本轮手记 · 结论：${(m.content || '').trim()}）`   // ★ 纸条＝上一轮的结论
    历史 = [...历史, { role: 'user', content: 轮.问 + (轮 === 终局 ? '' : 手记要求) }, asst]
  }
  return { 臂名, 累计, 明细 }
}

console.log('\n════ 跑 A 臂（全量回传 · 现状）════')
const A = await 跑一臂('A全量')
console.log('\n════ 跑 B 臂（手记 · 新案）════')
const B = await 跑一臂('B手记')

const fmt = (n) => n.toLocaleString('en-US')
console.log('\n═══ 对照表（两臂只差"历史思考带什么"）═══\n')
console.log('轮次    A 全量（现状）答的                 B 手记（新案）答的                 期望')
console.log('─'.repeat(104))
A.明细.forEach((d, i) => {
  const e = 各轮.concat([终局])[i]
  console.log(`第${i + 1}轮   ${(d.判 + ' ' + d.答).padEnd(32)} ${(B.明细[i].判 + ' ' + B.明细[i].答).padEnd(32)} ${e.期望.join('/')}`)
})
console.log('\nB 臂每轮的手记（＝它自己写的"桌上纸条"）：')
B.明细.forEach((d, i) => console.log(`  第${i + 1}轮：${d.手记}`))

console.log('\n═══ 三条判据 ═══')
const 成A = A.明细.every((d) => d.判 === '✅')
const 成B = B.明细.every((d) => d.判 === '✅')
console.log(`① 成没成：A（现状）${成A ? '全对 ✅' : '有错 ❌'} ｜ B（新案）${成B ? '全对 ✅' : '有错 ❌'} ⇒ ${成B ? '新案成立' : '★新案没成立，别接入'}`)
const 省 = 1 - B.累计.prompt / A.累计.prompt
console.log(`② 省不省：prompt_tokens  A ${fmt(A.累计.prompt)} ｜ B ${fmt(B.累计.prompt)} ⇒ 省 ${(省 * 100).toFixed(1)}%`)
console.log(`   （对照：它们各自"背"的思考字数 A ${fmt(A.累计.reasoning字)} 字 ｜ B 只背手记 ${fmt(B.累计.手记字)} 字）`)
console.log(`③ 跟现在比变没变：${成A && 成B ? '两臂答案**逐轮一致** ⇒ 效果没掉（人味/效率这一维，本轮只看答案对错）' : '★有差异，要人看'}`)
console.log('\n注：省钱只算 prompt_tokens（输入侧）；单价按官方价目另折。completion 两臂基本相当。')
