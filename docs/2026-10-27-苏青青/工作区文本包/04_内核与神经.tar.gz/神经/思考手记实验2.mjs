#!/usr/bin/env node
// ═══ 思考手记实验 v2（老板 1005 夜令：**10 次 · 每次至少烧 1 万 token · 先拿真实数据再推结论**）═══
//
// 与 v1（`思考手记实验.mjs`）的差别 —— 老板说"量级太小测不出真东西"：
//   ① 规模做上来：**20 人名单 · 18 轮**（历史累积 ⇒ A 臂天然出现 O(n²) 膨胀，正是要测的东西）
//   ② **重复 10 次**（每次＝独立两臂各跑一遍）
//   ③ **自带 token 守卫**：每次实验结束后核"两臂合计 token ≥ 10000"，不达标如实报红字
//   ④ 额外记两个诊断量：**A 臂每轮 prompt 增量**（验 O(n²)）／**B 臂省下来的比例**
//
// 两臂只差一处：历史里 assistant 消息的 `reasoning_content` 带什么 ——
//   A 全量（≈现状）：历轮思考原样带上
//   B 手记（≈新案）：只带"（本轮手记 · 结论：<上一轮正文结论>）"
//
// 纪律：只读研究、不碰生产件；凭证只找不打印。

import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs'

const 家 = process.env.HOME || '/data/data/com.dsharnessmobile.shell/files/home'
const DSH = process.env.DSH_HOME || `${家}/.dsh`
const 候选 = [`${DSH}/.credentials`, `${家}/.dsh/.credentials`, `${家}/.deepseek`]
try {
  const vault = `${DSH}/undo-snapshots/auto/env-vault`
  if (existsSync(vault)) {
    readdirSync(vault).filter((f) => f.endsWith('.env')).map((f) => `${vault}/${f}`)
      .sort((a, b) => (statSync(b).mtimeMs || 0) - (statSync(a).mtimeMs || 0)).forEach((f) => 候选.push(f))
  }
} catch { /* ignore */ }
let KEY = process.env.DEEPSEEK_API_KEY || '', BASE0 = process.env.DEEPSEEK_BASE_URL || ''
if (!KEY) for (const f of 候选) { try { if (!existsSync(f)) continue; const m = readFileSync(f, 'utf8').match(/DEEPSEEK_API_KEY\s*[=:]\s*["']?([A-Za-z0-9_-]{16,})/); if (m) { KEY = m[1]; break } } catch {} }
const BASE = (BASE0 || 'https://api.deepseek.com').replace(/\/$/, '')
const MODEL = process.env.DSH_EXP_MODEL || 'deepseek-flash'
if (!KEY) { console.error('✗ 找不到 key'); process.exit(1) }

const tools = [{ type: 'function', function: { name: 'noop', description: '占位工具（请求形态与生产一致）', parameters: { type: 'object', properties: {} } } }]
const 次数 = Number(process.env.EXP_TIMES || 10)

async function 发(messages, 重试 = 3) {
  for (let i = 0; i < 重试; i++) {
    try {
      const r = await fetch(`${BASE}/chat/completions`, {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${KEY}` },
        body: JSON.stringify({ model: MODEL, messages, tools, reasoning_effort: 'high', max_tokens: 600, stream: false }),
      })
      const t = await r.text()
      if (!r.ok) { if (i === 重试 - 1) throw new Error(`HTTP ${r.status}: ${t.slice(0, 150)}`); await new Promise((s) => setTimeout(s, 2000)); continue }
      const j = JSON.parse(t)
      return { m: j.choices[0].message, u: j.usage || {} }
    } catch (e) { if (i === 重试 - 1) throw e; await new Promise((s) => setTimeout(s, 2000)) }
  }
}

// ── 造案子：20 人 · 逐轮排除到剩 1 人（确定性生成，可复现）──
function 造案子(seed) {
  let s = seed
  const rnd = () => (s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff
  const 姓 = ['赵', '钱', '孙', '李', '周', '吴', '郑', '王', '冯', '陈', '褚', '卫', '蒋', '沈', '韩', '杨', '朱', '秦', '尤', '许']
  const 名 = ['岩', '澜', '野', '禾', '舟', '岚', '川', '宁', '亭', '澈', '陌', '岑', '序', '砚', '穗', '泠', '峭', '昀', '漾', '珑']
  const 性别 = ['男', '女'], 城 = ['京', '沪', '粤', '川', '陕'], 职业 = ['医师', '教员', '匠人', '账房'], 生肖 = ['鼠', '牛', '虎', '兔', '龙']
  const 人 = []
  for (let i = 0; i < 20; i++) {
    人.push({
      名: 姓[i] + 名[(i * 7) % 20],
      性别: 性别[i % 2],
      城: 城[(i * 3) % 5],
      职业: 职业[(i * 5) % 4],
      生肖: 生肖[(i * 11) % 5],
      岁: 24 + ((i * 13) % 40),
    })
  }
  const 目标 = 人[Math.floor(rnd() * 20)]
  const 条件池 = [
    { 说: '凶手不是女性', 留: (p) => p.性别 === '男' },
    { 说: '凶手岁数在 40 以上', 留: (p) => p.岁 >= 40 },
    { 说: '凶手来自京、沪或粤', 留: (p) => ['京', '沪', '粤'].includes(p.城) },
    { 说: '凶手的职业不是教员', 留: (p) => p.职业 !== '教员' },
    { 说: '凶手不属鼠、牛、虎', 留: (p) => !['鼠', '牛', '虎'].includes(p.生肖) },
    { 说: '凶手来自川或陕', 留: (p) => ['川', '陕'].includes(p.城) },
    { 说: '凶手属龙或兔', 留: (p) => ['龙', '兔'].includes(p.生肖) },
    { 说: '凶手是女性', 留: (p) => p.性别 === '女' },
    { 说: '凶手岁数在 40 以下', 留: (p) => p.岁 < 40 },
    { 说: '凶手是医师或账房', 留: (p) => ['医师', '账房'].includes(p.职业) },
    { 说: '凶手不来自京', 留: (p) => p.城 !== '京' },
    { 说: '凶手岁数是单数', 留: (p) => p.岁 % 2 === 1 },
    { 说: '凶手属虎或龙', 留: (p) => ['虎', '龙'].includes(p.生肖) },
    { 说: '凶手不姓赵、钱、孙', 留: (p) => !['赵', '钱', '孙'].includes(p.名[0]) },
    { 说: '凶手不是匠人', 留: (p) => p.职业 !== '匠人' },
    { 说: '凶手岁数能被 3 整除', 留: (p) => p.岁 % 3 === 0 },
    { 说: '凶手属牛或兔', 留: (p) => ['牛', '兔'].includes(p.生肖) },
    { 说: '凶手是账房', 留: (p) => p.职业 === '账房' },
  ]
  let 剩 = 人.slice()
  const 轮 = []
  for (const c of 条件池) {
    const 新 = 剩.filter(c.留)
    if (新.length === 剩.length) continue            // 这条不排除人 ⇒ 跳过
    if (!新.includes(目标)) continue                  // 这条会把目标排掉 ⇒ 跳过
    剩 = 新
    轮.push({ 说: c.说, 期望: 剩.map((p) => p.名) })
    if (剩.length === 1) break
  }
  return { 名单: 人, 目标, 轮 }
}

const 名单文本 = (人) => 人.map((p) => `${p.名}(${p.性别}·${p.岁}岁·${p.城}·${p.职业}·属${p.生肖})`).join('、')

async function 跑一臂(案子, 臂名) {
  let 历史 = [], prompt = 0, completion = 0, 全对 = true, 每轮 = []
  for (let i = 0; i < 案子.轮.length; i++) {
    const r = 案子.轮[i]
    const 问 = i === 0
      ? `名单：${名单文本(案子.名单)}。\n【第 1 条】${r.说}。\n现在还剩哪些嫌疑人？只列名字。`
      : `【第 ${i + 1} 条】${r.说}。\n现在还剩哪些嫌疑人？只列名字。`
    const { m, u } = await 发([...历史, { role: 'user', content: 问 }])
    prompt += u.prompt_tokens ?? 0; completion += u.completion_tokens ?? 0
    const 答 = (m.content || '').trim()
    const 对 = r.期望.every((x) => 答.includes(x)) && 答.replace(new RegExp(r.期望.join('|'), 'g'), '').match(/[\u4e00-\u9fa5]{2}/g) === null
    if (!对) 全对 = false
    每轮.push({ 轮: i + 1, prompt: u.prompt_tokens ?? 0, 对 })
    const asst = { role: 'assistant', content: 答 }
    if (臂名 === 'A') asst.reasoning_content = m.reasoning_content || ''
    else asst.reasoning_content = `（本轮手记 · 结论：${答}）`
    历史.push({ role: 'user', content: 问 }, asst)
  }
  return { prompt, completion, 全对, 每轮 }
}

console.log(`模型 ${MODEL} ｜ 重复 ${次数} 次 ｜ 每次＝两臂各跑一整案（20 人名单，逐轮排除到剩 1）\n`)
const 汇总 = []
for (let t = 1; t <= 次数; t++) {
  const 案子 = 造案子(1000 + t * 7919)
  const A = await 跑一臂(案子, 'A')
  const B = await 跑一臂(案子, 'B')
  const 合计 = A.prompt + A.completion + B.prompt + B.completion
  const 省 = 1 - B.prompt / A.prompt
  汇总.push({ t, 轮数: 案子.轮.length, A, B, 合计, 省 })
  const 守卫 = 合计 >= 10000 ? '✅' : '⚠️不足1万'
  console.log(`第 ${t} 次 ｜ ${案子.轮.length} 轮 ｜ A ${A.全对 ? '✅' : '❌'} prompt ${A.prompt} ｜ B ${B.全对 ? '✅' : '❌'} prompt ${B.prompt} ｜ 省 ${(省 * 100).toFixed(1)}% ｜ 两臂合计 ${合计} ${守卫}`)
}

const 平 = (f) => 汇总.reduce((s, x) => s + f(x), 0) / 汇总.length
const A对 = 汇总.filter((x) => x.A.全对).length, B对 = 汇总.filter((x) => x.B.全对).length
const 省均 = 平((x) => x.省)
const 达万 = 汇总.filter((x) => x.合计 >= 10000).length
console.log('\n════════ 十次汇总 ════════')
console.log(`① 成没成：A 全对 ${A对}/${次数} ｜ B 全对 ${B对}/${次数}`)
console.log(`② 省不省：prompt 累计 A ${汇总.reduce((s, x) => s + x.A.prompt, 0).toLocaleString()} ｜ B ${汇总.reduce((s, x) => s + x.B.prompt, 0).toLocaleString()} ⇒ 平均省 ${(省均 * 100).toFixed(1)}%（${汇总.map((x) => (x.省 * 100).toFixed(0) + '%').join(' / ')}）`)
console.log(`③ 跟现在比：${A对 === 次数 && B对 === 次数 ? '两臂十次全对 ⇒ 效果打平' : `A ${A对}/10 vs B ${B对}/10 ⇒ 差 ${Math.abs(A对 - B对)} 次`}`)
console.log(`④ 量级守卫：两臂合计 ≥1 万 token 的 = ${达万}/${次数}（平均每次 ${Math.round(平((x) => x.合计)).toLocaleString()} token）`)
const 首案 = 汇总[0]
console.log(`⑤ O(n²) 证据（第 1 次 A 臂每轮 prompt）：${首案.A.每轮.map((r) => r.prompt).join(' → ')}`)
console.log(`   （B 臂同轮）：${首案.B.每轮.map((r) => r.prompt).join(' → ')}`)
