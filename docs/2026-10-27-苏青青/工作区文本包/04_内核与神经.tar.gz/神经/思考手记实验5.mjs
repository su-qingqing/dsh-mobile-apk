#!/usr/bin/env node
// ═══ 思考手记实验 v5（小规模 · 6 轮 · 老板 1006 令「不必按 1 万托底，给个三四千的」）═══
// 原 ═══ 思考手记实验 v3（修 v2 的量级问题：v2 实跑只 3~5 轮 ⇒ 8/10 次不足 1 万 token）═══
//
// v2 的错：条件池固定 18 条、却逐条"试"（会把目标排掉/不排除人的被跳过）⇒ 有效轮数塌成 3~5。
// v3 的修：**以目标为准反向生成 18 轮** —— 每轮排除**一个非目标的人**（19 个别人够用），
//   并且每轮带一段**像样的材料**（证人证词/物证，150~250 字）⇒ 历史累积必然上万。
//
// 两臂只差历史里 assistant 的 `reasoning_content`：A 全量（≈现状）／B 手记（只带结论）。
// 老板令：**10 次 · 每次≥1 万 token · 先拿真实数据再推结论 · 不接工作点**。
// 跑法：EXP_TIMES=10 node 神经/思考手记实验3.mjs

import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs'
const 家 = process.env.HOME || '/data/data/com.dsharnessmobile.shell/files/home'
const DSH = process.env.DSH_HOME || `${家}/.dsh`
const 候选 = [`${DSH}/.credentials`, `${家}/.dsh/.credentials`, `${家}/.deepseek`]
try {
  const v = `${DSH}/undo-snapshots/auto/env-vault`
  if (existsSync(v)) readdirSync(v).filter((f) => f.endsWith('.env')).map((f) => `${v}/${f}`)
    .sort((a, b) => (statSync(b).mtimeMs || 0) - (statSync(a).mtimeMs || 0)).forEach((f) => 候选.push(f))
} catch {}
let KEY = process.env.DEEPSEEK_API_KEY || '', B0 = process.env.DEEPSEEK_BASE_URL || ''
if (!KEY) for (const f of 候选) { try { if (!existsSync(f)) continue; const m = readFileSync(f, 'utf8').match(/DEEPSEEK_API_KEY\s*[=:]\s*["']?([A-Za-z0-9_-]{16,})/); if (m) { KEY = m[1]; break } } catch {} }
const BASE = (B0 || 'https://api.deepseek.com').replace(/\/$/, '')
const MODEL = process.env.DSH_EXP_MODEL || 'deepseek-flash'
if (!KEY) { console.error('✗ 找不到 key'); process.exit(1) }
const tools = [{ type: 'function', function: { name: 'noop', description: '占位', parameters: { type: 'object', properties: {} } } }]
const 次数 = Number(process.env.EXP_TIMES || 10)

async function 发(messages, 重试 = 3) {
  for (let i = 0; i < 重试; i++) {
    try {
      const r = await fetch(`${BASE}/chat/completions`, {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${KEY}` },
        body: JSON.stringify({ model: MODEL, messages, tools, reasoning_effort: 'high', max_tokens: 8000, stream: false }),
      })
      const t = await r.text()
      if (!r.ok) { if (i === 重试 - 1) throw new Error(`HTTP ${r.status}: ${t.slice(0, 150)}`); await new Promise((s) => setTimeout(s, 2000)); continue }
      return (() => { const j = JSON.parse(t); return { m: j.choices[0].message, u: j.usage || {} } })()
    } catch (e) { if (i === 重试 - 1) throw e; await new Promise((s) => setTimeout(s, 2000)) }
  }
}

// 材料片段池（拼成"像样"的证词，每轮 150~250 字）
const 时段 = ['那天午后', '傍晚收摊前', '入夜头一更', '后半夜三更', '天将亮未亮时']
const 地点 = ['城东的茶棚', '巷口的老酒肆', '渡口的候船房', '西街的当铺前', '城南的戏台后']
const 物 = ['一把褪了漆的旧伞', '半张揉皱的车票', '一只磕了口的白瓷杯', '一本记到一半的流水账', '一枚磨得发亮的铜钱', '一方沾了墨的帕子']
const 旁人 = ['挑担的货郎', '扫街的老仆', '收账的伙计', '摆摊的算命先生', '赶车的车把式']
const 尾句 = ['这一节做得细，问了三遍都对得上', '录口供的人按了手印，日子时辰也记了', '两位证人对得上，只差半分不差', '这处前后咬得住，没有岔子']

function 造案子(seed) {
  let s = seed
  const rnd = () => (s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff
  const 姓 = ['赵', '钱', '孙', '李', '周', '吴', '郑', '王', '冯', '陈', '褚', '卫', '蒋', '沈', '韩', '杨', '朱', '秦', '尤', '许']
  const 名 = ['岩', '澜', '野', '禾', '舟', '岚', '川', '宁', '亭', '澈', '陌', '岑']
  const 人 = []
  for (let i = 0; i < 20; i++) 人.push({ 名: 姓[i] + 名[(i * 7) % 20], 性别: i % 2 ? '女' : '男', 岁: 24 + ((i * 13) % 40), 城: ['京', '沪', '粤', '川', '陕'][(i * 3) % 5] })
  const 目标 = 人[Math.floor(rnd() * 20)]
  const 别人 = 人.filter((p) => p !== 目标)
  // 洗牌（确定性）
  for (let i = 别人.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1));[别人[i], 别人[j]] = [别人[j], 别人[i]] }

  let 剩 = 人.slice()
  const 轮 = []
  const 轮数 = 6
  for (let i = 0; i < 轮数 && 剩.length > 1; i++) {
    const 排除者 = 别人[i % 别人.length]
    if (!剩.includes(排除者)) continue
    剩 = 剩.filter((p) => p !== 排除者)
    const 材料 = `【第 ${i + 1} 份材料 · ${时段[i % 5]}】\n` +
      `据 ${旁人[(i * 3) % 5]} 的证词：${时段[i % 5]}，有个人在 ${地点[(i * 7) % 5]} 露面，` +
      `手里拿着 ${物[(i * 11) % 6]}，跟人搭了两句话就往南去了，前后不到一盏茶的工夫。` +
      `问清了衣帽身形，与 ${排除者} 对不上：${排除者}那阵子在别处，有人看得真切，` +
      `时辰、去路、同谁在一处都记下了。${尾句[(i * 5) % 4]}。\n` +
      `据此，${排除者}不在场。`
    const 问 = (i === 0
      ? `名单：${人.map((p) => `${p.名}(${p.性别}·${p.岁}岁·${p.城})`).join('、')}。\n\n`
      : '') + 材料 + `\n\n现在还剩哪些嫌疑人？只列名字，不要解释。`
    轮.push({ 说: 问, 期望: 剩.map((p) => p.名), 排除者: 排除者.名, 目标: 目标.名 })
  }
  return { 人, 目标, 轮 }
}

async function 跑一臂(案子, 臂名) {
  let 历史 = [], prompt = 0, completion = 0, 全对 = true, 空答重试 = 0
  const 每轮 = []
  for (const r of 案子.轮) {
    let { m, u } = await 发([...历史, { role: 'user', content: r.说 }])
    if (!(m.content || '').trim()) {
      const r2 = await 发([...历史, { role: 'user', content: r.说 }])
      m = r2.m
      u = { prompt_tokens: (u.prompt_tokens||0)+(r2.u.prompt_tokens||0), completion_tokens: (u.completion_tokens||0)+(r2.u.completion_tokens||0) }
      空答重试++
    }
    prompt += u.prompt_tokens ?? 0; completion += u.completion_tokens ?? 0
    const 答 = (m.content || '').trim()
    const 对 = !答.includes(r.排除者) && 答.includes(r.目标)   // v4 新判分：该轮排掉的人不在答案里 & 目标还在
    if (!对) 全对 = false
    每轮.push({ prompt: u.prompt_tokens ?? 0, 对, 答: 答.slice(0, 60).replace(/\n/g,' ') })
    const asst = { role: 'assistant', content: 答 }
    asst.reasoning_content = 臂名 === 'A' ? (m.reasoning_content || '') : `（本轮手记 · 结论：${答}）`
    历史.push({ role: 'user', content: r.说 }, asst)
  }
  return { prompt, completion, 全对, 每轮, 空答重试, 空答: 每轮.filter((r) => !r.答).length }
}

console.log(`模型 ${MODEL} ｜ 重复 ${次数} 次 ｜ v3：20 人 · 18 轮（每轮带材料）｜ 两臂只差历史思考\n`)
const 汇总 = []
for (let t = 1; t <= 次数; t++) {
  const 案子 = 造案子(2000 + t * 7919)
  const A = await 跑一臂(案子, 'A')
  const B = await 跑一臂(案子, 'B')
  const 合计 = A.prompt + A.completion + B.prompt + B.completion
  汇总.push({ t, 轮数: 案子.轮.length, A, B, 合计, 省: 1 - B.prompt / A.prompt })
  console.log(`第 ${t} 次 ｜ ${案子.轮.length} 轮 ｜ A ${A.全对 ? '✅' : '❌'} ${A.prompt} ｜ B ${B.全对 ? '✅' : '❌'} ${B.prompt} ｜ 省 ${((1 - B.prompt / A.prompt) * 100).toFixed(1)}% ｜ 合计 ${合计} ·`)
}
const 平 = (f) => 汇总.reduce((s, x) => s + f(x), 0) / 汇总.length
const A对 = 汇总.filter((x) => x.A.全对).length, B对 = 汇总.filter((x) => x.B.全对).length
console.log('\n════════ 汇总 ════════')
console.log(`① 成没成：A 全对 ${A对}/${次数} ｜ B 全对 ${B对}/${次数}`)
console.log(`② 省不省：prompt A ${汇总.reduce((s, x) => s + x.A.prompt, 0).toLocaleString()} ｜ B ${汇总.reduce((s, x) => s + x.B.prompt, 0).toLocaleString()} ⇒ 平均省 ${(平((x) => x.省) * 100).toFixed(1)}%（${汇总.map((x) => (x.省 * 100).toFixed(0) + '%').join('/')}）`)
console.log(`③ 跟现在比：A ${A对}/${次数} vs B ${B对}/${次数}`)
console.log(`④b 空答轮数：A ${汇总.reduce((s,x)=>s+x.A.空答,0)} ｜ B ${汇总.reduce((s,x)=>s+x.B.空答,0)}（含重试后仍空）`)
console.log(`④ 量级守卫：合计≥1万 的 = ${汇总.filter((x) => x.合计 >= 10000).length}/${次数}（平均每次 ${Math.round(平((x) => x.合计)).toLocaleString()} token）`)
console.log(`⑤ O(n²) 实证（第 1 次 A 臂每轮 prompt）：${汇总[0].A.每轮.map((r) => r.prompt).join(' → ')}`)
console.log('\n=== A 臂逐轮答案 ===')
汇总[0].A.每轮.forEach((r,i)=>console.log(`  轮${String(i+1).padStart(2)} ${r.对?'OK':'XX'} | ${r.答}`))
console.log('=== B 臂逐轮答案 ===')
汇总[0].B.每轮.forEach((r,i)=>console.log(`  轮${String(i+1).padStart(2)} ${r.对?'OK':'XX'} | ${r.答}`))
console.log(`   （同案 B 臂）：${汇总[0].B.每轮.map((r) => r.prompt).join(' → ')}`)
