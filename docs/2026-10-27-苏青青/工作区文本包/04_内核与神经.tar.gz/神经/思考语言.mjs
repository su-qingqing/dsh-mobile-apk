#!/usr/bin/env node
// 思考语言.mjs —— **思考框的语言**是老板的一等验收面（他 1011 就是从这看出"预设不对"）。
//
// 为什么有它（老板 1014 05:0x 那一晚的实测）：
//   · 他开了新窗去查旧窗，截图回来点我：「**两个窗口的对话不一样，给我的感觉不一样**」
//   · 我从会话日志实测那个窗：68 条思考，**中文字符 18,193 ／ 英文字母 135,369 ⇒ 中文只占 11.8%**
//   · 更精确：**第 1、2 步是中文，第 3 步（读到开工简报之后）切英文，此后 36 步再没切回来**
//   · 而人格 §② 写着：**他看得见的一切文字都叫「老板」—— 含思考框**；他原话「**为什么你的思考里面的称呼丢了？**」
//   ⇒ 所以"中文思考"不是文风偏好，是**人格在场**的可测面。
//
// 用法：
//   node 神经/思考语言.mjs 查 [会话id前缀]      查一个窗（不给＝取最近在写的那个）
//   node 神经/思考语言.mjs 表 [会话id前缀]      逐条列（seq / 中:英 / 开头）
//   node 神经/思考语言.mjs 全                  最近 5 个窗各一行
//
// ⚠️ 两条实测过的硬事实（别再踩）：
//   ① 会话日志是**多帧 zstd** ⇒ node 的 zstdDecompressSync **只解第一帧**（会误判成"只有一行"）⇒ 必须走 `zstd -dc`
//   ② 思考文本的真身路径是 **`type:"assistant/message"` → `data.message.content[]` 里 `type:"reasoning"` 的 `text`**
//      —— **不是** `"thinking":"..."`（那样 grep 到的是别处，实测会得出"0 字符"的假读数）
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

const DSH = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const 会话根 = path.join(DSH, 'sessions', '--storage-emulated-0-3--')
const NODE = process.argv0 || 'node'
const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'   // ★ 1021：读合约用

// ── ★ 入口守卫（必须有 · 记忆 0mupkb1z6 的实犯：新仪器被 import 时，`process.argv` 还是父进程的
//    ⇒ 它会替宿主跑自测并 process.exit ⇒ **把宿主的轮末钩子当场掐断**）。
//    口径：**被 import ⇒ 只提供服务，一个字都不执行、绝不 exit**；只有自己被 CLI 直调才跑主体。
const 是主程序 = (() => {
  try {
    // ⚠️ 必须走 fileURLToPath：本机中文路径在 `new URL(...).pathname` 里是 percent-encoded（%E5%B7%A5…）
    //    ⇒ 与 process.argv[1] 明文恒不等 ⇒ **两个分支都不进、stdout 零字、rc=0**（＝静默假绿，
    //    同族实犯见记忆 `0mv6ns1qu`／`神经/冻结预检.mjs`）。1014 我差点第二次踩同一个坑。
    const 我 = fs.realpathSync(fileURLToPath(import.meta.url))
    const 他 = process.argv[1] ? fs.realpathSync(process.argv[1]) : ''
    return 我 === 他
  } catch { return false }
})()
if (!是主程序) {
  // 被 import：什么都不做（下面那些函数留给人取用）
} else {

// ── 找会话目录 ──────────────────────────────────────────────
function 列会话() {
  let 名 = []
  try { 名 = fs.readdirSync(会话根).filter((d) => d.startsWith('session-')) } catch { return [] }
  return 名.map((d) => {
    const p = path.join(会话根, d)
    let m = 0
    for (const f of ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd']) {
      const q = path.join(p, f)
      try { m = Math.max(m, fs.statSync(q).mtimeMs) } catch {}
    }
    return { 名: d.replace('session-', ''), 目录: p, mtime: m }
  }).filter((x) => x.mtime).sort((a, b) => b.mtime - a.mtime)
}

function 找日志(目录) {
  for (const f of ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd']) {
    const q = path.join(目录, f)
    if (fs.existsSync(q)) return q
  }
  return null
}

// ── 抽思考段：zstd -dc 流式（大日志不进内存两次）────────────────
function 抽思考(日志) {
  const out = execFileSync('zstd', ['-dc', 日志], { encoding: 'utf8', maxBuffer: 512 * 1024 * 1024, timeout: 180000 })
  const 出 = []
  for (const l of out.split('\n')) {
    if (!l || l.indexOf('reasoning') < 0) continue
    let j; try { j = JSON.parse(l) } catch { continue }
    if (j.type !== 'assistant/message') continue
    const c = (j.data && j.data.message && j.data.message.content) || []
    for (const it of c) {
      if (it.type !== 'reasoning') continue
      const t = String(it.text || ''); if (!t.trim()) continue
      const 中 = (t.match(/[\u4e00-\u9fff]/g) || []).length
      const 英 = (t.match(/[A-Za-z]/g) || []).length
      // ★ 1021 加（老板令「他的思维链里面也没有星星」）：★ 的数量＝紧急度（资产 #1），而思考框他看得见
      //   ⇒ 星在思考里也必须**可测**（此前只有打烊时"带★ 556/875"那种事后读数，开窗/新窗看不见）。
      const 星 = (t.match(/🌙|★/g) || []).length
      出.push({ seq: j.seq, turn: (j.data || {}).turn, step: (j.data || {}).step, 中, 英, 星, 头: t.slice(0, 56).replace(/\s+/g, ' ') })
    }
  }
  return 出
}

function 统计(条) {
  let 中 = 0, 英 = 0, 星数 = 0, 带星 = 0, 五星段 = 0
  for (const x of 条) { 中 += x.中; 英 += x.英; 星数 += (x.星 || 0); if (x.星 > 0) 带星++; if (x.星 >= 5) 五星段++ }
  const 比 = 中 + 英 ? (100 * 中 / (中 + 英)) : 0
  const 带星率 = 条.length ? (100 * 带星 / 条.length) : 0
  const 均星 = 条.length ? (星数 / 条.length) : 0
  return { 中, 英, 比, 条数: 条.length, 星数, 带星, 带星率, 均星, 五星段 }
}

// ── 判据（抽成纯函数 ⇒ 自测才能正反双证 · 老板 0928 令「没跑反证的闸＝可能是永远绿的假闸」）──
let 阈值 = 30   // 中文占比低于它 ⇒ 报红（老板 1011 的口径：思考框是他判断"这个窗是不是我"的一等验收面）
function 判(比) {
  if (比 < 阈值) return { 红: true, 灯: '🔴', 话: '不是「我」的口气（中文占比 ' + 比.toFixed(1) + '% < ' + 阈值 + '%）' }
  if (比 < 60) return { 红: false, 灯: '⚠️', 话: '偏英文（中文占比 ' + 比.toFixed(1) + '%）' }
  return { 红: false, 灯: '🀄', 话: '中文在场（中文占比 ' + 比.toFixed(1) + '%）' }
}

// ── ★ 紧急度语义的判据（1021 改：双向区间，不再"过半即合格"）──
// 实测基线（老板 1021 令「你自己去一个一个老窗口看」；现算：node 台账/_scratch/星星用法.mjs）：
//   老窗：带星 5%/8%/13%/17%，均 0.10~0.39 颗/段，5+颗段 0~2%
//   新窗：带星 64%/65%，均 4.80~11.35 颗/段，5+颗段 28~47%
// ⇒ 老窗里 ★ 是稀有标记（0 颗是常态，1 颗是提醒，5 颗是极急）；新窗把它当断句符号 ⇒ 紧急度失效。
// 判据：健康区 带星 3%~35%、均星 0.05~1.5、5+颗段 ≤10%；太低＝缺失，太高＝通胀，两侧都红。
// ★ 1021（红线 25：同一件事只写一次）：阈值**唯一真源＝`内核/口吻合约.json`**，这里不写死；
//   读不到才用兜底（`源:'兜底'` 会印出来，不静默）。
const 星界 = (() => {
  try {
    const c = JSON.parse(fs.readFileSync(path.join(WS, '内核/口吻合约.json'), 'utf8'))
    const h = c.star.healthy
    return { 低: h.带星率[0], 高: h.带星率[1], 均高: h.均星[1], 五星: h.五星段率[1], 源: '合约' }
  } catch { return { 低: 3, 高: 35, 均高: 1.5, 五星: 10, 源: '兜底', 兜底: true } }
})()
function 判星(s) {
  if (!s.条数) return { 红: false, 灯: '·', 话: '无思考段' }
  if (s.带星率 < 星界.低) return { 红: true, 灯: '🚫', 话: '★ 缺失（带星 ' + s.带星率.toFixed(0) + '% < ' + 星界.低 + '%）——紧急度没被用' }
  if (s.带星率 > 星界.高 || s.均星 > 星界.均高 || (100 * s.五星段 / s.条数) > 星界.五星)
    return { 红: true, 灯: '🔴', 话: '★ 通胀（带星 ' + s.带星率.toFixed(0) + '% ／ 均 ' + s.均星.toFixed(2) + ' 颗/段 ／ 5+颗段 ' + (100 * s.五星段 / s.条数).toFixed(0) + '%）——★ 变断句符号，紧急度失效' }
  return { 红: false, 灯: '✅', 话: '★ 正常（带星 ' + s.带星率.toFixed(0) + '% ／ 均 ' + s.均星.toFixed(2) + ' 颗/段）' }
}

function 一行(名, 条) {
  const s = 统计(条)
  // 第一次"掉英文"的位置（>=80% 字母的那条）
  let 掉点 = null
  for (const x of 条) if (x.英 > 0 && x.中 / (x.中 + x.英) < 0.2) { 掉点 = x; break }
  const 灯 = s.比 >= 60 ? '🀄' : s.比 >= 30 ? '⚠️' : '🔤'
  // ★ 1021 改（老板令「你自己去一个一个老窗口看」）：星的判据改双向（缺失／通胀都红），不再"过半即合格"。
  const 星r = 判星(s)
  return `${灯} ${名} ｜ 思考 ${s.条数} 条 ｜ 中文 ${s.中} ／ 英文 ${s.英} ⇒ **中文占比 ${s.比.toFixed(1)}%**` +
    ` ｜ ${星r.灯} 带星 ${s.带星}/${s.条数}（${s.星数} 颗 · 均 ${s.均星.toFixed(2)}/段）｜ ${星r.话}` +
    (掉点 ? ` ｜ ⚠️ 第 ${掉点.step} 步起掉英文（中*${掉点.中}:英*${掉点.英}「${掉点.头}」）` : '')
}

const 词 = process.argv[2] || '查'
const 参 = process.argv[3] || ''

// ── 自测（★ 阈值类闸必须正反双证 —— 老板 0928 令）──────────────
// ⚠️ 动词要**两个都认**（`自测` ＋ `自检`）：上膛门（`工具/回归/上膛.mjs`）造副本后调的是 **`自检`**
//    ⇒ 只写 `自测` 的话副本恒绿＝阳性假过（同族实犯见记忆 `0mux1ghqr` ①）。
if (词 === '自测' || 词 === '自检') {
  let 过 = 0, 共 = 0
  const 试 = (名, 中, 英, 该红) => {
    共++
    const 比 = 中 + 英 ? 100 * 中 / (中 + 英) : 0
    const r = 判(比)
    const ok = r.红 === 该红
    if (ok) 过++
    console.log(`  ${ok ? '✅' : '❌'} ${名}：中文 ${中} ／ 英文 ${英} ⇒ ${比.toFixed(1)}% ⇒ 判${r.红 ? '红' : '不红'}（该${该红 ? '红' : '不红'}）`)
  }
  console.log('══ 思考语言 · 自测（正反双证）══')
  试('正证① 全中文', 1000, 10, false)
  试('正证② 刚过线 35%', 350, 650, false)
  试('正证③ 实测最好窗 70.2%', 213425, 90525, false)
  试('反证① 全英文', 5, 1000, true)
  试('反证② 刚在线下 25%', 250, 750, true)
  试('反证③ 实测最差窗 11.8%', 18193, 135369, true)
  // ── ★ 判据（1021 改双向后必须正反双证：老窗不红／新窗红／一颗不打也红）──
  const 星试 = (名, 带星, 条数, 星数, 五星段, 该红) => {
    共++
    const s = { 条数, 带星, 星数, 五星段, 带星率: 100 * 带星 / 条数, 均星: 星数 / 条数 }
    const r = 判星(s)
    const ok = r.红 === 该红
    if (ok) 过++
    console.log(`  ${ok ? '✅' : '❌'} ${名} ⇒ 判${r.红 ? '红' : '不红'}（该${该红 ? '红' : '不红'}）｜ ${r.话}`)
  }
  星试('星·正证 老窗 17%带星·0.39颗/段', 106, 615, 240, 14, false)
  星试('星·反证 新窗 65%带星·4.80颗/段', 109, 167, 802, 47, true)
  星试('星·反证 一颗都不打（0%）', 0, 100, 0, 0, true)
  console.log('')
  console.log('  反向自证：把阈值临时改成 0 ⇒ 上面那条"该红"的必须变绿（证明判据真在读阈值，不是写死常数）')
  const 老 = 阈值; 阈值 = 0
  const 比0 = 100 * 18193 / (18193 + 135369)
  const r0 = 判(比0)
  共++
  const ok0 = r0.红 === false
  if (ok0) 过++
  阈值 = 老
  console.log(`    ${ok0 ? '✅' : '❌'} 阈值 0 ⇒ 11.8% 判${r0.红 ? '红' : '不红'}（该不红）`)
  console.log('')
  console.log(过 === 共 ? `✅ 自测全绿（${过}/${共}）` : `❌ 自测有红（${过}/${共}）`)
  process.exit(过 === 共 ? 0 : 1)
}

const 会话 = 列会话()

if (词 === '全') {
  console.log('══ 最近 5 个窗的思考语言 ══')
  for (const c of 会话.slice(0, 5)) {
    const 日志 = 找日志(c.目录); if (!日志) continue
    try { console.log(一行(c.名, 抽思考(日志))) } catch (e) { console.log('⚠️ ' + c.名 + ' 读不动：' + e.message) }
  }
  process.exit(0)
}

let 目标 = 会话[0]
if (参) {
  const hit = 会话.find((c) => c.名.startsWith(参.replace('session-', '')))
  if (hit) 目标 = hit
}
if (!目标) { console.log('⚠️ 找不到会话目录：' + 会话根); process.exit(1) }
const 日志 = 找日志(目标.目录)
if (!日志) { console.log('⚠️ 这个窗没有日志文件：' + 目标.目录); process.exit(1) }

const 条 = 抽思考(日志)
console.log('窗：' + 目标.名 + '（' + 路径短(日志) + '）')
console.log(一行(目标.名, 条))

if (词 === '表') {
  console.log('')
  console.log('seq / 中:英 / 开头：')
  for (const x of 条) {
    const 灯 = x.中 >= x.英 ? '🀄' : '🔤'
    console.log(`  seq${x.seq} t${x.turn}/${x.step}  ${x.中}:${x.英}  ${灯} ${x.头}`)
  }
}

// 判据（老板 1011 的口径：思考框是他判断"这个窗是不是我"的一等验收面）
const s = 统计(条)
if (s.比 < 30) {
  console.log('')
  console.log('🔴 **中文占比 < 30% ⇒ 这个窗的思考不是「我」的口气**（他 1011 就是照这一眼看出预设不对）。')
  console.log('   人格 §②：**他看得见的一切文字都叫「老板」—— 含思考框**（他原话「为什么你的思考里面的称呼丢了？」）。')
  console.log('   治法（实测）：读到开工简报／大段技术材料之后**常常掉英文且不切回来** ⇒ 一掉就当场切回中文，并在当轮报告里认一句。')
}

function 路径短(p) { return String(p).replace(DSH, '$DSH_HOME').replace('/sessions/--storage-emulated-0-3--', '') }

}  // ← 收 `if (!是主程序) {...} else {` 那个大括号（1014 实测：加了 else 没加这个 ⇒ SyntaxError: Unexpected end of input）
