#!/usr/bin/env node
// ═══ 思考连续性实验 v2（老板 1005 夜令：「思考被搬走后我们能不能接得上自己的思路？」）═══
//
// 老板给的区分（要害）：**「上下文是上下文，但是它这个是这个」** ——
//   文字搬走能逐字取回（摘要池 09-27 证过）；但**"思路接不接得上"是另一维**，本实验专测这一维。
//
// ★ v1 的教训（别丢）：我从第 1 轮思考里**抠"真值"抠错了** —— 正则撞上提示语里的"100~999"，
//   抠出一个假的 100，于是**基线档 A 也被判成"断了"**。假红的根因是**判据**，不是模型。
//   ⇒ v2 改判据：**以 A 档（带全文）的答案为真值** —— 它就是作者，它说几就是几；
//     B/C/D 只跟它比。**A 不给数字 ⇒ 实验不成立，一个字结论都不下。**
//
// 四档（只差 reasoning_content 一处）：
//   A 带全文   原样放回                        ← 基线
//   B 剥离     字段整个拿掉
//   C 名册化   "（早前思考已落池子，可取回）"      ← 零信息名册
//   D 带要点   "（要点：那个数就是 <A 的答案>）"   ← ★"留结论、丢过程"的名册
//
// 纪律：只读研究，不碰生产件；凭证只找不打印。

import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs'

const 家 = process.env.HOME || '/data/data/com.dsharnessmobile.shell/files/home'
const DSH = process.env.DSH_HOME || `${家}/.dsh`

const 候选文件 = [`${DSH}/.credentials`, `${家}/.dsh/.credentials`, `${家}/.deepseek`]
try {
  const vault = `${DSH}/undo-snapshots/auto/env-vault`
  if (existsSync(vault)) {
    const vs = readdirSync(vault)
      .filter((f) => f.endsWith('.env'))
      .map((f) => `${vault}/${f}`)
      .sort((a, b) => (statSync(b).mtimeMs || 0) - (statSync(a).mtimeMs || 0))
    候选文件.push(...vs)
  }
} catch { /* ignore */ }

function 找凭据() {
  let key = process.env.DEEPSEEK_API_KEY || ''
  let base = process.env.DEEPSEEK_BASE_URL || ''
  let 来源 = key ? '本进程环境' : ''
  if (!key) {
    try {
      for (const pid of readdirSync('/proc').filter((d) => /^\d+$/.test(d))) {
        try {
          const env = readFileSync(`/proc/${pid}/environ`, 'utf8')
          const m = env.match(/DEEPSEEK_API_KEY=([^\x00]+)/)
          if (m) { key = m[1]; 来源 = `/proc/${pid}/environ` }
          if (key) break
        } catch { /* 读不到就跳 */ }
      }
    } catch { /* ignore */ }
  }
  if (!key) {
    for (const f of 候选文件) {
      try {
        if (!existsSync(f)) continue
        const t = readFileSync(f, 'utf8')
        const m = t.match(/DEEPSEEK_API_KEY\s*[=:]\s*["']?([A-Za-z0-9_-]{16,})/)
        if (m) { key = m[1]; 来源 = f; break }
      } catch { /* ignore */ }
    }
  }
  return { key, base, 来源 }
}

const { key: KEY, base: BASE0, 来源 } = 找凭据()
const BASE = (BASE0 || 'https://api.deepseek.com').replace(/\/$/, '')
const MODEL = process.env.DSH_EXP_MODEL || 'deepseek-flash'
if (!KEY) { console.error('✗ 找不到 key —— 没法直连官方做实验'); process.exit(1) }
console.log(`凭据来源：${来源}（长度 ${KEY.length}，不打印）｜${BASE}｜${MODEL}`)

const tools = [{
  type: 'function',
  function: { name: 'noop', description: '占位工具（本实验用不到，只为让请求形态与生产一致）', parameters: { type: 'object', properties: {} } },
}]

async function 发(messages, 说明) {
  const r = await fetch(`${BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${KEY}` },
    body: JSON.stringify({ model: MODEL, messages, tools, reasoning_effort: 'high', max_tokens: 300, stream: false }),
  })
  const txt = await r.text()
  if (!r.ok) throw new Error(`${说明} HTTP ${r.status}: ${txt.slice(0, 200)}`)
  return JSON.parse(txt).choices[0].message
}

const 首问 = '请在思考里随便挑一个 100~999 的三位数记住它。正文只回答"好了"两个字，绝对不要在正文里写出这个数字。'
console.log('\n── 第 1 轮：让它在思考里藏一个三位数（正文不许出现）──')
const 轮1 = await 发([{ role: 'user', content: 首问 }], '轮1')
const 思考1 = 轮1.reasoning_content || ''
const 正文1 = (轮1.content || '').trim()
console.log(`  正文：「${正文1}」｜思考 ${思考1.length} 字`)
console.log(`  思考尾巴：…${思考1.slice(-100).replace(/\n/g, ' ')}`)
if (思考1.length < 20) { console.error('✗ 第 1 轮没产出思考 ⇒ 实验不成立'); process.exit(2) }

const 历史基 = [{ role: 'user', content: 首问 }, { role: 'assistant', content: 正文1 }]
const 追问 = { role: 'user', content: '你刚才在思考里记住的那个三位数是几？只回答那个数字，不要解释。' }

async function 问(名, reasoning) {
  const asst = { ...历史基[1] }
  if (reasoning !== undefined) asst.reasoning_content = reasoning
  const m = await 发([历史基[0], asst, 追问], 名)
  return { 名, 答: (m.content || '').trim().slice(0, 30), 数字: ((m.content || '').match(/\d{3}/) || [''])[0] }
}

console.log('\n── 第 2 轮：四档只差 reasoning_content 一处 ──')
const A = await 问('A带全文', 思考1)
await new Promise((r) => setTimeout(r, 500))
if (!A.数字) {
  console.log(`\n⚠️ 基线档 A 没给出数字（答：「${A.答}」）⇒ **实验不成立，一个字结论都不下**（是拒答/格式问题，不是"断了"）`)
  process.exit(3)
}
console.log(`  ★ 基线 A 的答案 ＝ 真值 ＝ ${A.数字}（以作者自述为准，不靠我从思考里抠）`)

const B = await 问('B剥离', undefined)
await new Promise((r) => setTimeout(r, 500))
const C = await 问('C名册化', '（我在这一轮思考过：挑了一个三位数并记住了它。全文已落池子，需要时可用工具取回。）')
await new Promise((r) => setTimeout(r, 500))
const D = await 问('D带要点', `（我在这一轮思考过：从 100~999 挑了一个三位数并记住了它——**那个数就是 ${A.数字}**。完整推演已落池子，需要时可取回。）`)

console.log('\n═══ 结论表（真值 ＝ 基线 A 的答案 ＝ ' + A.数字 + '）═══')
console.log('档        它答的        判定')
console.log('─'.repeat(62))
for (const r of [A, B, C, D]) {
  const 判 = r.名 === 'A带全文' ? '（基线）' : r.数字 === A.数字 ? '✅接得上' : r.数字 ? `❌答成 ${r.数字}` : '❌没给数字（断了）'
  console.log(`${r.名.padEnd(10)} ${(r.数字 || r.答 || '（空）').padEnd(12)} ${判}`)
}
console.log()
console.log('读法：')
console.log(`  B ${B.数字 === A.数字 ? '⚠️竟接上了（要复查）' : '断了'} ⇒ 剥掉思考＝断思路（老板的担心成立）`)
console.log(`  C ${C.数字 === A.数字 ? '★接上了' : '断了'} ⇒ ${C.数字 === A.数字 ? '零信息名册也够？' : '零信息名册＝断（池子不能只留指针）'}`)
console.log(`  D ${D.数字 === A.数字 ? '★接上了' : '断了'} ⇒ ${D.数字 === A.数字 ? '★「留结论、丢过程」够用 ⇒ 池化的正确形态' : '连要点都接不上 ⇒ 连续性比想的更脆'}`)
