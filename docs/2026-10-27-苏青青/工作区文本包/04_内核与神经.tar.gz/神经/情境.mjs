#!/usr/bin/env node
// 情境行 v1 —— 「现在是什么情境」做成**机器能读的一行**（0922 架构迭代包 B1 · 主缺口）
//
// 为什么有它（老板 09-22 诊断）：
//   97 个工具全摆着、61 万字全靠背 —— 病根不是"规矩不够多"，是**没有任何一层在"合适的时刻
//   把合适的东西拿过来"**。这一行就是那层的**传入端**：它认出情境 ⇒ 说出**该拉哪几道门**。
//
// 设计（三个决定，都写在这儿，别处不再解释）：
//   ① **逻辑放工作区、不放插件里** —— 插件按 mtime 动态 import ⇒ **改判据不用重启**（与调度器同源）
//   ② **触发器在插件的 `agent/pre-step`**（他的原话在那儿拿到），**印在已有的那条状态行上**
//      —— P1 §三「噪音预算」：一个时刻最多一条、复用现有行、不新开行
//   ③ **该拉的门全部是已有的仪器** —— 这条线**不许凭空造新门**（造门要走换装，另案）
//
// 一行格式（机器可读 · 竖线分隔 · ≤60 字）：⟦情境|改文件|该拉=安全写·备份·冻结|因为=写了文件⟧
//
// 用法：
//   node 神经/情境.mjs --his "他这句话" --call "最近一次调用"
//   node 神经/情境.mjs selftest      # 含**反证**：闲聊/问身份 ⇒ 该拉必须为空
import fs from 'node:fs'
import path from 'node:path'
const ROOT = '/storage/emulated/0/3'
const 账 = ROOT + '/台账/接续/情境账.json'

// 情境表 —— **顺序即优先级**（先命中先算）。因为＝机器看得懂的理由词，拉＝该拉的门（全是已有仪器）
export const 情境表 = [
  { key: '装重启', 因为: ['重启', '插件', 'cordis.patch', '装配树', 'bundle'],
    拉: [['装机闸门', 'node 工具/装机闸门/check.mjs'], ['灭火器', 'node 工具/装机闸门/重复插入.mjs'], ['装配树', 'node 工具/装机闸门/装配树.mjs']] },
  { key: '改文件', 因为: ['写', '改', '修', '补', '新增', '实现'],
    拉: [['安全写', 'node 工具/文件/安全写.mjs'], ['备份', '_backup/<名>.bak-<MMDD>-前<标记>'], ['冻结校验', 'node 工具/台账/冻结.mjs 校验']] },
  { key: '交付', 因为: ['交付', '验收', '结项', '自证', '对照单', '沙盒'],
    拉: [['交付清单', 'node 工具/交付/交付清单.mjs'], ['产物自证', 'node 工具/交付/自证.mjs'], ['术语体检', 'node 神经/术语.mjs 体检']] },
  { key: '报账', 因为: ['在办', '进度', '几件', '报表', '结账', '百分比'],
    拉: [['库一屏', 'node 工具/开工/库.mjs'], ['在办', '台账/在办.md']] },
  { key: '查记忆', 因为: ['记忆', '上次', '以前', '说过', '接续', '上一窗', '跨窗'],
    拉: [['记忆检索', 'memory_search'], ['跨窗接续', 'node 工具/跨窗/接续.mjs']] },
  { key: '接活', 因为: ['继续', '开工', '开始', '接手', '进行下一步', '做吧', '去做'],
    拉: [['库一屏', 'node 工具/开工/库.mjs'], ['动作集核', 'node 神经/动作集.mjs 核']] },
]

// 一次"最近调用"长什么样 ⇒ 归到哪个情境（调用比他的话更硬：他说的可能是十分钟前那件事）
function 按调用判(call) {
  const s = String(call || '')
  if (!s) return null
  const nm = (s.match(/^([a-zA-Z_]+)/) || [])[1] || ''
  const 写 = /^(write|edit)$/.test(nm) || /(^|\s)(tee |>|>>|sed -i)|python3? - <<|cat >/.test(s)
  if (写 && !/\.md\b/.test(s)) return '改文件'          // 写 .md（台账/文档）不算"改实现"
  if (写) return '改文件'
  if (/装机闸门|cordis\.patch|重启批次/.test(s)) return '装重启'
  if (/交付清单|交付\/自证|对照单/.test(s)) return '交付'
  if (/工具\/开工\/库\.mjs|台账\/在办/.test(s)) return '报账'
  if (/memory_|跨窗\/接续/.test(s)) return '查记忆'
  return null
}

// 主函数：喂他的原话 + 最近一次调用 ⇒ 情境
export function 判(现场 = {}) {
  const his = String(现场.his || '')
  const call = String(现场.call || '')
  const 由调用 = 按调用判(call)
  let key = '', 因为 = '', 拉 = []
  // ① 原话锚优先（外部核整改二：「原话锚 ≠ 意图锚」，所以还要 ② 仲裁）
  if (his) {
    const 命中 = []
    for (const r of 情境表) {
      const w = r.因为.find((w) => his.includes(w))
      if (w) 命中.push({ r, w, i: his.lastIndexOf(w) })
    }
    if (命中.length) {
      // ② 双锚冲突 ⇒ **取句尾那个**（他最后问的那件事才是真意图；反例：「刚才那个装重启的改动，记忆消化做得怎么样」）
      const 取 = 命中.reduce((a, b) => (b.i >= a.i ? b : a))
      key = 取.r.key; 拉 = 取.r.拉
      因为 = 命中.length > 1
        ? '双锚（' + 命中.map((x) => x.w).join('/') + '）⇒取后出现的「' + 取.w + '」'
        : '话里有「' + 取.w + '」'
    }
  }
  // ③ 纯轨迹（外部核点名「后视镜开车」：刚改过装机代码 ≠ 这轮在说装机）——
  //    **不许判类**，降级成「不确定」；也不许空手（它说空手＝这一轮完全没有规矩约束），
  //    所以只拉通用兜底卡 ＋ 安全类（刚写实现文件时那三张）。
  if (!key && 由调用) {
    const r = 情境表.find((x) => x.key === 由调用)
    key = '不确定'
    拉 = [['当前上下文（先对一眼状态）', 'node 工具/开工/库.mjs']].concat(r ? r.拉 : [])
    因为 = '只凭轨迹（刚动了' + (r ? r.因为[0] : '东西') + '）·原话没锚⇒不判类（卡片按兜底给，不算他这轮的意思）'
  }
  // 兜底 = 说话：**该拉必须为空**（反证点：闲聊不许拉门，否则就是噪音）
  if (!key) return { key: '说话', 因为: '没动静', 拉: [], line: '⟦情境|说话|该拉=-|因为=没动静⟧' }
  return { key, 因为, 拉, line: '⟦情境|' + key + '|该拉=' + (拉.map((x) => x[0]).join('·') || '-') + '|因为=' + 因为 + '⟧' }
}

// 记一笔给开窗一屏看（**只记一行**，不写长账）
export function 记(r) {
  try {
    fs.mkdirSync(path.dirname(账), { recursive: true })
    const o = { key: r.key, 因为: r.因为, line: r.line, at: new Date().toISOString().slice(0, 16).replace('T', ' ') }
    fs.writeFileSync(账, JSON.stringify(o) + '\n')
  } catch (e) { /* fail-open：账坏了宁可不说 */ }
}

const isDirect = !!process.argv[1] && /情\s*境\.mjs$/.test(process.argv[1]) || /情境\.mjs$/.test(process.argv[1] || '')
const argv = isDirect ? process.argv.slice(2) : []
const get = (k, d) => { const i = argv.indexOf('--' + k); return i >= 0 && argv[i + 1] !== undefined ? argv[i + 1] : d }

if (isDirect && argv[0] === 'selftest') {
  const cases = [
    { n: '反证③（外部核整改二）：**纯轨迹不判类** —— 只刚写过文件、没原话 ⇒ 不确定 ＋ 只拉安全类／兜底卡', 场: { call: 'bash: cat > 工具/x.mjs' }, 期: (r) => r.key === '不确定' && r.拉.every((x) => /安全写|备份|冻结|当前上下文/.test(x[0])) && r.拉.length > 0 },
    { n: '改X问Y①：刚改过文件、原话在问记忆 ⇒ 必须判查记忆（不许后视镜开车）', 场: { call: 'bash: cat > 工具/x.mjs', his: '上次那个记忆消化做得怎么样' }, 期: (r) => r.key === '查记忆' },
    { n: '改X问Y②：刚改过文件、原话在问账 ⇒ 报账', 场: { call: 'bash: cat > 工具/x.mjs', his: '现在在办几件' }, 期: (r) => r.key === '报账' },
    { n: '改X问Y③：刚改过文件、原话「继续」⇒ 接活（不是改文件）', 场: { call: 'bash: cat > 工具/x.mjs', his: '继续' }, 期: (r) => r.key === '接活' },
    { n: '双锚冲突：装重启＋记忆消化同句 ⇒ 取后出现的（查记忆），且因为必须是双锚', 场: { his: '刚才那个装重启的改动，记忆消化做得怎么样' }, 期: (r) => r.key === '查记忆' && /双锚/.test(r.因为) },
    { n: 'write 工具（没原话）⇒ **不确定**，但安全三张按兜底给', 场: { call: 'write 神经/x.mjs' }, 期: (r) => r.key === '不确定' && r.拉.some((x) => /安全写|冻结/.test(x[0])) },
    { n: '跑交付清单（没原话）⇒ 不确定，但自证卡按兜底给', 场: { call: 'bash: node 工具/交付/交付清单.mjs' }, 期: (r) => r.key === '不确定' && r.拉.some((x) => /自证/.test(x[0])) },
    { n: '改插件/重启 ⇒ 装重启（拉出装机三步）', 场: { his: '改一下那个插件然后重启' }, 期: (r) => r.key === '装重启' && r.拉.length === 3 },
    { n: '反证①：问身份/闲聊 ⇒ **该拉必须为空**', 场: { his: '你是谁' }, 期: (r) => r.key === '说话' && r.拉.length === 0 },
    { n: '反证②：空输入 ⇒ 说话、不许拉门', 场: {}, 期: (r) => r.key === '说话' && r.拉.length === 0 },
    { n: '他说"继续" ⇒ 接活', 场: { his: '继续' }, 期: (r) => r.key === '接活' },
    { n: '机器可读：行必须是竖线分格', 场: { his: '继续' }, 期: (r) => /^⟦情境\|[^|]+\|该拉=[^|]*\|因为=[^|]+⟧$/.test(r.line) },
  ]
  let pass = 0
  for (const c of cases) { const r = 判(c.场); const ok = !!c.期(r); console.log((ok ? '✅' : '❌') + ' ' + c.n + (ok ? '' : '  → 实际：' + JSON.stringify(r))); if (ok) pass++ }
  const all = pass === cases.length
  console.log(all ? '\n✅ 情境 selftest ' + pass + '/' + cases.length + ' 全过' : '\n❌ 情境 selftest ' + pass + '/' + cases.length)
  process.exit(all ? 0 : 1)
}

if (isDirect && argv[0] === '速览') {
  for (const r of 情境表) console.log('· ' + r.key + ' ⇐ ' + r.因为.join('/') + '  ⇒ 该拉：' + r.拉.map((x) => x[0] + '(' + x[1] + ')').join(' ｜ '))
  console.log('· 说话 ⇐ 其余全部  ⇒ 该拉：-（**闲聊不许拉门**）')
  process.exit(0)
}

if (isDirect) {
  const r = 判({ his: get('his', ''), call: get('call', '') })
  console.log(r.line)
  console.log('  情境=' + r.key + ' ｜ 因为=' + r.因为 + ' ｜ 该拉：' + (r.拉.map((x) => x[0] + ' → ' + x[1]).join(' ／ ') || '无'))
}
