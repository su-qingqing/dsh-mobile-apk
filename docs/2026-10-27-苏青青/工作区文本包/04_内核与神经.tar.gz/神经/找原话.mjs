import fs from 'node:fs';
const f=process.argv[2];
const kw=process.argv.slice(3);
const txt=fs.readFileSync(f,'utf8');
let n=0,hit=0;
for(const line of txt.split('\n')){
  if(!line.trim())continue; n++;
  let e; try{e=JSON.parse(line)}catch{continue}
  const d=e.data||{};
  const m=d.message||e.message||{};
  if(m.role!=='user')continue;
  const c=m.content; let s=typeof c==='string'?c:Array.isArray(c)?c.map(x=>x?.text||x?.content||'').join(''):'';
  if(!s.trim())continue;
  if(kw.length && !kw.some(k=>s.includes(k)))continue;
  hit++;
  console.log(`\n--- #${n} seq=${e.seq} ---\n${s.slice(0,1100)}`);
  if(hit>=Number(process.env.MAXHIT||12))break;
}
console.log(`\n[共 ${n} 条事件, 命中 ${hit}]`);
