#!/usr/bin/env node
// 报表缺格门 —— 把「维度体检 --扫」的红，变成**能拦人的读数**（2026-10-08 · R9 立、R11 时间闸、R12 上膛）
//
// 【它治什么病】R8 三方交叉证实：红是真的（真打烊单报 10 格没表态）＋ 仪器是好的（selftest 3/3）
//   ＋ 格子是真的空 ⇒ **缺陷不在"仪器没跑"，在"报红了不阻断"**（外部核四步闭环第④步缺失）。
//   仪器查得再勤，红字没有后果 ＝ 等于没查（内核 #51 的又一活标本）。
//
// 【它怎么治】① 跑 `维度体检 --扫` 拿全部红 ② 扣掉判过的（`台账/接续/报表缺格_已判.json`）
//   ③ **只管新件**（红线 23：验收判据＝下次不再犯）—— 10 格是「交付前」的质检，交付已发生，
//      事后补 ＝ 编造当时的判断 ⇒ 历史件只列不拦 ④ 剩下的 ⇒ 印清单 ＋ **exit 1**。
//
// 【只读】不写任何文件。判词由人写进那张 json，本门只认表不认人。
// 【怎么验】`node 神经/报表缺格门.mjs; echo $?`（**别走管道** —— 管道会吃掉真实退出码）
//          `node 神经/报表缺格门.mjs selftest` ⇒ 应 `自测 2/2 ⇒ 仪器可信`
// 【挂点】已进 `工具/回归/上膛清单.json`（上膛闸＝仪器三对照：抹掉关键判据必须变红、无害改动必须仍绿）
import fs from "node:fs";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
const ROOT = "/storage/emulated/0/3";
// ★ 自测必须指向「自己现在这个文件」，不许硬编码路径 ——
//   否则上膛闸抹掉「副本」时，副本的自测跑去跑**原版**（没被抹），阳性对照永远测不出来（R12 被上膛闸当场逮到）。
const 自 = fileURLToPath(import.meta.url);
// 生效起：只有 mtime 晚于它的**新交付物**缺格才拦。环境变量只给自测用（默认逐字不变）
const 生效起 = Date.parse(process.env.REPORT_GATE_SINCE || "2026-10-08T00:00:00+08:00");

// ★ 两个动词都认（`selftest` 与 `自检`）—— 上膛闸造副本后调的是 **`自检`**；
//   只写 `selftest` ⇒ 副本恒绿、阳性假过（1007 老坑 0mux1ghqr，R12 我又踩一次，被上膛闸当场逮到）。
if (process.argv.includes('selftest') || process.argv.includes('自检')) {
  const 跑 = (env) => {
    try { execFileSync("node", [自], { env: { ...process.env, ...env }, stdio: "pipe" }); return 0 }
    catch (e) { return (e && typeof e.status === "number") ? e.status : 1 }
  };
  const a = 跑({});                                                    // 阴性：当前状态（历史件全判过）应绿
  const b = 跑({ REPORT_GATE_IGNORE_JUDGED: "1", REPORT_GATE_SINCE: "1970-01-01T00:00:00+08:00" }); // 阳性：忽略判词表 ＋ 全当新件 ⇒ 必须红
  const ok = (a === 0 && b === 1);
  console.log("自测：" + (a === 0 ? "✅" : "❌") + " 阴性（当前状态应绿，实得 exit " + a + "）");
  console.log("      " + (b === 1 ? "✅" : "❌") + " 阳性（把历史件全当新件应红，实得 exit " + b + "）");
  console.log(ok ? "自测 2/2 ⇒ 仪器可信" : "自测 ❌ ⇒ 仪器坏了（去查 生效起／判词表／新件红 那段）");
  process.exit(ok ? 0 : 1);
}

let 表 = {};
try { 表 = JSON.parse(fs.readFileSync(ROOT + "/台账/接续/报表缺格_已判.json", "utf8")) } catch { }
// ★ 自测开关（默认逐字不变）：忽略判词表 ⇒ 让"新件缺格"那条路能被阳性对照真的走到。
//   起因（R12 实测）：判词表把 7 份红全判过了 ⇒ 没判 为空 ⇒ 无论生效起调到多早都算不出新件红 ⇒ 阳性对照永远测不到。
const 豁免集 = process.env.REPORT_GATE_IGNORE_JUDGED ? new Set() : new Set((表.已判 || []).map((x) => x.文件));
const mtime = (f) => { try { return fs.statSync(ROOT + "/" + f).mtimeMs } catch { return 0 } };
let out = "";
try {
  out = execFileSync("node", [ROOT + "/工具/交付/维度体检.mjs", "--扫", ROOT], { maxBuffer: 1 << 26 }).toString();
} catch (e) { out = String((e && e.stdout) || ""); }
const 红 = out.split("\n").filter((l) => l.includes("🔴")).map((l) => (l.match(/台账\/\S+\.md/) || [""])[0]).filter(Boolean);
const 已判 = 红.filter((f) => 豁免集.has(f));
const 没判 = 红.filter((f) => !豁免集.has(f));
const 新件红 = 没判.filter((f) => mtime(f) >= 生效起);
const 历史红 = 没判.filter((f) => mtime(f) < 生效起);
console.log("【报表缺格门】扫到红 **" + 红.length + "** 份 ｜ 已判 " + 已判.length + " ｜ 历史件（没判但老） " + 历史红.length + " ｜ **新件缺格 " + 新件红.length + "**");
if (历史红.length) {
  console.log("   ⏳ 历史件（本门生效前交付 ⇒ 只列不拦；事后补 10 格 ＝ 编造当时的判断）：");
  for (const f of 历史红) console.log("      " + f);
  console.log("      ⇒ 建议写进 `台账/接续/报表缺格_已判.json` 并写明理由和期限（判词表要能说出为什么它不算红）");
}
for (const f of 新件红) console.log("   🔴 " + f + " —— **新交付物缺「质检 10 格」**⇒ 交付前得补（每格 ✅查过+一句／⛔不适用+理由）");
if (新件红.length) {
  console.log("   ⇒ **不许静默过**：补它，或在判词表里写明理由和期限再判它");
  process.exit(1);
}
console.log("   ✅ 没有「新交付物缺格」（本门只管 mtime ≥ " + new Date(生效起).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai", hour12: false }) + " 的件）");
