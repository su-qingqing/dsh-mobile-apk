// 从会话日志里抽「用户原话」；支持任意嵌套 role:user
import fs from 'node:fs';
const txt = fs.readFileSync(0, 'utf8');
const kw = (process.env.KW||'').split('|').filter(Boolean);
const out = [];
function textsOf(c){
  if(typeof c==='string') return c;
  if(Array.isArray(c)) return c.map(textsOf).join('');
  if(c && typeof c==='object') return c.text || textsOf(c.content) || '';
  return '';
}
function walk(o){
  if(!o || typeof o!=='object') return;
  if(o.role==='user' && (o.content!==undefined||o.text!==undefined)){
    const s=(textsOf(o.content)||o.text||'').trim();
    if(s) out.push(s);
  }
  for(const k of Object.keys(o)) walk(o[k]);
}
for(const line of txt.split('\n')){
  if(!line.trim()) continue;
  let e; try{ e=JSON.parse(line) }catch{ continue }
  const before=out.length; walk(e);
  if(kw.length) for(let i=before;i<out.length;i++) if(!kw.some(k=>out[i].includes(k))) out[i]='';
}
const uniq=[...new Set(out.filter(s=>s && s.length>4))];
if(process.env.MODE==='count'){ console.log(uniq.length); }
else { for(const s of uniq) console.log('\n=====\n'+s.slice(0,1200)); }
console.log(''); // 结尾标记
