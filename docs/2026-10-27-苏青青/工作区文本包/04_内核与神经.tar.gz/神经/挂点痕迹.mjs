#!/usr/bin/env node
// 挂点痕迹.mjs · 1010 建（外部独立核判决第 4 条：E 桶「靠自觉」19/54 ——
//   核的原话：「只读字段文本不算证据，要**运行痕迹**」。）
//
// 病根：「挂点装上没有」一直靠**读源码/字段文本**判（`工具/台账/挂点体检.mjs`）—— 那**能被措辞骗**；
//   真问题是：该自动响的口子，**真响过吗**？（"挂上了" ≠ "跑过了"，这正是内核 #51 那族。）
//
// 判据（**运行痕迹 · 骗不了**）：把「每轮必到」的挂点清单里的**命令/路径**，
//   丢进最近 N 个**会话日志**里数现身次数 —— 日志是既成事实，不随我怎么写台账而变。
// ⚠️ 口径（诚实先说）：**现身 0 次 ≠ 一定坏了** —— 有一类挂点是"给我看的指针"（按需才跑，如打烊类）。
//   ⇒ 本件**只报数、不下判决**；它治的是"我拿'挂上了'当'跑过了'"。
//
// 清单来源（两处"每轮必到"的正身）：① `台账/接续/每轮必读.json` 的 pins（提取其中的 `工具/…` 路径）
//   ② `神经/轮末自检.mjs` 里 spawn 的仪器路径。
//
// 用法：
//   node 神经/挂点痕迹.mjs 扫 [日志数=3]   # 出一张表：挂点 → 最近 N 个会话里现身次数
//   node 神经/挂点痕迹.mjs 一屏            # 只印一行（**绿时零字**：没有"零现身"的挂点就不出字）
//   node 神经/挂点痕迹.mjs 落盘            # 写 `台账/接续/挂点痕迹.md`
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const HOME = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const 会目录 = path.join(HOME, 'sessions', '--storage-emulated-0-3--')

/** 从文本里抽「工具/…」路径（去重 · 只要 .mjs/.sh） */
function 抽路径(t) {
  const 集 = new Set()
  for (const m of String(t).matchAll(/(工具\/[A-Za-z0-9_\u4e00-\u9fa5/\-]+\.(?:mjs|sh))/g)) 集.add(m[1])
  return [...集]
}

function 挂点清单() {
  const 出 = new Map()   // 路径 → 来源
  try {
    const j = JSON.parse(fs.readFileSync(path.join(WS, '台账/接续/每轮必读.json'), 'utf8'))
    for (const p of j.pins || []) for (const x of 抽路径(p)) if (!出.has(x)) 出.set(x, 'pins')
  } catch { }
  try {
    const t = fs.readFileSync(path.join(WS, '神经/轮末自检.mjs'), 'utf8')
    for (const x of 抽路径(t)) if (!出.has(x)) 出.set(x, '轮末自检')
  } catch { }
  return 出
}

function 最近日志(数) {
  try {
    return fs.readdirSync(会目录)
      .map((d) => { const p = ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd'].map((x) => path.join(会目录, d, x)).find((x) => fs.existsSync(x)); if (!p) return null; try { return { d, p, m: fs.statSync(p).mtimeMs } } catch { return null } })
      .filter(Boolean).sort((a, b) => b.m - a.m).slice(0, 数)
  } catch { return [] }
}

function 扫(数 = 3) {
  const 清单 = 挂点清单()
  const 日志 = 最近日志(数)
  const 文本 = []
  for (const L of 日志) {
    try {
      // ⚠️ 会话日志是**多帧 zstd**（每 turn 一帧）⇒ `zlib.zstdDecompressSync` **只解第一帧**
      //   （1010 实测：压缩 1.48MB 只吐出 203B）⇒ 全部挂点都会显示"零现身"＝**假红**。
      //   正解＝命令行 `zstd -dc`（解全部帧）；隔壁 `打烊.mjs` 就是这么干的。
      //   ★ 这条记忆里**早有**（`0muu88l5r`，已摆 10 次），我这次又踩 ⇒ 把注释钉在这里。
      const t = execFileSync('/data/data/com.dsharnessmobile.shell/files/usr/bin/zstd', ['-dc', L.p], { encoding: 'utf8', maxBuffer: 1 << 28, timeout: 90000 })
      文本.push(String(t))
    } catch { }
  }
  const 全 = 文本.join('\n')
  const 列 = [...清单.entries()].map(([件, 源]) => {
    let n = 0
    for (const t of 文本) n += t.split(件).length - 1
    return { 件, 源, 次数: n }
  }).sort((a, b) => a.次数 - b.次数)
  return { 列, 日志数: 日志.length, 字节: 全.length }
}

function 一屏(r) {
  const 零 = r.列.filter((x) => x.次数 === 0)
  if (!零.length) return ''
  return '挂点痕迹 ⚠️ ' + 零.length + '/' + r.列.length + ' 个「每轮必到」的挂点在最近 ' + r.日志数 + ' 个会话里**零现身**（≠ 一定坏，有的是按需才跑的指针）⇒ `node 神经/挂点痕迹.mjs 扫` 看是哪几个'
}

const cmd = process.argv[2] || '一屏'
const 数 = Number(process.argv[3] || 3)
const r = 扫(数)

if (cmd === '一屏') {
  const s = 一屏(r)
  if (s) console.log(s)
  process.exit(0)
}

if (cmd === '扫' || cmd === '落盘') {
  console.log('挂点痕迹 · 挂点 ' + r.列.length + ' 个 ｜ 扫最近 ' + r.日志数 + ' 个会话（' + Math.round(r.字节 / 1024) + 'KB 正文）')
  for (const x of r.列) console.log('  ' + String(x.次数).padStart(4) + ' 次  ' + x.件 + '（源：' + x.源 + '）')
  if (cmd === '落盘') {
    const 行 = ['# 挂点痕迹 · ' + new Date().toLocaleString('zh-CN') + '（机器生成 · 只读）', '',
      '判据：把「每轮必到」的挂点丢进最近 ' + r.日志数 + ' 个**会话日志**里数现身次数（运行痕迹 · 骗不了）。',
      '⚠️ **零现身 ≠ 一定坏**：有的是"给我看的指针"（按需才跑）⇒ 本件只报数、不下判决。', '',
      '| 挂点 | 来源 | 最近 ' + r.日志数 + ' 个会话里现身 |', '|---|---|---|']
    for (const x of r.列) 行.push('| ' + x.件 + ' | ' + x.源 + ' | ' + x.次数 + ' |')
    fs.writeFileSync(path.join(WS, '台账/接续/挂点痕迹.md'), 行.join('\n') + '\n')
    console.log('已落盘 台账/接续/挂点痕迹.md')
  }
  process.exit(0)
}

console.log('用法：挂点痕迹.mjs 扫 [日志数] ｜ 一屏 ｜ 落盘')
