#!/usr/bin/env node
// 按来源 · 日志是「多来源混写」的：判"现在跑的是哪个版本"必须**按来源过滤**，不能取尾巴（门 · 坑 0mu63gt4t）
// 实测：$DSH_HOME/kickoff-gate.log 21MB／25.7 万行；apply 行里 **13047 条来自自测工作区**、只有 1694 条来自生产
//       ⇒ 取尾巴 ⇒ 拿自测实例的版本当生产版本 ⇒ **假绿**（历史上真发生过）。
// 用法：node 神经/按来源.mjs 最新 [--生产 <路径>] ｜ 尾巴 [--生产 <路径>] ｜ 来源 ｜ 自检
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
const 家 = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const a = process.argv.slice(2)
const v = a[0] || '最新'
const 取 = (n, d) => { const i = a.indexOf(n); return i >= 0 && a[i + 1] ? a[i + 1] : d }
const 生产 = 取('--生产', '/storage/emulated/0/3')
const 日志 = 取('--日志', path.join(家, 'kickoff-gate.log'))
const 读 = () => {
  if (!fs.existsSync(日志)) { console.error('❌ 日志不在：' + 日志); process.exit(1) }
  return fs.readFileSync(日志, 'utf8').split('\n')
}
const 来源of = (l) => { const m = l.match(/workspace=(\S+)/); if (m) return m[1]; const s = l.match(/sid=(\S+)/); return s ? '会话:' + s[1] : null }
const 版本of = (l) => { const m = l.match(/^apply\(v([^)]+)\)/); return m ? m[1] : null }
function apply行s() {
  const L = 读(), out = []
  L.forEach((l, i) => { const ver = 版本of(l); if (!ver) return; const pid = (l.match(/pid=(\d+)/) || [])[1] || '?'; out.push({ i: i + 1, ver, ws: 来源of(l) || '（无 workspace）', pid, raw: l }) })
  if (!out.length) { console.error('❌ 这份日志里一条 apply 行都没有 ⇒ 判不出任何版本（别硬猜）'); process.exit(1) }
  return out
}
function 最新() {
  const A = apply行s()
  const 每 = new Map()
  for (const r of A) 每.set(r.ws, r)                       // 后来的覆盖先前的 ⇒ 每个来源的最近一次
  const 全 = a.includes('--全')
  const p = 每.get(生产)
  const 自测 = [...每.entries()].filter(([ws]) => ws.includes('.dsh-kickoff/'))
  const 其它 = [...每.entries()].filter(([ws]) => ws !== 生产 && !ws.includes('.dsh-kickoff/'))
  console.log('apply 行 ' + A.length + ' 条 ｜ 来源 ' + 每.size + ' 个（生产 1 ／ 自测·隔离 ' + 自测.length + ' ／ 其它 ' + 其它.length + '）')
  if (p) console.log('⭐ 生产 ' + 生产 + ' ⇒ **v' + p.ver + '** ｜ 第 ' + p.i + ' 行 pid=' + p.pid + ' ｜ 这个来源共 ' + A.filter((x) => x.ws === 生产).length + ' 条')
  else console.log('❌ 生产 ' + 生产 + ' 在日志里一条 apply 都没有 ⇒ "生产跑哪个版本"这份日志答不了（别硬猜）')
  const 自测最近 = 自测.slice().sort((x, y) => y[1].i - x[1].i)[0]
  if (自测最近) console.log('   （噪声）自测·隔离 ' + 自测.length + ' 个来源、合计 ' + 自测.reduce((n, [, r]) => n + A.filter((x) => x.ws === r.ws).length, 0) + ' 条；最近一个是 ' + 自测最近[0] + ' ⇒ v' + 自测最近[1].ver)
  const 其它排 = 其它.slice().sort((x, y) => y[1].i - x[1].i)
  ;(全 ? 其它排 : 其它排.slice(0, 5)).forEach(([ws, r]) => console.log('   ' + ws + ' ⇒ v' + r.ver + ' ｜ 第 ' + r.i + ' 行'))
  if (!全 && 其它排.length > 5) console.log('   …另有 ' + (其它排.length - 5) + ' 个其它来源（要看全加 --全）')
  const 最后 = A[A.length - 1]
  console.log('')
  if (最后.ws === 生产) console.log('✅ 日志最后一条 apply 恰好也是生产（v' + 最后.ver + '）')
  else console.log('⚠️ 日志**最后一条** apply 来自「' + 最后.ws + '」＝v' + 最后.ver + ' —— **那不是生产**，拿它判版本＝假绿（坑 0mu63gt4t 的现场）。生产真值看上面 ⭐ 那一行。')
  console.log('⭐ 生产真值：' + (p ? 'v' + p.ver + '（第 ' + p.i + ' 行 pid=' + p.pid + '）' : '❌ 答不了 —— 日志里没有生产来源的 apply 行'))
}
function 尾巴() {
  const A = apply行s()
  const 最后 = A[A.length - 1]
  console.log('日志最后一条 apply：' + 最后.raw.slice(0, 160))
  if (最后.ws === 生产) { console.log('✅ 尾巴就是生产（v' + 最后.ver + '）⇒ 这一条可以当判据'); return 0 }
  console.log('🔴 尾巴**不是生产**：它来自「' + 最后.ws + '」（v' + 最后.ver + '）')
  console.log('   ⇒ 拿尾巴判生产版本＝**假绿**。要判生产，跑：node 神经/按来源.mjs 最新')
  return 1
}
function 来源() {
  const L = 读()
  const ws = new Map(), sid = new Map(), 无 = { n: 0 }
  for (const l of L) {
    const m = l.match(/workspace=(\S+)/), s = l.match(/sid=(\S+)/)
    if (m) ws.set(m[1], (ws.get(m[1]) || 0) + 1)
    else if (s) sid.set(s[1], (sid.get(s[1]) || 0) + 1)
    else 无.n++
  }
  console.log('总行数 ' + L.length)
  console.log('按工作区来源（' + ws.size + ' 种）：')
  ;[...ws.entries()].sort((x, y) => y[1] - x[1]).slice(0, 8).forEach(([k, n]) => console.log('   ' + String(n).padStart(7) + '  ' + (k === 生产 ? '⭐ 生产 ' : '        ') + k))
  console.log('按会话来源（' + sid.size + ' 种，前 8）：')
  ;[...sid.entries()].sort((x, y) => y[1] - x[1]).slice(0, 8).forEach(([k, n]) => console.log('   ' + String(n).padStart(7) + '  ' + k))
  console.log('两种标记都没有的行：' + 无.n + '（这些行判不了来源，别拿它们当依据）')
}
function 自检() {
  const 临时 = path.join(process.env.DSH_HOME || '/tmp', 'tmp', '按来源自检')
  fs.mkdirSync(临时, { recursive: true })
  const f = path.join(临时, 't.log')
  // 造的就是历史现场：生产 v2.6 在前，自测实例 v2.8 在后 ⇒ 尾巴会骗人
  fs.writeFileSync(f, [
    'apply(v2.6): pid=111 enforce=true retrieve=true workspace=/storage/emulated/0/3',
    'RETRIEVE 2026-09-18T10:00:00 bash [bash:ls] sid=session-aaa',
    'apply(v2.8): pid=222 enforce=false retrieve=false workspace=/storage/emulated/0/3/.dsh-kickoff/testws',
    '',
  ].join('\n'))
  const 跑 = (动词) => spawnSync('node', [process.argv[1], 动词, '--日志', f], { encoding: 'utf8' })
  let r = 0
  const c1 = 跑('最新')
  const ok1 = c1.status === 0 && /生产真值：v2\.6/.test(c1.stdout) && /那不是生产/.test(c1.stdout)
  r += ok1 ? 1 : 0
  console.log('  ① 生产在前、自测在后 ⇒ 生产真值必须是 v2.6：' + (ok1 ? '✅' : '❌'))
  const c2 = 跑('尾巴')
  const ok2 = c2.status === 1 && /尾巴\*\*不是生产\*\*/.test(c2.stdout)
  r += ok2 ? 1 : 0
  console.log('  ② 同一份日志的"尾巴"必须判红（exit=' + c2.status + '）：' + (ok2 ? '✅' : '❌'))
  fs.writeFileSync(f, 'apply(v3.2): pid=333 workspace=/storage/emulated/0/3\n')
  const c3 = 跑('尾巴')
  const ok3 = c3.status === 0 && /尾巴就是生产/.test(c3.stdout)
  r += ok3 ? 1 : 0
  console.log('  ③ 生产在最后 ⇒ 尾巴必须判绿（exit=' + c3.status + '）：' + (ok3 ? '✅' : '❌'))
  fs.writeFileSync(f, 'PROMOTED loaded n=7\n')
  const c4 = 跑('最新')
  r += c4.status === 1 ? 1 : 0
  console.log('  ④ 一条 apply 都没有 ⇒ 拒判（exit=' + c4.status + '）：' + (c4.status === 1 ? '✅' : '❌'))
  // ★★ 1013 改写（原文：console.log(r === 4 ? '✅ 自检 4/4 过' : …) ＋ process.exit(r === 4 ? 0 : 1)）
  //   病：**分母写死**。将来加第 5 条断言 ⇒ r 到 5、判据还是 r === 4 ⇒ **永远红**；
  //   反过来的病更坏：有人把 4 校准成**通过数** ⇒ **失败的断言被藏住、一直报绿**
  //   （同形状的实证事故：神经/重启批次.mjs 原来 `const N = 19`）。
  //   治法＝照抄那件已修好的形状：**现算总数 ＋ 只许增的底线**。
  //   ★ 本件**不需要加 import**：`fs` 本来就在，中文路径用 decodeURIComponent 解掉百分号编码
  //     （别把 `new URL(...).pathname` 直接当路径 —— 那正是 `冻结预检.mjs` 静默假绿的病根）。
  const 总数 = (fs.readFileSync(decodeURIComponent(new URL(import.meta.url).pathname), 'utf8')
    // ★ 1013 修：本件的计数**两种形态混用** —— 「ok1 那种」3 条 ＋「c4点status 那种」1 条。
    //   ⚠️ **别在这行里写出那两种写法的原样** —— 我第一版就是写出来了 ⇒ **正则把注释也算进去** ⇒
    //     总数现算成 6（4 条真断言 ＋ 注释里 2 处）⇒ 报「4/6」、**把一个本来绿的闸改成红的**。
    //     ★ 老坑原话：**判据要打在产物上，不许打在源码上 —— 注释会违反它自己的判据。**
    .match(/r \+= (ok\d+|c\d+\.status === 1) \? 1 : 0/g) || []).length
  const 底线 = 4   // ★ 只许往上调，不许往下调（防有人悄悄删样本）
  const 全过 = r === 总数 && 总数 >= 底线
  console.log(全过 ? '✅ 自检 ' + r + '/' + 总数 + ' 过（底线 ' + 底线 + '）'
                   : '❌ 自检只过 ' + r + '/' + 总数 + '（底线 ' + 底线 + '；总数现算自源码）')
  process.exit(全过 ? 0 : 1)
}
if (v === '最新') 最新()
else if (v === '尾巴') process.exit(尾巴())
else if (v === '来源') 来源()
else if (v === '自检') 自检()
else { console.log('用法：按来源.mjs 最新 [--生产 <路径>] ｜ 尾巴 ｜ 来源 ｜ 自检'); process.exit(2) }
