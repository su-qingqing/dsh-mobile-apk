#!/usr/bin/env node
// 换窗公式 v2 · 2026-09-19 · ④号窗（session-cce76c1e）
//   v1 收到老板令「这里面应该有个公式」后落地；v2 按 `qwen3.8-max` 独立核（核验单 007）改正两处真错：
//     ① 原式把「新窗开局 5 步的成本」既算进求和项、又加成 S ⇒ **重复计费**；
//     ② 死表把门槛写成"10 万 token 就换"，实际临界是 **11~14 万**（随剩余步数变）⇒ 改成**算出来**。
//
// 它现在能干什么（人话）：
//   读你当前窗口的**真实上下文大小**，算出「接着干」和「开新窗再干」哪个更省钱、省多少，
//   并告诉你**临界线在哪**（上下文涨到多少才值得换）。零 token：只读本地会话日志，不联网、不调模型。
//
// 用法：node 神经/换窗公式.mjs [剩余步数=15] [会话id]
// 退出码：0 接着跑 ｜ 1 该换窗 ｜ 3 仪器故障
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { 每百万 } from './价目.mjs'

// ── 常量：全部来自 2026-09-19 实测（7 个真实会话，见 台账/对照/核验单_007_换窗公式.md）──
const P_万 = 每百万.命中.空闲 / 100  // ¥/万 token/步 —— 缓存**命中**价（官方 ¥0.02/百万＝¥0.0002/万）。1018 收口：旧值 0.002 用的是 ¥0.2/百万 ⇒ 高估 10 倍
const 每步小项 = 0.012  // ¥/步 —— 新增输入 + 输出（不含缓存读）
const S0 = 0.09         // ¥ —— 换窗的**纯额外开销**（读交接页／重新认人／第一步摸索）。证据等级＝推断。
                        //      实测 ¥0.21 是"新窗开局 5 步的总成本"，那 5 步已由下面的求和项计过 ⇒ 只留差额，避免重复计费。
const C0 = 5.2          // 万 token —— 新窗口开局上下文，实测 4.0~6.7
const G = 0.3           // 万 token/步 —— 新窗口上下文增速，实测 +0.2~0.36

const argv = process.argv.slice(2)
const N = Number(argv[0]) > 0 ? Number(argv[0]) : 15
const sid = argv[1]
const HOME = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const ROOT = path.join(HOME, 'sessions')
// ★ 1013 第16刀：引擎升 v4 后日志名从 v3 变 v4 ⇒ 依次认 v4／v3／无版本（原写死 v3 ⇒ 新窗读不到、退回老会话）。
function 认日志(d, s) { return ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd'].map((x) => path.join(d, s, x)).find((x) => fs.existsSync(x)) }
function find(id) { for (const ws of fs.readdirSync(ROOT)) { const f = 认日志(path.join(ROOT, ws), id); if (f) return { id, f } } return null }
function newest() {
  let best = null
  for (const ws of fs.readdirSync(ROOT)) {
    const d = path.join(ROOT, ws); if (!fs.statSync(d).isDirectory()) continue
    for (const s of fs.readdirSync(d)) {
      const f = 认日志(d, s); if (!f) continue
      const m = fs.statSync(f).mtimeMs; const isRoot = s.startsWith('session-'); const bestRoot = best && best.id.startsWith('session-')
      if (!best || (isRoot && !bestRoot) || (isRoot === !!bestRoot && m > best.m)) best = { id: s, f, m }
    }
  }
  return best
}
const t = sid ? find(sid) : newest()
if (!t) { console.error('找不到会话日志（可用 预算.mjs 的会话 id）'); process.exit(3) }
let text = ''
try { text = execFileSync('zstd', ['-dc', t.f], { encoding: 'utf8', maxBuffer: 512 * 1024 * 1024, timeout: 90000 }) }
catch (e) { console.error('解压失败：', String(e.message).slice(0, 120)); process.exit(3) }
const us = []
for (const l of text.split('\n')) {
  if (!l) continue
  let j; try { j = JSON.parse(l) } catch { continue }
  const u = j && j.data && j.data.usage
  if (u && typeof u.inputTokens === 'number') us.push({ i: u.inputTokens || 0, o: u.outputTokens || 0, c: u.cacheReadTokens || 0 })
}
if (us.length < 3) { console.error('用量记录太少（' + us.length + ' 条），算不出上下文'); process.exit(3) }

const C = Math.round(us.slice(-3).reduce((s, x) => s + x.c, 0) / 3 / 1000) / 10   // 万 token
const 继续 = N * (C * P_万 + 每步小项)
let 换窗 = S0 + N * 每步小项
for (let k = 1; k <= N; k++) 换窗 += (C0 + G * k) * P_万
const C星 = C0 + G * (N + 1) / 2 + S0 / (P_万 * N)   // 临界上下文（万 token）：C 超过它才值得换

let verdict, code, 人话
if (C > 30) {
  verdict = '立刻换窗'; code = 1
  人话 = `上下文已到 ${C} 万 token，每步约 ¥${(C * P_万 + 每步小项).toFixed(3)}，而且这已经进了"一轮塞太多会被压死"的风险区 —— 换窗（换前把资产写台账、给他交接词）。`
} else if (C >= C星) {
  verdict = '换窗划算'; code = 1
  人话 = `接着跑 ${N} 步约 ¥${继续.toFixed(2)}，换新窗再跑 ${N} 步约 ¥${换窗.toFixed(2)} —— 换窗省约 ¥${(继续 - 换窗).toFixed(2)}（${Math.round((继续 - 换窗) / Math.max(继续, 1e-9) * 100)}%）；临界线 ${C星.toFixed(1)} 万 token，你现在 ${C} 万。`
} else {
  verdict = '接着跑'; code = 0
  人话 = `现在 ${C} 万 token、每步约 ¥${(C * P_万 + 每步小项).toFixed(3)}；剩余 ${N} 步时换窗的临界是 ${C星.toFixed(1)} 万 —— 还差 ${(C星 - C).toFixed(1)} 万，接着跑。`
}

console.log(`┌─ 换窗公式 v2（第 ${us.length} 步 · 会话 ${String(t.id).slice(0, 12)}）`)
console.log(`│ 现在的上下文：${C} 万 token（最近 3 步均值，每步都要重发一遍）`)
console.log(`│ 这个窗口每步 ≈ ¥${(C * P_万 + 每步小项).toFixed(3)}   ｜ 新窗口起步 ≈ ¥${(C0 * P_万 + 每步小项).toFixed(3)}/步`)
console.log(`│ 接着跑 ${N} 步 ≈ ¥${继续.toFixed(2)}   ｜   换新窗再跑 ${N} 步 ≈ ¥${换窗.toFixed(2)}（含切换开销 ¥${S0}）`)
console.log(`│ 临界上下文（剩余 ${N} 步时）＝ ${C星.toFixed(1)} 万 token`)
console.log(`└─ ${verdict}：${人话}`)
console.log('')
console.log('判据表（由公式算，不看死表）：')
console.log(`  上下文 > 30 万            ⇒ 立刻换窗   进入"被压死"的**带宽**风险区（跟钱无关：新价下每步才 ¥${(30 * P_万 + 每步小项).toFixed(3)}）`)
console.log(`  上下文 ≥ 临界 ${C星.toFixed(1)} 万   ⇒ 换窗划算   省的钱藏在"每步都要重发整段上下文"里`)
console.log(`  上下文 < 临界             ⇒ 接着跑     换窗的开场成本收不回来`)
console.log(`  临界 C* = C₀(${C0}) + G·(N+1)/2 + S₀/(P_万·N) —— 剩余步数越多，临界越低`)
console.log('交接余量（老板 2026-09-23 令）：**不许等撞线才说** —— 余额 < 一次交接（≈6 步 × 0.3 万 ＝ 1.8 万）的 1.5 倍时，先落交接单再换窗。仪器：node 神经/上下文账.mjs 交接')
console.log('')
console.log('常数出处：缓存命中价从 价目.mjs 取（官方 ¥0.02/百万）｜ S₀、开局 5.2 万 token = 7 个真实会话实测中位')
console.log('千问独立核改正（2026-09-19）：① 原式重复计费 ② 死表门槛标到 10 万、实际临界 11~14 万')
console.log('⚠️ 前提：结论在"缓存命中"下成立；缓存一旦失效（改前缀/超 TTL），单价差 10 倍，两边都涨 ⇒ 别只看这一条。')
process.exit(code)
