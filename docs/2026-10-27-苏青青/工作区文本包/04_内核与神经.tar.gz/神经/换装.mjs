#!/usr/bin/env node
/**
 * 换装.mjs —— 「减」的手：**换装，不是砍**（老板 2026-09-22 · 0922 架构迭代包 A3）
 *
 * 它是什么（人话）：想把一个旧部件拿下来、换个新的上去时走这条路。
 *   它不是"删掉"，是"替换"—— 所以必须同时回答三句：
 *     ① **备份了吗**（旧的先在 `_backup/` 留一份）
 *     ② **旧的去哪了**（登记：搬到哪 / 并进了谁 —— 不许"人间蒸发"）
 *     ③ **能退回来吗**（`退 --id` 一键还原）
 *   **净增不被允许**（封层类型）：想加一条行为动作/工具动作 ⇒ 先拿一条来换。
 *
 * 为什么有它（内核 #51）："砍东西"这件事在盘上从来只有**我说一句"删了"**，
 *   没有备份、没有去处、没有退路 ⇒ 砍完就找不回来了。现在砍 = 换装，三样缺一 ⇒ **拒收**。
 *
 * ⚠️ 先核过 `工具/文件/补丁.mjs` 能不能直接扩成这个（A3 要求先核）：
 *   **不能直接扩**。补丁的语义是「**改文件内容**」（锚点/生成/语法查/写回），
 *   换装要的是「**部件级替换 + 旧件去哪 + 可一键退回**」—— 那是**登记**，不是文本替换。
 *   两个职责塞一个件 ⇒ 补丁那个件的单一职责就没了。
 *   ⇒ 所以：**换装只管登记与退回；要真改文件，仍走 `补丁.mjs`**（不重造写文件的轮子）。
 *
 * 用法：
 *   node 神经/换装.mjs 校                                    # 封层与账的体检
 *   node 神经/换装.mjs 账 [--all]                            # 看换装登记表
 *   node 神经/换装.mjs 换 --类型 <…> --旧 <名> --新 <名> --为什么 <…> [--旧件去哪 <…>] [--apply]
 *   node 神经/换装.mjs 加 --类型 <…> --名 <名> --为什么 <…> [--apply]
 *   node 神经/换装.mjs 退 --id <N> [--apply]
 *   node 神经/换装.mjs selftest
 * 隐藏入参（供自测，不给人用）：--账 --基线 --备份目录
 * 退出码：0 绿 ｜ 1 红/被拒 ｜ 2 用法错
 */
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const HERE = path.join(WS, '神经')
const arg = (k, d = '') => { const i = process.argv.indexOf(k); return i >= 0 && process.argv[i + 1] && !String(process.argv[i + 1]).startsWith('--') ? process.argv[i + 1] : d }
const has = (k) => process.argv.includes(k)

/** 封层类型：**只许替换、不许净增**。基线清单在 `动作集封层.json`（别处不许再存一份）。 */
const 封层类 = ['行为动作', '工具动作']
/** 不封顶类型：法（内核条文）永远会长 —— 记忆 0mu9w1glv：拿"上限"套法＝套错层。 */
const 不封顶类 = ['内核条文', '工具', '文档', '其它']

const BASE = arg('--基线', path.join(HERE, '动作集封层.json'))
const BOOK = arg('--账', path.join(HERE, '换装账.json'))
const BK = arg('--备份目录', path.join(WS, '_backup'))
const stamp = () => { const d = new Date(); const p = (n) => String(n).padStart(2, '0'); return p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) }

const rdJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')) } catch { return d } }
const backUp = (f) => {
  if (!fs.existsSync(f)) return ''
  fs.mkdirSync(BK, { recursive: true })
  let out = path.join(BK, path.basename(f) + '.bak-' + stamp() + '-前换装')
  for (let i = 2; fs.existsSync(out); i++) out = path.join(BK, path.basename(f) + '.bak-' + stamp() + '-前换装-' + i)
  fs.copyFileSync(f, out)
  return out
}

// ───────────────────── 校 ─────────────────────
function 校() {
  let red = 0
  // ① 动作集封层（真值在 动作集.mjs 核 —— 不在这里重造数数逻辑）
  const r = spawnSync('node', [path.join(WS, '神经/动作集.mjs'), '核'], { cwd: WS, encoding: 'utf8', timeout: 60000 })
  if (r.status === 0) console.log('✅ 动作集封层：没越界（行为/工具动作都没净增）')
  else { console.log('❌ 动作集封层：**越界了** —— 跑 `node 神经/动作集.mjs 核` 看是哪一条'); red++ }

  // ② 换装账：每笔"换"都必须有"旧件去哪"
  const book = rdJson(BOOK, { rows: [] })
  const rows = book.rows || []
  const bad = rows.filter((x) => x.动作 === '换' && !x.旧件去哪 && x.状态 !== '已退')
  if (bad.length) { console.log('❌ 换装账里有 ' + bad.length + ' 笔"换了但没说旧件去哪"：' + bad.map((x) => '#' + x.id).join(' ')); red++ }
  else console.log('✅ 换装账：' + rows.length + ' 笔，每笔"换"都写了旧件去哪')

  // ③ 基线里每个名字是否还在（被静默删掉＝同样破封层）
  const base = rdJson(BASE, null)
  if (base) {
    const 换过的 = new Set(rows.filter((x) => x.动作 === '换' && x.状态 !== '已退').map((x) => x.旧 + '→' + x.新))
    const 应有 = [...(base.行为动作 || []), ...(base.工具动作 || [])]
    if (应有.length) console.log('   基线 ' + base.at + '：行为 ' + (base.行为动作 || []).length + ' ＋ 工具 ' + (base.工具动作 || []).length + ' ｜ 已换装 ' + 换过的.size + ' 笔（换过的名字在基线上叫"新名"）')
  }
  console.log(red === 0 ? '\n✅ 换装体检全绿' : '\n❌ 换装体检有 ' + red + ' 处红')
  return red === 0 ? 0 : 1
}

// ───────────────────── 账 ─────────────────────
function 账(all) {
  const book = rdJson(BOOK, { rows: [] })
  const rows = (book.rows || []).filter((x) => all || x.状态 !== '已退')
  console.log('换装账 ' + BOOK + '（共 ' + (book.rows || []).length + ' 笔，显示 ' + rows.length + ' 笔）')
  if (!rows.length) { console.log('（还没有换装记录）'); return 0 }
  for (const x of rows) {
    console.log('#' + x.id + ' ' + x.at + ' ｜ ' + x.动作 + ' ' + x.类型 + ' ｜ ' + x.旧 + (x.新 ? ' → ' + x.新 : '') +
      (x.旧件去哪 ? ' ｜ 旧件去哪：' + x.旧件去哪 : '') + ' ｜ 为什么：' + String(x.为什么 || '').slice(0, 40) +
      (x.状态 === '已退' ? ' ｜ **已退**' : ''))
  }
  return 0
}

function 写账(row) {
  const book = rdJson(BOOK, { rows: [] })
  book.rows = book.rows || []
  row.id = (book.rows.reduce((m, x) => Math.max(m, x.id || 0), 0)) + 1
  row.at = new Date().toLocaleString('zh-CN', { hour12: false })
  book.rows.push(row)
  fs.mkdirSync(path.dirname(BOOK), { recursive: true })
  fs.writeFileSync(BOOK, JSON.stringify(book, null, 1) + '\n')
  return row.id
}

// ───────────────────── 加 ─────────────────────
function 加(类型, 名, 为什么, apply) {
  const miss = []
  if (!类型) miss.push('--类型')
  if (!名) miss.push('--名')
  if (!为什么) miss.push('--为什么')
  if (miss.length) { console.error('❌ 拒收：缺 ' + miss.join(' ／ ')); return 2 }
  if (封层类.includes(类型)) {
    console.error('❌ **封层类型不许净增**：' + 类型 + ' 只许**换成**一条 —— 用 `换 --类型 ' + 类型 + ' --旧 <拿掉谁> --新 ' + 名 + '`。')
    console.error('   （理由：封层＝这张清单封顶了；真要破封层，走 `动作集.mjs 封层 --理由 "…"` 显式开封并在台账留痕。）')
    return 1
  }
  if (!不封顶类.includes(类型)) { console.error('❌ 认不出的类型：' + 类型 + '（认得的：' + [...封层类, ...不封顶类].join(' / ') + '）'); return 2 }
  console.log('➕ 加 ' + 类型 + '：' + 名 + '（不封顶类型 —— 法/工具永远会长，这里不设上限）')
  console.log('   为什么：' + 为什么)
  if (!apply) { console.log('   （干跑，加 --apply 才落账）'); return 0 }
  const id = 写账({ 动作: '加', 类型, 旧: '', 新: 名, 旧件去哪: '', 为什么, 状态: '生效' })
  console.log('   📒 已落账 #' + id)
  return 0
}

// ───────────────────── 换 ─────────────────────
function 换(类型, 旧, 新, 为什么, 去哪, apply) {
  const miss = []
  if (!类型) miss.push('--类型')
  if (!旧) miss.push('--旧')
  if (!新) miss.push('--新')
  if (!为什么) miss.push('--为什么')
  if (miss.length) { console.error('❌ 拒收：缺 ' + miss.join(' ／ ')); return 2 }
  const 是封层 = 封层类.includes(类型)
  if (是封层 && !去哪) {
    console.error('❌ 拒收：换装**必须说旧件去哪**（`--旧件去哪 <_backup/… 或 并入了谁>`）——')
    console.error('   说不出 ⇒ 那就不叫换装、叫**砍**（砍是这轮明令不许的）。')
    return 1
  }
  let base = null, 命中的键 = ''
  if (是封层) {
    base = rdJson(BASE, null)
    if (!base) { console.error('❌ 找不到封层基线：' + BASE); return 1 }
    for (const k of ['行为动作', '工具动作']) {
      if ((base[k] || []).includes(旧)) { 命中的键 = k; break }
    }
    if (!命中的键) { console.error('❌ 基线里没有「' + 旧 + '」这一条 ⇒ 不能换（先 `动作集.mjs 核` 看真名）'); return 1 }
    if ((base[命中的键] || []).includes(新)) { console.error('❌ 基线里已经有「' + 新 + '」了 ⇒ 换上去会重复'); return 1 }
  }
  console.log('🔁 换装：' + 类型 + ' ｜ ' + 旧 + ' → ' + 新)
  console.log('   为什么：' + 为什么)
  console.log('   旧件去哪：' + (去哪 || '（不封顶类型：只落账，不搬东西）'))
  if (!apply) { console.log('   （干跑，加 --apply 才真换）'); return 0 }
  let 备份 = ''
  if (是封层) {
    备份 = backUp(BASE)
    const i = base[命中的键].indexOf(旧)
    base[命中的键][i] = 新
    base.刷新 = { at: new Date().toISOString().slice(0, 10), 由: '换装.mjs', 换的: 旧 + ' → ' + 新, 为什么 }
    fs.writeFileSync(BASE, JSON.stringify(base, null, 1) + '\n')
    console.log('   ✅ 基线已换：' + 旧 + ' → ' + 新 + (备份 ? '（换前基线另存 ' + path.relative(WS, 备份) + '）' : ''))
  }
  const id = 写账({ 动作: '换', 类型, 旧, 新, 旧件去哪: 去哪, 为什么, 备份: 备份 ? path.relative(WS, 备份) : '', 状态: '生效' })
  console.log('   📒 已落账 #' + id + ' ｜ 退回去：`node 神经/换装.mjs 退 --id ' + id + ' --apply`')
  return 0
}

// ───────────────────── 退 ─────────────────────
function 退(id, apply) {
  if (!id) { console.error('用法：换装.mjs 退 --id <N> [--apply]'); return 2 }
  const book = rdJson(BOOK, { rows: [] })
  const row = (book.rows || []).find((x) => String(x.id) === String(id))
  if (!row) { console.error('❌ 账上没有 #' + id); return 1 }
  if (row.状态 === '已退') { console.error('❌ #' + id + ' 已经退过了'); return 1 }
  console.log('↩️ 退回 #' + id + '：' + row.动作 + ' ' + row.类型 + ' ｜ ' + row.旧 + (row.新 ? ' → ' + row.新 : ''))
  if (!apply) { console.log('   （干跑，加 --apply 才真退）'); return 0 }
  if (row.动作 === '换' && 封层类.includes(row.类型)) {
    const base = rdJson(BASE, null)
    if (!base) { console.error('❌ 找不到封层基线'); return 1 }
    for (const k of ['行为动作', '工具动作']) {
      const i = (base[k] || []).indexOf(row.新)
      if (i >= 0) { base[k][i] = row.旧; delete base.刷新; fs.writeFileSync(BASE, JSON.stringify(base, null, 1) + '\n'); console.log('   ✅ 基线已退回：' + row.新 + ' → ' + row.旧); break }
    }
  }
  row.状态 = '已退'
  row.退回时间 = new Date().toLocaleString('zh-CN', { hour12: false })
  fs.writeFileSync(BOOK, JSON.stringify(book, null, 1) + '\n')
  console.log('   📒 账上已标"已退"')
  return 0
}

// ───────────────────── selftest ─────────────────────
function selftest() {
  const T = path.join(process.env.DSH_HOME || '/tmp', 'tmp', '换装自测-' + process.pid)
  fs.rmSync(T, { recursive: true, force: true }); fs.mkdirSync(T, { recursive: true })
  const 基线 = path.join(T, '基线.json'), 账本 = path.join(T, '账.json'), 备 = path.join(T, '备')
  fs.writeFileSync(基线, JSON.stringify({ at: '2026-09-22', 行为动作: ['A01', 'A02'], 工具动作: ['跑库一屏'] }, null, 1))
  const run = (a) => spawnSync('node', [path.join(HERE, '换装.mjs'), ...a, '--基线', 基线, '--账', 账本, '--备份目录', 备], { encoding: 'utf8' })
  let pass = 0, fail = 0
  const t = (n, c, ex = '') => { if (c) { pass++; console.log('  ✅ ' + n) } else { fail++; console.log('  ❌ ' + n + (ex ? ' — ' + ex : '')) } }

  let r = run(['加', '--类型', '行为动作', '--名', 'X99', '--为什么', '试净增', '--apply'])
  t('反证①：封层类型**净增被拒**（退出码 1）', r.status === 1 && /封层类型不许净增/.test(r.stderr + r.stdout), 'rc=' + r.status)
  t('反证①b：被拒时**账上不许留痕**（拒了就是没做）', !fs.existsSync(账本))

  r = run(['加', '--类型', '内核条文', '--名', '#78', '--为什么', '法不封顶', '--apply'])
  t('正证：**法不封顶** —— 内核条文可以加（退出码 0）', r.status === 0, 'rc=' + r.status)

  r = run(['换', '--类型', '行为动作', '--旧', 'A01', '--新', 'A01新', '--为什么', '替换', '--apply'])
  t('反证②：换装**不说旧件去哪 ⇒ 拒收**', r.status === 1 && /旧件去哪/.test(r.stderr + r.stdout), 'rc=' + r.status)

  r = run(['换', '--类型', '行为动作', '--旧', 'A01', '--新', 'A01新', '--为什么', '替换', '--旧件去哪', '_backup/A01.bak', '--apply'])
  const b1 = JSON.parse(fs.readFileSync(基线, 'utf8'))
  t('正证：换装成功 ⇒ 基线里 A01 变成 A01新', r.status === 0 && b1.行为动作.includes('A01新') && !b1.行为动作.includes('A01'), 'rc=' + r.status)
  t('正证：换装**留了备份**（_backup 里有换前那份）', fs.readdirSync(备).some((f) => /前换装/.test(f)))
  t('正证：换装落账了', JSON.parse(fs.readFileSync(账本, 'utf8')).rows.length >= 2)

  r = run(['退', '--id', '2', '--apply'])
  const b2 = JSON.parse(fs.readFileSync(基线, 'utf8'))
  t('正证：`退 --id` 一键退回 ⇒ 基线回到 A01', r.status === 0 && b2.行为动作.includes('A01') && !b2.行为动作.includes('A01新'), 'rc=' + r.status)
  t('正证：账上标了"已退"', JSON.parse(fs.readFileSync(账本, 'utf8')).rows.find((x) => x.id === 2).状态 === '已退')

  r = run(['换', '--类型', '行为动作', '--旧', 'A01', '--新', 'A01新', '--为什么', '替换', '--旧件去哪', 'x', '--apply'])
  r = run(['校'])
  t('校：换装账体检能跑（不炸）', typeof r.status === 'number')

  console.log('\n' + (fail === 0 ? '✅ 全绿' : '❌ 有红') + ' ' + pass + '/' + (pass + fail) + (fail === 0 ? ' —— 双证成立：拒收/备份/退回三条都真的会响' : ''))
  fs.rmSync(T, { recursive: true, force: true })
  return fail === 0 ? 0 : 1
}

// ───────────────────── 主流程 ─────────────────────
const [verb, ...rest] = process.argv.slice(2)
if (verb === 'selftest') process.exit(selftest())
const apply = has('--apply')
let rc = 0
if (!verb || verb === '账') rc = 账(has('--all'))
else if (verb === '校') rc = 校()
else if (verb === '加') rc = 加(arg('--类型'), arg('--名'), arg('--为什么'), apply)
else if (verb === '换') rc = 换(arg('--类型'), arg('--旧'), arg('--新'), arg('--为什么'), arg('--旧件去哪'), apply)
else if (verb === '退') rc = 退(arg('--id'), apply)
else { console.error('未知动作：' + verb + '\n用法：校 ｜ 账 [--all] ｜ 换 --类型 <…> --旧 <名> --新 <名> --为什么 <…> [--旧件去哪 <…>] [--apply] ｜ 加 --类型 <…> --名 <名> --为什么 <…> [--apply] ｜ 退 --id <N> [--apply] ｜ selftest'); rc = 2 }
process.exit(rc)
