#!/usr/bin/env node
// 掉档账.mjs · 1001 造 —— 掉档步（缓存命中<50%）到底是谁、花多少钱
import fs from "node:fs"; import path from "node:path"; import os from "node:os";
import { 解多帧 } from "./注入计量.mjs";
import { 每百万 } from "./价目.mjs";
const H = process.env.DSH_HOME || path.join(os.homedir(), ".dsh");
const 根 = path.join(H, "sessions");
const 会话 = [];
for (const ws of fs.readdirSync(根)) { const p = path.join(根, ws); if (!fs.statSync(p).isDirectory()) continue;
  for (const s of fs.readdirSync(p)) { const d = path.join(p, s); if (!fs.statSync(d).isDirectory()) continue;
    for (const f of fs.readdirSync(d)) if (f.endsWith(".zstd")) 会话.push({ 名: s, f: path.join(d, f) }); } }
const 价 = { 新入: 每百万.未命中.空闲, 缓存读: 每百万.命中.空闲 };  // ¥/百万（1018 收口：从 价目.mjs 取官方分档）
let 总新入=0,总缓存=0,掉步=0,掉新入=0,首步=0,掉首步=0,掉后=0,掉新入后=0;
const 榜=[];
for (const {名,f} of 会话) {
  let r; try { r = 解多帧(fs.readFileSync(f)); } catch { continue; }
  let 第几步=0; let 本会话掉=[];
  for (const l of r.文本.split("\n")) { if (!l.trim().startsWith("{")) continue;
    let e; try { e=JSON.parse(l) } catch { continue; }
    if (e.type!=="assistant/message") continue;
    const 找=(o)=>{ if(!o||typeof o!=="object")return null; if(Array.isArray(o)){for(const x of o){const y=找(x); if(y)return y} return null}
      if(o.inputTokens!==undefined) return o; for(const k of Object.keys(o)){const y=找(o[k]); if(y)return y} return null };
    const u=找(e); if(!u||!u.totalTokens) continue;
    第几步++;
    const 新=u.inputTokens||0, 缓=u.cacheReadTokens||0, 合=u.totalTokens;
    总新入+=新; 总缓存+=缓;
    if (缓/合 < 0.5) { 掉步++; 掉新入+=新; if (第几步===1) { 首步++; 掉首步++ } else { 掉后++; 掉新入后+=新; 本会话掉.push({seq:e.seq,新,合,第几步}) } }
  }
  if (本会话掉.length) 榜.push({名, 次:本会话掉.length, 新入:本会话掉.reduce((a,b)=>a+b.新,0), 前3:本会话掉.slice(0,3)});
}
const 钱=(t)=> "¥"+(t/1e6*价.新入).toFixed(2);
console.log("══ 掉档账（命中<50% 的步）══");
console.log(`步：总 ${(总新入, 0)===0?"":""}${掉步} 步掉档 ｜ 其中**会话第一步（冷启动）${掉首步}** ｜ 会话中途掉档 **${掉后}**`);
console.log(`新入 token：全部 ${总新入.toLocaleString()} ｜ 掉档步占 ${掉新入.toLocaleString()}（${(掉新入/总新入*100).toFixed(1)}%）｜ 其中中途掉档 ${掉新入后.toLocaleString()}（${(掉新入后/总新入*100).toFixed(1)}%）`);
console.log(`★ 若这些按全额价（¥2/百万）算：全部新入 ${钱(总新入)} ｜ **中途掉档那部分 ${钱(掉新入后)}**`);
console.log(`\n掉档最多的会话：`);
榜.sort((a,b)=>b.新入-a.新入).slice(0,8).forEach(x=>console.log(`   ${x.名.slice(0,24)} 掉 ${x.次} 步 ｜ 新入 ${x.新入.toLocaleString()} ｜ 前 3 步 seq=${x.前3.map(y=>y.seq).join(",")}（各在第 ${x.前3.map(y=>y.第几步).join("/")} 个用量步）`));
