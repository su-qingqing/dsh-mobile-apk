/**
 * 工具/内核/插件_连续性.js —— 阶段 4 的插件片段（**尚未贴进生产件**）
 *
 * 用法（将来）：由 @dsh-user/dsh-own-memory/lib/index.js 的 apply() 里调
 *   挂连续性(ctx)            ← 只多这一行 + 一个 import
 *
 * 判据不重复：全部复用 连续性.mjs（单一真源），本文件只做"挂载"这一层。
 * 不碰生产件、不重启；用假 ctx 即可冒烟。
 */
import { 开, 取, 门, 开工, 压缩, 封 } from './连续性.mjs'

export function 挂连续性(ctx, 记 = console.log) {
  // ① 一个工具 · 七个动作（工具名纯 ASCII，红线 20）
  ctx.effect(() => {
    const tools = ctx.get('tools')
    if (!tools || typeof tools.register !== 'function') { 记('continuity: tools 缺席，不注册（fail-open）'); return }
    const 工具 = {
      name: 'continuity',
      description: '轮次的钥匙与门：kickoff=开一轮并生成清单／fetch=取钥匙／gate=看门能不能开／start=开工／compress=压缩后重判／seal=留痕拿回执／status=只读',
      parameters: {
        type: 'object', additionalProperties: false,
        properties: {
          action: { type: 'string', enum: ['kickoff', 'fetch', 'gate', 'start', 'compress', 'seal', 'status'] },
          任务: { type: 'string', description: '本轮任务（生成清单用）' },
          上轮: { type: 'string', description: '上一轮遗留（生成清单用）' },
          键: { type: 'string', description: '钥匙 id 或来源' },
          步: { type: 'string', description: '步骤 id（seal 必填）' },
          结果: { type: 'string', description: '结果摘要' },
        },
        required: ['action'],
      },
      output: { schema: { type: 'object', additionalProperties: true }, render: (_a, v) => [{ type: 'text', text: JSON.stringify(v) }] },
      async execute(a) {
        switch (a.action) {
          case 'kickoff': return 开({ 任务: a.任务, 上轮: a.上轮 })
          case 'fetch': return 取(a.键)
          case 'gate': case 'status': return 门()
          case 'start': return 开工()
          case 'compress': return 压缩()
          case 'seal': return 封(a.步, a.结果)
          default: return { ok: false, note: '未知 action: ' + a.action }
        }
      },
    }
    const 注销 = [tools.register(工具)]
    记('continuity: ready（1 工具 · ' + 工具.parameters.properties.action.enum.length + ' 动作）')
    return () => 注销.forEach((f) => f())
  })

  // ② 压缩后重过门（外核第 2 刀）：见 compact-checkpoint 标记 ⇒ 打标 + 重判
  ctx.on('agent/pre-step', async (payload, next) => {
    const d = await next()
    try {
      if (!d || d.kind !== 'enter' || !Array.isArray(d.messages)) return d
      const 压了 = d.messages.some((m) => m?.source?.kind === 'compact-checkpoint')
      if (压了) {
        const r = 压缩()
        记(`continuity: 检测到压缩 ⇒ ${r.state}，门${r.门.pass ? '仍开' : '不开（缺 ' + r.门.missing.length + ' 把）'}`)
      }
    } catch (e) { 记('continuity: 压缩检测失败（fail-open）: ' + e.message) }
    return d
  })
}
