#!/usr/bin/env node
// 指针死查 —— 插件 ＋ 预设/技能 里写死的工作区路径，指的东西还在不在
// 用法：node 神经/插件死指针.mjs [--全]
//
// 为什么有它（2026-10-20 立）：
//   口令 4479 次、钉子户 2354 次 fail-open 躺了 36 天没人发现 —— 缺的是一道「引用的文件在不在」的常驻检查。
//   0928 批「12 个活 .mjs 在代码里写死老路径去归档区找东西」、1020 批搬家没改指针，都是同一个根。
//
// 判据：正则抓路径 → fs.existsSync。**只报存在性，不判该不该在**（内核 #71）。
// 本器自己的两个坑（1020 当场修，别再犯）：
//   ① 取 m[1]（捕获组只有「工具」两个字）⇒ 只出 3 条假绿；必须取 m[0]。
//   ② 扩展名顺序 js 在 json 前 ⇒ 轮.json 被截成 轮.js；顺序必须 mjs|json|js|md。
import fs from 'node:fs'
import path from 'node:path'

const 工作区 = '/storage/emulated/0/3'
const 预设 = '/data/data/com.dsharnessmobile.shell/files/home/.dsh/.agent-presets/suqingqing'
const 插件根 = '/data/data/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/node_modules/@dsh-user'
const 正则 = /(工具|台账|神经|记忆|内核)\/[A-Za-z0-9_\-\u4e00-\u9fa5/]+\.(mjs|json|js|md)(?![a-zA-Z0-9])/g

const 断 = []
const 全 = new Set()
// ★ 豁免（1021 加）：这三条是**合理不存在**，不是断点。判据附在每行后面，**不加宽口径**（内核 #71：判不了的绝不猜）。
const 豁免 = [
  { 相: /台账\/交付测试_内核_0918\.md$/, 因: '历史交付文档，已归档（内容在 _backup/搬家前_1020-0914 里）' },
  { 相: /台账\/开工卡\/MMDD-事项\.md$/, 因: '模板占位（MMDD 是日期占位符，不是真路径）' },
  { 相: /工具\/内核\/插件_连续性\.js$/, 因: '旧文件名（搬去 dsh-own-memory/lib/continuity.js 了），只在注释里' },
]
const 记 = (来源, 文, 名) => {
  for (const m of 文.matchAll(正则)) {
    if (全.has(m[0])) continue
    全.add(m[0])
    if (豁免.some((x) => x.相.test(m[0]))) continue
    if (!fs.existsSync(path.join(工作区, m[0]))) 断.push({ 来源, 名, 相: m[0], 行: 文.slice(0, m.index).split('\n').length })
  }
}

// ① 插件 lib/*.js
for (const 包 of fs.readdirSync(插件根)) {
  const lib = path.join(插件根, 包, 'lib')
  if (!fs.existsSync(lib)) continue
  for (const f of fs.readdirSync(lib)) {
    if (!/\.(js|mjs)$/.test(f)) continue
    记('插件', fs.readFileSync(path.join(lib, f), 'utf8'), 包 + '/' + f)
  }
}

// ② 预设 + 技能（.yml / .md / .mjs）
const 走 = (d) => {
  for (const f of fs.readdirSync(d)) {
    const p = path.join(d, f)
    const st = fs.statSync(p)
    if (st.isDirectory()) { 走(p); continue }
    if (!/\.(ya?ml|md|mjs|js)$/.test(f)) continue
    记('预设', fs.readFileSync(p, 'utf8'), p.replace(预设 + '/', ''))
  }
}
if (fs.existsSync(预设)) 走(预设)

console.log('扫了 ' + 全.size + ' 条唯一路径引用（插件 ＋ 预设/技能）')
if (!断.length) console.log('✅ 全部存在')
else {
  console.log('❌ 不存在的 ' + 断.length + ' 条：')
  for (const x of 断) console.log('  [' + x.来源 + '] ' + x.名 + ':' + x.行 + '  →  ' + x.相)
}
process.exit(断.length ? 1 : 0)
// 注：默认 exit 1（有断）好让外部当红；**打烊挂点调用时不能因它中断** —— 打烊用 try/catch 兜，
// 并把 e.stdout 里的报告原样印出来（见 工具/开工/打烊.mjs §二十四）。
