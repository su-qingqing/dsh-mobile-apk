// 改单 · manifest（0922 · 外部核整改三）
// 外部核（qwen3.8-max）判：`关联文件 mtime ≥ 改动起始` 是**把完整性校验偷换成活跃度校验** ——
//   「Agent 只要 touch 一下就能过闸，语义同步从未发生」（反例：三个月后真该改时，旧 mtime 把遗漏埋掉）。
// 所以本工具**不看 mtime**，只有一条硬规则：**「无需变更」必须写理由**（写理由这个动作本身逼我显式想）。
// 理由由下一轮／他抽检，机器只保证"这一格不是空的"。
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs'
const ROOT = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const 目录 = ROOT + '/台账/改单'
const 合法 = ['内容同步', '无需变更', '待确认']
const 表头 = '| 文件 | 状态 | 理由（「无需变更」必填） |\n|---|---|---|\n'
const 说明 = '> ⚠️ **本单不看 mtime** —— 外部核（qwen3.8-max）判定：mtime 比的是「文件被碰过」不是「内容同步了」，touch 一下就过闸，\n' +
             '> 真正的遗漏反而被埋掉。所以这里只有一条硬规则：**「无需变更」必须写理由**（≥6 字），下轮或老板抽检。\n'

export function 开(名, 时刻) {
  if (!名 || 名.length < 2) return { ok: false, 错: '改单名太短' }
  mkdirSync(目录, { recursive: true })
  const t = 时刻 || new Date().toISOString().slice(0, 16).replace('T', ' ').replace(/:/g, '')
  const p = 目录 + '/' + t + '-' + 名.replace(/[\/\s]+/g, '_') + '.md'
  writeFileSync(p, '# 改单 · ' + 名 + '\n\n> 起始 ' + t + ' ｜ 规矩：改动文件＋关联文件都写进来；状态三选一：' + 合法.join(' / ') + '\n\n' + 说明 + '\n' + 表头, 'utf8')
  return { ok: true, 路径: p }
}
export function 录(路径, 文件, 状态, 理由) {
  if (!路径 || !existsSync(路径)) return { ok: false, 错: '改单不存在：' + 路径 }
  if (!文件) return { ok: false, 错: '没给文件名' }
  if (!合法.includes(状态)) return { ok: false, 错: '状态必须是 ' + 合法.join('/') + '，收到「' + 状态 + '」' }
  const r = String(理由 || '').trim()
  if (状态 !== '内容同步' && r.length < 6) return { ok: false, 错: '状态「' + 状态 + '」必须写理由（≥6 字）—— 外部核：写理由这个动作本身逼你显式想；空格＝假装同步' }
  if (状态 === '内容同步' && !existsSync(ROOT + '/' + 文件)) return { ok: false, 错: '声称「内容同步」但这文件不存在：' + 文件 }
  const 行 = '| ' + 文件 + ' | ' + 状态 + ' | ' + (r || '（同步过）') + ' |\n'
  writeFileSync(路径, readFileSync(路径, 'utf8') + 行, 'utf8')
  return { ok: true, 行: 行.trim() }
}
export function 核(路径) {
  if (!路径 || !existsSync(路径)) return { ok: false, 错: '改单不存在：' + 路径 }
  const 行 = readFileSync(路径, 'utf8').split('\n').filter(l => /^\|/.test(l) && !/^\|\s*文件/.test(l) && !/^\|---/.test(l))
  const 数 = { 内容同步: 0, 无需变更: 0, 待确认: 0, 缺理由: 0, 文件不在: 0 }
  for (const l of 行) {
    const c = l.split('|').map(x => x.trim())
    const f = c[1], s = c[2], r = c[3] || ''
    if (数[s] !== undefined) 数[s]++
    if (s !== '内容同步' && r.length < 6) 数.缺理由++
    if (s === '内容同步' && f && !existsSync(ROOT + '/' + f)) 数.文件不在++
  }
  const 坏 = 数.缺理由 + 数.文件不在
  return { ok: 坏 === 0, 数, 说: '内容同步 ' + 数.内容同步 + ' ｜ 无需变更 ' + 数.无需变更 + ' ｜ 待确认 ' + 数.待确认 + ' ｜ 缺理由 ' + 数.缺理由 + ' ｜ 文件不在 ' + 数.文件不在 + '　（**不看 mtime**）' }
}
const isDirect = process.argv[1] && /改单\.mjs$/.test(process.argv[1])
const argv = isDirect ? process.argv.slice(2) : []
if (isDirect && argv[0] === 'selftest') {
  let pass = 0, all = 0
  const ck = (n, ok, 补) => { all++; if (ok) pass++; console.log((ok ? '✅' : '❌') + ' ' + n + (ok ? '' : '  → ' + 补)) }
  const p = 开('自测单', '2026-09-22 2359').路径
  ck('反证①：「无需变更」不写理由 ⇒ 拒收', 录(p, '神经/情境.mjs', '无需变更', '').ok === false)
  ck('反证②：状态乱写 ⇒ 拒收', 录(p, '神经/情境.mjs', '改完了', '因为所以科学道理').ok === false)
  ck('反证③：声称同步但文件不存在 ⇒ 拒收', 录(p, '工具/不存在.mjs', '内容同步', '').ok === false)
  ck('正例①：「无需变更」+理由 ⇒ 收', 录(p, '神经/情境.mjs', '无需变更', '本轮只动判据、不动分类表结构').ok === true)
  ck('正例②：真文件「内容同步」⇒ 收', 录(p, '神经/改单.mjs', '内容同步', '').ok === true)
  const r = 核(p)
  ck('核：报出裸数（含「不看 mtime」字样）', /不看 mtime/.test(r.说) && r.数.无需变更 === 1, r.说)
  ck('反证④：缺理由的行会被数出来', r.数.缺理由 === 0 && r.ok === true, JSON.stringify(r.数))
  console.log('改单 selftest ' + pass + '/' + all + (pass === all ? ' 全过' : ' ❌ 有红'))
  try { const fs = await import('node:fs'); fs.unlinkSync(p) } catch (e) {}
  process.exit(pass === all ? 0 : 1)
}
if (isDirect) {
  const [v, ...a] = argv
  if (v === '开') console.log(JSON.stringify(开(a.join(' ')), null, 1))
  else if (v === '录') console.log(JSON.stringify(录(a[0], a[1], a[2], a.slice(3).join(' ')), null, 1))
  else if (v === '核') { const r = 核(a[0]); console.log((r.ok ? '✅ ' : '❌ ') + r.说); process.exit(r.ok ? 0 : 1) }
  else console.log('用法：改单.mjs 开 <名> ｜ 录 <单> <文件> <内容同步|无需变更|待确认> [理由] ｜ 核 <单>')
}
