#!/usr/bin/env node
// 判据：内核 #70「边界不靠『我判断得准』，靠『结构上够不着』」—— 本工具用**结构**（不是我的克制）挡住不可逆操作。
// 唯一改文件通道（2026-09-19 建）—— 把「改文件」收敛成一条**自带五道保护**的路：
//   ① 命中数必须 === 1（不猜、不将就）  ② 先 cp 备份 .bak-<MMDD>-前<标记>
//   ③ 替换  ④ 目标是 js/mjs ⇒ node --check  ⑤ 正反复核（再反向替换一次必须与原文逐字一致）
//   ★ ⑥ 解析体检（2026-09-23 加）：目标是 .json/.yml/.yaml ⇒ **写入之前**先验解析；改前能读、改后读不了 ⇒
//        **拦下不写**（退出码 3＝fail-closed）。判据住工作区 `神经/解析体检.mjs`（热加载 ⇒ 改判据不用重启）。
//   ★ ⑦ 冻结预检（2026-09-23 加，老板亲口裁「直接去做」）：目标是**冻结清单**里的文件 ⇒ 先逐条印
//        「针／类／为什么冻」，再按类判（不许动＝整行逐字不变｜只能加＝只许往后追加）；**断针 ⇒ 拦下不写**
//        （退出码 3）。判据住工作区 `神经/冻结预检.mjs`（热加载）。这道门就是当天该拦住我的那道。
// 为什么建它：历史上我改文件的方式五花八门（heredoc / node -e / 手写补丁脚本 / sed），
//   反复在同一类地方翻车 —— 漏备份（摆了 6 次还是漏）、锚点撞多次、**补丁脚本自己语法错**。
//   收敛成一条路 ⇒ 这几类坑**结构上消失**（结构缺席 > 闸门拦截 > 条文）。
// 用法：node 神经/改文件.mjs <目标> --旧 <含旧串的文本文件> [--新 <含新串的文本文件>] [--标记 名]
//       ★ 不给 --新 = 删除那一段。**旧串/新串一律走文件** ⇒ JS 里零转义、不会再被反引号/引号绊倒。
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { 拿锁, 放锁 } from './锁.mjs';   // ★ 1007 夜：并发五处裸奔① —— 补**事前互斥**（此前只有乐观锁＝事后发现）
const WS = '/storage/emulated/0/3';
const a = process.argv.slice(2);
const flag = (n) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : '' };
const target = a[0];
const oldF = flag('--旧'), newF = flag('--新'), mark = flag('--标记') || '改文件';
if (!target || !oldF) { console.log('用法：改文件.mjs <目标> --旧 <旧串文件> [--新 <新串文件>] [--标记 名]'); process.exit(2) }
const rd = (f) => fs.readFileSync(f.startsWith('/') ? f : path.join(WS, f), 'utf8');
const T = target.startsWith('/') ? target : path.join(WS, target);
const oldS = rd(oldF);
const newS = newF ? rd(newF) : '';
const src = fs.readFileSync(T, 'utf8');
let n = src.split(oldS).length - 1;
let oldUse = oldS, newUse = newS;
// ★ 2026-09-19 四修：锚点落在**行中间**时，旧串文件结尾那个换行（heredoc 自动加的）会让命中数变 0，
//   而报错只说"命中 0 次"，看不出是多了个换行 ⇒ 自动试一次"去掉尾部换行"，并明确告诉你它这么做了。
if (n !== 1 && /\n$/.test(oldS)) {
  const alt = oldS.replace(/\n+$/, '');
  const m = src.split(alt).length - 1;
  if (m === 1) { oldUse = alt; newUse = newS.replace(/\n+$/, ''); n = 1; console.log('ℹ️ 旧串文件尾部换行不属于原文 ⇒ 已自动去掉尾部换行再匹配（锚点落在行中间时会这样）') }
}
if (n !== 1) { console.log('❌ 命中 ' + n + ' 次（必须恰好 1 次）⇒ 未改任何东西。目标 ' + T); process.exit(2) }
// ⚠️ 两个自己踩过的 bug（建好当天就修）：① 日期原来用 toISOString ⇒ 是 **UTC**，比设备本地早 8 小时，备份名会写成前一天；② 同一天同一个 --标记 跑第二次会**覆盖**第一次的备份 ⇒ 丢掉真正的"改前"状态。
// ★ 2026-09-29 接共用件（做法库 #278 的规矩：「**日期一律走 `神经/本地时间.mjs`**」）——
//   实证病灶：本件与 `打烊.mjs` 各自手写一遍"取本地月日"，而共用件 `本地时间.mjs` **一个 import 都没有**
//   （挂点体检 0929 报它真孤儿）⇒ 规矩写了、件立了、没人来取 ＝ 同一件事三处实现。
//   走**静态 import ＋ 本地兜底**：共用件读不到也绝不让改文件停摆（这是唯一改文件通道，B01）。
let 今天 = null;
try { ({ 今天 } = await import('./本地时间.mjs')) } catch (e) { 今天 = null }
const d = new Date();
const stamp = 今天
  ? 今天(d).slice(5, 7) + 今天(d).slice(8, 10)
  : String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
let bak = T + '.bak-' + stamp + '-前' + mark, k = 2;
while (fs.existsSync(bak)) { bak = T + '.bak-' + stamp + '-前' + mark + '-' + k; k++ }
fs.writeFileSync(bak, src);
const out = src.replace(oldUse, newUse);
/* ★ 2026-09-23 第六道保护：解析体检（钉子户板 0mu8y8vh2 的第三步「验证能不能被解析」）——
   备份 ＋ 逐字复核只证明"字节对了"，不保证"这份 YAML/JSON 还有人读得懂"。
   改前能解析、改后解析不了 ⇒ **拦下不写**（退出码 3）；改前本来就解析不了 ⇒ 只警告（不拦，别让老文件改不动）。
   判据住工作区 `神经/解析体检.mjs`（mtime 热加载）⇒ 以后改判据不用重启。 */
let 解析行 = '  解析体检 跳过（非配置类或模块没接上）'
let 拦下 = false
try {
  const PP = '/storage/emulated/0/3/神经/解析体检.mjs'
  const PM = await import('file://' + PP + '?v=' + fs.statSync(PP).mtimeMs)
  if (PM && typeof PM.体检文本 === 'function' && typeof PM.判 === 'function') {
    const 尾 = ((/\.([A-Za-z0-9]+)$/.exec(T) || [])[1] || '').toLowerCase()
    const 旧档 = PM.体检文本(src, 尾, T), 新档 = PM.体检文本(out, 尾, T)
    const d = PM.判(旧档, 新档)
    拦下 = !d.放行
    解析行 = '  解析体检（.' + (尾 || '无后缀') + '）' + (新档.档 === 'ok' ? '✅ ' : 新档.档 === '跳过' ? '⏭ ' : 新档.档 === '黄' ? '🟡 ' : '❌ ') +
      新档.说明 + '｜级别 ' + d.级别 + (PM.选库 ? '｜按路径选库=' + PM.选库(T) : '') + (d.级别 === '改前就红' ? '（改前这份就解析不了 ⇒ 只警告不拦）' : '')
  }
} catch (e) { 解析行 = '  解析体检 fail-open：' + ((e && e.message) || e) }
console.log(解析行)
if (拦下) { console.log('⛔ 拦下不写：新内容解析不了 ⇒ **文件保持原样**（老内容还在、备份也在）。先修好再改。'); process.exit(3) }
/* ★ 2026-09-23 第七道保护：冻结预检 —— 当天我改 #50 前只看了"命中 3 处"这个**数字**、没读那 3 处是什么，
   断了两根冻结针。这道门把"读内容"变成动作：命中清单就逐条印针／类／为什么冻；断针 ⇒ **拦下不写**。 */
let 冻行 = '  冻结预检 跳过（模块没接上）'
let 冻拦 = false
try {
  const FP = '/storage/emulated/0/3/神经/冻结预检.mjs'
  const FM = await import('file://' + FP + '?v=' + fs.statSync(FP).mtimeMs)
  if (FM && typeof FM.预检 === 'function') {
    const r = FM.预检(T, src, out, JSON.parse(fs.readFileSync('/storage/emulated/0/3/台账/冻结清单.json', 'utf8')))
    for (const x of r.说明) console.log('  ' + x)
    冻拦 = !r.放行
    冻行 = r.放行 ? '  冻结预检 ✅ ' + (r.条目.length ? '命中 ' + r.条目.length + ' 条冻结条目，没断针' : '不在冻结清单里') : '  冻结预检 ❌ 断针 ' + r.断针.length + ' 条 ⇒ 拒写'
  }
} catch (e) { 冻行 = '  冻结预检 fail-open：' + ((e && e.message) || e) }
console.log(冻行)
if (冻拦) { console.log('⛔ 拦下不写：这份文件在冻结清单里，这次替换会动到针 ⇒ **文件保持原样**（备份也在）。正规出口：先请老板裁 ⇒ 再 `node 工具/台账/冻结.mjs 校验 --基线` 接针（或先留样）。'); process.exit(3) }
/* ★ 2026-09-24 第八道保护：**乐观锁**（老板 09-22 批的 J1）—— 写前记指纹、写时比对，**变了就拒绝覆盖**。
   `待你决／在办／总库／交接单` 这些**文本**台账此前一把锁都没有（结构化那两份 `收手.db／claims.db` 已经有了）；
   本工程真发生过**丢更新**（总库被覆盖成 0 行）。语义：每次成功写入后把 `sha256(全文)` 前 16 位记进
   `神经/改文件指纹.json`；下次写之前拿它跟**盘上现内容**比 —— 不一样 ⇒ 说明我读过之后有人动过 ⇒ 拒绝。
   确实要以手上这份为准：`--强改`（会印留痕行）。 */
const 锁档 = '/storage/emulated/0/3/神经/改文件指纹.json'
const { createHash } = await import('node:crypto')
const sha16 = (b) => createHash('sha256').update(b).digest('hex').slice(0, 16)
let 锁 = {}
try { 锁 = JSON.parse(fs.readFileSync(锁档, 'utf8')) } catch {}
const 强改 = process.argv.includes('--强改')
const 现纹 = sha16(fs.readFileSync(T))
const 记纹 = 锁[T] && 锁[T].sha
if (记纹 && 记纹 !== 现纹 && !强改) {
  console.log('⛔ 乐观锁拦下：' + T + ' 在**我上次写入之后被改过**（记 ' + 记纹 + ' ≠ 现 ' + 现纹 + '）⇒ 不覆盖。')
  console.log('   重新读一遍再改；或 `--强改` 明确以手上这份为准。')
  process.exit(3)
}
if (强改 && 记纹 && 记纹 !== 现纹) console.log('（留痕）--强改：' + T + ' 记 ' + 记纹 + ' → 现 ' + 现纹)
/* ★ 1007 夜（老板点头「按你的建议来」）：**租约写前检查** —— 接进唯一改文件通道，**只报警不硬拦**。
   别人（别的窗）正持着这份文件的租约 ⇒ 印一行薄警告（rc 不变）；没人持／查不通 ⇒ 一个字不印。
   租约件名有「带工作区前缀／不带」两种写法 ⇒ 两种都查一遍（实测租约不做归一化）。 */
let 租约行 = 0
try {
  const 我窗 = process.env.DSH_SESSION_ID || ''
  const LM = '/storage/emulated/0/3/神经/租约.mjs'
  const 前缀 = '/storage/emulated/0/3/'
  const 归 = (p) => { let s = String(p); if (s.startsWith(前缀)) s = s.slice(前缀.length); if (s.startsWith('./')) s = s.slice(2); return s }
  const 持 = []
  for (const q of [...new Set([String(T), 归(T)])]) {
    const r = spawnSync(process.env.DSH_NODE || 'node', [LM, '查', q, '--json'], { encoding: 'utf8', timeout: 4000 })
    if (r.status === 0 && r.stdout) {
      for (const x of (JSON.parse(r.stdout).条 || [])) {
        if (x && x.持有人 && x.持有人 !== 我窗 && x.状态 === '有效' && !持.some(y => y.件 === x.件 && y.持有人 === x.持有人)) 持.push(x)
      }
    }
  }
  for (const x of 持) { console.log('⚠️ 租约提示（不拦）：' + T + ' 现由 **' + x.持有人 + '** 持有（到期 ' + (x.到期人话 || x.到期) + '）⇒ 确认不是同一件活再改。'); 租约行++ }
} catch (e) { /* fail-open：租约查不通不挡路、也不出声 */ }
if (!租约行 && process.env.改文件_印租约行 === '1') console.log('  租约提示 ✅ 没人持')
/* ★ 1010 夜 · 保护之十：**承重测绘（写入之前）** —— 老板点名「最大的问题是**没有正确的前提**，
   总是用自己以为的事情去干活」＋「改之前先量盘上真有什么」。与保护之九的区别：**九是改完之后才报**
   （外部核的话：「只停在改文件时印一下，它会是一个很高级的灯」）⇒ 这一条要在**动手前**问「谁在消费它」。
   判据本体住 `神经/耦合连续性.mjs`（热加载 ⇒ 改判据不用重启）。豁免：台账/记忆/调研/备份（记录件，不是生产件）。
   规则：rc=0 两栏空 ⇒ 绿｜rc=1 有机器消费者 ⇒ 🔴 印出来 + 要 `DSH_LOAD_OK=1` 才放行（否则 exit 5 不写）
        ｜rc=2 判据读不到 ⇒ fail-closed 拦｜超时/异常 ⇒ fail-open（印一行"没量到"，绝不让通道停摆）
   ★ 1010 自测抓到的坑：**环境变量名必须是 ASCII** —— 第一版写 `DSH_承重已核`，bash 里
   `DSH_承重已核=1 node …` 直接报 `command not found`（bash 变量名只许 [A-Za-z0-9_]）⇒ 改用 `DSH_LOAD_OK`。 */
{
  const _工 = WS + '/神经/耦合连续性.mjs'
  const _rel = path.relative(WS, T)
  const _豁免 = /^(台账|记忆|调研|_backup|_事故|\.dsh-kickoff)\//.test(_rel) || /\.bak-/.test(_rel)
  if (!_豁免 && fs.existsSync(_工)) {
    const _r = spawnSync(process.env.DSH_NODE || 'node', [_工, '查', _rel], { encoding: 'utf8', timeout: 20000 })
    const _o = String(_r.stdout || '')
    const _件 = _o.split('\n').filter((l) => /^  · /.test(l)).map((l) => l.trim().slice(2))
    if (_r.status === 1) {
      console.log('🔴 承重测绘（改前）：**有人把它当上游**（' + _件.length + ' 件）⇒ 动它就得连带改这些件、并逐件复验：')
      _件.slice(0, 8).forEach((x) => console.log('    · ' + x))
      if (_件.length > 8) console.log('    …另 ' + (_件.length - 8) + ' 件（看全量：node 神经/耦合连续性.mjs 查 ' + _rel + '）')
      if (process.env.DSH_LOAD_OK !== '1') {
        console.log('    ⛔ 未确认 ⇒ **拦下不写**（exit 5）。想清楚连带面、确认要动 ⇒ 加 `DSH_LOAD_OK=1` 重跑同一条命令。')
        process.exit(5)
      }
      console.log('    ✅ 已显式确认（DSH_LOAD_OK=1）⇒ 继续写入')
    } else if (_r.status === 2) {
      console.log('⛔ 承重测绘 fail-closed：判据读不到 ⇒ **不许无前提动手**：' + (_o.trim().split('\n').pop() || ''))
      if (process.env.DSH_LOAD_OK !== '1') process.exit(5)
    } else if (_r.status === 0) {
      console.log('  承重测绘 ✅ 机器栏空（可以动；备份＋沙盒照旧，红线 5／19）')
    } else {
      console.log('  承重测绘 ⏭ 没量到（rc=' + _r.status + '）⇒ fail-open，不挡路')
    }
  }
}
// ★ 1007 夜：**事前互斥** —— 两窗同时改同一份 ⇒ 后者等锁（等不到就如实报、不动手），不再并肩写
{ const _锁名 = '改文件-' + T
  const _l = 拿锁(_锁名, { 等毫秒: Number(process.env.改文件_等锁毫秒 || 8000) })
  if (!_l.ok) { console.log('⛔ 另一窗正在改这份 ⇒ 等不到锁，先不动：' + T + '（' + _l.因 + '）'); process.exit(4) }
  try { fs.writeFileSync(T, out) } finally { 放锁(_锁名) } }
const roundOK = out.replace(newUse, oldUse) === src;
let check = '跳过（非 js/mjs）';
if (/\.(mjs|js|cjs)$/.test(T)) {
  const r = spawnSync('node', ['--check', T], { encoding: 'utf8' });
  check = r.status === 0 ? '通过' : ('失败 ' + String(r.stderr || '').split('\n').slice(0, 2).join(' / '));
}
/* ★ 2026-09-24 保护之八·补一：**改坏了要能自己退回去**。
   实案（09-23 夜）：我在 shebang 前插了一行注释，把这条"唯一通道"自己弄坏 —— 它**只报错、不回滚**，
   文件停在坏状态，之后每一次编辑全部 rc=1。判据：**"报了错"不等于"没改坏"**。 */
const 改坏 = (!roundOK || check.startsWith('失败'))
if (改坏) {
  fs.writeFileSync(T, fs.readFileSync(bak))
  console.log('❌ 已改坏 ⇒ **自动回滚**：' + T + ' 已从 ' + path.basename(bak) + ' 逐字还原')
  console.log('   原因：' + (!roundOK ? '正反复核不一致' : 'node --check 失败'))
  process.exit(3)
}
console.log('✔ 已改 ' + T);
console.log('  备份 ' + path.basename(bak) + '（' + src.length + ' → ' + out.length + ' 字节）');
console.log('  正反复核 逐字一致');
try { 锁[T] = { sha: sha16(fs.readFileSync(T)), at: new Date().toISOString().slice(0,16).replace('T',' ') }; fs.writeFileSync(锁档, JSON.stringify(锁, null, 1)) } catch {}
console.log('  node --check ' + check);
/* ★ 2026-10-10 保护之九：**连续性（影响面）当场报** —— 老板 1009 夜问「为什么当初在改的时候
   没有把连续性考虑进去？以前埋的坑，当场就能发现，现在埋的坑越来越深」。
   病根：这是唯一改文件通道，可改完**没有任何东西**告诉我"谁在消费它／它引用的东西还在不在"，
   坑要等很久（甚至等老板"感觉不对"）才浮出来。判据本体住 `神经/连续体检.mjs`（热加载 ⇒ 改判据不用重启）。
   **只报不拦**；fail-open：体检跑不了 ⇒ 一声不响，绝不让这条通道停摆。 */
try {
  const _体 = WS + '/神经/连续体检.mjs'
  if (fs.existsSync(_体)) {
    const _r = spawnSync(process.env.DSH_NODE || 'node', [_体, '件', path.relative(WS, T)], { encoding: 'utf8', timeout: 8000 })
    for (const _l of String(_r.stdout || '').trim().split('\n').filter(Boolean)) {
      if (_l.startsWith('连续 ') || _l.includes('🔴')) console.log('  ' + _l.trim())
    }
  }
} catch { }
process.exit(0);
