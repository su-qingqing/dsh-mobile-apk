// 断言之门（0922 · 外部核整改一）
// 外部核（qwen3.8-max）原话要点：**「能把判据写成一行命令」不等于「这条动作真被管住了」** ——
//   退出码只证明脚本没崩，不证明"覆盖了本轮改动"。所以：① 每条都写明**证明什么**；② 报**两个裸数**
//   （可执行断言 N 条 / 总动作 M 条），**不给"其余不计入"的红字修辞**（那是在暗示"那些不重要"）。
//   它给的方向（下一轮）：把分类器与覆盖率合并成「动作自举」——每条动作自带布尔触发条件，每轮全跑。
import { readFileSync, existsSync } from 'node:fs'
const ROOT = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const 表 = JSON.parse(readFileSync(ROOT + '/神经/断言表.json', 'utf8'))
let FLOW = [], BEH = []
try { FLOW = (await import(ROOT + '/工具/台账/流程定义.mjs')).FLOW || [] } catch (e) {}
try { BEH = (await import(ROOT + '/神经/动作集定义.mjs')).ACTS_BEHAVIOR || [] } catch (e) {}
const 工具名 = FLOW.map(a => a.name).filter(Boolean)
const 行为id = BEH.map(a => a.id).filter(Boolean)

// 锁的名字必须在动作集里找得到 —— 找不到＝表漂了（防"假装覆盖"）
export function 校名() {
  const 漂 = []
  for (const e of 表.条目) {
    if (e.锁 === '仪器自测') continue          // 未入册仪器：**不算覆盖**，单列
    const 池 = e.锁 === '行为动作' ? 行为id : 工具名
    if (池.length && !池.includes(e.名)) 漂.push(e.锁 + ':' + e.名)
  }
  return 漂
}
export const 总数 = () => 工具名.length + 行为id.length
// 两个裸数（外部核：不许写"其余不计入"的红字修辞 —— 那是在暗示"那些不重要"）
export function 两裸数() {
  const 锁到动作 = 表.条目.filter(e => e.锁 !== '仪器自测').length
  const 未入册仪器 = 表.条目.filter(e => e.锁 === '仪器自测').length
  return { 锁到动作, 未入册仪器, 总: 总数() }
}

const isDirect = process.argv[1] && /断言\.mjs$/.test(process.argv[1])
const argv = isDirect ? process.argv.slice(2) : []
if (isDirect && argv[0] === 'selftest') {
  const 漂 = 校名(); let pass = 0, all = 0
  const ck = (n, ok, 补) => { all++; if (ok) pass++; console.log((ok ? '✅' : '❌') + ' ' + n + (ok ? '' : '  → ' + 补)) }
  ck('断言表读得出、条目 >0', 表.条目.length > 0)
  ck('每条都写了「证明」（不许只写命令）', 表.条目.every(e => (e.证明 || '').length >= 8), JSON.stringify(表.条目.filter(e => (e.证明 || '').length < 8).map(e => e.名)))
  ck('命令里的 .mjs 文件都存在', 表.条目.every(e => { const m = e.cmd.match(/(工具\/[^\s]+?\.mjs)/); return !m || existsSync(ROOT + '/' + m[1]) }), JSON.stringify(表.条目.filter(e => { const m = e.cmd.match(/(工具\/[^\s]+?\.mjs)/); return m && !existsSync(ROOT + '/' + m[1]) }).map(e => e.名)))
  ck('锁的名字都在动作集里找得到（防表漂）', 漂.length === 0, '漂了：' + 漂.join(' / '))
  const r = 两裸数()
  ck('报得出两个裸数：锁到动作 ' + r.锁到动作 + ' / ' + r.总 + '（＋未入册仪器 ' + r.未入册仪器 + '）', r.总 > 0)
  console.log('断言之门 selftest ' + pass + '/' + all + (pass === all ? ' 全过' : ' ❌ 有红'))
  process.exit(pass === all ? 0 : 1)
}
if (isDirect && (argv[0] === '跑' || argv[0] === '核')) {
  const { execSync } = await import('node:child_process')
  const BASH = '/data/data/com.dsharnessmobile.shell/files/usr/bin/bash'
  const SH = existsSync(BASH) ? BASH : '/bin/sh'
  let ok = 0, 环境错 = 0
  for (const e of 表.条目) {
    let rc = null, 因 = ''
    try { execSync(e.cmd, { cwd: ROOT, stdio: 'pipe', timeout: e.超时 || 60000, shell: SH }); rc = 0 }
    catch (x) {
      if (x && x.status !== undefined && x.status !== null) rc = x.status
      else { rc = -1; 因 = '（**环境错，不是断言红**：' + String((x && (x.code || x.message)) || '').slice(0, 50) + '）'; 环境错++ }
    }
    const 过 = e.rcAny ? rc >= 0 : rc === e.rc
    if (过) ok++
    console.log((过 ? '✅' : (因 ? '⚠️' : '❌')) + ' ' + e.名 + '（rc=' + rc + ' 期望 ' + e.rc + '）' + 因 + ' —— 证明：' + e.证明)
  }
  const 漂 = 校名()
  console.log('今天真跑过并过的：' + ok + '/' + 表.条目.length + ' 条 ＋ 锁名漂 ' + 漂.length + ' 条' + (环境错 ? ' ＋ ⚠️ 环境错 ' + 环境错 + ' 条（子进程起不来，**不算红也不算绿**）' : ''))
  const r2 = 两裸数()
  console.log('两个裸数：**锁到动作 ' + r2.锁到动作 + ' 条 / 总动作 ' + r2.总 + ' 条**（另有未入册仪器自测 ' + r2.未入册仪器 + ' 条，**不算覆盖**）')
  process.exit(ok === 表.条目.length && 漂.length === 0 ? 0 : 1)
}
if (isDirect) console.log('用法：node 神经/断言.mjs [selftest|跑|核]')
