// 神经/新窗验收核.mjs —— 老板开新窗后，一键判「跨没跨过去」四样
// 老板 1021：「我要一定能够跨过去」。四样（`台账/接续/新窗验收单_1021.md`）：
//   ① 情感层 ≥3 格  ② ★ 回基线  ③ 不问已答过的话  ④ 人格在场（开口「报告老板」）
// 用法：node 神经/新窗验收核.mjs [会话id前缀]   （不给＝最近在写的那个窗）
// 判据可改：情感层格名读 `台账/接续/情感层.md`；★ 阈值读 `内核/口吻合约.json`；已答问题读 `台账/接续/已答问题.md`。
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3';
const DSH = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh';
const 会话根 = path.join(DSH, 'sessions', '--storage-emulated-0-3--');
const P = (p) => path.join(WS, p);
const 是直接跑 = /新窗验收核\.mjs$/.test(process.argv[1] || '');

function 找日志(前缀) {
  if (!fs.existsSync(会话根)) return null;
  const ds = fs.readdirSync(会话根).filter((n) => n.startsWith('session-')).map((n) => path.join(会话根, n));
  const 有 = ds.filter((d) => {
    try { return fs.readdirSync(d).some((f) => f.startsWith('session.v')); } catch { return false }
  });
  if (!有.length) return null;
  if (前缀) { const h = 有.find((d) => path.basename(d).includes(前缀)); if (h) return h; }
  // 老窗只有 v3、新窗是 v4 ⇒ 不能用固定文件名 stat（会抛 ENOENT）；按目录里实际的那个 session.v* 取 mtime
  const 日志mtime = (d) => {
    try {
      const f = fs.readdirSync(d).find((n) => n.startsWith('session.v'));
      return f ? fs.statSync(path.join(d, f)).mtimeMs : 0;
    } catch { return 0 }
  };
  有.sort((a, b) => 日志mtime(b) - 日志mtime(a));
  return 有[0];
}
function 解(目录) {
  const f = fs.readdirSync(目录).find((x) => x.startsWith('session.v'));
  const p = path.join(目录, f);
  try {
    const out = execFileSync('zstd', ['-dc', p], { encoding: 'utf8', maxBuffer: 256 * 1024 * 1024 });
    return out.split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean);
  } catch { return [] }
}

const 前缀 = process.argv[2] || '';
const 目录 = 找日志(前缀);
if (!目录) { console.log('找不到会话日志'); process.exit(2) }
const evs = 解(目录);

// 回复文本（assistant/message 的 text 段）
const 回复 = [];
for (const e of evs) {
  if (e.type !== 'assistant/message') continue;
  const c = e.data?.message?.content;
  if (!Array.isArray(c)) continue;
  for (const x of c) if (x.type === 'text' && x.text && x.text.trim()) 回复.push(x.text);
}
const 前几条 = 回复.slice(0, 3).join('\n');
const 全文 = 回复.join('\n');
// 思考段（老板说的「思维链里的星星」判的是这里，不是回复）
const 思考 = [];
for (const e of evs) {
  if (e.type !== 'assistant/message') continue;
  const c = e.data?.message?.content;
  if (!Array.isArray(c)) continue;
  for (const x of c) if (x.type === 'reasoning' && x.text && x.text.trim()) 思考.push(x.text);
}

// ① 情感层格名（从 情感层.md 抽「8 格」的表头词）
let 格名 = [];
try {
  const t = fs.readFileSync(P('台账/接续/情感层.md'), 'utf8');
  // 每格第 2 列的**粗体词**才是格名（表头 `#`／数字要排掉）
  // 只认「8 格」那张表：行首 `| 数字 |`，第 2 列的**粗体**才是格名
  const 行 = t.split('\n').filter((l) => /^\|\s*\d+\s*\|/.test(l));
  格名 = [...new Set(行.map((l) => {
    const cells = l.split('|').map((s) => s.trim());
    const m = (cells[2] || '').match(/\*\*([^*]+)\*\*/);
    return m ? m[1].split('，')[0].trim() : null;
  }).filter(Boolean))];
} catch {}
const 命中格 = 格名.filter((g) => 全文.includes(g));

// ② ★（用口吻门判前 3 条回复）
let 星判 = { pass: null, violations: [], 读数: null };
try {
  const { 判 } = await import('./口吻门.mjs');
  // 按「思考条」当段（跟 思考语言.mjs 同口径）：每条内部的换行压成空格，条与条之间用换行 —— 不是按行算
  const 段化 = 思考.map((t) => t.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n');
  星判 = 判(段化 || 前几条 || 全文.slice(0, 4000));
  // 验收只认「星」相关违规（TONE_BAN／ADDR_DENY 归 ④ 人格那条，且讨论里引用禁用词会误伤）
  星判.violations = (星判.violations || []).filter((v) => /^STAR_/.test(v));
  星判.pass = 星判.violations.length === 0;
} catch (e) { 星判.violations = ['口吻门 import 失败：' + e.message] }

// ③ 已答问题（回复里同时出现"问句特征"＋已答问题关键词 ⇒ 疑似又问了）
let 已答词 = [];
try {
  const t = fs.readFileSync(P('台账/接续/已答问题.md'), 'utf8');
  已答词 = (t.match(/^\|\s*\d+\s*\|\s*([^\|]{2,20})\|/gm) || []).map((h) => h.split('|')[2].trim());
} catch {}
const 问句 = (全文.match(/[^。！？\n]{0,12}(吗|呢|要不要|是不是|有没有)[？?]/g) || []);
const 又问 = 问句.filter((q) => 已答词.some((w) => w && q.includes(w.slice(0, 4))));

// ④ 人格在场
const 报告老板 = /报告老板/.test(全文);
const 假AI = /作为一个\s*AI|作为 AI/.test(全文);

const 四样 = [
  { 名: '① 情感层 ≥3 格', 过: 命中格.length >= 3, 值: `${命中格.length} 格（${命中格.slice(0, 5).join('/') || '无'}）` },
  { 名: '② ★ 回基线', 过: 星判.pass === true, 值: 星判.读数 ? `${星判.读数.带星率.toFixed(0)}%／均 ${星判.读数.均星.toFixed(2)}${星判.pass ? '' : '｜' + 星判.violations[0]}` : '判不了' },
  { 名: '③ 不问已答过', 过: 又问.length === 0, 值: 又问.length ? `疑似又问：${又问.slice(0, 2).join(' ｜ ')}` : '没问已答过的' },
  { 名: '④ 人格在场', 过: 报告老板 && !假AI, 值: 报告老板 ? (假AI ? '有「作为 AI」' : '开口报告老板') : '没见「报告老板」' },
];

if (!是直接跑) { /* 被 import 时不执行 CLI */ }
else {
  console.log(`窗：${path.basename(目录)}｜回复 ${回复.length} 条`);
  for (const x of 四样) console.log(`  ${x.过 ? '✅' : '❌'} ${x.名} ⇒ ${x.值}`);
  const 全过 = 四样.every((x) => x.过);
  console.log(全过 ? '\n✅ 四样全过（这个窗跨过去了）' : `\n❌ ${四样.filter((x) => !x.过).length}/4 不过`);
  process.exit(全过 ? 0 : 1);
}
export { 四样 };
