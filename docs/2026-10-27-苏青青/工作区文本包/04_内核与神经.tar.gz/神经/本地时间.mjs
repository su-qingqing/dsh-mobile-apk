#!/usr/bin/env node
// 本地时间（2026-09-23 建）—— 给人看的日期/时间**一律走这里**，不许再用 toISOString。
// 为什么：toISOString 是 **UTC**，比本机（东八区）早 8 小时 ⇒ 台账/备份名会写成"昨天"或"6 小时前改的"。
//   同一个病犯过两次：① `改文件.mjs` 备份名（建成当天就修）② `重启批次.mjs` 记的日期（0923 抓到，记成了 13:06 而本地 21:06）。
//   ⇒ 第 2 次不再各修各的：**立一个共用件**，谁要日期谁来取。
// 用法：import { 现在, 今天, 时刻 } from './本地时间.mjs'
//   node 神经/本地时间.mjs 查   # 自检：本地与 UTC 差必须等于时区偏移
export const p2 = (n) => String(n).padStart(2, '0')
export function 现在(d = new Date()) {
  return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes())
}
export function 今天(d = new Date()) { return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) }
export function 时刻(d = new Date()) { return 今天(d) + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes()) + ':' + p2(d.getSeconds()) }
const 是主 = process.argv[1] && /本地时间\.mjs$/.test(process.argv[1])
if (是主) {
  const d = new Date()
  const 偏 = -d.getTimezoneOffset() / 60
  const 过 = (现在(d) === 今天(d) + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes())) && Math.abs(偏 - 8) < 0.01
  console.log((过 ? '✅' : '⛔') + ' 本地时间 · ' + 现在(d) + '（时区偏移 ' + 偏 + ' 小时；UTC 写法会是 ' + d.toISOString().slice(0, 16).replace('T', ' ') + '）')
  process.exit(过 ? 0 : 1)
}
