#!/usr/bin/env node
// 术语表 v1 —— **给他的报表里，每个英文名／技术词后面必须跟一个小括号白话**
//
// 老板 2026-09-19 原话（这一条已纠正第 5 次）：
//   「挂的这个文件的英文名旁边**加一个小写的括号**，让我看得懂这是干什么用的，
//    然后它的英文名**翻译成一个很白话的中文**，它是有什么功能，然后这样子我就看得懂了嘛」
// ⇒ 病根不是"我这次忘了"，是**"哪些词算专业词"一直靠我现想** ⇒ 每次赶进度就漏。
//    治法：把"必须翻的词"变成**一份清单**（真源就在下面 TERMS），并且能被机器扫。
//
// 用法：
//   node 神经/术语.mjs 表              # 印全表（他也能看）
//   node 神经/术语.mjs 查 turn         # 查一个词
//   node 神经/术语.mjs 扫 <文件…>       # 术语体检：找出"出现但**没带括号解释**"的裸术语
//   node 神经/术语.mjs selftest        # 阴性对照（裸的必须报、带括号的必须不报）
import fs from 'node:fs';
import path from 'node:path';

// ★ 真源：英文名／标识符 → 一句白话（他看得懂的那种，不写行话）
export const TERMS = {
  // ── 接手／收尾的仪器 ─────────────────────────────
  '库.mjs': '开工第一屏——一句命令，把「我是谁、在办几件、上一轮欠什么」抽到眼前',
  '简报.mjs': '比"库"更细的清单（台账目录／仪器一览／内核条数）',
  '打烊.mjs': '轮末收工清单——把这一轮的账、交的件、学到什么、下一步，一次算清楚',
  '接续.mjs': '读**已经关掉的**旧窗口（活着的窗口用 read_window 读）',
  '采集.mjs': '把各个窗口的产出物逐条 `ls` 验一遍，报"哪些还在、哪些找不到"',
  '总库.md': '接手要用的**目录页**——每样东西在哪、多大、怎么取',
  // ── 交付／验证 ─────────────────────────────────
  '交付清单.mjs': '交付前固定要跑的清单——只打红绿，不下"能不能交"的判决',
  '双证.mjs': '正证＋反证一起跑：证明判据不是"永远绿"',
  '跑全部.mjs': '老事故重考卷——过去翻过的车，再考一遍',
  '界面断言.mjs': '界面快照对比——没列进"本次只该改的几处"的变化，一律判失败',
  '干净房间.mjs': '隔离沙盒——在一个一次性副本里跑命令，跑完审计有没有越界、有没有留垃圾',
  '冻结.mjs': '查"标着不许动的东西"有没有被别的窗口动过',
  '证据.mjs': '给结论盖防改章（算哈希），别人可以自己验',
  '收手门.mjs': '你的待办队列——**只有你说「验收通过」，那一行才勾**',
  '调度.mjs': '算「本轮走到哪一步、还漏了什么」的那个调度器（它吐出工具结果后面那行）',
  '动作集.mjs': '动作清单的读写工具（核／印／坑／记坑／补入）',
  '闸门自测.mjs': '闸门插件的回归测试——假环境里挂真插件，不碰生产',
  '挂点体检.mjs': '扫「我们该做的事，有没有挂在必然发生的时刻上」',
  '指纹基线.json': '内核条数与哈希的**唯一真值**（别背数字，以它为准）',
  // ── 引擎里的"时刻"（英文事件名） ─────────────────
  'agent/turn-stopping': '引擎的「这一轮要收尾了」时刻——模型不再输出时，引擎叫我一次',
  'tools/post-execute': '「每一次工具调用之后」的时刻——现在那行状态行就挂在这',
  'tools/pre-execute': '「每一次工具调用之前」的时刻——开工闸门拦人就拦在这',
  'agent/pre-step': '「我每次要动手之前」的时刻',
  // ── 手艺词 ────────────────────────────────────
  'spawn': '另起一个小进程去跑一条命令（它失败了会刷一大段报错栈）',
  '5th arg': '第 5 个参数——调用时少传了它，所以检查拿不到"依据页"',
  'mtime': '文件的最后修改时间（用它可以判断"文件换了没换"，换了就重新加载）',
  'fail-open': '出错了就**放行**（宁可不拦，也不误伤）',
  'selftest': '仪器自己验自己——喂已知答案，答错就报红',
  '反证': '故意把关键特征抹掉／用错跑法，看它**会不会变红**；不会变红＝这个"绿"没意义',
  '双证': '正证（照正确判据跑的绿）＋ 反证（抹掉特征必须变红）两样都有',
  '裸术语': '一个英文名或技术词直接贴在报表里，**后面没有小括号白话**——你就看不懂',
};

// ★ 报表固定尾句（老板 2026-09-19 点名：「这一句话要直接保留下来，在我每一次看你的报表的时候，你应该加一句」）
//   他要的三个意思：① 看不懂就喊停（我马上翻给他）② 他明确说「进行下一步」之前我不动手 ③ 优先处理他那端的问题
// ★★ 1009 修根（老板当场质问「为什么一直在下一步不是说让你自己跑吗」）：第 ② 条与他给的**放手期**
//   （09-22「不要来问我」／1009「你下一步自己去做啊，跑个长期任务」）**打架**；两造**都是他定的** ⇒
//   不许我私自挑（红线 15）⇒ 做成**状态可判**：盘上有 `台账/接续/放手期.json` 且 `授权:true` ⇒ 吐**放手版**
//   （保留"看不懂就喊停"，去掉"我不动手"，改成"我接着做 X"）；**没有那个文件 ⇒ 逐字不变**（标准版）。
const 放手期 = (() => { try { return JSON.parse(fs.readFileSync('/storage/emulated/0/3/台账/接续/放手期.json', 'utf8')) } catch { return null } })();
const 标准尾句 = [
  '**⚠️ 读完先别急着让我往下走**：这份报表里**任何一处**专业名词看不懂，或觉得逻辑有问题，直接说一句就行（例：「turn-stopping 是什么」／「第 3 条逻辑不对」）——',
  '① 我**马上停手**，用 `术语.mjs 查`（术语表查询：英文名 → 一句白话）当场翻给你，**问哪里解释哪里**；',
  '② **在你明确说「进行下一步」之前，我不会动手做下一步**；',
  '③ **优先处理你这端的问题**：先把你看不懂的、觉得不对的弄清楚，我们再继续。',
  // ★ 1021 加（老板令「想办法，治根」）：**落款一律机器生成，不再手写**。
  //   病根（实测：两份报告各犯一次）：手写时写成「苏青青 · 你的工作助理」（顺序颠倒）⇒ 报告体检逐字认不到 ⇒ 报「缺④落款」。
  //   治法：尾句整块一步吐出 ⇒ 我贴整块就不可能写错（六格从"靠我记得"变成"抄现成的"）。
  '工作助理 · 苏青青',
].join('\n');
const 放手尾句 = [
  '**⚠️ 这一轮我自己接着跑、不停下等你**（你说的「自己去做」）—— 这是你授的**放手期**；但报表里**任何一处看不懂 ⇒ 当场问**，或觉得逻辑不对，说一句我就**马上停手**当场翻给你：',
  '① **看不懂当场问**：用 `术语.mjs 查`（术语查询：英文名 → 一句白话）—— **问哪里、解释哪里**；',
  '② **我接着做：' + ((放手期 && 放手期.接着做) || '当前主线') + '** —— 做完给你结论，**不再问「下一步做不做」**（⚠️ 这是放手期的例外：**标准口径仍是「我没说进行下一步不动手」**，你说停或「打烊」⇒ 立刻回到那条）；',
  '③ 你要改方向、叫停、或优先处理你这端的事，直接说一句。',
].join('\n');
export const TAIL = (放手期 && 放手期.授权) ? 放手尾句 : 标准尾句;

const args = process.argv.slice(2);
const out = (...a) => console.log(...a);
const keys = Object.keys(TERMS);

if (args[0] === '表' || args[0] === 'list') {
  out('术语表（' + keys.length + ' 条）—— 给我自己看，也给他看：每个词后面那句话就是该跟在他面前的样子\n');
  for (const k of keys) out('  ' + k.padEnd(24) + ' = ' + TERMS[k]);
  process.exit(0);
}

if (args[0] === '查') {
  const q = (args[1] || '').toLowerCase();
  const hits = keys.filter((k) => k.toLowerCase().includes(q));
  if (!hits.length) { out('（没这个词——要么它该加进表里，要么它不是术语）'); process.exit(2); }
  for (const k of hits) out('  ' + k.padEnd(24) + ' = ' + TERMS[k]);
  process.exit(0);
}

// 扫：找出"出现了、但**紧跟其后**没有括号、且**本文件里任何一处都没解释过**"的裸术语（每个词只报第一次出现）
export function scan(text) {
  // ★ 2026-09-22（接手窗实测 · 假红）：**命令与代码里的文件名不该算裸术语** ——
  //   `node 工具/交付/交付清单.mjs` 这种命令行，19 处"裸术语"里绝大多数是它；给每条命令配白话＝为形式而形式（内核 #72）。
  //   口径：**先摘掉 `反引号` 与 ```代码块``` 再扫**（解释性正文才需要白话）。
  text = String(text).replace(/```[\s\S]*?```/g, ' ').replace(/`[^`]*`/g, ' ')
  // ① 先算出所有括号覆盖的区间 —— 括号**内部**提到的词不算裸（它本来就是解释的一部分）
  const ranges = [];
  const stack = [];
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '（' || c === '(') stack.push(i);
    else if (c === '）' || c === ')') { const s2 = stack.pop(); if (s2 !== undefined) ranges.push([s2, i]); }
  }
  const inBracket = (i, len) => ranges.some(([x, y]) => i >= x && i + len <= y);
  // ② 收集全部命中，**长词优先**：否则「双证.mjs（…）」里的短词「双证」会被算成裸的（反证抓到的第 2 个假阳性）
  const hits = [];
  for (const k of keys) {
    let i = 0;
    while ((i = text.indexOf(k, i)) >= 0) {
      const after = text.slice(i + k.length, i + k.length + 3);
      hits.push({ term: k, at: i, len: k.length, told: /[（(]/.test(after) });
      i += k.length;
    }
  }
  hits.sort((x, y) => y.len - x.len);
  const keep = [];
  for (const h of hits) {
    if (keep.some((x) => h.at >= x.at && h.at + h.len <= x.at + x.len)) continue;  // 被更长的术语包着 ⇒ 不单独算
    keep.push(h);
  }
  // ③ 只留"没被解释、也不在括号里"的
  const 裸 = keep.filter((h) => !h.told && !inBracket(h.at, h.len));
  // ★ 2026-09-23（**文件级语义** · 十七号窗）：同一个词只要在**本文件里被解释过一次**，其余出现就都不算裸。
  //   依据：老板要的是"**这个词他看不看得懂**"，不是"每次出现都配括号"——解释过一遍，后面重复出现（最典型＝产物清单「跑:」格里的命令）再报就是假红。
  //   实测：交付报告第 50 行写过「接续.mjs（跨窗读旧窗口那个）」，第 80 行命令里的同名仍被算成 1 处。
  const 已解释 = new Set(keep.filter((h) => h.told || inBracket(h.at, h.len)).map((h) => h.term));
  const 首位 = new Map();
  for (const h of 裸) if (!已解释.has(h.term) && !首位.has(h.term)) 首位.set(h.term, h);
  return [...首位.values()].map((h) => ({ term: h.term, at: h.at, said: TERMS[h.term] }));
}

if (args[0] === '扫') {
  const files = args.slice(1);
  if (!files.length) { out('用法：术语.mjs 扫 <文件…>'); process.exit(2); }
  let total = 0;
  for (const f of files) {
    let t = ''; try { t = fs.readFileSync(f, 'utf8') } catch (e) { out('  ⚠ 读不到 ' + f); continue }
    const n = scan(t);
    total += n.length;
    out((n.length ? '🔴 ' : '🟢 ') + f + ' —— 裸术语 ' + n.length + ' 处');
    const byTerm = {};
    for (const x of n) byTerm[x.term] = (byTerm[x.term] || 0) + 1;
    for (const [k, c] of Object.entries(byTerm).slice(0, 8)) out('     · ' + k + ' ×' + c + '  → 该写成：' + k + '（' + TERMS[k] + '）');
    if (Object.keys(byTerm).length > 8) out('     …还有 ' + (Object.keys(byTerm).length - 8) + ' 个词');
  }
  out('\n合计裸术语 ' + total + ' 处');
  process.exit(total ? 1 : 0);
}

// ★ 2026-09-22 老板亲定：「**总体进度要放在劝停（喊停邀请）的前面**，而且**不只放一次 —— 我要每次都能看得到**」
//   ⇒ 把它焊进**同一个尾块**：一条命令吐出来，顺序写死（进度在上、喊停在下）。这就是"像喊停那句一样"的机械形态。
async function progressBlock() {
  try {
    const { execFileSync } = await import('node:child_process')
    return execFileSync(process.argv0 || 'node', ['/storage/emulated/0/3/工具/开工/进度.mjs', '--块'],
      { encoding: 'utf8', timeout: 40000, cwd: '/storage/emulated/0/3' }).trim()
  } catch (e) { return '⚠️ 总体进度这次没跑成（' + String((e && e.message) || e).split('\n')[0].slice(0, 80) + '）—— **如实标出，不许编一个数**' }
}
if (args[0] === '尾句' || args[0] === 'tail') {
  if (args.includes('--只喊停')) { console.log(TAIL); process.exit(0) }   // 留一个老口子（万一某处只要那句）
  console.log(await progressBlock())
  console.log('\n---\n')
  console.log(TAIL)
  process.exit(0)
}

// 体检：一次做两件 —— 裸术语 ＋ 「看不懂就喊停」那句在不在（交付清单用它）
if (args[0] === '体检') {
  const files = args.slice(1);
  if (!files.length) { out('用法：术语.mjs 体检 <文件…>'); process.exit(2); }
  let bad = 0;
  for (const f of files) {
    let t = ''; try { t = fs.readFileSync(f, 'utf8') } catch (e) { out('  ⚠ 读不到 ' + f); bad++; continue }
    const n = scan(t);
    const hasTail = /读完先别急着让我往下走/.test(t) && /优先处理你这端的问题/.test(t);
    if (n.length) { out('🔴 ' + f + ' —— 裸术语 ' + n.length + ' 处（该写成：词（白话））'); bad += n.length; }
    if (!hasTail) { out('🔴 ' + f + ' —— **缺「看不懂就喊停」那句**（跑 `node 神经/术语.mjs 尾句` 拿标准句）'); bad++; }
    // ★ 2026-09-22 老板亲定：「**总体进度要放在劝停（喊停邀请）的前面**……**不只放一次，我要每次都能看得到**」
    //   ⇒ 机器闸：① 报表里必须有【总体进度】块 ② 它必须在**喊停邀请之上**。缺一就报红。
    //   （拿整块＝一条命令：`node 神经/术语.mjs 尾句` —— 它已经按这个顺序吐出来）
    const iProg = t.search(/【交付面】/)
    const iTail = t.indexOf('读完先别急着让我往下走')
    if (iProg < 0) { out('🔴 ' + f + ' —— **缺【总体进度】块**（整块拿法：`node 神经/术语.mjs 尾句`）'); bad++; }
    else if (iTail >= 0 && iProg > iTail) { out('🔴 ' + f + ' —— **总体进度块跑到喊停邀请下面去了**（顺序写死：**进度在上、喊停在下**）'); bad++; }
    // ★ 2026-09-19 老板当场点出的两处缺栏（只对"给我的报表"查 —— 判据＝带了喊停尾句的才算报表）
    const hasWindow = /换到新窗口/.test(t);
    const hasMoney = /¥\s*\d/.test(t) || /token/i.test(t);
    if (hasTail) {
      if (!hasWindow) { out('🔴 ' + f + ' —— **缺「换到新窗口它还在不在、谁触发它」栏**（老板 2026-09-19：「**在别的窗口可不可以用？能不能检索得到？你没有告诉我**」）'); bad++; }
      if (!hasMoney) { out('🔴 ' + f + ' —— **成本栏里没有钱／token 数字**（老板 2026-09-19：「**这不叫成本吧？这叫本轮新增了什么吧？**」⇒ 「成本」＝真金白银，「新增了什么」另起一栏）'); bad++; }
    }
    if (!n.length && hasTail && hasWindow && hasMoney) out('🟢 ' + f + ' —— 术语干净 ＋ 带着喊停邀请 ＋ 新窗口栏 ＋ 钱数字');
  }
  out('\n合计问题 ' + bad + ' 处');
  process.exit(bad ? 1 : 0);
}

if (args[0] === 'selftest') {
  const nakedText = '这轮挂了 agent/turn-stopping 和 spawn，还差 5th arg。';
  const okText = '这轮挂了 agent/turn-stopping（引擎的"这一轮要收尾了"时刻），还有 spawn（另起一个小进程跑命令）。';
  const a = scan(nakedText), b = scan(okText);
  const c1 = a.length >= 3, c2 = b.length === 0;
  // ★ 用例 3（2026-09-19 反证逼出来的）：解释文字里提到的词**不许误报**
  const nested = '样本：双证.mjs（正证＋反证一起跑）和 库.mjs（开工第一屏）。';
  const c = scan(nested);
  const c3 = c.length === 0;
  out((c1 ? '✅' : '❌') + ' 裸的必须报出来（实报 ' + a.length + ' 个：' + a.map((x) => x.term).join('、') + '）');
  out((c2 ? '✅' : '❌') + ' 带括号的必须**不报**（实报 ' + b.length + ' 个）');
  out((c3 ? '✅' : '❌') + ' 解释文字里提到的词**不许误报**（实报 ' + c.length + ' 个' + (c.length ? '：' + c.map((x) => x.term).join('、') : '') + '）');
  // ★ 用例 4（2026-09-23 文件级语义）：同一个词在本文件里**已经解释过一次** ⇒ 后面重复出现的不许再报
  const 重复 = '接续.mjs（跨窗读旧窗口那个）在此说明过了。产物清单：- X ｜ 脚本 ｜ 跑:node 工具/跨窗/接续.mjs 核 工具/取证 ; 含:都在';
  const d = scan(重复);
  const c4 = d.length === 0;
  out((c4 ? '✅' : '❌') + ' 同文件已解释过 ⇒ 重复出现不许再报（实报 ' + d.length + ' 个' + (d.length ? '：' + d.map((x) => x.term).join('、') : '') + '）');
  const all = c1 && c2 && c3 && c4;
  out(all ? '\n✅ selftest 4/4 全过' : '\n❌ selftest 不过 —— 判据坏了');
  process.exit(all ? 0 : 1);
}

out('用法：术语.mjs 表 | 查 <词> | 扫 <文件…> | 体检 <文件…> | 尾句 | selftest');
