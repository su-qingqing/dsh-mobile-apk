#!/usr/bin/env node
/**
 * 条文复查.mjs v1 · 2026-09-23 —— 老板口径：「**内核条文我明显跟你说了，有些东西就都不用我去判了**……
 *   这个系统现在已经大部分自动化了，我还是说了**红线跟尺度的判定由我自己亲自审查**，我指的红线都是
 *   **红线中的红线**，而不是说以上那种普通的法律条文」（他原话）。
 * ⇒ 分工（写死在这把尺子里，谁也别想混过去）：
 *   · **自动化**（不用他判）：普通条文的**增／废** —— 机器按判据给候选，我给理由后 `落`，**只标停用、不删正文**、变更日志留痕。
 *   · **他亲审**（一步都不许自动）：① **红线中的红线**（身份／不自动／不重启／装配树／合规三条…命中红线词表的条文）
 *                              ② **尺子本身（阈值与判据）**：红线词表、天数阈值、重要性门槛、受保护层名单。
 * 判据（机器能判的三样）：① **谁引用它**（`#编号` 唯一串，排除内核正文自己）② 它有没有**产物/挂点** ③ 是不是**红线词**。
 * ⛔ 铁律：判不了写 `需人判`；**零引用 ≠ 该废**（可能只是没人爱写编号）⇒ `落` 必须我**逐个**给理由，且必须带证据。
 * 用法：node 神经/条文复查.mjs 查 [--全] ｜ 落 <编号> --理由 "…" ｜ 核
 */
import fs from 'node:fs'
import path from 'node:path'
const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const P = (...a) => path.join(WS, ...a)
const 条 = process.argv.slice(2), 动词 = 条[0]
const 实参 = (名) => { const i = process.argv.indexOf(名); return i > 0 ? process.argv[i + 1] : null }
const 停用账 = P('内核', '停用条文.json')
const 变更日志 = P('内核', '变更日志.md')
// ── 红线词表（★ 这张表＝「尺子」，改它要他亲审）
const 红线词 = /身份|不许|绝不|红线|隔离|合规|许可|绕过|防护|装配树|重启|个人项目|工作项目|认不出|冻结/
const 语料 = []
const 走 = (dir, exts, 深) => {
  let 项 = []; try { 项 = fs.readdirSync(P(dir), { withFileTypes: true }) } catch { return }
  for (const e of 项) {
    const rel = dir + '/' + e.name
    if (e.isDirectory()) { if (!/node_modules|_backup|\.git|历史遗留/.test(rel) && 深 < 4) 走(rel, exts, 深 + 1); continue }
    if (!exts.some((x) => e.name.endsWith(x)) || e.name.includes('.bak')) continue
    try { 语料.push([rel, fs.readFileSync(P(rel), 'utf8')]) } catch { }
  }
}
走('工具', ['.mjs', '.js'], 0); 走('台账', ['.md', '.json'], 0); 走('内核', ['.md', '.json'], 0); 走('记忆', ['.md', '.json'], 0)
try { 语料.push(['$DSH_HOME/AGENTS.md', fs.readFileSync((process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh') + '/AGENTS.md', 'utf8')]) } catch { }
const 条文 = []
for (const m of fs.readFileSync(P('内核/内核.md'), 'utf8').matchAll(/^(\d+)\.\s+(\*\*)?(.{0,120})/gm)) {
  const n = Number(m[1]), 文 = m[3].replace(/\*\*/g, '').trim()
  let 引用 = 0
  const re = new RegExp('#' + n + '(?![0-9])')
  for (const [p, t] of 语料) { if (p === '内核/内核.md') continue; if (re.test(t)) 引用++ }
  const 亲审 = 红线词.test(文)
  const 有产物 = /`[^`]*\.(mjs|js|json|md)`|工具\/|台账\//.test(文)
  条文.push({ n, 文, 引用, 亲审, 有产物 })
}
const 已停 = (() => { try { return JSON.parse(fs.readFileSync(停用账, 'utf8')) } catch { return { 停用: [] } } })()
const 停号 = new Set((已停.停用 || []).map((x) => x.n))
if (动词 === '核') {
  const 断 = [
    ['条文表读出来了（>50 条）', 条文.length > 50],
    ['每条都有亲审/自动判据', 条文.every((x) => typeof x.亲审 === 'boolean')],
    ['红线词表非空（尺子在场）', 红线词.source.length > 10],
    ['停用账可读', Array.isArray(含停用().停用)],
  ]
  let 过 = 0; for (const [名, 真] of 断) { if (真) 过++; console.log('  ' + (真 ? '✅' : '❌') + ' ' + 名) }
  console.log('\n  自检：' + 过 + '/' + 断.length + (过 === 断.length ? ' 全绿' : ' ⚠️ 有红')); process.exit(过 === 断.length ? 0 : 1)
}
function 含停用() { try { return JSON.parse(fs.readFileSync(停用账, 'utf8')) } catch { return { 停用: [] } } }
if (动词 === '落') {
  const n = Number(条[1]); const 理由 = 实参('--理由')
  const x = 条文.find((y) => y.n === n)
  if (!x) { console.error('❌ 没有这条条文：# ' + n); process.exit(1) }
  if (!理由 || 理由.length < 8) { console.error('❌ 「落」必须给 --理由 "…"（≥8 字）：自动化 ≠ 随便'); process.exit(1) }
  if (x.亲审) { console.error('❌ #' + n + ' 命中**红线词表** ⇒ 属「红线中的红线」，只能他亲审，不许自动落。\n   命中词：' + (x.文.match(红线词) || [''])[0]); process.exit(2) }
  const d = 含停用()
  if (d.停用.some((y) => y.n === n)) { console.log('  ⏭ #' + n + ' 早就停用了（' + d.停用.find((y) => y.n === n).at + '）'); process.exit(0) }
  d.停用.push({ n, 文: x.文.slice(0, 60), 引用数: x.引用, 理由, at: new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false }) })
  d.at = new Date().toISOString()
  fs.writeFileSync(停用账, JSON.stringify(d, null, 1))
  fs.appendFileSync(变更日志, '\n- ' + new Date().toISOString().slice(0, 10) + ' **条文停用 #' + n + '**（自动化流程，非老板逐条判）：' + 理由 + ' ｜引用数 ' + x.引用 + ' ｜ 留痕 `内核/停用条文.json`（**只标停用，正文一字未删**）\n')
  console.log('  ✅ #' + n + ' 已标停用（正文没删，留痕在 内核/停用条文.json ＋ 变更日志）')
  process.exit(0)
}
const FULL = 条.includes('--全')
const 自动候选 = 条文.filter((x) => !x.亲审 && x.引用 === 0 && !停号.has(x.n))
console.log('🔍 条文复查 · ' + new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false }))
console.log('   ' + 条文.length + ' 条 ｜ **他亲审**（红线中的红线）' + 条文.filter((x) => x.亲审).length + ' 条 ｜ 零引用 ' + 条文.filter((x) => x.引用 === 0).length + ' 条 ｜ 已停用 ' + 停号.size + ' 条\n')
console.log('   【他亲审·一步都不许自动】' + 条文.filter((x) => x.亲审).map((x) => '#' + x.n).join(' ') + '\n')
console.log('   【零引用 ⇒ 我逐个判（可落／可留）】' + (自动候选.length ? 自动候选.map((x) => '#' + x.n).join(' ') : '（无）'))
if (FULL) for (const x of 自动候选) console.log('     · #' + x.n + ' ｜有产物/挂点：' + (x.有产物 ? '是' : '否') + ' ｜' + x.文.slice(0, 70))
console.log('\n   尺子（阈值）本身＝他亲审：红线词表 ' + 红线词.source.slice(0, 40) + '… ｜ 改它要报他')
