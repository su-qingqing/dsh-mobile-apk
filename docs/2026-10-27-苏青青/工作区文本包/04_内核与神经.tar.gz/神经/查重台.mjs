#!/usr/bin/env node
// 查重台 · 1008 —— **动手做一件事之前，先问「这个活做过没」**
// 起因（1008 实犯）：我连着两次重复劳动 —— ① 静默吞：1006 已扫 418 文件、逐个核过「真病 0 处」；
//   ② 工具定义：10 天前 `0muiewvky` 就量过「68 件 54298B/轮」。
// ⇒ 红线 24「同一个坑第二次踩 ⇒ 当场改根」⇒ 把「先查」做成机器面（不是再写一条规矩）。
// 用法：node 神经/查重台.mjs <词> [词2 …]
// 判据：**任一查命中 ⇒ 先读那一条/那一段**，再决定还要不要动手。
import { DatabaseSync } from 'node:sqlite'
import { execFileSync } from 'node:child_process'

const 词 = process.argv.slice(2).filter(x => !x.startsWith('-'))
const WS = '/storage/emulated/0/3'
if (!词.length) {
  console.log('用法：node 神经/查重台.mjs <词> [更多词]')
  console.log('作用：动手前先查「这个活做过没」—— 记忆库／坑账／台账 三处一次查完')
  process.exit(2)
}
let 命中总 = 0

console.log('══ ① 记忆库（' + 词.join(' / ') + '）══')
try {
  const db = new DatabaseSync(WS + '/.dsh-meow/memory.db', { readOnly: true })
  const 行 = []
  for (const t of ['soul','user','rules','project','topic','fact','lesson']) {
    const 条件 = 词.map(() => '(content LIKE ? OR keywords LIKE ? OR title LIKE ?)').join(' OR ')
    const 参 = 词.flatMap(w => ['%' + w + '%', '%' + w + '%', '%' + w + '%'])
    try {
      for (const r of db.prepare('select id,content,updated_at from ' + t + ' where (' + 条件 + ") and status='active' order by updated_at desc limit 6").all(...参)) 行.push({ 表: t, ...r })
    } catch {}
  }
  db.close()
  行.sort((a, b) => String(b.updated_at).localeCompare(String(a.updated_at)))
  const 显 = 行.slice(0, 10)
  if (!显.length) console.log('   （0 命中）')
  for (const r of 显) console.log('   [' + r.表 + '] ' + String(r.id).slice(0, 12) + ' ｜ ' + String(r.updated_at).slice(0, 10) + ' ｜ ' + String(r.content).replace(/\s+/g, ' ').slice(0, 110))
  命中总 += 显.length
} catch (e) { console.log('   （连库失败：' + String(e.message).slice(0, 70) + '）') }

console.log('══ ② 坑账 ══')
try {
  const 出 = execFileSync('node', [WS + '/工具/记忆/坑账.mjs', '查', 词[0]], { encoding: 'utf8', cwd: WS })
  const 段 = 出.split('\n').filter(l => /📌|命中 \d+ 条/.test(l)).slice(0, 4)
  if (段.length) { for (const l of 段) console.log('   ' + l.trim()); 命中总 += 1 } else console.log('   （0 命中）')
} catch (e) { console.log('   （坑账调用失败）') }

console.log('══ ③ 台账（接续单／开工卡／清单）══')
try {
  const 出 = execFileSync('grep', ['-rn', '--include=*.md', '-m1', 词[0], WS + '/台账/接续', WS + '/台账/开工卡'], { encoding: 'utf8' })
  const 行s = 出.split('\n').filter(Boolean).slice(0, 8)
  if (!行s.length) console.log('   （0 命中）')
  for (const l of 行s) console.log('   ' + l.replace(WS + '/', '').slice(0, 128))
  命中总 += 行s.length
} catch { console.log('   （0 命中）') }

console.log('')
console.log(命中总 ? '  ⇒ 有命中：**先读上面这些，再决定要不要动手**（这活很可能已经做过／已有结论）' : '  ⇒ 三处都没命中 ⇒ 大概率是新活（仍建议换个词再查一次 —— 记忆检索是 2-gram 碎片匹配，0 命中 ≠ 没有）')
