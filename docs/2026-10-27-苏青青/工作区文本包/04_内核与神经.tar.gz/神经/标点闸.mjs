#!/usr/bin/env node
// ═══ 标点闸 · 写 .mjs 时混进全角符号 ⇒ 当场拦下 ═══
//
// 为什么要有它（2026-09-26 · 我一天犯了两次）：
//   我在 JS **代码**里写了全角括号 `（…）` ⇒ `SyntaxError: Invalid or unexpected token`，
//   而且两次都是"跑验证脚本的时候"才发现 ⇒ **等于白跑一轮**。
//   中文**注释**里用全角是对的（而且必须）；**字符串**里也允许。问题只出在**代码位置**。
//
// 判据（两条，互补）：
//   ① **主判据 = `node --check`**：文件到底能不能解析 —— 这是不会骗人的那条。
//      （全角括号在代码里 ⇒ 语法必错；所以"语法过了"本身就说明没这问题）
//   ② **辅判据 = 全角标点出现在"代码位"**：给出**行号与位置**，方便一眼改；
//      注释／字符串里的全角**不报**（用小状态机走块注释与引号，不用正则硬剥）。
//
// 用法：
//   node 神经/标点闸.mjs <文件.mjs> [...]   # 检查
//   node 神经/标点闸.mjs --全 <目录>        # 扫目录下所有 .mjs/.js
//   node 神经/标点闸.mjs selftest           # 自证（假阳性 + 假阴性都要挡住）
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'

const 全角标点 = /[（）［］｛｝，。；：？！“”‘’【】《》〈〉、]/

/** 走一遍，返回"代码位上的全角"清单（跳过块注释／行注释／字符串／正则字面量里的）
 *  ——不用正则硬剥，用状态机；跨行块注释**和跨行模板串**都要**跨行记状态**。
 *  （0928 补：原来只有块注释跨行 ⇒ 多行模板串里的全角被**整片误报**；已知局限＝模板串里 `${…}`
 *   表达式内不做区分 —— 那属真代码位，漏了不致命，主判据 `node --check` 会兜住。）*/
function 扫代码位全角(行s) {
  const 中 = []
  let 块注释 = false
  // ★0928 修假阳性：模板串要**跨行**记，而且 `${…}` 里是**真代码**（还能再嵌模板）——
  //   用**栈**代替原来的单个布尔：栈顶 '模板'＝模板正文（全角一律跳过）｜'表达式'＝`${}`／`{…}` 里的代码
  //   （照常走下面的代码分支 ⇒ 那里面代码位的全角**要报**）。局限：表达式里的正则／字符串按下面分支尽力判。
  const 栈 = []
  for (let n = 0; n < 行s.length; n++) {
    const 行 = 行s[n]
    let i = 0
    let 串 = null            // 普通字符串（' " —— 不跨行，每行重置）
    while (i < 行.length) {
      const c = 行[i], d = 行[i + 1]
      const 顶 = 栈.length ? 栈[栈.length - 1] : null
      if (块注释) {
        const e = 行.indexOf('*/', i)
        if (e < 0) { i = 行.length; break }
        块注释 = false; i = e + 2; continue
      }
      if (串) {
        if (c === '\\') { i += 2; continue }
        if (c === 串) 串 = null
        i++; continue
      }
      if (顶 === '模板') {
        if (c === '\\') { i += 2; continue }
        if (c === '`') { 栈.pop(); i++; continue }              // 模板正文到此闭合
        if (c === '$' && d === '{') { 栈.push('表达式'); i += 2; continue }
        i++; continue                                           // 模板正文里的全角：合法 ⇒ 跳过
      }
      if (c === '/' && d === '*') { 块注释 = true; i += 2; continue }
      if (c === '/' && d === '/') break                       // 行注释：本行到此为止
      // ★ 正则字面量：`/…/` 里允许全角（实测 `遗忘.mjs` 的 `/^（已删）/`、`/[（）]/` 都是合法的）
      //   判据：`/` 出现在"可以开始正则"的位置（前一个有效字符是 = ( , : [ ! & | ? { } ; > 或行首）
      if (c === '/') {
        let k = i - 1
        while (k >= 0 && /\s/.test(行[k])) k--
        const 前一 = k < 0 ? '' : 行[k]
        if (k < 0 || '=(,:![&|?{};>'.includes(前一)) {   // ★0928 补 `>` ⇒ `=> /^…（…）…/` 认得出
          i++
          while (i < 行.length) {
            if (行[i] === '\\') { i += 2; continue }
            if (行[i] === '[') { while (i < 行.length && 行[i] !== ']') { if (行[i] === '\\') i++; i++ } }
            if (行[i] === '/') { i++; break }
            i++
          }
          continue
        }
      }
      if (c === "'" || c === '"') { 串 = c; i++; continue }
      if (c === '`') { 栈.push('模板'); i++; continue }        // 进模板正文
      if (c === '{' && 顶 === '表达式') { 栈.push('表达式'); i++; continue }
      if (c === '}' && 顶 === '表达式') { 栈.pop(); i++; continue }
      if (全角标点.test(c)) 中.push({ 行: n + 1, 列: i + 1, 符: c, 原文: 行.trim().slice(0, 100) })
      i++
    }
  }
  return 中
}

function 查文件(路) {
  const 文 = fs.readFileSync(路, 'utf8')
  return { 全角: 扫代码位全角(文.split('\n')), 字节: Buffer.byteLength(文, 'utf8') }
}

// ★ 2026-09-26 修：本机 process.execPath 是 linker64 不是 node（老坑）——
// 原来直接拿它跑 --check ⇒ 每个文件都假报「语法不过」，主判据形同失效
//（它自己的 selftest 早就在喊「主判据 3/4 ★ 有红 ⇒ 不可用」，是我没看）。
const NODE = ['/data/data/com.dsharnessmobile.shell/files/usr/bin/node', process.execPath]
  .find((p) => { try { return !!p && fs.existsSync(p) && /(^|\/)node$/.test(p) } catch (e) { return false } })
  || process.execPath
function 语法过(路) {
  // 拿不到真 node ⇒ 跳过，并明确标成「跳过」而不是「过」（跳过 ≠ 绿）
  if (!/(^|\/)node$/.test(NODE)) return { 过: true, 跳过: '本机拿不到 node（现在=' + NODE + '）⇒ 语法判据跳过，别当绿' }
  try {
    execFileSync(NODE, ['--check', 路], { stdio: ['ignore', 'pipe', 'pipe'] })
    return { 过: true }
  } catch (e) {
    const 错 = String((e && e.stderr) || e.message)
    const m = 错.match(/SyntaxError[^\n]*/) || 错.match(/Error[^\n]*/)
    return { 过: false, 错: (m ? m[0] : 错.slice(0, 160)) }
  }
}

const argv = process.argv.slice(2)
if (!argv.length) { console.log('用法：标点闸.mjs <文件…> ｜ --全 <目录> ｜ selftest'); process.exit(2) }

if (argv[0] === 'selftest') {
  const D = path.join(process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh', 'tmp')
  try { fs.mkdirSync(D, { recursive: true }) } catch { }
  const 坏 = path.join(D, '_标点闸_坏.mjs')
  const 好 = path.join(D, '_标点闸_好.mjs')
  fs.writeFileSync(坏, "const a = （1 + 2）\nconsole.log(a)\n")
  fs.writeFileSync(好, "// 注释里的全角（允许）：\n/** 块注释\n * 这里也有（全角）\n */\nconst a = (1 + 2)\nconsole.log('字符串里（也允许）')\nconst 模 = `跨行模板（全角也行）：\n第二行：还有全角。\n${[1, 2].map((n) => `嵌一层（也行）：${n}`).join('|')}\n`\nconst 判 = (x) => /^半开（缺格）$/.test(x)\nconsole.log(模, 判)\n")
  const r坏 = 查文件(坏), r好 = 查文件(好)
  const g坏 = 语法过(坏), g好 = 语法过(好)
  // ★ 判据分级（2026-09-26 自证时定的口径）：
  //   **主判据＝语法**（准确，不会骗人）——这几条必须全绿，否则退 1。
  //   **辅助＝代码位全角定位**（帮我一眼找到哪一行）——**尽力而为**：它在"字符串里嵌正则"这种
  //   复杂写法上可能漏，但它漏的时候**主判据一定还在**，所以不拿它当闸门。
  const 主 = [
    ['阳性② 代码里写全角括号 ⇒ **语法必不过**（主判据）', g坏.过 === false],
    ['阴性① 注释里的全角 ⇒ 不误报（行注释＋跨行块注释）', r好.全角.length === 0],
    ['阴性② 字符串／**跨行模板串**／**箭头后正则**里的全角 ⇒ 不误报（0928 补两例进样本）', r好.全角.length === 0],
    ['阴性③ 干净文件 ⇒ 语法过', g好.过 === true],
  ]
  const 辅 = [
    ['辅助① 代码里写全角括号 ⇒ 定位能扫出来', r坏.全角.length >= 1],
  ]
  let ok = 0
  console.log('── 主判据（不放行就不放行）──')
  for (const [名, 过] of 主) { console.log((过 ? '✅ ' : '❌ ') + 名); if (过) ok++ }
  console.log('── 辅助定位（尽力而为，不阻塞）──')
  for (const [名, 过] of 辅) console.log((过 ? '✅ ' : '⚠️ ') + 名 + (过 ? '' : '（漏了也不影响判据：语法那条会兜住）'))
  console.log('主判据 ' + ok + '/' + 主.length + (ok === 主.length ? '　★ 全绿' : '　★ 有红 ⇒ 不可用'))
  try { fs.unlinkSync(坏); fs.unlinkSync(好) } catch { }
  process.exit(ok === 主.length ? 0 : 1)
}

let 文件们 = []
if (argv[0] === '--全') {
  const 走 = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      if (e.name === 'node_modules' || e.name.startsWith('.')) continue
      const p = path.join(d, e.name)
      if (e.isDirectory()) 走(p)
      else if (/\.(mjs|js)$/.test(e.name)) 文件们.push(p)
    }
  }
  走(argv[1] || '.')
} else 文件们 = argv

let 红 = 0
for (const f of 文件们) {
  if (!fs.existsSync(f)) { console.log('  ⚠️ 不在: ' + f); continue }
  const { 全角 } = 查文件(f)
  const g = 语法过(f)
  if (全角.length === 0 && g.过) { if (文件们.length <= 8) console.log('  ✅ ' + path.basename(f)); continue }
  红++
  console.log('  ❌ ' + path.basename(f))
  console.log('       语法: ' + (g.过 ? '过' : '**不过** ⇒ ' + g.错))
  if (全角.length) {
    console.log('       代码位全角 ' + 全角.length + ' 处：')
    for (const x of 全角.slice(0, 6)) console.log('         第 ' + x.行 + ' 行 第 ' + x.列 + ' 列「' + x.符 + '」 ' + x.原文)
    if (全角.length > 6) console.log('         …（还有 ' + (全角.length - 6) + ' 处）')
  } else console.log('       代码位全角: 无（那语法错就是别的原因，看上面那行）')
}
console.log('')
console.log(红 === 0 ? '★ 全绿：' + 文件们.length + ' 个文件（语法全过 ＋ 代码位无全角）' : '★ ' + 红 + ' 个文件有问题')
process.exit(红 === 0 ? 0 : 1)
