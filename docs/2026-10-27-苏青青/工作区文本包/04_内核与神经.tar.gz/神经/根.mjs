#!/usr/bin/env node
// ═══ 根.mjs · 单一根（蓝图 §8.1「不许硬编码」）═══
//
// 病根（现场抓到的）：`神经/停手线.mjs` 里写死 `const W = '/storage/emulated/0/3'`
//   ⇒ 在电脑上一跑就是 `ENOENT: scandir 'C:\storage\emulated\0\3\工具'`。
//   蓝图 §8.1 的原话：「**定义单一根**：所有脚本从**一个地方**取根 —— 优先环境变量（`DSH_ROOT`／`DSH_HOME`），
//   没有则读一个 `根.txt`」。
//
// ★ 一条纪律（蓝图同节）：「**不要现在全改**（不把设想的未来搬到现在）：
//   先建一个"根"的定义 ＋ 列清单；真要迁的那天再逐条换」。⇒ 本件只提供**取根法**与**清单仪器**，
//   **不批量改别人的文件**（改哪个文件由那一轮的事决定）。
//
// 取根顺序（从硬到软，逐级回落）：
//   ① 环境变量 `DSH_KICKOFF_WS`（引擎/闸门已经在用的那个，优先它 = 与现网一致）
//   ② 环境变量 `DSH_ROOT`（跨平台新名）
//   ③ 工作区根下的 `根.txt`（**逐级向上找**：脚本可能在 神经/ 里）
//   ④ 脚本自己所在位置往上找：含 `工具/` 与 `台账/` 两个目录的那一层
//   ⑤ 全都没有 ⇒ **抛错**（绝不许静默回落到某个默认路径 —— 那是"显示≠实际"）
//
// 用法（给别的脚本 import）：
//   import { 根, 取根, 列硬编码 } from './根.mjs'
//   const W = 根()          // 字符串
// 用法（命令行）：
//   node 神经/根.mjs 印        # 印现在取到的根与它是怎么取到的
//   node 神经/根.mjs 列 [目录]  # 列硬编码点（蓝图 §8.1 第 2 步）
//   node 神经/根.mjs 核        # 自证
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const 本件 = fileURLToPath(import.meta.url)
const 起点 = path.dirname(本件)

/** 逐级向上找「同时含 工具/ 与 台账/」的那一层 —— 那是工作区根。 */
function 向上找工作区(从) {
  let d = 从
  for (let i = 0; i < 8; i++) {
    if (fs.existsSync(path.join(d, '工具')) && fs.existsSync(path.join(d, '台账'))) return d
    const 上 = path.dirname(d)
    if (上 === d) break
    d = 上
  }
  return null
}

/** 逐级向上找 根.txt（它里面第一行非空非注释就是根）。 */
function 读根txt(从) {
  let d = 从
  for (let i = 0; i < 8; i++) {
    const p = path.join(d, '根.txt')
    if (fs.existsSync(p)) {
      try {
        const l = fs.readFileSync(p, 'utf8').split('\n').map((x) => x.trim()).filter((x) => x && !x.startsWith('#'))
        if (l.length) return { 值: l[0], 从: p }
      } catch { /* 继续往上 */ }
    }
    const 上 = path.dirname(d)
    if (上 === d) break
    d = 上
  }
  return null
}

/** ★ 2026-09-26 抓到的真陷阱：Windows 上 `fs.existsSync('/storage/emulated/0/3')` **返回 true**
 *  （那个前导斜杠被解析成**盘根** `C:\`，而盘根当然存在）⇒ 光判"存在"等于没判，
 *  于是 `根.txt` 里写的**设备根**在电脑上照样"通过"，取到假根、还不报错。
 *  ⇒ 判据必须升级成「**它真的是个工作区**」：是个目录，且同时含 `工具/` 与 `台账/`。 */
const 是工作区 = (p) => {
  try {
    if (!fs.statSync(p).isDirectory()) return false
    return fs.existsSync(path.join(p, '工具')) && fs.existsSync(path.join(p, '台账'))
  } catch { return false }
}

/** 取根：回 { 值, 怎么来的 } —— **怎么来的**要能印出来（坏了才知道该查哪儿）。 */
export function 取根() {
  if (process.env.DSH_KICKOFF_WS && 是工作区(process.env.DSH_KICKOFF_WS)) return { 值: process.env.DSH_KICKOFF_WS, 怎么: '环境变量 DSH_KICKOFF_WS（与现网一致，优先）' }
  if (process.env.DSH_ROOT && 是工作区(process.env.DSH_ROOT)) return { 值: process.env.DSH_ROOT, 怎么: '环境变量 DSH_ROOT' }
  const t = 读根txt(起点)
  if (t) {
    if (是工作区(t.值)) return { 值: t.值, 怎么: '根.txt（' + t.从 + '）' }
    // 这条要**说出来**，不许默默换掉 —— 否则他改了 根.txt 却不知道没生效
    const w = 向上找工作区(起点)
    if (w) return { 值: w, 怎么: '根.txt 写的是「' + t.值 + '」，**本机不是工作区**（不存在／缺 工具/ 或 台账/）⇒ 落到"向上找"（' + w + '）' }
    throw new Error('根.txt 写的是「' + t.值 + '」，但本机不是工作区，且向上也没找到 —— 请改 根.txt')
  }
  const w = 向上找工作区(起点)
  if (w) return { 值: w, 怎么: '从脚本位置向上找"含 工具/ 与 台账/ 的那一层"' }
  throw new Error('取不到根：DSH_KICKOFF_WS／DSH_ROOT／根.txt／向上找，四条路都没成 —— **不许静默回落**')
}

export function 根() { return 取根().值 }

/** 列硬编码点（蓝图 §8.1 第 2 步：「逐条点名，不许通配符批量替换」）。 */
export function 列硬编码(从 = 根()) {
  const 找 = ['/storage/emulated/0/3', '/data/user/0/com.dsharnessmobile', '/data/data/com.dsharnessmobile']
  const 命中 = []
  const 走 = (d, 深 = 0) => {
    if (深 > 5) return
    let es = []
    try { es = fs.readdirSync(d, { withFileTypes: true }) } catch { return }
    for (const e of es) {
      if (e.name === '_backup' || e.name === 'node_modules' || e.name === '.git' || e.name === '沙盒' || e.name === '档案') continue
      const p = path.join(d, e.name)
      if (e.isDirectory()) { 走(p, 深 + 1); continue }
      if (!/\.(mjs|js|sh|py|json|md)$/.test(e.name)) continue
      if (/\.bak-/.test(e.name)) continue
      let t = ''
      try { t = fs.readFileSync(p, 'utf8') } catch { continue }
      const 行 = t.split('\n')
      for (let i = 0; i < 行.length; i++) for (const s of 找) if (行[i].includes(s)) 命中.push({ 文件: path.relative(从, p), 行: i + 1, 片段: 行[i].trim().slice(0, 96) })
    }
  }
  for (const sub of ['工具', '台账']) { const p = path.join(从, sub); if (fs.existsSync(p)) 走(p) }
  return 命中
}

const a = process.argv.slice(2)
const 子 = a[0]
// ★ 2026-09-26 现场抓到的真缺陷：这个文件**同时是库又是命令**。
//   一开始没加守卫 ⇒ `停手线.mjs` 一 import 它，它的 CLI 就自己跑起来、还 process.exit 了
//   （表现：跑停手线的自证，印出来的却是根的自证）。判据＝**"我是不是被直接执行的那个文件"**。
const 是主 = (() => {
  try { return process.argv[1] && path.resolve(process.argv[1]) === path.resolve(本件) } catch { return false }
})()

if (是主) {
  if (子 === '印') {
    const r = 取根()
    console.log('📌 根 = ' + r.值)
    console.log('   怎么来的：' + r.怎么)
    for (const sub of ['工具', '台账', '内核', '记忆']) console.log('   ' + sub + '：' + (fs.existsSync(path.join(r.值, sub)) ? '✅在' : '🔴不在'))
  } else if (子 === '列') {
    const 从 = a[1] || 根()
    const 命中 = 列硬编码(从)
    const 按文件 = new Map()
    for (const h of 命中) 按文件.set(h.文件, (按文件.get(h.文件) || 0) + 1)
    console.log('🔍 硬编码点清单（蓝图 §8.1 第 2 步）· 根 ' + 从)
    console.log('   命中 ' + 命中.length + ' 处 ／ 分布在 ' + 按文件.size + ' 个文件')
    console.log('')
    const 排 = [...按文件.entries()].sort((x, y) => y[1] - x[1])
    for (const [f, n] of 排.slice(0, 25)) console.log('   ' + String(n).padStart(4) + ' 处  ' + f)
    if (排.length > 25) console.log('   …还有 ' + (排.length - 25) + ' 个文件')
    console.log('')
    console.log('★ 纪律：**逐条点名，不许通配符批量替换**（蓝图 §8.1 原话）；')
    console.log('   真要迁的那天再逐条换，换完每改一个就跑一次它的自检。')
  } else if (子 === '核' || !子) {
    const 断 = []
    // ① 取根四条路的第一条：环境变量优先。
    //   ★ 2026-09-26 修（自证自己红了 2 条）：原来用 `'C:/假根A'` 这种**假路径**测"优先"，
    //     但判据已经从"存在"升级成"**是工作区**（含 工具/ 与 台账/）" ⇒ 假路径必然过不了，
    //     自证当然红。**教训：改判据必须同批改自证夹具**，否则"功能对、自证红"看起来像坏了。
    //   ★ 2026-09-26 第二次修：临时目录**不许用 `/tmp`** ——
    //     本机硬事实写着「`/tmp` 不可写 ⇒ 用 `$DSH_HOME/tmp/`」（安卓上实测 EACCES）。
    //     ⇒ 取临时目录也走"哪能写用哪"：`$DSH_HOME/tmp` → `TMPDIR` → `os.tmpdir()`，逐个试。
    const 临时根 = (() => {
      const 候选 = [process.env.DSH_HOME && path.join(process.env.DSH_HOME, 'tmp'), process.env.TMPDIR, process.env.TEMP]
        .filter(Boolean).concat([path.join(process.cwd(), '.tmp')])
      for (const c of 候选) {
        try { fs.mkdirSync(c, { recursive: true }); const t = fs.mkdtempSync(path.join(c, '根自证-')); return t } catch { /* 下一个 */ }
      }
      throw new Error('连一个能写的临时目录都找不到（试过 $DSH_HOME/tmp、TMPDIR、TEMP、cwd/.tmp）')
    })()
    const 临时 = 临时根
    for (const sub of ['工具', '台账']) fs.mkdirSync(path.join(临时, sub), { recursive: true })
    const 旧 = { WS: process.env.DSH_KICKOFF_WS, ROOT: process.env.DSH_ROOT }
    process.env.DSH_KICKOFF_WS = 临时
    断.push(['环境变量 DSH_KICKOFF_WS 优先（**且它真的是个工作区**）', 根() === 临时])
    const 临时2 = 临时 + '-B'
    for (const sub of ['工具', '台账']) fs.mkdirSync(path.join(临时2, sub), { recursive: true })
    delete process.env.DSH_KICKOFF_WS
    process.env.DSH_ROOT = 临时2
    断.push(['没 WS 时用 DSH_ROOT', 根() === 临时2])
    // ② 都清掉 ⇒ 应该靠"向上找"拿到真工作区（因为本件就在 神经/ 里）
    delete process.env.DSH_ROOT
    const r = 取根()
    断.push(['四条路里"向上找"能拿到真工作区（本件住在 神经/ ⇒ 必然找得到）', fs.existsSync(path.join(r.值, '工具')) && fs.existsSync(path.join(r.值, '台账'))])
    断.push(['"怎么来的"必须可印（坏了才知道查哪儿）', typeof r.怎么 === 'string' && r.怎么.length > 4])
    if (旧.WS !== undefined) process.env.DSH_KICKOFF_WS = 旧.WS
    if (旧.ROOT !== undefined) process.env.DSH_ROOT = 旧.ROOT
    // ③ ★ 新反证：**假路径不许被当成根**（Windows 上 `/storage/emulated/0/3` 会被解析成盘根 ⇒ 光判"存在"会假过）
    process.env.DSH_KICKOFF_WS = '/storage/emulated/0/3'
    const 假 = 取根()
    断.push(['假路径（前导斜杠解析成盘根）**不许**被当成根 —— 判据是"是工作区"不是"存在"', 假.值 !== '/storage/emulated/0/3' && /不是工作区|向上找/.test(假.怎么)])
    if (旧.WS !== undefined) process.env.DSH_KICKOFF_WS = 旧.WS; else delete process.env.DSH_KICKOFF_WS
    // ④ 反证：真的什么都不给时**必须抛错**，不许静默回落
    const 源 = fs.readFileSync(本件, 'utf8')
    断.push(['取不到 ⇒ 抛错（源码里有"不许静默回落"）', /不许静默回落/.test(源)])
    // ⑤ 列硬编码能真列出东西（设备上应有命中；本机可能 0 —— 不许因此判红）
    const 命中 = 列硬编码(根())
    断.push(['列硬编码可跑（命中 ' + 命中.length + ' 处）', Array.isArray(命中)])
    let 过 = 0
    for (const [名, 真] of 断) { console.log('  ' + (真 ? '✅' : '❌') + ' ' + 名); if (真) 过++ }
    console.log('\n  自证：' + 过 + '/' + 断.length + (过 === 断.length ? ' 全绿' : ' ⚠️ 有红'))
    process.exit(过 === 断.length ? 0 : 1)
  } else {
    console.error('用法：根.mjs 印 ｜ 列 [目录] ｜ 核')
    process.exit(2)
  }
}
