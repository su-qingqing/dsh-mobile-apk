#!/usr/bin/env node
// 检索门 · 开源/市场检索必须「名字 ＋ 能力词」两遍（门 · 坑 0mu6ydy73）
// 为什么有它：我只按项目名搜 ⇒ 漏掉三件高价值件；按能力词重搜当场挖到。
//            ⇒ 做成"记录单 ＋ 检查器"：**两遍缺一遍就不许下结论**（缺一遍 ⇒ exit 1）。
// 用法：node 神经/检索门.mjs 开 <主题>   ｜ 查 <记录单文件>  ｜ 自检
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'   // ★ 1013 加：自测要读自己的源码、现算断言总数（治"写死分母"）
const 工作区 = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const 模板 = (主题) => [
  '# 检索记录 · ' + 主题,
  '',
  '> 规矩（坑 `0mu6ydy73`）：**名字一遍 ＋ 能力词一遍**，缺一遍不许下结论；0 命中必须先换词再判。',
  '',
  '## 第一遍 · 按名字',
  '<!-- 一行一条：| 名字 | 星数／来源 | 结论（拿来用／借鉴／弃） | -->',
  '',
  '## 第二遍 · 按能力词',
  '<!-- 先写你用的能力词：例 verification / checklist / sandbox / verify -->',
  '<!-- 能力词：                                                -->',
  '<!-- 一行一条：| 名字 | 星数／来源 | 结论（拿来用／借鉴／弃） | -->',
  '',
  '## 两遍对账',
  '- 第一遍命中：',
  '- 只被第二遍挖到的（第一遍漏的）：',
  '- 结论：',
  '',
].join('\n')
function 是数据行(l) {
  const t = l.trim()
  if (!t.startsWith('|')) return false
  if (/^\|[\s\-:|]+\|$/.test(t)) return false
  const c = t.split('|').length - 2
  return c >= 3
}
function 查(f) {
  if (!fs.existsSync(f)) { console.error('❌ 记录单不存在：' + f); process.exit(1) }
  const s = fs.readFileSync(f, 'utf8')
  const i1 = s.indexOf('## 第一遍')
  const i2 = s.indexOf('## 第二遍')
  const i3 = s.indexOf('## 两遍对账')
  const 报 = []
  if (i1 < 0) 报.push('缺「## 第一遍 · 按名字」整节')
  if (i2 < 0) 报.push('缺「## 第二遍 · 按能力词」整节')
  const 一 = i1 >= 0 && i2 > i1 ? s.slice(i1, i2) : i1 >= 0 ? s.slice(i1) : ''
  const 二 = i2 >= 0 && i3 > i2 ? s.slice(i2, i3) : i2 >= 0 ? s.slice(i2) : ''
  const n1 = 一.split('\n').filter(是数据行).length
  const n2 = 二.split('\n').filter(是数据行).length
  if (i1 >= 0 && n1 === 0) 报.push('第一遍（名字）一条记录都没有')
  if (i2 >= 0 && n2 === 0) 报.push('第二遍（能力词）一条记录都没有')
  const 对账 = i3 >= 0 ? s.slice(i3) : ''
  if (i3 < 0) 报.push('缺「## 两遍对账」节')
  else if (!/结论[：:]\s*\S/.test(对账)) 报.push('「两遍对账」里没写结论')
  console.log('   第一遍（名字）：' + n1 + ' 条 ｜ 第二遍（能力词）：' + n2 + ' 条')
  if (报.length) {
    console.log('🔴 这份记录单不合格：')
    报.forEach((x) => console.log('   · ' + x))
    console.log('   ⇒ 补齐再下结论（名字＋能力词两遍是**缺一不可**，不是"最好有"）')
    process.exit(1)
  }
  console.log('✅ 两遍齐、结论在 —— 可以据此下结论')
}
const [v, x] = process.argv.slice(2)
if (v === '开') {
  if (!x) { console.log('用法：检索门.mjs 开 <主题>'); process.exit(2) }
  const d = new Date()
  const 戳 = String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0')
  const 夹 = path.join(工作区, '台账/对照')
  fs.mkdirSync(夹, { recursive: true })
  const f = path.join(夹, '检索记录_' + 戳 + '-' + x.replace(/[\/\\:*?"<>|\s]+/g, '_').slice(0, 40) + '.md')
  if (fs.existsSync(f)) { console.log('⚠️ 已存在（没覆盖）：' + f); process.exit(1) }
  fs.writeFileSync(f, 模板(x))
  console.log('✅ 记录单开好了：' + f.replace(工作区 + '/', ''))
  console.log('   写完用：node 神经/检索门.mjs 查 <那个文件>')
} else if (v === '查') 查(x || '')
else if (v === '自检') {
  const 临时 = path.join(process.env.DSH_HOME || '/tmp', 'tmp', '检索门自检')
  fs.mkdirSync(临时, { recursive: true })
  const f = path.join(临时, 'r.md')
  const 跑 = () => spawnSync('node', [process.argv[1], '查', f], { encoding: 'utf8' })
  let r = 0
  fs.writeFileSync(f, 模板('自检'))
  const c1 = 跑(); const ok1 = c1.status === 1 && /第一遍/.test(c1.stdout); r += ok1 ? 1 : 0
  console.log('  ① 空白单 ⇒ 必须红：exit=' + c1.status + (ok1 ? ' ✅' : ' ❌'))
  fs.writeFileSync(f, 模板('自检').replace('<!-- 一行一条：| 名字 | 星数／来源 | 结论（拿来用／借鉴／弃） | -->', '| strukto-ai/mirage | 3609★ | 借鉴 |'))
  const c2 = 跑(); const ok2 = c2.status === 1 && /第二遍/.test(c2.stdout); r += ok2 ? 1 : 0
  console.log('  ② 只填第一遍 ⇒ 必须点名第二遍：exit=' + c2.status + (ok2 ? ' ✅' : ' ❌'))
  const 填 = (t) => t
    .replace('<!-- 一行一条：| 名字 | 星数／来源 | 结论（拿来用／借鉴／弃） | -->', '| strukto-ai/mirage | 3609★ | 借鉴 |')
    .replace('<!-- 一行一条：| 名字 | 星数／来源 | 结论（拿来用／借鉴／弃） | -->', '| oxbshw/watch-skill | 334★ | 拿来用 |')
  fs.writeFileSync(f, 填(模板('自检')))
  const c3 = 跑()
  const ok3 = c3.status === 1 && /结论/.test(c3.stdout); r += ok3 ? 1 : 0
  console.log('  ③ 两遍填了但没写结论 ⇒ 必须红：exit=' + c3.status + (ok3 ? ' ✅' : ' ❌'))
  fs.writeFileSync(f, 填(模板('自检')).replace('- 结论：', '- 结论：两遍一致 ⇒ 采用 mirage 的虚拟工作区'))
  const c4 = 跑(); const ok4 = c4.status === 0; r += ok4 ? 1 : 0
  console.log('  ④ 两遍齐 ＋ 有结论 ⇒ 必须绿：exit=' + c4.status + (ok4 ? ' ✅' : ' ❌'))
  // ★★ 1013 改写（原文：console.log(r === 4 ? '✅ 自检 4/4 过' : …) ＋ process.exit(r === 4 ? 0 : 1)）
  //   病：**分母写死**。将来有人加第 5 条断言 ⇒ r 到 5、判据还是 r === 4 ⇒ **永远红**；
  //   反过来的病更坏：有人把 4 校准成**通过数** ⇒ **失败的断言被藏住、一直报绿**
  //   （同形状的实证事故：神经/重启批次.mjs 原来 `const N = 19`）。
  //   治法＝照抄那件已修好的形状：**现算总数 ＋ 只许增的底线**。
  const 总数 = (fs.readFileSync(fileURLToPath(import.meta.url), 'utf8').match(/r \+= ok\d+ \? 1 : 0/g) || []).length
  const 底线 = 4   // ★ 只许往上调，不许往下调（防有人悄悄删样本）
  const 全过 = r === 总数 && 总数 >= 底线
  console.log(全过 ? '✅ 自检 ' + r + '/' + 总数 + ' 过（底线 ' + 底线 + '）'
                   : '❌ 自检只过 ' + r + '/' + 总数 + '（底线 ' + 底线 + '；总数现算自源码）')
  process.exit(全过 ? 0 : 1)
} else { console.log('用法：检索门.mjs 开 <主题> ｜ 查 <文件> ｜ 自检'); process.exit(2) }
