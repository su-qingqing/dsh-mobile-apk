#!/usr/bin/env node
// 步数表 · 2026-09-23 立（老板令：成本仪器退役 ⇒ 换成「本步数 + 上下文还要多少才被压缩」）
//   为什么换：预算.mjs 在大会话上跑不完（>120 秒被杀）；换窗公式.mjs 也是整篇读日志 ⇒ 同样超时。
//   治法：**只读日志尾巴**（zstd -dc 流式 → tail 截尾 8MB）⇒ 秒级。整篇读是读出瓶颈，不是算法瓶颈。
//   用法：node 神经/步数表.mjs [会话id]    退出码：0 还能走 ｜ 1 该拆轮/换窗 ｜ 3 读不到
import fs from 'node:fs'
import path from 'node:path'
import { execSync } from 'node:child_process'

const HOME = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const ROOT = path.join(HOME, 'sessions')
const 步数红线 = 12        // 内核 #50：单轮工具调用 >12 ⇒ 拆轮
const 压缩线_万 = 11       // 引擎自动压缩的**实测**临界（换窗公式注释：实测 11~14 万，随剩余步数变）

function 找日志(id) {
  if (id) for (const ws of fs.readdirSync(ROOT)) { const f = ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd'].map((x) => path.join(ROOT, ws, id, x)).find((x) => fs.existsSync(x)); if (f) return { id, f } }
  let best = -1, hit = null
  for (const ws of fs.readdirSync(ROOT)) {
    const d = path.join(ROOT, ws); if (!fs.statSync(d).isDirectory()) continue
    for (const s of fs.readdirSync(d)) { const f = ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd'].map((x) => path.join(d, s, x)).find((x) => fs.existsSync(x)); if (!f) continue
      const m = fs.statSync(f).mtimeMs; if (m > best) { best = m; hit = { id: s, f } } }
  }
  return hit
}
const t0 = Date.now()
const L = 找日志(process.argv[2])
if (!L) { console.error('⛔ 找不到会话日志'); process.exit(3) }
let 尾 = ''
try { 尾 = execSync('zstd -dc ' + JSON.stringify(L.f) + ' | tail -c 8000000', { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, timeout: 90000, shell: '/data/data/com.dsharnessmobile.shell/files/usr/bin/bash' }) }
catch (e) { console.error('⛔ 读日志失败：' + e.message); process.exit(3) }
const 读秒 = (Date.now() - t0) / 1000

const 行 = 尾.split('\n').filter(Boolean)
const 用 = []            // 每次请求的用量
let 本轮 = 0, 人话下标 = 0, 调用总数 = 0, 本轮工具 = 0, 压缩线实测 = null, 压缩次数 = 0
for (const l of 行) {
  let j; try { j = JSON.parse(l) } catch { continue }
  const d = j && j.data ? j.data : {}
  const t = String(j.type || '')
  if (t === 'assistant/message' && d.usage && typeof d.usage.inputTokens === 'number') {
    用.push({ 上下文: (d.usage.inputTokens || 0) + (d.usage.cacheReadTokens || 0), turn: d.turn || 0 })
    if ((d.turn || 0) > 本轮) 本轮 = d.turn || 0
  }
  if (t === 'user/message') { const sr = d.source; const 非人 = sr && ['compact','skill-catalog','@deepseek-ai/dsh-system-prompt'].some((x) => String(sr).includes(x)); if (!非人) 人话下标 = 用.length }
  if (t === 'tool/call') { 调用总数++; if (用.length >= 人话下标) 本轮工具++ }
  if (t === 'compaction/start') { 压缩次数++; if (用.length) 压缩线实测 = 用[用.length - 1].上下文 }
}
const 末 = 用.length ? 用[用.length - 1] : null
if (!末) { console.error('⛔ 尾巴里没有用量记录（日志尾部没有一次请求？）'); process.exit(3) }
const 上下文万 = 末.上下文 / 10000
// 每步增长：取最近 5 次的平均差
const 近 = 用.slice(-6).map((x) => x.上下文)
const 增 = 近.length > 1 ? (近[近.length - 1] - 近[0]) / (近.length - 1) / 10000 : 0
const 线 = 压缩线实测 ? 压缩线实测 / 10000 : 压缩线_万
const 还能步 = 增 > 0.05 ? Math.max(0, Math.floor((线 - 上下文万) / 增)) : 99
const 步数余 = 步数红线 - 本轮工具

console.log('=== 步数表 · ' + new Date().toLocaleString('zh-CN', { hour12: false, timeZone: 'Asia/Shanghai' }) + ' ===')
console.log('会话 ' + String(L.id).slice(0, 22) + ' ｜ 日志 ' + (fs.statSync(L.f).size / 1048576).toFixed(1) + ' MB ｜ 本次读尾巴 ' + 读秒.toFixed(1) + ' 秒')
console.log('')
console.log('【本轮步数】' + 本轮工具 + ' 步 ｜ 红线 ' + 步数红线 + ' 步 ⇒ ' + (步数余 > 0 ? '还剩 ' + 步数余 + ' 步' : '⚠️ 已超 ' + (-步数余) + ' 步（该拆轮）'))
console.log('【上下文】现在 ' + 上下文万.toFixed(1) + ' 万 token ｜ 每步约涨 ' + (增>0?增.toFixed(2):'0（本段在压缩后重置）') + ' 万 ｜ 压缩线 **实测 ' + 线.toFixed(1) + ' 万**' + (压缩线实测 ? '（上次自动压缩**发生时**的上下文真值 ' + 压缩线实测 + ' token）' : '（尾巴里没看到压缩）'))
console.log('【还能走】≈ ' + (还能步 === 99 ? '算不出（本段没涨）' : 还能步) + ' 步就到压缩线（到了引擎会自动压缩，长的内容会被摘要）')
console.log('【日志里已知】尾巴里自动压缩 ' + 压缩次数 + ' 次 ｜ 尾巴里工具调用共 ' + 调用总数 + ' 次')
const 判决 = (步数余 <= 0 || (typeof 还能步 === 'number' && 还能步 <= 2))
console.log('')
console.log(判决 ? '⇒ ⚠️ 该拆轮／换窗：把剩下的列成下一段（不是砍活）。' : '⇒ ✅ 还能接着干。')
process.exit(判决 ? 1 : 0)
