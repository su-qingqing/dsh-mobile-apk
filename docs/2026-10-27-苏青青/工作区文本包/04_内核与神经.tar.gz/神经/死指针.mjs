#!/usr/bin/env node
// 死指针 v2 —— 判「代码里写死的路径，指向的东西还在不在」。
// 为什么要它：搬家后一批活工具的指针指向归档区、静默失效没人知道。
//   病根不是「忘了记」，是「**没人改指针**」＋「**没有存在性检查这一层**」。
//
// v1 的错（2026-09-26 当天自查出，**同一天第四次假红**）：
//   653 条里报 181 条「真死」，逐条一看几乎全是假的 ——
//     · `node 神经/体检.mjs > _backup/报告.txt` 是**整条命令**，不是路径
//     · `cp a.md 台账/b.md`、`cat > 工具/x.mjs` 是**示例文本**
//     · `../台账/流程定义.mjs` 是**相对路径**，我拿它拼了 ROOT
//     · `/storage/.../在办.md` 是**绝对路径**，被我拼成 ROOT + 绝对路径
//   ⇒ 根因：没定「什么算路径」。v2 口径：**字符串整体必须只由 路径字符＋斜杠 组成**。
//
// 三态（不许两态 —— 两态会把 .js↔.json 误报成「文件已不在」）：
//   ✅ 在 ／ ⚠️ 换名（主名同、后缀不同）／ ❌ 真死（主名也不同）
// 判不了的绝不猜：变量拼接出来的路径标「动态·测不了」，不算红也不算绿（内核 #71）。
import fs from 'node:fs';
import path from 'node:path';

const ROOT = '/storage/emulated/0/3';
const 根目录 = ['工具', '台账', '内核', '记忆', '调研', '桌宠项目'];
const 纯路径 = /^\/?[\/A-Za-z0-9_.\-\u4e00-\u9fa5]+$/;   // 只有 路径字符＋斜杠
const 有后缀 = /\.(mjs|js|json|jsonl|md|db|sh|yml|yaml|txt|png|sqlite|zst|json5)$/;
const 路径词 = /(工具|台账|内核|记忆|调研|桌宠项目|_backup|档案|记忆库)\//;

function 走(d, out = []) {
  let es; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return out; }
  for (const e of es) {
    const p = path.join(d, e.name);
    if (e.isDirectory()) { if (!['node_modules', '.git', '_backup'].includes(e.name)) 走(p, out); }
    else if (e.name.endsWith('.mjs')) out.push(p);
  }
  return out;
}

const 文件 = 根目录.flatMap(d => 走(path.join(ROOT, d)));
const 真死 = [], 换名 = [], 动态 = [], 跳过 = [];
// ★ 1001-10-02 加「已判」：本器只报「在不在」，**不判该不该在**（内核 #71）—— 那部分由人核过、写成数据。
//   为什么必须这样：10 条「真死」逐条一核**全是假红**（测试夹具／桩造参数／字符串比对／按需创建），
//   可这个数每轮印在记忆门上 ⇒ 变成一笔永远还不掉的假欠账。判过的进 `死指针豁免.json`（**仍然印出来**，
//   只是不算欠账）—— 不许静默吞掉：真坏的那天，它还在这张表上，只是换了一行字。
const 豁免文件 = path.join(ROOT, '神经/死指针豁免.json')
let 已判表 = new Map()
const 锚表 = new Map()
try {
  const j = JSON.parse(fs.readFileSync(豁免文件, 'utf8'))
  for (const e of (j.已判 || [])) if (e && e.at) 已判表.set(String(e.at), String(e.判 || ''))
  // ★ 1013 加：锚匹配（位置会漂、内容不会）—— 「文件|锚串」形态；行号那半边仍照老法认
  for (const e of (j.已判 || [])) if (e && e.at && e.锚) {
    const m = String(e.at).match(/^(.*):\d+$/)
    if (m) 锚表.set(m[1] + '|' + String(e.锚), String(e.判 || ''))
  }
} catch { 已判表 = new Map() }
const 件键 = (f, n) => String(f).replace(ROOT + '/', '') + ':' + n
const 判过 = [];
const 统计 = { 总: 0, 在: 0 };

for (const f of 文件) {
  const lines = fs.readFileSync(f, 'utf8').split('\n');
  lines.forEach((line, i) => {
    for (const m of line.matchAll(/['"`]([^'"`\n]{4,140})['"`]/g)) {
      const s = m[1];
      if (!路径词.test(s) || !有后缀.test(s)) continue;
      if (s.includes('${')) { 动态.push([f, i + 1, s]); continue; }
      if (!纯路径.test(s)) continue;                        // 命令／句子／含空格 ⇒ 不是路径指针
      if (s.startsWith('node ') || s.includes('>')) continue;
      统计.总++;
      // 解析基准：绝对 / 相对本文件 / 相对工作区
      // v3：『/内核/内核.md』这种**以斜杠开头但第二段是工作区根目录名**的，是"相对工作区"，
      //     不是绝对路径（v2 拿它当绝对路径 ⇒ 又一批假红）。真绝对路径只认 /storage 与 /data。
      const 是工作区根 = /^\/(工具|台账|内核|记忆|调研|桌宠项目|_backup)\//.test(s);
      const 全 = (s.startsWith('/storage/') || s.startsWith('/data/')) ? s
               : 是工作区根 ? path.join(ROOT, s)
               : s.startsWith('../') ? path.resolve(path.dirname(f), s)
               : path.join(ROOT, s);
      const 注 = /^\s*(\/\/|\*)/.test(line) ? '（注释）' : '';
      if (fs.existsSync(全)) { 统计.在++; continue; }
      const dir = path.dirname(全), base = path.basename(全).replace(/\.[^.]+$/, '');
      let 撞 = null;
      try { 撞 = fs.readdirSync(dir).find(x => x.replace(/\.[^.]+$/, '') === base) || null; } catch {}
      // v4（2026-09-27）：假红第四次同族 —— 尺子把三类**本来就不该在**的路径当死指针。
      //   ① 写路径：`writeFileSync(台账/x.json)` 是**程序要生成的目标**，跑一次就有，不该判死；
      //   ② 夹具：文件头写着"自测／不碰生产"的，里面故意指不存在的路径（如 `工具/不存在.mjs`）；
      //   ③ 注释：注释里提到的旧文件名，不算指针。
      {
        const 该行 = (() => { try { return fs.readFileSync(f, "utf8").split("\n")[i] || ""; } catch { return ""; } })();
        const 头 = (() => { try { return fs.readFileSync(f, "utf8").slice(0, 12000); } catch { return ""; } })();
        const 写动词 = /(writeFileSync|appendFileSync|mkdirSync|createWriteStream|rmSync|unlinkSync|copyFileSync|renameSync)\s*\(/;
        if (写动词.test(该行) && 该行.includes(s)) { 跳过.push(["写路径·跑一次就有", f, i + 1, s]); continue; }
        if (/自测|不碰生产|夹具|fixture|故意造错|mkdtempSync/.test(头)) { 跳过.push(["夹具文件·路径是它自己现造的", f, i + 1, s]); continue; }
        if (/^\s*(\/\/|\*|\/\*)/.test(该行)) { 跳过.push(["注释里提到的旧名", f, i + 1, s]); continue; }
      }
      if (撞) 换名.push([f, i + 1, s, 撞, 注]);
      else if (已判表.has(件键(f, i + 1))) 判过.push([f, i + 1, s, 已判表.get(件键(f, i + 1))]);
      else if ([...锚表.keys()].some((k) => k.startsWith(f + '|') && s.includes(k.split('|')[1]))) 判过.push([f, i + 1, s, '（按**锚**命中已判：行号漂了、内容还在）']);
      else 真死.push([f, i + 1, s, 注]);
    }
  });
}

const rel = p => String(p).replace(ROOT + '/', '');
console.log('══ 死指针体检 v2 ══ 扫了 ' + 文件.length + ' 个 .mjs');
console.log('  真·路径指针 ' + 统计.总 + ' 条 ｜ ✅ 在 ' + 统计.在 + ' ｜ ⚠️ 换名 ' + 换名.length +
            ' ｜ ❌ 真死 ' + 真死.length + (判过.length ? '（另 ' + 判过.length + ' 条**已判**·不算欠账）' : '') +
            ' ｜ 动态·测不了 ' + 动态.length);
console.log('');
if (判过.length) {
  console.log('· 已判（核过引用行 ⇒ 不是缺口；**仍然印出来**，真坏的那天会掉回上一行）：');
  判过.forEach(([f, n, s, 判]) => console.log('   ' + rel(f) + ':' + n + '  → ' + s + '   〔' + 判 + '〕'));
  console.log('');
}
if (真死.length) {
  console.log('❌ 真死（主名都不同 —— 这是缺口）：');
  真死.forEach(([f, n, s, 注]) => console.log('   ' + rel(f) + ':' + n + 注 + '  → ' + s));
  console.log('');
}
if (换名.length) {
  console.log('⚠️ 换名（主名同、后缀不同 —— 东西在，是**尺子写错了**）：');
  换名.forEach(([f, n, s, 撞, 注]) => console.log('   ' + rel(f) + ':' + n + 注 + '  → 写的是 ' + s + '，真身 ' + 撞));
  console.log('');
}
if (动态.length) {
  console.log('· 动态·测不了 ' + 动态.length + ' 条（变量拼出来的，本器不猜）：');
  动态.slice(0, 5).forEach(([f, n, s]) => console.log('   ' + rel(f) + ':' + n + '  ' + s));
  if (动态.length > 5) console.log('   …还有 ' + (动态.length - 5) + ' 条');
  console.log('');
}
// ══════════════════════════════════════════════════════════════════════════
// 反向段：孤儿（★ 2026-10-05 加 · 老板令「把你抓出来的洞给修了」）
//   为什么必须有这一段：判「这件没人用」我**连栽三次，全是判据口径没定死** ——
//     ① 只扫工作区 ⇒ 0928 差点把最活跃的 `神经/回程.mjs` 判成孤儿退役（真引用在**插件源码**里）
//     ② 引用源只认 md/mjs/js/json/sh/txt/yml/yaml/html ⇒ 漏掉 `.ps1`／`.tsv`／无后缀文件，
//        当场冒出 4 件假孤儿；其中 `工具/dsh-mobile-apk/scripts/golden/extract-seq.mjs`
//        被 `scripts/device-smoke.ps1` **真引着** —— 照旧口径搬，就搬掉了活工具链里的一件
//   ⇒ 本段把口径**写死在这儿**（不靠我下次记得）：
//      引用源 = **工作区全部文本文件（不过滤扩展名，二进制按 \0 判）**
//             ＋ **插件源码面**（$DSH_HOME/profiles/*/node_modules/@dsh-user）
//             ＋ **壳配置／预设**（$DSH_HOME/*.yml|yaml|json ＋ .agent-presets）
//      两档一起报（不许只报一档）：
//        严格孤儿 = 没有任何**活文件**提过它（跳过 档案／_backup／tmp/_tmp —— 历史记录不算「有人用」）
//        宽松孤儿 = 连档案／记录里也没人提过（这一档才敢说「从来没人提」）
//   仍然是「只报在不在、不判该不该在」（内核 #71）：删／搬之前由人核。
const 孤儿模式 = process.argv.includes('--孤儿') || process.argv.includes('--selftest');
const 自测 = process.argv.includes('--selftest');
let 严格孤儿 = [], 宽松孤儿 = [], 扫面 = { 候选: 0, 活源: 0, 档源: 0, 插件源: 0, 词: 0 };

if (孤儿模式) {
  const 跳 = /(^|\/)(_backup|node_modules|\.git|tmp|_tmp|\.combo-cache)(\/|$)/;
  const 档档 = /(^|\/)(档案|_archive|台账\/轮末|台账\/归档|台账\/证据|台账\/池子)(\/|$)/;
  const 词表 = (文本, 集) => { for (const m of 文本.matchAll(/[A-Za-z0-9_.\-\u4e00-\u9fa5]{2,120}/g)) 集.add(m[0]); };
  const 读文本 = p => { try { const b = fs.readFileSync(p); if (b.length > 3_000_000) return null; const s = b.toString('utf8'); return s.includes('\0') ? null : s; } catch { return null; } };
  const 全文件 = [];
  (function 走2(d) {
    let es; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of es) { const p = path.join(d, e.name); const rel = String(p).replace(ROOT + '/', '');
      if (跳.test(rel)) continue;
      if (e.isDirectory()) 走2(p); else 全文件.push(p); }
  })(ROOT);
  const 活词 = new Set(), 档词 = new Set();
  for (const p of 全文件) { const rel = String(p).replace(ROOT + '/', ''); const t = 读文本(p); if (t === null) continue;
    if (档档.test(rel)) { 档词.add(path.basename(p)); 词表(t, 档词); } else { 词表(t, 活词); 扫面.活源++; } }
  // 插件源码面／壳配置／预设（0928 的盲区）
  const HOME = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh';
  const 插件根 = [];
  try { for (const pr of fs.readdirSync(path.join(HOME, 'profiles'))) 插件根.push(path.join(HOME, 'profiles', pr)); } catch {}
  插件根.push(path.join(HOME, '.agent-presets'));
  for (const r of 插件根) { const 子树 = [];
    (function 走3(d) { let es; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
      for (const e of es) { const p = path.join(d, e.name);
        if (e.isDirectory()) { if (!['node_modules', '.git', 'dist', 'assets'].includes(e.name)) 走3(p); }
        else if (/\.(js|mjs|json|yml|yaml|md)$/.test(e.name)) 子树.push(p); } })(r);
    for (const p of 子树) { const t = 读文本(p); if (t === null) continue; 词表(t, 活词); 扫面.插件源++; } }
  try { for (const f of fs.readdirSync(HOME)) if (/\.(yml|yaml|json)$/.test(f)) { const t = 读文本(path.join(HOME, f)); if (t) { 词表(t, 活词); 扫面.插件源++; } } } catch {}
  // 候选：--根 <目录> 可改（自测用），默认 工具/ 下 .mjs
  const 根参数 = (() => { const i = process.argv.indexOf('--根'); return i > -1 ? process.argv[i + 1] : '工具'; })();
  const 候选根 = path.join(ROOT, 根参数);
  const 候选 = 全文件.filter(f => f.startsWith(候选根 + '/') && f.endsWith('.mjs'));
  扫面.候选 = 候选.length; 扫面.词 = 活词.size;
  for (const f of 候选) {
    const 名 = path.basename(f);
    const 活提过 = 活词.has(名);
    const 档提过 = 档词.has(名);
    if (!活提过) 严格孤儿.push([f, 档提过]);
    if (!活提过 && !档提过) 宽松孤儿.push(f);
  }
  console.log('══ 反向段 · 孤儿（v1 · 2026-10-05）══');
  console.log('  候选 ' + 扫面.候选 + ' 件（根=' + 根参数 + '／*.mjs）｜引用源：工作区活文件 ' + 扫面.活源 +
              ' ＋ 插件源码面／壳配置 ' + 扫面.插件源 + ' 个文件 · 词表 ' + 扫面.词);
  console.log('  严格孤儿（没有任何活文件提过）**' + 严格孤儿.length + '** 件' +
              (严格孤儿.filter(x => x[1]).length ? '（其中 ' + 严格孤儿.filter(x => x[1]).length + ' 件只在档案/记录里出现过）' : '') +
              ' ｜ 宽松孤儿（连记录里也没人提）' + 宽松孤儿.length + ' 件');
  if (严格孤儿.length) { console.log('  · 严格孤儿：'); 严格孤儿.slice(0, 25).forEach(([f, 档过]) => console.log('     ' + String(f).replace(ROOT + '/', '') + (档过 ? '  〔只在档案/记录里被提过〕' : ''))); if (严格孤儿.length > 25) console.log('     …还有 ' + (严格孤儿.length - 25) + ' 件'); }
  console.log('  ⚠️ 本段仍只报「有没有人提」，**不判该不该留**（内核 #71）；删／搬前用 `--孤儿` 重扫一遍。');
  console.log('');
  if (自测) {
    const 断言 = [
      ['反证① 活标本：extract-seq.mjs 被 device-smoke.ps1 引 ⇒ 不许算孤儿', !严格孤儿.some(([f]) => f.endsWith('/golden/extract-seq.mjs')) && !宽松孤儿.some(f => f.endsWith('/golden/extract-seq.mjs'))],
      ['反证② 页面探针 run.mjs 被 做法库 引 ⇒ 不许算孤儿', !宽松孤儿.some(f => f.endsWith('/cdp/run.mjs'))],
      ['反证③ 口径覆盖：扫过插件源码面（插件源 > 0）', 扫面.插件源 > 0],
      ['反证④ 口径覆盖：引用源含非 md/mjs 扩展名（活源数 > 工具/ 下 .mjs 数）', 扫面.活源 > 扫面.候选],
    ];
    let bad = 0;
    for (const [名, ok] of 断言) { console.log('   ' + (ok ? '✅' : '❌') + ' ' + 名); if (!ok) bad++; }
    console.log('   自测：' + (断言.length - bad) + '/' + 断言.length + (bad ? ' ❌' : ' ✅'));
    process.exit(bad ? 1 : 0);
  }
}

console.log('⚠️ 本器只报「在不在」，**不判该不该在**（内核 #71：判不了的绝不猜）。');
process.exit((真死.length || 严格孤儿.length) ? 1 : 0);
