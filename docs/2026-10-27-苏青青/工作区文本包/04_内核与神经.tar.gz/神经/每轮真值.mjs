#!/usr/bin/env node
// 每轮真值 v1 · 2026-09-28 立（**修尺子**：池化之后，日志留档 ≠ 每轮真发的东西）
// ════════════════════════════════════════════════════════════════════════════
// 【为什么要它】0928 我报过错：拿「日志里出现过几块压缩摘要 × 每块字数」当成「每轮都在发」，
//   得出「池化哑了 8 小时、每轮白背 8,759 字」——**两条都错**：
//     ① **时区**：摘要池日志与 session 事件的 time 是 **UTC**（`toISOString()`），
//        本地 = UTC+8 ⇒ 日志里「12:43:08Z」＝**本地 20:43:08**，我按本地读成"8 小时没动"。
//     ② **尺子**：池子是「**搬走不删**」——被替掉的检查点**全文仍留在会话日志里**（可复原、可审计），
//        但**请求面**（surface）上只剩 465 字节的名册。按日志量 ⇒ 把已搬走的算成还在身上。
//   ⇒ 正解：**先把 surfaceOp 链跑一遍，得出"请求面"，再在请求面上量**。
//
// 【表面语义】（从本会话日志实证，18 条检查点全部被替换）
//   · 事件带 `surfaceOp:"append"` ⇒ 加进表面；
//   · 事件带 `surfaceOp:{op:"replace",startSeq,endSeq}` ⇒ 先把**已进表面**且 seq 落在
//     [startSeq,endSeq] 内的事件移出，再把自身加进表面；
//   · 链条实例：`1753`(compaction 检查点, replace 1678→1685) → `1755`(池子名册,
//     replace 1753→1753) ⇒ 表面最终留着**名册**，检查点全文被移出（但仍在日志里）✓
//
// 【判据（自检）】跑完必须满足：表面上 **plugin:compact 检查点 = 0 条**、
//   **summary-pool 名册 = 1 条**（池子工作时）。不满足 ⇒ 池子真哑了，才该报红。
//
// 【用法】node 神经/每轮真值.mjs [会话目录名或日志路径]
//   不给参数 ⇒ 自动取本工作区**最近改动**的那个会话日志。
// 【真源】会话日志 `$DSH_HOME/sessions/<工作区>/<会话id>/session.v3.jsonl.zstd`
// ════════════════════════════════════════════════════════════════════════════
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'

const HOME = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const 工作区 = process.env.DSH_SUMMARY_POOL_WS || '/storage/emulated/0/3'

/** 认帧解压：v3 是**一帧一压**，`zstd -dc` 只出第一帧（0928 踩过）⇒ 按 magic 切开逐帧解 */
function 认帧解压(文件) {
  const b = fs.readFileSync(文件)
  const idx = []
  for (let i = 0; i + 3 < b.length; i++) if (b[i] === 0x28 && b[i + 1] === 0xb5 && b[i + 2] === 0x2f && b[i + 3] === 0xfd) idx.push(i)
  const out = []
  let 坏 = 0
  for (let k = 0; k < idx.length; k++) {
    try { out.push(zlib.zstdDecompressSync(b.subarray(idx[k], k + 1 < idx.length ? idx[k + 1] : b.length))) } catch { 坏++ }
  }
  return { 文本: Buffer.concat(out).toString('utf8'), 帧: idx.length, 坏, 压缩字节: b.length }
}

/** 找日志：显式路径 > 会话目录名 > 本工作区最新 */
function 找日志(参) {
  if (参 && fs.existsSync(参) && fs.statSync(参).isFile()) return 参
  const 本区 = path.join(HOME, 'sessions', '--' + 工作区.replace(/^\//, '').replace(/\//g, '-') + '--')
  const 根 = fs.existsSync(本区) ? 本区 : path.join(HOME, 'sessions')
  let 候选 = []
  for (const d of fs.readdirSync(根)) {
    const p = path.join(根, d)
    if (!fs.statSync(p).isDirectory()) continue
    if (参 && !d.includes(参)) continue
    for (const f of fs.readdirSync(p)) if (f.startsWith('session') && f.endsWith('.zstd')) 候选.push(path.join(p, f))
  }
  if (!候选.length) return null
  候选.sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)
  return 候选[0]
}

const 文 = (d) => (d && Array.isArray(d.content) ? d.content.filter((p) => p && typeof p.text === 'string').map((p) => p.text).join('\n') : '')
const 本地 = (t) => (t ? new Date(t).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', hour12: false }) : '?')
const 来源名 = (e) => {
  const s = (e.data && e.data.source) || {}
  return (s.kind || e.type || '?') + (s.plugin ? ':' + s.plugin : '') + (s.form ? ':' + s.form : '')
}

const 参 = process.argv[2]
const 日志 = 找日志(参)
if (!日志) { console.error('❌ 找不到会话日志（给路径或会话目录名）'); process.exit(2) }
const { 文本, 帧, 坏, 压缩字节 } = 认帧解压(日志)
const 事件 = []
for (const l of 文本.split('\n')) { const t = l.trim(); if (!t) continue; try { 事件.push(JSON.parse(t)) } catch { } }

// ── 跑 surfaceOp 链 ──────────────────────────────────────────────────────────
const 表面 = new Map() // seq -> event
let 加了 = 0, 移了 = 0
for (const e of 事件) {
  const op = e.surfaceOp
  if (op && typeof op === 'object' && op.op === 'replace') {
    const a = op.startSeq ?? op.start, b = op.endSeq ?? op.end
    for (const k of [...表面.keys()]) if (k >= a && k <= b) { 表面.delete(k); 移了++ }
  }
  表面.set(e.seq, e); 加了++
}
const 表 = [...表面.values()].sort((a, b) => a.seq - b.seq)

// ── 在**请求面**上量（只算进请求的文本块） ───────────────────────────────────
const 账 = new Map()
let 合计 = 0
for (const e of 表) {
  const t = 文(e.data)
  if (!t) continue
  const k = 来源名(e)
  const v = 账.get(k) || { 条: 0, 字: 0, 例: '' }
  v.条++; v.字 += t.length; if (!v.例) v.例 = t.replace(/\s+/g, ' ').slice(0, 40)
  账.set(k, v)
  合计 += t.length
}
const 检查点 = 表.filter((e) => e.data && e.data.source && e.data.source.kind === 'plugin' && e.data.source.plugin === 'compact')
const 名册 = 表.filter((e) => e.data && e.data.source && e.data.source.kind === 'summary-pool')
const 压缩 = 事件.filter((e) => e.type === 'compaction/summary')

console.log('日志：' + 日志)
console.log('认帧：' + 帧 + ' 帧（坏 ' + 坏 + '）｜压缩 ' + 压缩字节 + ' 字节 → 解出 ' + 文本.length + ' 字符｜事件 ' + 事件.length + ' 条')
console.log('最后压缩：seq ' + (压缩.length ? 压缩[压缩.length - 1].seq : '无') + ' ｜UTC ' + (压缩.length ? new Date(压缩[压缩.length - 1].time).toISOString().slice(11, 19) : '-') + ' ｜★本地 ' + 本地(压缩.length ? 压缩[压缩.length - 1].time : 0))
console.log('表面：' + 表.length + ' 条（加入 ' + 加了 + ' · 移出 ' + 移了 + '）')
console.log('── 请求面每轮构成（按来源） ──')
for (const [k, v] of [...账.entries()].sort((a, b) => b[1].字 - a[1].字)) {
  console.log('  ' + String(v.字).padStart(7) + ' 字 ×' + String(v.条).padStart(3) + '  ' + k + (v.例 ? '  ｜ ' + v.例 : ''))
}
console.log('  ' + String(合计).padStart(7) + ' 字 ＝ **请求面文本合计**')
// ── 每轮真值：只算**最后一次压缩之后**的表面（＝下一次请求真正要带的对话部分） ──
const 界 = 压缩.length ? 压缩[压缩.length - 1].seq : 0
const 账2 = new Map(); let 合2 = 0
for (const e of 表) {
  if (e.seq <= 界) continue
  const t = 文(e.data); if (!t) continue
  const k = 来源名(e); const v = 账2.get(k) || { 条: 0, 字: 0 }
  v.条++; v.字 += t.length; 账2.set(k, v); 合2 += t.length
}
console.log('── ★每轮真值（最后一次压缩之后表面 · 界 seq ' + 界 + '） ──')
for (const [k, v] of [...账2.entries()].sort((a, b) => b[1].字 - a[1].字)) console.log('  ' + String(v.字).padStart(7) + ' 字 ×' + String(v.条).padStart(3) + '  ' + k)
console.log('  ' + String(合2).padStart(7) + ' 字 ＝ **每轮真值（不含工具定义）**')
// ★ 0928 修尺：自检只许量**活注入面**（界之后＝下一步真会发出去的那些）。
//   旧版量的是"表"（＝整段历史面，里面躺着每一次注入的旧副本）⇒ 每次报表都误报 ⚠️（0928 老板问「还会重复注入吧」时踩到）。
const 活检查点 = 检查点.filter((e) => e.seq > 界)
const 活名册 = 名册.filter((e) => e.seq > 界)
console.log('── 自检（池子判据 · 量**活注入面**＝界 seq ' + 界 + ' 之后） ──')
console.log('  活面上引擎检查点：' + 活检查点.length + ' 条（池子工作时应为 0）' + (活检查点.length ? ' ⇒ ❌ 池子哑了：' + 活检查点.map((e) => e.seq + '/' + 文(e.data).length + '字').join(' ') : ' ⇒ ✅'))
console.log('  活面上池子名册：' + 活名册.length + ' 条（应为 1）' + (活名册.length === 1 ? ' ⇒ ✅ ' + ((活名册[0].data.source || {}).池子 || '') : ' ⇒ ⚠️'))
console.log('  历史面（只是记录 · 不是每步发）：引擎检查点残留 ' + 检查点.length + ' 条｜池化累计 ' + 名册.length + ' 次')
