#!/usr/bin/env node
// ═══ 注入计量器 v2 · 「你本人说的字」vs「引擎替你注入的字」 ═══
//
// v1（2026-09-2x）：只能从 stdin 吃一份解压好的日志 —— 所以每次都要
//   `zstd -dc <会话日志> | node 注入计量.mjs`，**没有基线、没有前后比**。
//   后果：老板那条「提示词优化」做完也**证明不了成没成**，只能凭感觉。
//
// v2（2026-09-26，老板令「全部做了做一个长期任务」）：加三个口子 ——
//   node 神经/注入计量.mjs              # 测最新一个会话（自己找、自己解压）
//   node 神经/注入计量.mjs 测 [会话id]   # 同上，可点名
//   node 神经/注入计量.mjs 基线 [名]     # 存基线（落 台账/接续/注入基线.json）
//   node 神经/注入计量.mjs 比 [名]       # 与基线比 → 每块涨/跌多少字
//   <解压好的日志> | node 神经/注入计量.mjs    # 老路子，逐字保留（向后兼容）
//
// ★ 纪律：
//   · 判据是**它的数字**，不是"某个文件现在短了"（老板亲自核过的坑：
//     86KB→15KB 而总输入 token 没动 —— 因为根级说明/工具描述/历史仍全进）。
//   · 基线**只增不改**：每存一次追加一条带时间戳的记录，不许覆盖历史。
//   · 读不到日志 ⇒ **明说读不到并给退路**，绝不许静默印 0（隐藏的 0 = 假绿）。
import { readFileSync, writeFileSync, existsSync, readdirSync, statSync, mkdirSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const require = createRequire(import.meta.url)
// ★ 2026-09-27 加：**主判定** —— 原来 CLI 段是裸块：谁 `import` 它谁就当场被印一屏，
//   还可能被里面的 process.exit 截断调用方输出（实测踩过）。被 import 时**应当什么都不做**。
const 主 = (() => { try { return path.resolve(process.argv[1] || '') === fileURLToPath(import.meta.url) } catch { return false } })()
const 抬头窗 = Number(process.env.DSH_HEADWIN || 200) // 抬头锚定窗口（字，ASCII 环境变量 DSH_HEADWIN）：真注入块的抬头都在最前面；超过这个位置命中的 ⇒ 算"引文夹带"。
//   ★ 旋钮是留给**核账**的：`DSH_HEADWIN=999999999` ⇒ 退化成旧口径（任意位置命中），
//     同一份日志跑两遍，新旧口径差多少字就是实数，不用凭感觉说"口径变了"。
const WS = process.env.DSH_KICKOFF_WS || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const P = (...a) => path.join(WS, ...a)
const HOME0 = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const 基线文件 = '台账/接续/注入基线.json'

// ══ ★★ 2026-09-26 实测抓到的**真缺陷**（这条比什么都值钱）══
// 会话日志是**多帧** zstd（实测这个文件：232 帧）。而
//   · `zstdDecompressSync(整个文件)`  **只解出第 1 帧**（203 B），**不抛错、不报警** ——
//     它把剩下的帧**原样留在解出的字节里**，所以"解出来的东西里没有魔数"是**假象**，
//     让人误判成"全解开了"。用这个口径量注入面 ⇒ **数出 0，而且看起来正常**。
//   · `createZstdDecompress()` 流式**同样只吃第一帧**。
//   ⇒ 唯一对的做法：**逐帧推进**（见 `解多帧`）。这也解释了我们旧口径
//     （`zstd -dc | node 注入计量.mjs`）为什么必须依赖 zstd 二进制 —— 因为 node 自己做不到。
// 教训入账：**"没抛错"不等于"全解开了"**；多帧格式上必须显式走帧边界。
const MAGIC = Buffer.from([0x28, 0xb5, 0x2f, 0xfd])

/** 逐帧解开多帧 zstd：用 magic 位置当帧边界，每帧单独解，能解几帧是几帧。 */
export function 解多帧(buf) {
  const pos = []
  let i = 0
  while (i <= buf.length - 4) { const j = buf.indexOf(MAGIC, i); if (j < 0) break; pos.push(j); i = j + 1 }
  const z = require('node:zlib')
  const 片段 = []
  let 帧 = 0, 跳 = 0
  for (let n = 0; n < pos.length; n++) {
    const s = pos[n]
    const e = n + 1 < pos.length ? pos[n + 1] : buf.length
    try { 片段.push(z.zstdDecompressSync(buf.subarray(s, e))); 帧++ } catch { 跳++ }
  }
  return { 文本: Buffer.concat(片段).toString('utf8'), 帧, 跳, magic出现: pos.length }
}

/** 解压：① 多帧逐帧解（正路）② zstd 二进制（对照/兜底）③ 明文 */
function 解压(buf) {
  if (buf.subarray(0, 4).equals(MAGIC)) {
    const r = 解多帧(buf)
    if (r.帧 > 0) return { 文本: r.文本, 路: '逐帧解 ' + r.帧 + ' 帧（跳 ' + r.跳 + '／magic ' + r.magic出现 + '）' }
  }
  for (const bin of [HOME0.replace(/\/\.dsh$/, '') + '/usr/bin/zstd', 'zstd']) {
    try {
      const out = execFileSync(bin, ['-dc'], { input: buf, maxBuffer: 256 * 1024 * 1024, timeout: 120000 })
      return { 文本: out.toString('utf8'), 路: bin }
    } catch (e) { /* 下一个 */ }
  }
  return { 文本: buf.toString('utf8'), 路: '明文（没解压成功）' }
}

/** 找会话日志：`$DSH_HOME/sessions/<工作区目录>/<会话>/session.v4.jsonl.zstd`
 *  ★ 1013 第16刀：引擎升 v4 后日志名从 v3 变 v4 ⇒ 依次认 v4／v3／无版本（原写死 v3 ⇒ 新窗一律读不到）。
 *  ★ 不猜工作区目录名（平板 `--storage-emulated-0-3--`、电脑 `--C-Users-…--`）⇒ 全扫一遍按 mtime 取最新。 */
export function 找日志(要哪个) {
  const root = path.join(HOME0, 'sessions')
  if (!existsSync(root)) return { 错: '会话根目录不在：' + root }
  const 候选 = []
  let 工作区们 = []
  try { 工作区们 = readdirSync(root).map(x => path.join(root, x)) } catch (e) { return { 错: '列不出 sessions：' + e.message } }
  for (const d of 工作区们) {
    let 会话们 = []
    try { 会话们 = readdirSync(d).filter(x => x.startsWith('session-')) } catch { continue }
    for (const s of 会话们) {
      const f = ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd'].map(x => path.join(d, s, x)).find(x => existsSync(x))
      if (!f) continue
      let m = 0; try { m = statSync(f).mtimeMs } catch {}
      候选.push({ 会话: s, 文件: f, mtime: m })
    }
  }
  if (!候选.length) return { 错: '一个会话日志都没找到（扫了 ' + 工作区们.length + ' 个工作区目录）' }
  候选.sort((a, b) => b.mtime - a.mtime)
  if (要哪个 && 要哪个 !== '测') {
    const k = String(要哪个).replace(/^session-/, '')
    const hit = 候选.find(x => x.会话.includes(k))
    if (!hit) return { 错: '点名的会话找不到：' + 要哪个, 可选: 候选.slice(0, 5) }
    return { ...hit, 全部: 候选, 点名: '点名' }
  }
  // ★ 2026-09-27 修（实测事故）：原来只按 mtime 取最新 ⇒ 同工作区两扇窗时，
  //   "最新"会跟着**最后写日志的那个窗**翻脸；我中午就把隔壁窗 e84402ff 的数当成了本窗的。
  //   现在：优先**本进程自认身份**（`$DSH_SESSION_ID`，工具执行器里有、引擎进程 env 里实测没有）。
  const 自认 = process.env.DSH_SESSION_ID || ''
  if (自认) {
    const hit = 候选.find(x => x.会话 === 自认 || x.会话.includes(自认.replace(/^session-/, '')))
    if (hit) return { ...hit, 全部: 候选, 点名: '自认' }
    return { ...候选[0], 全部: 候选, 点名: '自认落空（要 ' + 自认.slice(0, 13) + '… 没找到 ⇒ 报的是最新那个）' }
  }
  return { ...候选[0], 全部: 候选, 点名: '没自认身份（引擎 spawn 的卡片走这条 ⇒ 别当本窗）' }
}

// ── 计量本体（★★ 2026-09-26 重写：口径对着**真日志**定，不是拍脑袋）──
// 实测这条会话的 37 条 user/message 长相（逐条看过）：
//   · 5 类"引擎/系统注入"：长期记忆块 ／ 工作区 instructions ／ 运行时上下文 ／ 技能目录 ／ 他插进来的系统提醒
//   · ★ **checkpoint 压缩摘要**：8,327~12,829 字/条，**8 条** —— 旧口径把它当成"他说的"，
//     于是"信噪比"被**虚高**（把系统的字算到人头上）。这条必须单列。
//   · **可能相关的记忆**：引擎按关键词注入的检索块（旧口径只在注释里提了一句，没数）
//   · **老板本人**：实测 **8~154 字**的短句（他走语音）⇒ 判据＝"短、且不含任何注入抬头"
const 注入抬头 = [
  ['长期记忆整块', 'lt', /=====\s*长期记忆\s*=====/],
  // ★ 1008 改名：这一栏**不是**单独一份工作区 AGENTS.md —— 那个 reminder 里装着**两份**：
  //   `~/.dsh/AGENTS.md`（红线本，18KB，占约 79%）＋ `<工作区>/AGENTS.md`（索引，4.7KB）。
  //   原名让我自己误判成“工作区 AGENTS.md 该瘦身”（真大头是每轮必到的红线本，动不得）。
  //   ★ 待办：按 `Instructions from: <路径>` 把两份分开计量（现在只改名，不动统计逻辑 —— K.ws 还被用来算轮数）。
  ['常驻面（红线本＋工作区AGENTS）', 'ws', /workspace instructions/],
  ['运行时上下文', 'rt', /Current runtime context/],
  ['技能目录', 'sk', /available skill catalog/],
  ['rules 82 条', 'rl', /=====\s*(规则|rules)\s*=====/i],
  ['可能相关的记忆', 'kw', /可能相关的记忆，仅供参考/],
  ['技能使用说明', 'skd', /A skill is a reusable set of task-specific/],
  ['指令增删提醒', 'ins', /Instructions (removed|added)|Additional instructions from/],
  ['★ 压缩摘要(checkpoint)', 'ck', /automatically generated checkpoint condensing/],
]
// ★ 2026-09-27 加：**子系统回音**（不是他说的字，却以 user/message 的身份进来）
//   实测本窗 89 条"短消息"里 6 条是这类：后台作业回执 `background job bash-1 …`、
//   子代理回话 `Agent 599e0dfa-… sent a message:`、记忆插件任务 `[meow-memory-…]`。
//   混进分母 ⇒ 信噪比被压低（把机器的字算到他头上）。**分母只许留他本人。**
const 回音样 = /^(background job |Agent [0-9a-f]{6,}[-0-9a-f]* sent a message|\[meow-memory-|task |bash-|tool |\{|## )/

export const 量 = (lines) => {
  const collect = (o, out) => {
    if (!o || typeof o !== 'object') return
    if (Array.isArray(o)) { for (const x of o) collect(x, out); return }
    if (o.type === 'text' && typeof o.text === 'string') out.push(o.text)
    for (const k of Object.keys(o)) if (k !== 'text') collect(o[k], out)
  }
  const K = {}
  for (const [, k] of 注入抬头) { K[k] = 0; K[k + 'Sum'] = 0 }
  const human = []
  const 别的 = []
  const 引文 = []
  const 回音 = []
  // ★ 1008：tools 通道的累计 —— 声明必须在循环外。
  //   ⚠️ 我第一次改漏了这两行（前面的 edit 因"file changed"失败，重试时只贴了分支），
  //   跑起来就是 ReferenceError。**教训：edit 失败后重试，必须把整组改动一起重贴。**
  let 工具面 = 0, 工具面次数 = 0
  for (let i = 0; i < lines.length; i++) {
    let e; try { e = JSON.parse(lines[i]) } catch { continue }
    // ★ 1008 新口径：**tools 通道**（工具定义）不在文本注入里，却比全部文本注入加起来还大
    //   —— 实测每条 request/header 恒定 ~32,119 字符（30/30 条都带）。
    //   ★ 不量它 ⇒「判据只许用合计那一行」这话本身是错的（那行漏了最大一笔）。
    if (e.type === 'request/header') {
      const j = lines[i].indexOf('"tools"')
      if (j >= 0) { 工具面 += (lines[i].length - j); 工具面次数++ }
      continue
    }
    if (e.type !== 'user/message') continue
    const out = []; collect(e, out); const t = out.join('\n')
    if (t.length < 4) continue
    // ★ 2026-09-27 改口径（实测缺陷）：原来用 `re.test(t)` ＝ **整条消息任意位置命中**（contains）
    //   ⇒ checkpoint 摘要里引用到的块（它整段抄了旧上下文）会被算成"那一栏"，
    //     于是「压缩摘要 53.3%」与「长期记忆 16.0%」互相污染，账不可信。
    //   现在：**按"抬头出现在第几个字"判**（真注入块的抬头都在最前面，≤ `抬头窗` 才算），
    //   超过窗口才命中的 ⇒ 单列【引文夹带】，**不吸进任何一栏**；
    //   多个抬头同时命中时取**最靠前**那个（不是"列表里排第一"那个）。
    let 归 = '', 归名 = '', 归位 = -1
    for (const [名, k, re] of 注入抬头) {
      const m = re.exec(t)
      if (m && (归位 < 0 || m.index < 归位)) { 归 = k; 归名 = 名; 归位 = m.index }
    }
    if (归 && 归位 <= 抬头窗) {
      K[归]++; K[归 + 'Sum'] += t.length
      // ★ 1008 拆口径：这一条 reminder 里装着**两份**文件（红线本 ＋ 工作区 AGENTS.md），
      //   混成一栏会让人误判「工作区 AGENTS.md 该瘦身」——实测红线本占约 79%。
      //   ★ `t` 来自 `collect(JSON.parse(line))` ⇒ 换行是**真换行**，不是字面 "\\n" 两字符。
      if (归 === 'ws') {
        const 段 = t.split(/Instructions from:\s*/).slice(1)
        for (const q of 段) {
          const nl = q.indexOf('\n')
          const 路 = nl > 0 ? q.slice(0, nl).trim() : ''
          const 长 = nl > 0 ? q.length - nl : q.length
          if (/\.dsh\/AGENTS\.md$/.test(路)) K.ws红线本 = (K.ws红线本 || 0) + 长
          else if (/AGENTS\.md$/.test(路)) K.ws工作区 = (K.ws工作区 || 0) + 长
        }
      }
      continue
    }
    const 夹 = 注入抬头.filter(([, , re]) => re.test(t)).map(([名]) => 名)
    if (夹.length) { 引文.push({ i, len: t.length, 块: 夹.join('＋'), 位: 归位, head: t.replace(/\s+/g, ' ').slice(0, 60) }); continue }
    // 认不出的：短的当"他本人"，长的单列（诚实：不硬塞进任何一栏）
    //   ★ 2026-09-27 补：短消息里**混着"子系统回音"**（后台作业通知／子代理回话／记忆插件任务），
    //     它们不是他说的字 —— 混进分母会把信噪比压低（实测 89 条里 6 条是回音）。
    if (t.length <= 400) {
      if (回音样.test(t)) 回音.push({ i, len: t.length, head: t.replace(/\s+/g, ' ').slice(0, 40) })
      else human.push({ i, len: t.length, head: t.replace(/\s+/g, ' ').slice(0, 40) })
    } else 别的.push({ i, len: t.length, head: t.replace(/\s+/g, ' ').slice(0, 40) })
  }
  const inj = 注入抬头.reduce((s, [, k]) => s + K[k + 'Sum'], 0)
  // ★ 1008：tools 通道单列（它不在 `inj` 里 —— 不占文本注入，却比它更大）。
  K.工具面 = 工具面次数; K.工具面Sum = 工具面
  const 他 = human.reduce((s, x) => s + x.len, 0)
  const 引文Sum = 引文.reduce((s, x) => s + x.len, 0)
  const 回音Sum = 回音.reduce((s, x) => s + x.len, 0)
  // 轮数：优先用业务块的出现次数当分母（长期记忆 1 次是首帧基线，不算每轮）
  const 轮数 = Math.max(K.ws, K.rt, K.sk, 1)
  return { K, human, 别的, 引文, 引文Sum, 回音, 回音Sum, inj, 他, 轮数 }
}

const 块名 = 注入抬头.map(([n, k]) => [n, k])

/** 窗签：把「这次读的到底是哪扇窗」印在读数第一行 —— 防止把隔壁窗的数当成自己的（09-27 实测栽过）。 */
export function 窗签(L) {
  const t = (ms) => { try { return new Date(ms).toLocaleString('sv-SE', { timeZone: 'Asia/Shanghai' }).slice(0, 16) } catch { return '?' } }
  return '窗 ' + String(L.会话 || '?').replace(/^session-/, '').slice(0, 8) + ' ｜ ' + (L.点名 || '没标注') + ' ｜ 日志写到 ' + t(L.mtime) + ' ｜ 读数于 ' + t(Date.now())
}

export function 印(R, 标题, 签) {
  console.log('【引擎替你注入的】' + (标题 ? '  ' + 标题 : ''))
  if (签) console.log('  ' + 签)
  for (const [名, k] of 块名) {
    const n = R.K[k], s = R.K[k + 'Sum']
    if (!n && !s) continue
    const pct = R.inj ? (s / R.inj * 100).toFixed(1) : '0.0'
    console.log('  ' + 名.padEnd(22) + String(n).padStart(3) + ' 次 ／ ' + String(s).padStart(9) + ' 字  ｜ 占注入面 ' + pct + '%')
    if (k === 'ws') {
      // ★ 1008：把这一栏**拆开印** —— 否则看数的人（我）会误判「工作区 AGENTS.md 该瘦身」；
      //   实测真大头是**红线本**（每轮必到、动不得），工作区那份只是一小截。
      const a = R.K.ws红线本 || 0, b = R.K.ws工作区 || 0, s2 = a + b
      const 均 = (x) => Math.round(x / (n || 1)).toLocaleString()
      // ★ 1008 补：**必须同时印「每次均」** —— 上面的字数是**累计**（n 次注入事件之和）。
      //   只看累计会把 6 次的红线本读成"每轮 48KB"，于是得出"该大砍"的错误结论；
      //   实测每次只 ~8 千字（48,507 ÷ 6）。
      //   ⚠️ 措辞纪律：是「**每次注入事件**」**不是「每轮」** —— 千问 1007 已核出我这个硬伤
      //   （记忆 0muyfht2n：事件次数 ≠ 轮数，28 轮里可能只有 3 次）。
      if (s2) console.log('      └ 其中：红线本 ' + a + ' 字（每次均 ' + 均(a) + '）／ 工作区 AGENTS.md ' + b + ' 字（每次均 ' + 均(b) + '）（红线本占 ' + (a / s2 * 100).toFixed(0) + '%）')
    }
  }
  // ── ★ 池子校正（2026-10-08 加 · 老板令「建议的判据要从池子出发」）──────────────
  //   病根（当场查实）：本工具读的是**会话日志**，而摘要池插件是"搬走不删"——
  //   日志里留着原文（如 10,411 字节），**实际注入的是名册（487 字节）**。
  //   ⇒ checkpoint 那栏必须用池子校正，否则虚高几十倍（实测：日志口径 26% vs 真注入 ~1%）。
  //   真源：$DSH_HOME/summary-pool.log 每行 `换：摘要-xxxx ／ 原文 A 字节 → 名册 B 字节`。
  try {
    const 池路 = path.join(HOME0, 'summary-pool.log')
    if (existsSync(池路) && R.K.ck) {
      let 原B = 0, 名B = 0, 次数 = 0
      // ★ 只取**最后 R.K.ck 条** ＝ 本窗的替换（日志是追加的）；不切片会把所有历史窗口一起算进来
      //   （1008 实犯：不切片 ⇒ 算出 297 次／真占 60%，当场被自己抓住 ⇒ 切片修掉）
      const 全 = [...readFileSync(池路, 'utf8').matchAll(/原文 (\d+) 字节 → 名册 (\d+) 字节/g)]
      for (const m of 全.slice(-Math.max(1, R.K.ck))) { 原B += +m[1]; 名B += +m[2]; 次数++ }
      if (次数) {
        const 真注入 = R.inj - R.K.ckSum + 名B
        console.log('  ' + '★ 池子校正(真注入)'.padEnd(20) + String(次数).padStart(4) + ' 次 ／ ' + String(名B).padStart(9) + ' 字  ｜ **真占注入面 ' + (名B / 真注入 * 100).toFixed(1) + '%**（上面那栏 ' + R.K.ckSum + ' 字是"搬走不删"的审计原文；池子把 ' + 原B + ' 字节缩成 ' + 名B + ' 字节 ＝ 缩 ' + (100 * (1 - 名B / 原B)).toFixed(1) + '%）')
        console.log('  ' + '  校正后合计'.padEnd(22) + '      ／ ' + String(真注入).padStart(9) + ' 字（' + (真注入 / 1024).toFixed(1) + ' KB）　★ 判据与建议只许用这一行')
      }
    }
  } catch (e) { /* fail-open：读不到池子日志就不校正，绝不因此报错 */ }
  console.log('  ' + '合计'.padEnd(22) + '      ／ ' + String(R.inj).padStart(9) + ' 字（' + (R.inj / 1024).toFixed(1) + ' KB）')
  // ★ 1008：tools 通道（工具定义）—— **它不在上面的分母里，却是最大的单一注入面**。
  //   实测每条 request/header 恒定 ~32,119 字符（30/30 条都带）＝ 比全部文本注入还大。
  //   ★ 千问 1007 提过「工具定义 47,976 字符/轮 **未经重量不能当真**」⇒ 本行就是那次重量。
  if (R.K.工具面Sum) {
    console.log('  ' + '★ tools 通道(工具定义)'.padEnd(20) + String(R.K.工具面).padStart(4) + ' 次 ／ ' + String(R.K.工具面Sum).padStart(9) + ' 字  ｜ **每次 ' + Math.round(R.K.工具面Sum / R.K.工具面).toLocaleString() + ' 字**（不在上面分母里；随工具件数走，不随文本注入走）')
  }
  if (R.引文 && R.引文.length) {
    console.log('  ' + '【引文夹带】'.padEnd(20) + String(R.引文.length).padStart(3) + ' 次 ／ ' + String(R.引文Sum).padStart(9) + ' 字  ｜ **不算进上面任何一栏**（正文里引用了某块抬头、但抬头不在最前面）')
    for (const x of R.引文.slice(0, 3)) console.log('      ' + String(x.len).padStart(7) + ' 字 夹带「' + x.块 + '」首位在 ' + x.位 + ' 字处  ' + x.head)
  }
  console.log('')
  console.log('【你本人说的】' + R.human.length + ' 条 ／ ' + R.他 + ' 字')
  for (const h of R.human.slice(-6)) console.log('  ' + String(h.len).padStart(6) + ' 字  ' + h.head)
  if (R.回音 && R.回音.length) {
    console.log('  ── 单列【子系统回音】' + R.回音.length + ' 条 ／ ' + R.回音Sum + ' 字（后台作业回执／子代理回话／记忆插件任务 —— **不算他说的**，也不进上面任何一栏）')
    for (const h of R.回音.slice(-3)) console.log('      ' + String(h.len).padStart(6) + ' 字  ' + h.head)
  }
  if (R.别的 && R.别的.length) {
    console.log('')
    console.log('【认不出的长消息】（既不匹配任何注入抬头、又超过 400 字 ⇒ **不硬塞进任何一栏**，单列给你看）')
    for (const h of R.别的.slice(0, 8)) console.log('  ' + String(h.len).padStart(6) + ' 字  ' + h.head)
  }
  if (R.inj && R.他) {
    console.log('')
    console.log('【信噪比】引擎注入 : 你说的 = ' + (R.inj / Math.max(R.他, 1)).toFixed(1) + ' : 1')
    console.log('          每轮注入 ≈ ' + Math.round(R.inj / R.轮数) + ' 字（分母＝工作区块出现次数 ' + R.轮数 + '）')
  }
  console.log('\n【口径纪律（吃了亏才写下来的）】')
  console.log('  ⚠️ 判据只能用**这个数字**，不许用"某个文件现在短了"（86KB→15KB 而总输入 token 没动，实测过）。')
  console.log('  ⚠️ 日志里 grep 到「可能相关的记忆」不算数 —— 它可能只是某条记忆的正文在引这句话。')
  console.log('  ⚠️ **压缩摘要（checkpoint）单列**：它是系统生成的，旧口径曾把它算成"你说的"⇒ 信噪比被虚高。')
  console.log('  ⚠️ 会话日志是**多帧** zstd：只解一帧会数出 0 **而且不报错**（本工具已改成逐帧）。')
}

function 读基线() {
  try { return JSON.parse(readFileSync(P(基线文件), 'utf8')) } catch { return { unit: '注入基线', version: 1, records: [] } }
}
function 存基线(名, R, 来源, 账) {
  const j = 读基线()
  j.records = j.records || []
  j.records.push({
    名: 名 || ('基线-' + new Date().toISOString().slice(0, 16).replace('T', ' ')),
    at: new Date().toISOString(),
    来源: 来源,
    // ★ 2026-09-27 加：**账要能自证"算的是哪份日志、算在哪一刻"** —— 否则下次读到这个数
    //   没法判"过期没有"（必读卡靠这两格算账龄：只 statSync，不解压、不跑子进程）。
    日志: (账 && 账.日志) || null,
    日志字节: (账 && 账.字节) || null,
    抬头窗: 抬头窗,
    合计: R.inj, 他: R.他, 轮数: R.轮数,
    块: Object.fromEntries(块名.map(([n, k]) => [n, R.K[k + 'Sum']])),
  })
  try { mkdirSync(path.dirname(P(基线文件)), { recursive: true }) } catch {}
  writeFileSync(P(基线文件), JSON.stringify(j, null, 1))
  return j.records[j.records.length - 1]
}
function 比基线(名, R) {
  const j = 读基线()
  const rs = j.records || []
  if (!rs.length) { console.log('还没有基线 ⇒ 先跑 `node 神经/注入计量.mjs 基线 [名]`'); return 2 }
  const b = 名 ? (rs.find(x => x.名 === 名) || rs[rs.length - 1]) : rs[rs.length - 1]
  console.log('【与基线比】基线「' + b.名 + '」' + b.at + '（' + b.来源 + '）')
  console.log('  块名'.padEnd(24) + '基线'.padStart(10) + '现在'.padStart(12) + '变化'.padStart(12) + '  幅度')
  const 行 = (n, a, c) => {
    const d = c - a
    const p = a ? (d / a * 100).toFixed(1) + '%' : '—'
    console.log('  ' + n.padEnd(22) + String(a).padStart(10) + String(c).padStart(12) + String((d > 0 ? '+' : '') + d).padStart(12) + '  ' + p)
  }
  for (const [n, k] of 块名) 行(n, b.块?.[n] ?? 0, R.K[k + 'Sum'])
  行('合计', b.合计, R.inj)
  行('你本人说的', b.他, R.他)
  const d = R.inj - b.合计
  console.log('')
  console.log(d < 0 ? '✅ 注入面**降了** ' + Math.abs(d) + ' 字' : d > 0 ? '⚠️ 注入面**涨了** ' + d + ' 字' : '＝ 没变')
  console.log('  ★ 但**别只看总数**：外部 48 次配对 A/B 实测，同一套 −82% 精简法里')
  console.log('    「总成功率不动、简单任务 50%→25%」——总分正好把这种分化藏起来。')
  console.log('    ⇒ 要分**日常短活 vs 大活**分别看，且必须配回归集（红数不涨）。')
  return 0
}

// ── CLI ────────────────────────────────────────────────────────────────────
const a = process.argv.slice(2)
const 子 = a[0]

if (主 && 子 === 'selftest') {
  // 自证：正样本（真日志数得出块）＋ 反证（坏路径必须报错 / 只解一帧必须报红，不许静默 0）
  const L = 找日志()
  if (L.错) { console.log('⚠️ 自证只跑到一半：' + L.错); console.log('   （在没装引擎的机器上这是正常的；设备上必须能过）'); process.exit(3) }
  const raw = readFileSync(L.文件)
  const { 文本, 路 } = 解压(raw)
  const R = 量(文本.split('\n').filter(l => l.trim().startsWith('{')))
  console.log('✅ 正样本：找到会话 ' + L.会话.slice(0, 20) + '… ／ ' + raw.length + ' B ／ 解压走 ' + 路)
  console.log('   数出：注入合计 ' + R.inj + ' 字，你说的 ' + R.他 + ' 字，' + R.human.length + ' 条')
  // ★ 反证 A（多帧陷阱）：只解一帧 ⇒ 必须报红。这是今天实测抓到的真缺陷，钉在这里防回归。
  const 只一帧 = (() => { try { return require('node:zlib').zstdDecompressSync(raw).toString('utf8') } catch { return '' } })()
  const 单帧行 = 只一帧.split('\n').filter(l => l.trim().startsWith('{')).length
  const 全行 = 文本.split('\n').filter(l => l.trim().startsWith('{')).length
  if (全行 > 1 && 单帧行 < 全行) {
    console.log('✅ 反证通过（多帧陷阱）：单帧解只有 ' + 单帧行 + ' 行，逐帧解有 ' + 全行 + ' 行')
    console.log('   ⇒ 若哪天有人把 解压() 改回 zstdDecompressSync，这行会变成 ' + 单帧行 + ' 行、注入数掉到 0，当场报红')
  } else {
    console.log('   （本会话只有 1 帧或恰好相等，多帧反证这条这次不成立：单帧 ' + 单帧行 + ' vs 全量 ' + 全行 + '）')
  }
  if (R.inj === 0) { console.error('❌ 反证失败：注入口径数出 0 —— 要么日志里没有那几块，要么口径坏了（不许当绿）'); process.exit(1) }
  const bad = 找日志('绝对不存在的会话zzz')
  if (!bad.错) { console.error('❌ 反证失败：点一个不存在的会话竟然找到了东西'); process.exit(1) }
  console.log('✅ 反证通过：点名不存在的会话 ⇒ 明确报错（' + bad.错.slice(0, 30) + '…）')
  console.log('✅ 反证通过：读不到日志时**绝不许印 0** —— 上面那条走的是报错路，不是 0')
  console.log('   ' + 窗签(L))
  // ══ ★ 2026-09-27 口径改动的**夹具级**反证（不靠真日志，靠造出来的三条）══
  //   起因：旧口径用 `re.test(整条)` ＝ **任意位置命中**（contains）⇒ checkpoint 摘要**整段抄了旧上下文**，
  //   它引用的块被算成那一栏 ⇒「压缩摘要 53.3%」与「长期记忆 16.0%」互相污染，账不可信。
  //   新口径：按**抬头出现在第几个字**判（≤ 抬头窗 ＝ 真抬头；超出 ⇒ 单列【引文夹带】）。
  const 造 = (t) => JSON.stringify({ type: 'user/message', data: { content: [{ type: 'text', text: t }] } })
  const R2 = 量([
    造('This is an automatically generated checkpoint condensing an earlier span of the conversation' + '\n' + '===== 长期记忆 =====' + '\n' + 'x'.repeat(400)),
    造('z'.repeat(250) + ' 我刚看到 ===== 长期记忆 ===== 那行'),
  ])
  const R3 = 量([造('===== 长期记忆 =====' + '\n' + 'y'.repeat(500))])
  const 过 = (名, 实, 期) => { const ok = 实 === 期; console.log((ok ? '✅ ' : '❌ ') + 名 + '（实 ' + 实 + ' ／ 期 ' + 期 + '）'); return ok }
  let 全过 = true
  全过 = 过('夹具① 头是 checkpoint、体内夹带长期记忆抬头 ⇒ 只算【压缩摘要】', R2.K.ck, 1) && 全过
  全过 = 过('夹具① 同一份摘要里的长期记忆抬头**不许**算进【长期记忆】', R2.K.lt, 0) && 全过
  全过 = 过('夹具② 抬头出现在第 250 字（超出窗口）⇒ 落【引文夹带】', R2.引文.length, 1) && 全过
  全过 = 过('夹具② 夹带那条**压不进任何一块**', R2.K.lt + R2.K.ck, 1) && 全过
  全过 = 过('夹具③ 抬头就在最前面 ⇒ 正常算进【长期记忆】', R3.K.lt, 1) && 全过
  // 夹具④／⑤：分母（"他本人说的"）不许被机器回音污染
  const R4 = 量([造('background job bash-1 (bash: cd /storage/emulated/0/3 && echo hi)'), 造('审核通过')])
  全过 = 过('夹具④ 后台作业回执 ⇒ 落【子系统回音】、**不算他说的**', R4.回音.length, 1) && 全过
  全过 = 过('夹具④ 回执那条不许进"他本人"', R4.human.length, 1) && 全过
  全过 = 过('夹具⑤ 他真说的短句（审核通过）⇒ 留在"他本人"', R4.human[0] && R4.human[0].head, '审核通过') && 全过
  if (!全过) { console.error('❌ 反证失败：抬头口径（位置锚定 ' + 抬头窗 + ' 字）坏了 —— 账会互相污染，不许当绿'); process.exit(1) }
  // ★ 反证 D（import 即跑）：本文件被 import 时必须**一句都不印**
  //   （原来 CLI 段是裸块：谁 import 谁被印一屏，还可能被里面的 process.exit 截断调用方输出）
  const 自身 = 'file://' + fileURLToPath(import.meta.url)
  let 倒 = ''
  try {
    倒 = execFileSync(process.argv0, ['-e', `import(${JSON.stringify(自身)}).then(function(){console.log('IMPORT-OK')},function(e){console.log('IMPORT-FAIL ' + e.message)})`], { encoding: 'utf8', timeout: 30000 })
  } catch (e) { 倒 = String(e.stdout || '') + String(e.stderr || '') }
  if (倒.includes('IMPORT-OK') && !倒.includes('【引擎替你注入的】')) console.log('✅ 反证通过（import 即跑）：被 import 时一句多余的话都没印')
  else { console.error('❌ 反证失败（import 即跑）：import 它竟然印了东西 ⇒\n' + 倒.slice(0, 400)); process.exit(1) }
  process.exit(0)
}

if (主 && 子 === '基线') {
  // ★ 2026-09-27 加：`基线 <名> [会话]` —— 可点名会话。原来只能测"最新那个"，
  //   而"最新"在多窗并行时会漂到隔壁窗（本窗实测过：账记到了 e84402ff 头上）。
  const L = 找日志(a[2])
  if (L.错) { console.error('❌ ' + L.错 + '\n   ⇒ 退路：<解压好的日志> | node 神经/注入计量.mjs'); process.exit(2) }
  const { 文本 } = 解压(readFileSync(L.文件))
  const R = 量(文本.split('\n').filter(l => l.trim().startsWith('{')))
  const 账 = { 日志: L.文件, 字节: statSync(L.文件).size }
  const rec = 存基线(a[1], R, '会话 ' + L.会话.slice(0, 20), 账)
  console.log('✅ 基线已存：' + rec.名 + ' ／ 合计 ' + rec.合计 + ' 字（块：' + JSON.stringify(rec.块) + '）')
  console.log('   ' + 窗签(L))
  console.log('   落盘：' + P(基线文件) + '（**只增不改**，历史一条不删）')
  process.exit(0)
}

if (主 && 子 === '比') {
  const L = 找日志()
  if (L.错) { console.error('❌ ' + L.错); process.exit(2) }
  const { 文本 } = 解压(readFileSync(L.文件))
  const R = 量(文本.split('\n').filter(l => l.trim().startsWith('{')))
  印(R, '当前会话 ' + L.会话.slice(0, 16), 窗签(L))
  console.log('')
  process.exit(比基线(a[1], R))
}

// 默认（无参 或 `测 [会话]`）：测最新一个 / 点名一个
if (主) {
  const 要 = 子 === '测' ? a[1] : null
  const L = 找日志(要)
  if (L.错) {
    // 退回 v1 行为：stdin
    let 有stdin = false
    try { 有stdin = !process.stdin.isTTY } catch {}
    if (!有stdin) { console.error('❌ ' + L.错 + '\n   ⇒ 退路：<解压好的日志> | node 神经/注入计量.mjs'); process.exit(2) }
    const lines = readFileSync(0, 'utf8').split('\n').filter(l => l.trim().startsWith('{'))
    印(量(lines), 'stdin（老路子）')
    process.exit(0)
  }
  const { 文本, 路: 解路 } = 解压(readFileSync(L.文件))
  const R = 量(文本.split('\n').filter(l => l.trim().startsWith('{')))
  印(R, '会话 ' + L.会话.slice(0, 16) + '（' + L.文件.replace(HOME0, '$DSH_HOME') + '）', 窗签(L))
  console.log('  解压走：' + 解路 + ' ｜ 同工作区还有 ' + (L.全部.length - 1) + ' 个会话可点名：')
  for (const x of L.全部.slice(1, 4)) console.log('    · ' + x.会话.slice(0, 22) + '…  ' + new Date(x.mtime).toISOString().slice(0, 16))
}
