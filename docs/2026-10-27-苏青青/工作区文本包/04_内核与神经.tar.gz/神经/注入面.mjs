#!/usr/bin/env node
// ═══ 注入面 · 「这一轮到底注入了什么」全貌 ═══
//
// 为什么要有它（老板 2026-09-26 令）：
//   我们的系统提示词是**十个来源拼起来的**，而**没有任何一处能看到全貌**。
//   业界是"一份 Prompt.txt，一处可读"；我们是十处各写各的 ⇒ **逻辑冲突没有地方看得见**。
//   外部同构（Klatch `GET /api/channels/:id/prompt-debug`）给的形状是**三态 ＋ 拼好的全文**：
//     `{ layers: { kitBriefing:"ACTIVE", projectMemory:"INACTIVE", channelAddendum:"EMPTY" }, assembledPrompt:"…" }`
//   ★ 我们缺的正是那个**三态**：现在连"这一层在不在"都看不见，更看不见"**该在但不在**"。
//
// 用法：
//   node 神经/注入面.mjs            # 三层视图（全貌）
//   node 神经/注入面.mjs selftest   # 自证：三态真的判得出来吗（造空/造缺）
//
// 纪律：**只读**。它不往提示词里写任何东西，也不改任何来源文件。
import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const WS = process.env.DSH_KICKOFF_WS || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const P = (...a) => path.join(WS, ...a)
const DH = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const D = (...a) => path.join(DH, ...a)

const 读 = (p) => { try { return readFileSync(p, 'utf8') } catch { return null } }
const 字节 = (p) => { try { return statSync(p).size } catch { return null } }
const 目录内 = (p) => { try { return readdirSync(p) } catch { return null } }

/** 三态：ACTIVE（在场且有量）／EMPTY（在位但是空的）／INACTIVE（该在但不在）
 *  ★ 2026-09-26 补第四态「读不到」：**"文件不在"和"文件在但我没权限读"不是一回事**。
 *    实测场景：`run-as` 读不了 `/storage`（缺 MANAGE_EXTERNAL_STORAGE）⇒ 工作区那几条
 *    曾被误报成 INACTIVE（假红）。判法：**父目录能不能列** —— 能列而文件不在 ⇒ 真 INACTIVE；
 *    连父目录都列不了 ⇒ 读不到（**不许当成"不在"**）。 */
const 能读 = (p) => { try { readFileSync(p); return true } catch (e) { return e && e.code !== 'EACCES' && e.code !== 'EPERM' } }
const 能列 = (p) => { try { readdirSync(p); return true } catch { return false } }
const 态 = (p) => {
  const dir = path.dirname(p)
  if (!能列(dir)) return '读不到'
  if (!existsSync(p)) return 'INACTIVE'
  if (!能读(p)) return '读不到'
  const b = 字节(p)
  if (b === null) return '读不到'
  return b === 0 ? 'EMPTY' : 'ACTIVE'
}
const 标 = (s) => s === 'ACTIVE' ? '🟢 ACTIVE  ' : s === 'EMPTY' ? '⚪ EMPTY   ' : s === '读不到' ? '🚫 读不到  ' : '🔴 INACTIVE'

const 行 = []
const 加 = (层, 名, 状态, 量, 取法) => 行.push({ 层, 名, 状态, 量, 取法 })

// ══ 第一层：注入面十来源（逐条核真文件）══
// ① 引擎默认 persona（前缀/后缀）—— 引擎内置，我们看不到文件；真值只能从 dump-config 取
加('L0 装配壳', '① 引擎默认 persona 前缀/后缀', 'ACTIVE', '内置（见 dump-config）', '`dsh --profile web --dump-config`')
// ② 全局 AGENTS.md
{
  const p = D('AGENTS.md')
  加('L2 身份', '② $DSH_HOME/AGENTS.md', 态(p), 字节(p) + ' B', '读文件')
}
// ③ 生产 persona.prefix（1020 修：原来读 .agent-presets 死件 ⇒ 引擎 0.2.0-rc.2 起只认装配行，
//    真正注入的是 profiles/web/cordis.patch.yml 里内联那份；再从 yml 里切出来量，不能只报文件大小）
{
  const p = D('profiles/web/cordis.patch.yml')
  const 文 = 读(p)
  let 量 = '（读不到）', 状 = 态(p)
  if (文) {
    const m = 文.split('\n')
    const i = m.findIndex((x) => /^\s*prefix:\s*\|-/.test(x))
    if (i >= 0) {
      const 缩 = (m[i].match(/^\s*/) || [''])[0].length   // prefix 行自己的缩进
      let j = i + 1
      while (j < m.length) {
        const 行文 = m[j]
        if (行文.trim() === '') { j++; continue }          // 空行算段内
        if ((行文.match(/^\s*/) || [''])[0].length <= 缩) break  // 缩进回到同级或更小 ⇒ 段结束
        j++
      }
      const 段 = m.slice(i + 1, j).join('\n')
      量 = Buffer.byteLength(段, 'utf8') + ' B / ' + (j - i - 1) + ' 行'
      状 = 段.trim() ? 'ACTIVE' : 'EMPTY'
    } else { 量 = '⚠️ 没找到 prefix: |- 段（格式变了？）'; 状 = 'INACTIVE' }
  }
  加('L2 身份', '③ 生产 persona.prefix', 状, 量, '`读 ' + p.replace(DH, '$DSH_HOME') + '`')
}
// ④ 工作区 AGENTS.md
{
  const p = P('AGENTS.md')
  加('L5 工作区', '④ 工作区 AGENTS.md', 态(p), 字节(p) + ' B', '读文件')
}
// ⑤ dsh-agent-instructions 的 maxBytes（上限＝它决定"截不截"）
{
  const p = D('profiles/web/cordis.patch.yml')
  const m = (读(p) || '').match(/maxBytes:\s*(\d+)/)
  加('L0 装配壳', '⑤ agent-instructions maxBytes', m ? 'ACTIVE' : 'INACTIVE', m ? m[1] + ' B（截断线）' : '读不到', '读预设 yml')
}
// ⑥ 第三方插件段（每插件可能自带 prompt 段；这里只报"装了几件"）
{
  const p = D('profiles/web/node_modules/@dsh-user')
  const ls = 目录内(p)
  加('L6 插件段', '⑥ @dsh-user 插件', ls && ls.length ? 'ACTIVE' : (ls ? 'EMPTY' : 'INACTIVE'), ls ? ls.length + ' 件' : '读不到', 'ls 目录')
}
// ⑦ 长期记忆整块（走 memory.db，由插件注入）
{
  const p = P('.dsh-meow/memory.db')
  const b = 字节(p)
  加('L7 记忆', '⑦ 长期记忆整块', 态(p), b ? b + ' B（库）' : '读不到', '`注入计量.mjs` 量它真注入了多少')
}
// ⑧ 工具定义（97 个）—— 真值只能从 dump-config/运行时取
加('L7 工具', '⑧ 工具定义', 'ACTIVE', '约 6.9 万字符/轮（蓝图实测）', '`dsh --profile web --dump-config`')
// ⑨ rules 82 条（老板 0923 亲拍"直接注入"）
加('L4 规矩', '⑨ rules 82 条', 'ACTIVE', '按库计（见注入计量）', '`注入计量.mjs` 单独报它占百分之几')
// ⑩ 运行时上下文
加('L1 环境锚', '⑩ 运行时上下文', 'ACTIVE', '约 433 字（平板实测）', '`注入计量.mjs`')

// ══ 第二层：技能两处（重叠要看得见）══
const 技1 = 目录内(D('skills'))
const 技2 = 目录内(D('.agent-presets/suqingqing/skills'))
let 重叠 = []
if (技1 && 技2) 重叠 = 技1.filter((x) => 技2.includes(x))
// ★ 1013 迭代 3.0：**重叠的代价要现算**（不写死读数）—— 同名技能的 `description` 会进「技能目录」、
//   **每步重发**；两处长度若不一样，"用哪一份"就是一笔每步的钱。实测（1013）：两份**正文逐字节一样**，
//   **只差 `description` 那一行**；引擎给我的是**预设那份**（拿本窗技能目录的 description 与两处逐字比对出来的）。
const 描 = (p) => {
  try { return (readFileSync(p, 'utf8').split('\n').find((l) => l.startsWith('description:')) || '').replace(/^description:\s*/, '').trim() } catch { return '' }
}
const 描差 = (() => {
  const 明细 = []; let 总 = 0
  for (const n of 重叠) {
    const a = 描(D('skills') + '/' + n + '/SKILL.md').length
    const b = 描(D('.agent-presets/suqingqing/skills') + '/' + n + '/SKILL.md').length
    if (a || b) { 明细.push(n + ' 长 ' + a + ' ／ 短 ' + b + '（差 ' + (a - b) + '）'); 总 += Math.max(0, a - b) }
  }
  return { 明细, 总 }
})()

// ══ 第三层：抽屉（不进拼接，只留指针）══
const 抽屉 = [
  ['全局要则全文', P('内核/全局要则.md')],
  ['工作区要则全文', P('记忆/工作区要则_全.md')],
  ['内核正文', P('内核/内核.md')],
  ['内核详解', P('内核/内核详解/详解.md')],
  ['做法库', P('台账/做法库.md')],
  ['在办', P('台账/在办.md')],
]

if (process.argv.includes('selftest')) {
  // 自证：三态**真判得出来**吗 —— 造一个不存在的 ⇒ 必须 INACTIVE；造一个空的 ⇒ 必须 EMPTY
  const fs = await import('node:fs')
  const T = path.join(process.env.TMPDIR || '/tmp', '注入面自证')
  let ok = 0, all = 0
  try { fs.mkdirSync(T, { recursive: true }) } catch {}
  const 试 = (名, 造, 期望) => {
    all++
    const p = path.join(T, 名)
    try { fs.rmSync(p, { force: true }) } catch {}
    if (造 === '空') fs.writeFileSync(p, '')
    if (造 === '有') fs.writeFileSync(p, 'x')
    const got = 态(p)
    const pass = got === 期望
    console.log((pass ? '✅' : '❌') + ' ' + 名 + '：期望 ' + 期望 + '，实得 ' + got)
    if (pass) ok++
  }
  试('不存在.md', '无', 'INACTIVE')
  试('空的.md', '空', 'EMPTY')
  试('有料.md', '有', 'ACTIVE')
  // ★ 第四态「读不到」的反证：现实中已经撞到过（`run-as` 读 /storage ⇒ 工作区那几条曾被误报 INACTIVE），
  //   但"造一个权限不足的路径"在本机各处行为不一致（root 会绕过）⇒ **不硬造**。
  //   改为**钉住判据本身**：不许把"读不到"当成"不在"（源码里 态() 的三个 return 点）。
  const 源 = readFileSync(fileURLToPath(import.meta.url), 'utf8')
  const 有读不到分支 = /return '读不到'/.test(源) && /能列\(dir\)/.test(源)
  all++
  console.log((有读不到分支 ? '✅' : '❌') + ' 第四态判据在源码里：读不到 ≠ 不在（能列父目录才算 INACTIVE）')
  if (有读不到分支) ok++
  console.log('自证 ' + ok + '/' + all)
  process.exit(ok === all ? 0 : 1)
}

// ── 印全貌 ────────────────────────────────────────────────────────────────
console.log('════ 注入面 · 这一轮到底注入了什么（全貌）════')
console.log('工作区 ' + WS)
console.log('$DSH_HOME ' + DH)
console.log('')
console.log('── 第一层：十个来源 ──')
const 层序 = ['L0 装配壳', 'L1 环境锚', 'L2 身份', 'L4 规矩', 'L5 工作区', 'L6 插件段', 'L7 记忆', 'L7 工具']
let 缺 = 0
for (const L of 层序) {
  const rs = 行.filter((r) => r.层 === L)
  if (!rs.length) continue
  console.log('  【' + L + '】')
  for (const r of rs) {
    if (r.状态 === 'INACTIVE') 缺++
    console.log('    ' + 标(r.状态) + ' ' + r.名.padEnd(30, '　') + ' ' + String(r.量) + '  ｜ ' + r.取法)
  }
}
console.log('')
console.log('── 第二层：技能两处（**重叠要看得见**）──')
console.log('  $DSH_HOME/skills            ：' + (技1 ? 技1.length + ' 个（' + 技1.join('、') + '）' : '🔴 INACTIVE'))
console.log('  预设 suqingqing/skills      ：' + (技2 ? 技2.length + ' 个（' + 技2.join('、') + '）' : '🔴 INACTIVE'))
console.log('  ' + (重叠.length ? '⚠️ **同名重叠 ' + 重叠.length + ' 个**：' + 重叠.join('、') + ' ⇒ 同一份技能存两处，改一处不改另一处就会分叉'
  + '\n     ★ **1013 实测：引擎给我的是「预设那份」** —— 判据＝拿本窗技能目录里的 `description` 与两处逐字比：'
  + '三条全与 `.agent-presets/suqingqing/skills/` 一致、与 `$DSH_HOME/skills/` **不一致**'
  + '（后者 10-05 改过、是「长 description」版）⇒ **改 `$DSH_HOME/skills/` 那份是白改**（我 10-05 就白改过一次）。'
  + '**要改同名技能 ⇒ 改预设那份**。'
  + (描差.总 > 0 ? '\n     ★ **代价现算**：改用「$DSH_HOME/skills 那一版」（长 description）⇒ **每步多 ' + 描差.总 + ' 字符**；逐份：' + 描差.明细.join(' ｜ ') : '')
  : '✅ 两处没有同名'))
console.log('')
console.log('── 第三层：抽屉（**不进拼接**，只留指针）──')
for (const [名, p] of 抽屉) console.log('  ' + 标(态(p)) + ' ' + 名.padEnd(18, '　') + ' ' + (字节(p) ?? '—') + ' B  ｜ ' + p.replace(WS + path.sep, ''))
console.log('')
console.log('── 判据 ──')
console.log('  · **INACTIVE 共 ' + 缺 + ' 条**（该在但不在 ⇒ 这是"全貌"真正要看的东西，不是文件大小）')
console.log('  · 🚫 **读不到 ≠ 不在**：权限不足时印"读不到"（例：`run-as` 读不了 `/storage`）—— 不许当成"文件没了"')
console.log('  · 每块**真注入了多少字** ⇒ 跑 `node 神经/注入计量.mjs`（它从会话日志读地面真相）')
console.log('  · ⚠️ **本屏只报"在不在"**；"注入了多少"必须以 注入计量 的数字为准，不许拿文件大小当注入量')
console.log('  · ⚠️ 三态里的 EMPTY 与 INACTIVE **不是一回事**：EMPTY＝在位但空（可能是故意的），INACTIVE＝该在却不在（一定是问题）')
