#!/usr/bin/env node
// 活份账 · 「每步到底有多少份、多少字活着」的仪器（2026-09-27 立）
// ════════════════════════════════════════════════════════════════════════════
// 【为什么要有它】老板 09-27 问：「系统提示词是重复注入叠加的……不可能省这么少」
//   注入计量.mjs 数的是**累计写入次数/字数**（480 万字）——那是"写了一路"的量，
//   **不是"同时活着几份"**。要回答"能不能省、能省多少"，必须量**活着的份数**。
//
// 【怎么量（判据，全部来自日志本身，不靠推断）】
//   ① 会话日志里每条 `compaction/summary` 带 `data.shadowedSeqs` = **它吃掉的 seq 名单**
//      （被吃的消息从上下文里撤掉，换成这一份摘要）。⇒ 每个 seq 都有"死亡时刻"：
//      死亡时刻(seq) = 最早一条 shadowedSeqs 里含它的 summary 的 seq；没有 ⇒ 永生。
//   ② 于是任一时刻 S 活着的 = `seq < S 且 死亡时刻 > S` 的那些消息。
//   ③ 按"消息头像"分桶（checkpoint / AGENTS.md 两本 / 技能目录 / 运行时上下文 / …），
//      算每个桶：写入次数、平均存活份数、单份字数、**常驻字/步**（＝均活份数 × 单份均字）。
//   ④ 工具定义不在消息通道，在 `request/header.data.header.tools`（每步都发）——
//      单独一节：声明件数／schema 字节／本窗实际调用次数 ⇒ 一眼看出多少是白发的。
//
// 【单位陷阱（实测踩过）】本文件里的"字"= JS 字符串长度（≈ 汉字个数）；
//   而引擎注释/报表里那些 "47,976 字符" 是**UTF-8 字节**（汉字 1 字 = 3 字节）。
//   两个数不能直接相加、相减 —— 对照锚：固定开销 18,176 token = 工具 47,976B + 系统提示 15,508B + AGENTS.md 25KB。
//
// 【用法】
//   node 神经/活份账.mjs              # 最新一个会话
//   node 神经/活份账.mjs 0b98df7d     # 指定会话（后缀片段）
// 判据（自检，会打印）：合计字数 > 0；checkpoint 均活份数 < 2（≥2 ⇒ 真叠加了，报红）。
// ════════════════════════════════════════════════════════════════════════════
import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'

const MAGIC = Buffer.from([0x28, 0xb5, 0x2f, 0xfd])   // zstd 帧魔数
const HOME = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'

/** 逐帧解开多帧 zstd（`zstdDecompressSync` 只解第一帧、静默丢其余 —— 实测坑） */
function 解多帧(buf) {
  const pos = []; let i = 0
  while (i <= buf.length - 4) { const j = buf.indexOf(MAGIC, i); if (j < 0) break; pos.push(j); i = j + 1 }
  const 片段 = []; let 帧 = 0, 跳 = 0
  for (let n = 0; n < pos.length; n++) {
    const s = pos[n], e = n + 1 < pos.length ? pos[n + 1] : buf.length
    try { 片段.push(zlib.zstdDecompressSync(buf.subarray(s, e))); 帧++ } catch { 跳++ }
  }
  return { 文本: Buffer.concat(片段).toString('utf8'), 帧, 跳 }
}

function 找日志(want) {
  const root = path.join(HOME, 'sessions')
  let best = null
  for (const ws of fs.readdirSync(root)) {
    const d = path.join(root, ws); if (!fs.statSync(d).isDirectory()) continue
    for (const s of fs.readdirSync(d)) {
      if (want && !s.includes(want)) continue
      const dir = path.join(d, s); let st
      try { st = fs.statSync(dir) } catch { continue }
      if (!st.isDirectory()) continue
      for (const fn of fs.readdirSync(dir)) {
        if (!fn.endsWith('.jsonl.zstd')) continue
        const f = path.join(dir, fn); const m = fs.statSync(f).mtimeMs
        if (!best || m > best.m) best = { f, m, s }
      }
    }
  }
  return best
}

const 文 = (e) => {
  const d = e.data || {}; const c = (d.message || {}).content ?? d.content ?? d.text ?? ''
  if (typeof c === 'string') return c
  if (Array.isArray(c)) return c.map(x => x.text || x.content || '').join('')
  return ''
}

const 桶名 = (t) => {
  const h = t.slice(0, 220)
  if (/^This is an automatically generated checkpoint/.test(t)) return '①压缩摘要 checkpoint'
  if (/workspace instructions may be relevant/i.test(h)) return '②AGENTS.md 两本（全局＋工作区）'
  if (/available skill catalog/i.test(h)) return '③技能目录'
  if (/^Current runtime context/i.test(h)) return '④运行时上下文（每轮必读行等）'
  if (/^<goal_round>/.test(t)) return '⑤goal_round 目标轮'
  if (/^<system-reminder>/.test(h)) return '⑥其它 system-reminder'
  if (/^<task-notification>|^<subagent/.test(h)) return '⑦子代理/通知'
  return '⑨其余（我自己的话、工具结果、台账注入…）'
}

const want = process.argv[2]
const L = 找日志(want)
if (!L) { console.log('✗ 没找到会话日志（$DSH_HOME/sessions/**/session*.jsonl.zstd）'); process.exit(1) }
const raw = fs.readFileSync(L.f)
const { 文本, 帧, 跳 } = 解多帧(raw)
console.log('══ 活份账 · 会话 ' + L.s + ' ══')
console.log('日志 ' + (raw.length / 1048576).toFixed(2) + ' MB ｜ zstd 帧 ' + 帧 + '（跳 ' + 跳 + '）｜ 解出 ' + 文本.length + ' 字符')

const ev = []
for (const ln of 文本.split('\n')) { if (!ln.trim()) continue; try { ev.push(JSON.parse(ln)) } catch { } }

// 死亡时刻表
const 死时 = new Map()
for (const e of ev) {
  if (e.type !== 'compaction/summary') continue
  for (const s of (e.data?.shadowedSeqs || [])) {
    const p = 死时.get(s); if (p === undefined || e.seq < p) 死时.set(s, e.seq)
  }
}
const 被吃 = 死时.size

// 分桶统计
const 统计 = new Map()
for (const e of ev) {
  if (e.type !== 'user/message' && e.type !== 'assistant/message' && e.type !== 'tool/result') continue
  const t = 文(e); if (!t) continue
  const n = 桶名(t)
  const r = 统计.get(n) || { 写入: 0, 字: 0, 件: [] }
  r.写入++; r.字 += t.length
  r.件.push({ seq: e.seq, 字: t.length, 死: 死时.get(e.seq) ?? Infinity })
  统计.set(n, r)
}
const 步seq = ev.filter(e => e.type === 'step/start').map(e => e.seq)
const 采样 = []; for (let i = 0; i < 步seq.length; i += 10) 采样.push(步seq[i])

console.log('\n── 一、每块：写入次数 ｜ 平均存活份数 ｜ 常驻字数/步（采样 ' + 采样.length + ' 步）──')
const 排 = []; let 总 = 0
for (const [n, r] of 统计) {
  let 和 = 0
  for (const S of 采样) { let a = 0; for (const x of r.件) if (x.seq < S && x.死 > S) a++; 和 += a }
  const 均活 = 和 / 采样.length, 均字 = r.字 / r.写入, 常驻 = 均活 * 均字
  排.push([n, r.写入, 均活, 均字, 常驻]); 总 += 常驻
}
排.sort((a, b) => b[4] - a[4])
for (const [n, 写入, 均活, 均字, 常驻] of 排)
  console.log(' ' + n.padEnd(32) + ' 写入' + String(写入).padStart(5) + ' ｜ 均活 ' + 均活.toFixed(2).padStart(6) +
    ' 份 ｜ 单份均 ' + String(Math.round(均字)).padStart(6) + ' 字 ｜ 常驻 ' + String(Math.round(常驻)).padStart(7) + ' 字/步')
console.log(' 消息通道常驻合计 ≈ ' + Math.round(总) + ' 字/步 ｜ 压缩吃掉 ' + 被吃 + ' 个 seq（事件总数 ' + ev.length + '）')

console.log('\n── 二、此刻活着的清单 ──')
const 活 = new Map()
for (const [n, r] of 统计) for (const x of r.件) if (x.死 === Infinity) {
  const c = 活.get(n) || { n: 0, 字: 0 }; c.n++; c.字 += x.字; 活.set(n, c)
}
let 活合 = 0
for (const [n, v] of [...活.entries()].sort((a, b) => b[1].字 - a[1].字)) {
  console.log(' ' + n.padEnd(32) + String(v.n).padStart(4) + ' 件  ' + String(v.字).padStart(7) + ' 字'); 活合 += v.字
}
console.log(' 活着合计 ' + 活合 + ' 字')

console.log('\n── 三、工具定义（不在消息通道，每步都发）──')
const rh = ev.filter(e => e.type === 'request/header')
if (!rh.length) console.log(' （日志里没有 request/header，跳过）')
else {
  const tools = rh[rh.length - 1].data.header.tools || []
  const 调 = new Map()
  for (const e of ev) if (e.type === 'tool/call') { const n = e.data?.name || '?'; 调.set(n, (调.get(n) || 0) + 1) }
  const 行 = tools.map(t => { const n = t.name || (t.function || {}).name || '?'; return [n, Buffer.byteLength(JSON.stringify(t)), 调.get(n) || 0] })
  const 总B = 行.reduce((a, b) => a + b[1], 0)
  const 未用 = 行.filter(x => x[2] === 0), 用过 = 行.filter(x => x[2] > 0)
  console.log(' 声明 ' + 行.length + ' 件 ｜ schema 合计 ' + 总B + ' 字节/步（＝每步都发）')
  console.log(' 用过 ' + 用过.length + ' 件 ' + 用过.reduce((a, b) => a + b[1], 0) + ' 字节 ｜ **一次没调用 ' + 未用.length + ' 件 ' +
    未用.reduce((a, b) => a + b[1], 0) + ' 字节**')
  console.log(' 未调用件（按体积排）：' + 未用.sort((a, b) => b[1] - a[1]).map(x => x[0] + ' ' + x[1] + 'B').join(' ｜ '))
}

// 自检
console.log('\n── 自检 ──')
const ck = 排.find(x => x[0].startsWith('①'))
let rc = 0
console.log((总 > 0 ? '✅' : '🔴') + ' 常驻合计 > 0（' + Math.round(总) + ' 字/步）'); if (!(总 > 0)) rc = 1
console.log((ck && ck[2] < 2 ? '✅' : '🔴') + ' checkpoint 均活份数 < 2（' + (ck ? ck[2].toFixed(2) : '?') + '）—— ≥2 才叫"叠加"')
if (!(ck && ck[2] < 2)) rc = 1
process.exit(rc)
