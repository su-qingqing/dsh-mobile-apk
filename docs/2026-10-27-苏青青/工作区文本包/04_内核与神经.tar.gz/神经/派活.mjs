#!/usr/bin/env node
// 派活 · 生成一张「把相关坑贴进去」的派活单（门 · 坑 0mu7k5dcx）
// 为什么有它：子代理／外部模型是 fresh 上下文，**不继承我每轮收到的记忆检索块** —— 坑不会自己到达它那里。
//            ⇒ 派活＝口头交接：把相关坑**原文**贴进提示词，否则等于没查过。
// 用法：node 神经/派活.mjs <主题> [--词 词1,词2] [--给 千问|子代理] [--无坑 <理由>] [--印]
import fs from 'node:fs'
import path from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import { spawnSync } from 'node:child_process'
const 工作区 = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const 库 = path.join(工作区, '.dsh-meow', 'memory.db')
const a = process.argv.slice(2)
function 自检() {
  // 每次自检跑在**自己的子夹**里：否则上一跑留下的派活单会被这一跑当成自己的产物读（2026-09-23 实测：第二次跑就掉 ①）
  const 临时 = path.join(process.env.DSH_HOME || '/tmp', 'tmp', '派活自检', 'run-' + process.pid)
  fs.mkdirSync(临时, { recursive: true })
  const 跑 = (...a) => spawnSync('node', [process.argv[1], ...a], { encoding: 'utf8', env: { ...process.env, 派活夹: 临时 } })
  let r = 0
  const c1 = 跑('派活门自检', '--词', '派活,子代理,坑', '--给', '千问')
  const 本跑 = fs.readdirSync(临时).filter((f) => f.endsWith('.md'))
  const 有 = 本跑.length === 1
  const 文 = 有 ? fs.readFileSync(path.join(临时, 本跑[0]), 'utf8') : ''
  const ok1 = c1.status === 0 && 有 && /相关的坑（原文/.test(文) && /禁止调用任何工具，直接凭材料推理/.test(文) && /要具体反例/.test(文)
  r += ok1 ? 1 : 0
  console.log('  ① 有相关坑 ⇒ 出提示词，且坑原文＋禁工具＋要反例都在：' + (ok1 ? '✅' : '❌') + (有 ? '' : '（本跑产出 ' + 本跑.length + ' 个 .md，要求正好 1 个）'))
  const c2 = 跑('zzz绝不存在这个词zzz', '--词', 'zzz绝不存在这个词zzz')
  const ok2 = c2.status === 1 && /一条相关坑都没捞到/.test(c2.stderr || '')
  r += ok2 ? 1 : 0
  console.log('  ② 捞不到坑且没写理由 ⇒ 拒派（exit=' + c2.status + '）：' + (ok2 ? '✅' : '❌'))
  const c3 = 跑('zzz绝不存在这个词zzz', '--词', 'zzz绝不存在这个词zzz', '--无坑', '自检用例')
  const ok3 = c3.status === 0
  r += ok3 ? 1 : 0
  console.log('  ③ 显式声明无坑 ⇒ 放行（exit=' + c3.status + '）：' + (ok3 ? '✅' : '❌'))
  // ★★ 1013（小件清零）改写 —— 原文：`console.log(r === 3 ? '✅ 自检 3/3 过' : …)` ＋ `process.exit(r === 3 ? 0 : 1)`
  //   病：**分母写死**。将来加第 4 条断言 ⇒ r 到 4、判据还是 r === 3 ⇒ **永远红**；
  //   反过来的病更坏：有人把 3 校准成**通过数** ⇒ **失败的断言被藏住、一直报绿**
  //   （同形状的实证事故：`神经/重启批次.mjs` 原来是 `const N = 19`，被校准成通过数 ⇒ 一条失败被藏住）。
  //   治法＝照抄已修好的那两件（`重启批次.mjs` 的 `C.总数` ／ `检索门.mjs:104-106`）：**现算总数 ＋ 只许增的底线**。
  //   ⚠️ 计数用的正则**不许把那条加分语句原样写进注释** —— 注释会被自己的正则数进去
  //     （老坑：**判据要打在产物上，不许打在源码上 —— 注释会违反它自己的判据**）。
  const 总数 = (fs.readFileSync(decodeURIComponent(new URL(import.meta.url).pathname), 'utf8')
    .match(/r \+= ok\d+ \? 1 : 0/g) || []).length
  const 底线 = 3   // ★ 只许往上调，不许往下调（防有人悄悄删样本）
  const 全过 = r === 总数 && 总数 >= 底线
  console.log(全过 ? '✅ 自检 ' + r + '/' + 总数 + ' 过（底线 ' + 底线 + '）'
                   : '❌ 自检只过 ' + r + '/' + 总数 + '（底线 ' + 底线 + '；总数现算自源码）')
  process.exit(全过 ? 0 : 1)
}
const 动词 = process.argv[2]
if (动词 === '自检') 自检()

const 主题 = a.find((x) => !x.startsWith('--')) || ''
const 取 = (名) => { const i = a.indexOf(名); return i >= 0 ? a[i + 1] : '' }
const 词 = 取('--词') ? 取('--词').split(/[,，]/).filter(Boolean) : []
const 给 = 取('--给') || '子代理'
const 无坑 = a.includes('--无坑') ? (取('--无坑') || '（没写理由）') : ''
const 印 = a.includes('--印')
if (!主题) { console.log('用法：node 神经/派活.mjs <主题> [--词 词1,词2] [--给 千问|子代理] [--无坑 <理由>] [--印]'); process.exit(2) }
const 词表 = [主题, ...词]
function 捞坑() {
  if (!fs.existsSync(库)) { console.error('❌ 记忆库不在：' + 库); process.exit(1) }
  const db = new DatabaseSync(库, { readOnly: true })
  const out = []
  for (const 表 of ['lesson', 'topic', 'rules', 'fact']) {
    let rows = []
    try { rows = db.prepare('select id,title,content,keywords,hit_count,project from ' + 表 + " where status='active'").all() } catch (e) { continue }
    for (const r of rows) {
      let 分 = 0, 命中 = 0
      for (const w of 词表) {
        if (!w) continue
        const inTitle = (r.title || '').includes(w) || (r.keywords || '').includes(w)
        const inBody = (r.content || '').includes(w)
        if (inTitle) { 分 += 3; 命中++ } else if (inBody) { 分 += 1; 命中++ }
      }
      if (命中 === 0) continue
      分 += Math.min((r.hit_count || 0) / 100, 2)
      out.push({ 表, id: String(r.id).slice(0, 8), title: r.title || '', content: r.content || '', 分, 命中 })
    }
  }
  out.sort((x, y) => y.分 - x.分 || y.命中 - x.命中)
  const 见 = new Set(), 去重 = []
  for (const o of out) { if (见.has(o.id)) continue; 见.add(o.id); 去重.push(o) }
  return 去重.slice(0, 6)
}
const 坑s = 捞坑()
if (坑s.length === 0 && !无坑) {
  console.error('❌ 按这些词一条相关坑都没捞到：' + 词表.join(' / '))
  console.error('   ⇒ 两条路（不许静默裸派）：① 换词 --词 词1,词2  ② 你确认这次真没有相关坑 ⇒ 加 --无坑 <理由>')
  process.exit(1)
}
const 坑块 = 坑s.length
  ? 坑s.map((k, i) => (i + 1) + '. [' + k.表 + ' ' + k.id + '] ' + k.title + '\n   ' + k.content.replace(/\n/g, '\n   ').slice(0, 400)).join('\n')
  : '（本次显式声明无相关坑 —— 理由：' + 无坑 + '）'
const 提示词 = [
  '# 派活 · ' + 主题,
  '（生成 ' + new Date().toLocaleString('zh-CN') + ' ｜ 收活方：' + 给 + ' ｜ 附带相关坑 ' + 坑s.length + ' 条）',
  '',
  '## 你要干什么',
  '（派活方在这里写清任务与产出形态）',
  '',
  '## 铁律（派活方替你带上，逐条照做）',
  '1. ' + (给 === '千问' ? '**禁止调用任何工具，直接凭材料推理。**' : '**你可以调用工具，但下面每一条都算判据。**'),
  '2. **要具体反例**：每条结论后面给一个"什么情况下它不成立／会出错"的反例；没有反例的结论判为无效。',
  '3. **材料全贴**：下面那些坑是我这边的**实测**，以它为准；要推翻必须给反例，不许凭常识推翻。',
  '4. **区分实测与推测**：推测必须标出来。',
  '5. 中文输出；结论要能被我直接搬进工作区（一句话结论 ＋ 证据）。',
  '',
  '## 相关的坑（原文 · 必须逐条考虑，别重复踩）',
  坑块,
  '',
].join('\n')
const 夹 = process.env.派活夹 || path.join(工作区, '台账/接续/派活')
fs.mkdirSync(夹, { recursive: true })
const d = new Date()
const 戳 = String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0') + '-' + String(d.getHours()).padStart(2, '0') + String(d.getMinutes()).padStart(2, '0')
const 名 = 戳 + '-' + 主题.replace(/[\/\\:*?"<>|\s]+/g, '_').slice(0, 40) + '.md'
const f = path.join(夹, 名)
fs.writeFileSync(f, 提示词)
console.log('✅ 派活单写好了：台账/接续/派活/' + 名)
console.log('   收活方 ' + 给 + ' ｜ 附带相关坑 ' + 坑s.length + ' 条：' + (坑s.map((k) => k.id).join(' ') || '无'))
if (印) { console.log('\n' + 提示词) }
