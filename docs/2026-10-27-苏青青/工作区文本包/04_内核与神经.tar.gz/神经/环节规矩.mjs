#!/usr/bin/env node
// 环节规矩 · 老板 09-23 令：「不能只落在最后的一个交接环节，还有拿取材料的环节，还有等等其他的一些」
// 用处：干活的每个环节，先把「这个环节该守的规矩」抽出来摆在手边 —— 规矩不是只在开窗时被动注入一次。
// 用法：node 神经/环节规矩.mjs 拿材料      ／  node 神经/环节规矩.mjs 全
import fs from 'node:fs'
import { DatabaseSync } from 'node:sqlite'
const 库 = '/storage/emulated/0/3/.dsh-meow/memory.db'
const 环节表 = {
  '接手': { 词: ['开工', '接手', '窗口', '注入', '动作集', '第一件事', '身份'], 话: '开窗第一眼：先核动作集在不在、再看上一窗留了什么' },
  '拿材料': { 词: ['检索', '找', '记忆', '材料', '命中', '关键词', '消化', '索引'], 话: '去库里翻东西之前：0 命中 ≠ 没有（检索是两字碎片匹配），先换词、再证明覆盖' },
  '干活': { 词: ['开工卡', '备份', '写', '实现', '闸门', '红线', '危险'], 话: '动手写之前：先出开工卡、先备份、高危路径停手问' },
  '留档': { 词: ['记忆', '提纯', '做法库', '台账', '记账', '留痕'], 话: '干完立刻留：记忆提纯成一句结论、做法库追加、台账写行' },
  '交付': { 词: ['交付', '证据', '封印', '收手', '回归', '验收', '断言'], 话: '交出去之前：证据挂上、回归跑过、状态写待审（完成只能老板勾）' },
  '交接': { 词: ['交接', '打烊', '轮末', '接续', '重启', '崩', '交班'], 话: '收工时：把「还欠什么、怎么退、崩了怎么办」写进交接单' },
}
const 词表 = process.argv[2]
const db = new DatabaseSync(库, { readOnly: true })
const 规矩 = db.prepare("select id,title,content from rules where status='active'").all()
function 抽(环节) {
  const { 词, 话 } = 环节表[环节]
  const 排 = []
  for (const r of 规矩) {
    const 文 = String(r.title || '') + ' ' + String(r.content || '')
    let s = 0
    for (let i = 0; i < 词.length; i++) if (文.includes(词[i])) s += 词.length - i
    if (s > 0) 排.push({ ...r, s })
  }
  排.sort((a, b) => b.s - a.s)
  return { 话, 排: 排.slice(0, 6), 命中数: 排.length }
}
const 要跑 = 词表 === '全' || !词表 ? Object.keys(环节表) : [词表]
for (const 环 of 要跑) {
  if (!环节表[环]) { console.log('⚠️ 没有这个环节：' + 环 + '（可选：' + Object.keys(环节表).join(' / ') + ' / 全）'); process.exit(2) }
  const { 话, 排, 命中数 } = 抽(环)
  console.log('\n【' + 环 + '】' + 话)
  console.log('  关键词：' + 环节表[环].词.join('、') + '　⇒　82 条规矩里命中 ' + 命中数 + ' 条，摆前 ' + 排.length + ' 条：')
  for (const r of 排) console.log('  · [' + r.id + '] ' + String(r.title || String(r.content).slice(0, 40)).replace(/\s+/g, ' ').slice(0, 78))
  if (!排.length) console.log('  （一条都没命中 —— 0 命中 ≠ 没有：换关键词再问一次）')

  // 2026-09-23 接进来的「踩坑升级链」：把坑账热点摆在干活/接手的眼前
  if (环 === '干活' || 环 === '接手') {
    try {
      const 账 = JSON.parse(fs.readFileSync('/storage/emulated/0/3/记忆/坑账.json', 'utf8'))
      const 热 = 账.坑.filter((k) => k.次数 >= 2 || String(k.状态).includes('红线'))
      console.log('  📒 坑账（踩坑升级链）：' + 账.坑.length + ' 个坑 ｜ 热点 ' + 热.length + ' 个' + (热.length ? '（踩过 ≥2 次 ⇒ 该做成门/产物了）' : ''))
  console.log('🧠 短期记忆（不算长期记忆）：挖到的真东西 ⇒ `短期.mjs 放 "…"`；出口三条：能做工具⇒做工具／做不成工具的教训⇒`升 --到 lesson`／都不占⇒`落 <id>`')
      for (const k of 热.slice(0, 5)) console.log('     · 次数 ' + k.次数 + ' ｜ ' + k.状态 + ' ｜ ' + String(k.坑).slice(0, 56))
      console.log('  📒 踩到**新**坑：`node 工具/记忆/坑账.mjs 踩 "<坑的一句话>"` —— 它先去记忆库找同类的坑（找到＝直接拿来用；没找到＝保留；第 2 次升级；第 3 次进规矩层；**第 4 次直接改根；改不动⇒报老板＋进红线**；**重大事故第一次就进红线**）')
    } catch (e) { }
  }
}
console.log('\n（这条工具就是「落点」的第一片：每个环节都把该守的规矩抽出来摆手边。下一步把它接进各环节的工具里。）')
