#!/usr/bin/env node
// ═══ 生效.mjs · 效应器（蓝图 §六 3.3 「自己动」那一格 / 调研路线一）═══
//
// 它补的是哪一环（人话）：
//   我们的「提醒」早就有了 —— `神经/调度.mjs` 每次工具调用后都算得出
//   `missing`（该做没做的那几个动作）。**但那个 missing 从来没有送进任何执行入口**
//   （实测：插件 `lib/index.js:1050` 只取了 `.line` 这一个字符串）。
//   ⇒「响了」与「做了」之间，一直靠我自觉；实测率就摆在那儿：跑库一屏 9/32。
//
// 本件做的是**三样**（调研路线一）：
//   ① 落点化（已在 `调度.mjs`：动作名 → 一行能跑的命令）
//   ② **执行者**（本件）：只认**白名单**里的动作
//   ③ **落地校验 ＋ 执行账本**：跑完留产物指纹；失败进"死信"，**不许静默丢**
//
// ★ 白名单准入条件**只有一条**（老板红线「东西不要自己冒出来」的机器化）：
//      **误执行也无害** —— 只读／幂等／或有 `_backup` 可回滚。
//   判据（可机器判，照调研 §4.2 C 类）：**把它故意跑两遍**，
//      第二遍若产生**不同于第一遍的后果**（文件内容变了／外部状态变了／多发了一条消息）⇒ **不许进白名单**。
//
// ★ 判断与执行分家（调研 §2.1 PDP/PEP）：
//   `调度.mjs` 只出**决策**（该做什么），本件只做**执行**（且只做白名单内的）。
//   两个文件互不调用对方 —— 改一边不用动另一边。
//
// 用法：
//   node 神经/生效.mjs 表                  # 印白名单（含"为什么它无害"）
//   node 神经/生效.mjs 干 <动作id>          # 跑一个（幂等：同键只跑一次）
//   node 神经/生效.mjs 干 <id> --再来一次    # 无视幂等，强制再跑（给"两遍无害"判据用）
//   node 神经/生效.mjs 核                   # 自证：幂等键／死信／白名单两条硬判据
import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const WS = process.env.DSH_KICKOFF_WS || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const P = (...a) => path.join(WS, ...a)
const 账本 = P('台账/接续/执行账.json')
const NOW = () => new Date().toISOString()

// ── 白名单（**准入只有一条：误执行也无害**）────────────────────────────────
// 每条必须写清：跑什么／产出什么（用来做落地校验）／凭什么说它无害
const 白名单 = [
  {
    id: '跑库一屏', cmd: '工具/开工/库.mjs', 产出: null,
    无害: '纯只读：读文件＋调只读仪器，不写任何生产文件（本文件自己那条"测不写盘"就是同族判据）',
  },
  {
    id: '冻结校验', cmd: '工具/台账/冻结.mjs 校验', 产出: null,
    无害: '只读校验：比对冻结清单的针与行哈希，写盘零处',
  },
  {
    id: '事故回归集', cmd: '工具/回归/跑全部.mjs', 产出: null,
    无害: '只跑既有回归用例；跑两遍结果一致（回归集本身是幂等的）',
  },
  {
    id: '动作集核', cmd: '神经/动作集.mjs 核', 产出: null,
    无害: '只读：数动作条数、查缺格/重复 id，不落盘',
  },
  {
    id: '停手线测', cmd: '神经/停手线.mjs 测', 产出: null,
    无害: '只报不动手（它自己的 `核` 里有一条判据就是"测 不写盘"）',
  },
  {
    id: '注入计量', cmd: '神经/注入计量.mjs', 产出: null,
    无害: '只读会话日志＋计数，不写盘（基线要显式跑 `基线` 子命令才写）',
  },
  {
    id: '注入面', cmd: '神经/注入面.mjs', 产出: null,
    无害: '只读十来源在不在，不写盘',
  },
]

// ── 黑名单（**结构上不给入口** —— 不是"我克制"，是这里根本没有这个名字）──
// 照调研 §4.2 A/B 两类：列出来是为了**让人看得见"为什么这几件不在表里"**
const 黑名单 = [
  ['会话窗口的开／关／切换／往里发消息', '红线：窗口权只在他本人'],
  ['重启引擎', '红线：动手永远是他'],
  ['装配树／启动路径的任何写入', '09-14 事故：41 次崩溃启动'],
  ['装包 / apt / pkg', '红线：apt 会去"修"，可能拆掉引擎所在的树'],
  ['写生产文件（工具/台账/内核/）', '那是"我们的账"，改错＝串味；且他要逐项看'],
  ['不可逆的外部副作用（对外发消息／提交／发布／删除）', '失败没有第二次机会'],
  ['他的动作（验收打勾／裁决／"进行下一步"）', '"完成"只能他勾'],
]

const 读账 = () => { try { return JSON.parse(fs.readFileSync(账本, 'utf8')) } catch { return { unit: '执行账', version: 1, 记录: [] } } }
const 写账 = (j) => { try { fs.mkdirSync(path.dirname(账本), { recursive: true }) } catch {}; fs.writeFileSync(账本, JSON.stringify(j, null, 1)) }
/** 幂等键＝(动作, 会话)。**不含时间** —— 含时间就等于"每次都算新"，幂等立刻失效（调研 §2.4）。 */
const 键 = (id, sid) => id + '@' + (sid || 'no-sid')
/** 产物指纹：文件 mtime+size+hash；命令则用 exit+stdout hash（调研 §4.1 J3）。 */
const 指纹 = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return s.length + ':' + h }

/** ★ node 用哪条路（2026-09-26 现场踩到）：本机 PATH 里**没有** node（只有引擎自带的绝对路径），
 *  而机器上 PATH 里有 —— 所以自证里若要再起一个自己，必须**两条路都试**，否则自证会"因为找不到 node 而红"，
 *  看起来像功能坏了，其实只是调用路径不对。**这正是②环境自检要治的同一个病。** */
const NODE = (() => {
  const 试 = (p) => { try { const r = spawnSync(p, ['-e', '0'], { timeout: 15000, stdio: 'ignore' }); return r.status === 0 } catch { return false } }
  if (试('node')) return 'node'
  if (process.execPath && 试(process.execPath)) return process.execPath
  return 'node'
})()

const 跑 = (cmd) => {
  const 段 = String(cmd).split(/\s+/)
  // ★ 环境要**显式传下去**（2026-09-26 现场踩到）：本机跑时 $DSH_HOME 不在默认位置，
  //   子进程拿不到就会退 1，看起来像"动作不安全"，其实是"没给它环境"。
  const env = { ...process.env }
  if (!env.DSH_KICKOFF_WS) env.DSH_KICKOFF_WS = WS
  const r = spawnSync(NODE, 段, { cwd: WS, env, encoding: 'utf8', timeout: 180000, maxBuffer: 64 * 1024 * 1024 })
  return { exit: r.status, out: String(r.stdout || ''), err: String(r.stderr || '').slice(0, 2000) }
}

const a = process.argv.slice(2)
const 子 = a[0]

if (子 === '表') {
  console.log('🦾 效应器 · 白名单（准入**只有一条**：误执行也无害）')
  console.log('')
  for (const w of 白名单) console.log('  ✅ ' + w.id.padEnd(12, '　') + ' `' + w.cmd + '`\n       凭什么无害：' + w.无害)
  console.log('')
  console.log('⛔ 黑名单（**结构上不给入口** —— 这里根本没有它们的名字）')
  for (const [名, 为什么] of 黑名单) console.log('  · ' + 名 + ' —— ' + 为什么)
  console.log('')
  console.log('★ 判据：白名单**只增不改**要走老板点头（同"东西不要自己冒出来"）；')
  console.log('  加一条之前必须**故意跑两遍**，第二遍后果不同 ⇒ 不许进。')
  process.exit(0)
}

if (子 === '干') {
  const id = a[1]
  const w = 白名单.find((x) => x.id === id)
  if (!w) {
    console.error('❌ 不在白名单：' + id)
    const 像黑 = 黑名单.find(([n]) => id && (n.includes(id) || id.includes(n.slice(0, 4))))
    if (像黑) console.error('   它在**黑名单**里：' + 像黑[0] + ' —— ' + 像黑[1])
    console.error('   ⇒ 效应器**结构上够不着**它（不是我克制）。要跑请老板点头，或我手动跑。')
    process.exit(3)
  }
  const sid = process.env.DSH_SESSION_ID || process.env.DSH_KICKOFF_SID || ''
  const k = 键(id, sid)
  const j = 读账()
  j.记录 = j.记录 || []
  const 强制 = a.includes('--再来一次')
  const 老 = j.记录.filter((r) => r.幂等键 === k)
  if (老.length && !强制) {
    console.log('⏭ 幂等：这个动作本会话已经跑过（键 ' + k + '）')
    console.log('   上一次：' + 老[老.length - 1].时刻 + ' ／ exit=' + 老[老.length - 1].exit + ' ／ 产物指纹 ' + 老[老.length - 1].指纹)
    console.log('   ⇒ 不重复执行（**同一件事做两遍也无害**是白名单的准入条件，但重复执行仍然是浪费）')
    process.exit(0)
  }
  const t0 = Date.now()
  const r = 跑(w.cmd)
  const 指 = 指纹(r.out)
  const 条 = {
    时刻: NOW(), 幂等键: k, 动作: id, 命令: w.cmd, 谁触发: '效应器（白名单自动）',
    exit: r.exit, 指纹: 指, 耗时ms: Date.now() - t0,
    失败归属: r.exit === 0 ? null : '❌ 停在 exit=' + r.exit + ' ⇒ 下次可重试；连续失败要人看',
  }
  j.记录.push(条)
  // 死信：失败**不许静默丢**（调研 §2.4）
  if (r.exit !== 0) { j.死信 = j.死信 || []; j.死信.push({ ...条, stderr尾: r.err.slice(-400) }) }
  写账(j)
  console.log((r.exit === 0 ? '✅' : '❌') + ' ' + id + ' 跑完 exit=' + r.exit + ' ／ ' + 条.耗时ms + 'ms ／ 产物指纹 ' + 指)
  console.log('   账本：' + 账本.replace(WS + path.sep, ''))
  if (r.exit !== 0) { console.log('   ⚠️ 已进**死信**（不静默丢）。stderr 尾：'); console.log('   ' + r.err.split('\n').slice(-6).join('\n   ')) }
  else console.log('   输出前 6 行：\n   ' + r.out.split('\n').slice(0, 6).join('\n   '))
  process.exit(r.exit === 0 ? 0 : 1)
}

if (子 === '核') {
  const 断 = []
  // ① 幂等键**不含时间**（含时间就等于没有幂等）
  const k1 = 键('跑库一屏', 's1'), k2 = 键('跑库一屏', 's1'), k3 = 键('跑库一屏', 's2')
  断.push(['幂等键＝(动作,会话)，同输入同键', k1 === k2 && k1 !== k3])
  断.push(['幂等键**不含时间**（等 20ms 再算，键必须一样）', (() => { const x = 键('a', 's'); const t = Date.now() + 20; while (Date.now() < t); return 键('a', 's') === x })()])
  // ② 黑名单里的东西**结构上跑不了**：真的调一次，必须退 3
  const 试 = spawnSync(NODE, [fileURLToPath(import.meta.url), '干', '重启引擎'], { cwd: WS, encoding: 'utf8', timeout: 60000 })
  断.push(['黑名单动作被拒（退 3，且**明确说是黑名单**）', 试.status === 3 && /黑名单/.test(String(试.stderr))])
  // ③ 不在名单里的也必须拒
  const 试2 = spawnSync(NODE, [fileURLToPath(import.meta.url), '干', '瞎编的动作'], { cwd: WS, encoding: 'utf8', timeout: 60000 })
  断.push(['不在名单 ⇒ 拒（不许"没找到就当成功"）', 试2.status === 3])
  断.push(['跑自己用的是哪条 node 路（本机/设备都对得上）', NODE === 'node' || /node/i.test(NODE)])
  // ④ 白名单每条都写了"凭什么无害"
  断.push(['白名单每条都有无害理由', 白名单.every((w) => w.无害 && w.无害.length > 8)])
  // ⑤ 失败必须进死信（不许静默丢）—— 源码级判据
  const 源 = fs.readFileSync(fileURLToPath(import.meta.url), 'utf8')
  断.push(['失败进死信（源码里有 死信 分支）', /j\.死信\.push/.test(源)])
  断.push(['落地校验有产物指纹', /指纹\(r\.out\)/.test(源) && /指纹: 指/.test(源)])
  let 过 = 0
  for (const [名, 真] of 断) { console.log('  ' + (真 ? '✅' : '❌') + ' ' + 名); if (真) 过++ }
  console.log('\n  自证：' + 过 + '/' + 断.length + (过 === 断.length ? ' 全绿' : ' ⚠️ 有红'))
  process.exit(过 === 断.length ? 0 : 1)
}

console.error('用法：生效.mjs 表 ｜ 干 <动作id> [--再来一次] ｜ 核')
process.exit(2)
