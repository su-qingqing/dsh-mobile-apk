import { readFileSync } from 'node:fs'
const lines = readFileSync(0, 'utf8').split('\n').filter((l) => l.trim().startsWith('{'))
const findUsage = (o) => {
  if (!o || typeof o !== 'object') return null
  if (Array.isArray(o)) { for (const x of o) { const r = findUsage(x); if (r) return r }; return null }
  if (o.inputTokens !== undefined) return o
  for (const k of Object.keys(o)) { const r = findUsage(o[k]); if (r) return r }
  return null
}
const reqs = []
for (const l of lines) {
  let e; try { e = JSON.parse(l) } catch { continue }
  if (e.type !== 'assistant/message') continue
  const u = findUsage(e)
  if (!u) continue
  const st = (e.data && (e.data.turn !== undefined ? e.data : (e.data.data || {}))) || {}
  reqs.push({ turn: st.turn, step: st.step, in: u.inputTokens || 0, cr: u.cacheReadTokens || 0, out: u.outputTokens || 0, rs: u.reasoningTokens || 0 })
}
const N = reqs.length
let I = 0, C = 0, O = 0, R = 0
for (const r of reqs) { I += r.in; C += r.cr; O += r.out; R += r.rs }
const M = (n) => (n / 1e6).toFixed(2) + 'M'
console.log('=== 有 usage 的 assistant/message：' + N + ' 条 ===')
console.log('新增输入 inputTokens  ' + M(I).padStart(9) + '   ← 全价')
console.log('缓存读 cacheRead      ' + M(C).padStart(9) + '   ← 缓存价')
console.log('合计 prompt           ' + M(I + C).padStart(9))
console.log('输出 output           ' + M(O).padStart(9))
console.log('推理 reasoning        ' + M(R).padStart(9))
console.log('★ 缓存命中率 = ' + (C / (I + C) * 100).toFixed(1) + '%')
const v = reqs.map((r) => r.in).sort((a, b) => a - b)
console.log('\n单次新增输入：最小 ' + v[0].toLocaleString() + ' / 中位 ' + v[Math.floor(N / 2)].toLocaleString() + ' / 最大 ' + v[N - 1].toLocaleString())
console.log('\n新增输入最大的 8 步：')
for (const r of reqs.slice().sort((a, b) => b.in - a.in).slice(0, 8)) console.log('  turn ' + String(r.turn).padStart(3) + ' step ' + String(r.step).padStart(3) + '  新增 ' + String(r.in).padStart(8) + '  缓存 ' + String(r.cr).padStart(8))

// ── 结论自动打印（不手写标签，全部由数据产生）──
const prompt = I + C
console.log('\n════ 折算（缓存按 1/10 价，行业通例）════')
const eff = I * 1.0 + C * 0.1
console.log('  新增输入  全价   ' + I.toLocaleString())
console.log('  缓存读    1/10   ' + (C / 10).toLocaleString() + '  （等效）')
console.log('  合计输入等效      ' + eff.toLocaleString())
console.log('  ⇒ 缓存重读占等效成本 ' + (C / 10 / eff * 100).toFixed(1) + '%')
console.log('  ⇒ 每次请求平均 prompt ' + Math.round(prompt / N).toLocaleString() + ' token')
console.log('  ⇒ 请求数 ' + N + '  ← 这是乘数')
