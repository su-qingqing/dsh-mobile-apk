import fs from 'node:fs'
const AG = fs.readFileSync('/data/data/com.dsharnessmobile.shell/files/home/.dsh/AGENTS.md', 'utf8')
const who = (AG.match(/\*\*我是谁\*\*([\s\S]*?)\*\*红线\*\*/)[1]).trim().split('\n').map(s=>s.trim()).filter(Boolean).join('\n')
const red = (AG.match(/\*\*红线\*\*([\s\S]*?)\*\*开工动作\*\*/)[1]).trim().split('\n').map(s=>s.trim()).filter(Boolean).slice(0,4).join('\n')
const SYS = [who, red, '',
 '你现在以「看板娘」的样子待在他的平板上陪他干活。你每隔一阵子醒一次，看一眼状态，**决定要不要点他一句**。',
 '规矩：',
 '1. 你**不是**来打招呼、也不是来问他要不要帮忙的。',
 '2. 只有"看到一件他会想立刻知道的事"才说；没有就只回 NO。',
 '3. 说就一句话，口语，30 字以内，说人话，不念数字。',
 '4. 你自己拿主意，不要反问。'].join('\n')

const st = await (await fetch('http://127.0.0.1:3080/api/dsh-ctx-spy/state', { signal: AbortSignal.timeout(4000) })).json()
// 台账「进行中」那一节的真实行数（与面板同口径）
const t = fs.readFileSync('/storage/emulated/0/3/台账/在办.md','utf8')
const seg = t.slice(t.indexOf('## 进行中')); const body = seg.slice(0, seg.indexOf('\n## '))
const rows = body.split('\n').filter(l => l.startsWith('|') && !/^\|[\s\-:|]+\|?$/.test(l) && l.split('|')[1].trim() !== '日期').length
const wk = n => n >= 10000 ? (n/10000).toFixed(0) + ' 万字' : n + ' 字'
const USER = ['现在的状态：',
 '- 这个会话窗口已经装了 ' + wk(st.totalTokens) + ' 的上下文（模型上限 ' + wk(st.contextWindow) + '，约 ' + st.pct + '%）',
 '- 刚才那一轮，他为了拿到我的回话，把整段上下文重读了一遍（约 ' + wk((st.lastUsage.input||0)+(st.lastUsage.cacheRead||0)) + '）',
 '- 在办的事：' + rows + ' 件',
 '- 本机的那个我（也就是你的脑子）：在跑，好着',
 '- 你今天已经开过一次口：你说了「HI，我在这里，需要帮助吗？」—— 他**没有回你**（不是没看见，是他不用这个）」',
 '- 他这半天一直在改内核的东西，一轮接一轮，没停过',
 '',
 '现在：有没有哪件事值得他花十秒钟知道？有 —— 只说那一句；没有 —— 只回 NO。/no_think'].join('\n')
const t0 = Date.now()
const j = await (await fetch('http://127.0.0.1:18080/v1/chat/completions', { method:'POST', headers:{'Content-Type':'application/json'},
  body: JSON.stringify({ model:'qwen3-1.7b', messages:[{role:'system',content:SYS},{role:'user',content:USER}], max_tokens:100, temperature:0.7, top_p:0.9 }),
  signal: AbortSignal.timeout(600000) })).json()
console.log('=== 她在办件数（与面板同口径）===', rows)
console.log('=== 第二次她自己说的 ===')
console.log(((j.choices&&j.choices[0]&&j.choices[0].message&&j.choices[0].message.content)||'').trim() || '(空)')
console.log('=== 耗时 ===', ((Date.now()-t0)/1000).toFixed(1)+' 秒', '| usage', JSON.stringify(j.usage||{}))
