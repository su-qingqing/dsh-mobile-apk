/**
 * 看板娘「活的一次呼吸」最小验证：
 *   眼睛（真实状态） → 脑子（本机 4B） → 她自己决定：说一句 or 不说（NO）
 * 不写任何文件、不改任何配置；只调本机 llama-server。
 */
import fs from 'node:fs'

const AG = fs.readFileSync('/data/data/com.dsharnessmobile.shell/files/home/.dsh/AGENTS.md', 'utf8')
const m = AG.match(/\*\*我是谁\*\*([\s\S]*?)\*\*红线\*\*/)
const who = (m ? m[1] : '').trim().split('\n').map((s) => s.trim()).filter(Boolean).join('\n')
const red = (AG.match(/\*\*红线\*\*([\s\S]*?)\*\*开工动作\*\*/) || [, ''])[1]
  .trim().split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 4).join('\n')

const SYS = [
  who, red,
  '',
  '现在你以「看板娘」的样子待在他的平板上陪他干活——你能看见下面这些状态，也可以选择说一句话，或者什么都不说。',
  '说话的规矩（只有这几条，其余你自己拿主意）：',
  '1. 只有真的对他有用才说；没话说就只回 NO。',
  '2. 说就一句话，口语，30 字以内，像人，不念数字、不写报告、不反问。',
  '3. 不要提"作为AI/模型"这类话。',
].join('\n')

let st = null
try {
  const r = await fetch('http://127.0.0.1:3080/api/dsh-ctx-spy/state', { signal: AbortSignal.timeout(4000) })
  st = await r.json()
} catch { st = null }

const wk = (n) => (n >= 10000 ? (n / 10000).toFixed(0) + ' 万字' : n + ' 字')
const rows = (fs.readFileSync('/storage/emulated/0/3/台账/在办.md', 'utf8').match(/^\|/gm) || []).length
const lk = await (async () => { try { const r = await fetch('http://127.0.0.1:3080/api/dsh-local-kernel/status', { signal: AbortSignal.timeout(3000) }); return await r.json() } catch { return null } })()

const lines = []
if (st && st.totalTokens) {
  lines.push('- 他现在这个会话窗口：已经装了 ' + wk(st.totalTokens) + ' 的上下文（模型上限 ' + wk(st.contextWindow || 0) + '，约 ' + st.pct + '%）')
  if (st.lastUsage) lines.push('- 刚过去这一轮：为了让我回话，他重读了一遍上下文，约 ' + wk((st.lastUsage.input || 0) + (st.lastUsage.cacheRead || 0)))
  lines.push('- 他用的模型：' + st.model + '（云上的算力）')
} else {
  lines.push('- 我看不清他窗口的占用（读不到）')
}
lines.push('- 在办的事：' + rows + ' 行')
lines.push('- 本机的那个"我"（本地模型）：' + (lk && lk.ready ? '在跑，好着' : '没在跑'))
lines.push('- 距离你上一次说话：很久了（这是今天第一次开口的机会）')
lines.push('- 他刚才一直在让你（云上的我）改内核的东西，一轮接一轮')

const USER = ['现在的状态：', ...lines, '', '你要不要跟他说一句？要，就只回那句话；不要，就回 NO。/no_think'].join('\n')

const t0 = Date.now()
const res = await fetch('http://127.0.0.1:18080/v1/chat/completions', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    model: 'qwen3-4b',
    messages: [{ role: 'system', content: SYS }, { role: 'user', content: USER }],
    max_tokens: 100, temperature: 0.7, top_p: 0.9,
  }),
  signal: AbortSignal.timeout(600000),
})
const j = await res.json()
const out = (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || ''
console.log('=== 她看到的状态（喂给她的原文）===')
console.log(USER.replace(' /no_think', ''))
console.log('=== 提示规模 ===', 'system', SYS.length, '字 / user', USER.length, '字')
console.log('=== 她自己说的（本机 4B 生成）===')
console.log(out.trim() || '(空)')
console.log('=== 耗时 ===', ((Date.now() - t0) / 1000).toFixed(1) + ' 秒')
console.log('=== usage ===', JSON.stringify(j.usage || {}))
