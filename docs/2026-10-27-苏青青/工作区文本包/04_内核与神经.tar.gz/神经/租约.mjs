#!/usr/bin/env node
// 租约.mjs —— 「工作区租约」：**意图级**所有权（分钟级、可续、过期回收、越界报警）
//
// 为什么要它（外部调研 ⇒ 转化）：Claude Code 的 worktree **在跑的时候对那棵树持锁、跑完才放**
//   （原文 `调研/外部_原文_1007/code.claude.com_docs_en_worktrees.md.md:67`）。
//   我们已有的 `神经/锁.mjs` 是**动作级**互斥（毫秒：谁在写这一下），
//   缺的是**意图级**所有权：谁在改这件事、改到几点、他掉线了怎么办。本件补这一段。
//
// 用法：
//   node 神经/租约.mjs 取 <件> [--窗 <id>] [--分钟 N]   # 已有别人持 ⇒ 拒（退 3）
//   node 神经/租约.mjs 续 <件> [--窗 <id>] --代 <代> [--分钟 N]   # 只有持有人 ＋ 世代对得上才许续
//   node 神经/租约.mjs 放 <件> [--窗 <id>] --代 <代>              # 只有持有人 ＋ 世代对得上才许放
//   node 神经/租约.mjs 查 [件]                          # 看谁持、第几代、还剩几分钟
//   node 神经/租约.mjs 清                               # 回收过期
//   node 神经/租约.mjs 自测 | 自检                       # 不碰生产账
//
// ★★ 1013 收口 · **世代号**（治「过期占用不得顶掉现役」）：
//   原来盘上只写「持有人＝窗 id」＝书 `M2-13` 说的那种「只写 `A owns X`」⇒ **过期持有者能清掉现役占用**。
//   实测（1013）：`DSH_SESSION_ID` 在引擎进程里读不到 ⇒ 窗 id 会退化成一模一样的 `未知窗`
//   ⇒ 「持有人」这一格**根本分不出两代**（谁都能"续/放"别人的）。
//   改法：每条占位多记一个 `代`（取的那一刻现摇）；**续／放 都要比代**；旧世代 ⇒ 拒（退 3），
//   新世代接管（过期回收）时**换新代** ⇒ 老持有者手里那串代从此作废。
// 落点：`台账/接续/租约.json`（复用 锁.mjs：带锁＋原子写）
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { 带锁, 原子写 } from './锁.mjs'

const 根 = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
// ★ 1007 夜修：**改成函数、每次现算** —— 原来在模块加载时读一次 env，自测里再改 env 就不生效 ⇒ 自测数据写进**生产账**（实测发生过）
const 账 = () => process.env.LEASE_FILE || path.join(根, '台账/接续/租约.json')
const 默认分钟 = 30

const 是主 = (() => { try { return !!process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url)) } catch { return false } })()
const 参 = k => { const i = process.argv.indexOf('--' + k); return i >= 0 ? process.argv[i + 1] : null }
const 现在 = () => Date.now()

function 读() { try { return JSON.parse(fs.readFileSync(账(), 'utf8')) } catch { return { 件: {} } } }
function 写(o) { fs.mkdirSync(path.dirname(账()), { recursive: true }); 原子写(账(), JSON.stringify(o, null, 1)) }
// ★ 边界（1007 夜 · 上膛的特异性对照逮到）：**「到点即过期」必须用 <=**。
//   用 < 时，若「取的那一刻」与「判的那一刻」落在同一毫秒，0 分钟租约会判成"还没过期" ⇒ 自测⑥随机红。
function 过期(x) { return !x || !x.持到 || x.持到 <= 现在() }
function 分钟差(t) { return Math.round((t - 现在()) / 60000) }
// ★ 1013 收口：**世代号** —— 每次「取」现摇一个；续/放都要比它（旧世代不许清新世代）
const 摇代 = () => 现在().toString(36) + '-' + process.pid.toString(36) + '-' + Math.random().toString(36).slice(2, 8)
const 短代 = (代) => (代 ? String(代).slice(0, 12) : '(无代·旧账)')

function 取(件, 窗, 分钟) {
  return 带锁('租约', () => {
    const o = 读(); o.件 = o.件 || {}
    const x = o.件[件]
    if (x && !过期(x) && x.窗 !== 窗) return {
      码: 3, 说: '⛔ 已被持：' + 件 +
        '\n   持有人 = ' + x.窗 +
        '\n   到期   = ' + new Date(x.持到).toLocaleString('zh-CN') + '（剩 ' + 分钟差(x.持到) + ' 分钟）' +
        '\n   怎么查 = node 神经/租约.mjs 查 ' + 件
    }
    const 回收 = x && 过期(x)   // ★ 核 A3：过期即回收 —— 必须**说出来**，不许默默接管
    const 代 = 摇代()           // ★ 新世代：老持有者手里那串代，从这一刻起作废
    o.件[件] = { 窗, 代, 取于: 现在(), 持到: 现在() + 分钟 * 60000, 续于: 现在() }
    写(o)
    return { 码: 0, 代, 说: '✅ 取到：' + 件 + ' ← ' + 窗 + '（到 ' + new Date(o.件[件].持到).toLocaleString('zh-CN') + '）' +
      '\n   ★ 世代 = ' + 代 + '（续/放都要带上它：`--代 ' + 代 + '`；丢了它 ⇒ 这件就放不掉，只能等过期）' +
      (回收 ? '\n   ♻️ 过期回收：原持有人 ' + x.窗 + ' 的租约已过期（' + new Date(x.持到).toLocaleString('zh-CN') + '）⇒ 自动接管；**它的旧世代 ' + 短代(x.代) + ' 就地作废**（旧世代不许清新世代）' : '') }
  })
}
function 续(件, 窗, 分钟, 代) {
  return 带锁('租约', () => {
    const o = 读(); const x = (o.件 || {})[件]
    if (!x) return { 码: 2, 说: '❌ 没这条租约：' + 件 }
    if (!代) return { 码: 3, 说: '⛔ 必须带 `--代 <代>`（取的那一刻印出来的那串）—— 没代就分不出"我这一代"，**旧世代不许清新世代**' }
    if (x.窗 !== 窗) return { 码: 3, 说: '⛔ 不是你的租约（持有人 ' + x.窗 + '）⇒ 不许续' }
    if (x.代 && x.代 !== 代) return { 码: 3, 说: '⛔ 世代不对（盘上 ' + 短代(x.代) + ' ≠ 你的 ' + 短代(代) + '）⇒ 你这一代已被回收，重新"取"' }
    if (过期(x)) return { 码: 3, 说: '⛔ 已过期（' + new Date(x.持到).toLocaleString('zh-CN') + '）⇒ 过期即回收，重新"取"' }
    x.持到 = 现在() + 分钟 * 60000; x.续于 = 现在(); 写(o)
    return { 码: 0, 代: x.代, 说: '✅ 已续到 ' + new Date(x.持到).toLocaleString('zh-CN') + '（世代 ' + 短代(x.代) + ' 不变）' }
  })
}
function 放(件, 窗, 代) {
  return 带锁('租约', () => {
    const o = 读(); const x = (o.件 || {})[件]
    if (!x) return { 码: 2, 说: '❌ 没这条租约：' + 件 }
    if (!代) return { 码: 3, 说: '⛔ 必须带 `--代 <代>` —— 没代就分不出"我这一代"；**旧世代不许清新世代**（就是"过期占用不得顶掉现役"那一格）' }
    if (x.窗 !== 窗) return { 码: 3, 说: '⛔ 不是你的租约（持有人 ' + x.窗 + '）⇒ 不许放' }
    if (x.代 && x.代 !== 代) return { 码: 3, 说: '⛔ 世代不对（盘上 ' + 短代(x.代) + ' ≠ 你的 ' + 短代(代) + '）⇒ **现役已换人，旧世代不许清它**' }
    delete o.件[件]; 写(o)
    return { 码: 0, 代, 说: '✅ 已放：' + 件 }
  })
}
function 查(件, 选 = {}) {
  const o = 读(); const 表 = Object.entries(o.件 || {}).filter(([k]) => !件 || k === 件)
  const 条 = 表.map(([k, x]) => ({
    件: k, 持有人: x.窗, 世代: x.代 || null, 世代短: 短代(x.代), 到期: x.持到, 到期人话: new Date(x.持到).toLocaleString('zh-CN'),
    状态: 过期(x) ? '已过期' : '有效', 剩分钟: 过期(x) ? 0 : 分钟差(x.持到), 取于: x.取于,
  }))
  if (选.json) return { 码: 0, 说: JSON.stringify({ 条 }, null, 1) }          // ★ 核 A2：机器读口
  // ★ 核 A4：越界报警 —— 薄警告，不硬拦（码仍是 0）
  let 头 = ''
  if (选.写 && 条.length && 条[0].状态 === '有效' && 选.窗 && 条[0].持有人 !== 选.窗)
    头 = '⚠️ 薄警告：' + 条[0].件 + ' 现由 ' + 条[0].持有人 + ' 持有（到期 ' + 条[0].到期人话 + '）—— 你要写它，建议先「取」或等它过期。**本警告不拦你**（薄警告≠硬拦）。\n'
  if (!条.length) return { 码: 0, 说: 头 + (件 ? '✅ 没人持：' + 件 : '（租约账是空的）') }
  const 行 = 条.map((c) => '  ' + (c.状态 === '已过期' ? '⌛过期' : '🔒持有') + ' ' + c.件 +
    '\n     持有人 = ' + c.持有人 +
    '\n     世代   = ' + c.世代短 + (c.世代 ? '（续/放都要带 `--代`）' : '（旧账：没有世代号，见 1013 收口那条）') +
    '\n     到期   = ' + c.到期人话 + '（' + (c.状态 === '已过期' ? '已过期，可回收' : '剩 ' + c.剩分钟 + ' 分钟') + '）' +
    '\n     状态   = ' + c.状态)
  return { 码: 0, 说: 头 + '租约（' + 条.length + ' 条）：\n' + 行.join('\n') }
}
function 清() {
  return 带锁('租约', () => {
    const o = 读(); const 前 = Object.keys(o.件 || {}).length
    for (const [k, x] of Object.entries(o.件 || {})) if (过期(x)) delete o.件[k]
    写(o)
    return { 码: 0, 说: '✅ 回收 ' + (前 - Object.keys(o.件).length) + ' 条过期租约（剩 ' + Object.keys(o.件).length + ' 条）' }
  })
}

function 自测() {
  const 备 = 账
  const 临时 = path.join(根, '_tmp', '租约自测-' + process.pid + '.json')
  process.env.LEASE_FILE = 临时
  if (!/_tmp/.test(String(process.env.LEASE_FILE || ""))) { console.log("⛔ 自测落点没改道 ⇒ 拒跑（否则会写脏生产账）"); return 1 }
  const r = []
  const ok = (名, 真) => r.push([名, !!真])
  try { fs.mkdirSync(path.dirname(临时), { recursive: true }) } catch { }
  try { fs.unlinkSync(临时) } catch { }
  // 用内部函数直测（不走 argv）
  const 取2 = (件, 窗, 分) => { process.env.LEASE_FILE = 临时; return 取(件, 窗, 分) }
  const 一 = 取2('件A', '窗1', 30)
  ok('① 空账能取到（且当场发一个世代号）', 一.码 === 0 && !!一.代)
  const 二 = 取2('件A', '窗2', 30)
  ok('② 别人正在持 ⇒ 必拒（退 3）', 二.码 === 3)
  const 三 = 取2('件A', '窗1', 30)
  ok('③ 持有人自己再取 ⇒ 许（续期 · 换新世代）', 三.码 === 0 && 三.代 !== 一.代)
  const 续2 = (件, 窗, 代, 分) => { process.env.LEASE_FILE = 临时; return 续(件, 窗, 分, 代) }
  ok('④ 非持有人续 ⇒ 拒', 续2('件A', '窗2', 三.代, 30).码 === 3)
  ok('⑤ 持有人续 ⇒ 许', 续2('件A', '窗1', 三.代, 60).码 === 0)
  ok('⑤b 不带代续 ⇒ 拒（分不出"我这一代"就不许动）', 续2('件A', '窗1', '', 60).码 === 3)
  const 过期取 = 取2('件B', '窗1', 0)
  const 抢 = 取2('件B', '窗2', 30)
  ok('⑥ 过期即回收（0 分钟后别人能取）', 过期取.码 === 0 && 抢.码 === 0)
  ok('⑥b 新胜旧：回收之后世代换人', !!过期取.代 && !!抢.代 && 过期取.代 !== 抢.代)
  ok('⑦ 查能印出持有人', /窗1|窗2/.test((() => { process.env.LEASE_FILE = 临时; return 查().说 })()))
  ok('⑦b 查能印出世代', /世代\s*=\s*\S+/.test((() => { process.env.LEASE_FILE = 临时; return 查().说 })()))
  const 放2 = (件, 窗, 代) => { process.env.LEASE_FILE = 临时; return 放(件, 窗, 代) }
  ok('⑧ 非持有人放 ⇒ 拒', 放2('件A', '窗9', 三.代).码 === 3)
  ok('⑨ 持有人放 ⇒ 许', 放2('件A', '窗1', 三.代).码 === 0)
  // ★★ 1013 收口四条：**旧世代不许清新世代**（"过期占用不得顶掉现役"）
  ok('⑩ 旧不许顶新：过期持有者拿旧世代「放」⇒ 拒（退 3）', 放2('件B', '窗1', 过期取.代).码 === 3)
  const 还 = (() => { process.env.LEASE_FILE = 临时; return 查('件B') })()
  ok('⑪ 后果堵住了：现役（窗2）那条租约还在、还是有效', /窗2/.test(还.说) && !/没人持/.test(还.说))
  ok('⑫ 连"窗名也相同"的旧世代也拒（不靠窗名兜底 —— 引擎里 DSH_SESSION_ID 读不到时会全员 = 未知窗）', 放2('件B', '窗2', 过期取.代).码 === 3)
  ok('⑬ 不带代放 ⇒ 拒（fail-closed）', 放2('件B', '窗2', '').码 === 3)
  ok('⑭ 现役拿自己的新世代 ⇒ 放得掉（正常路没被堵）', 放2('件B', '窗2', 抢.代).码 === 0)
  process.env.LEASE_FILE = 备
  try { fs.unlinkSync(临时) } catch { }
  const 败 = r.filter(x => !x[1])
  console.log('【租约 · 自测】')
  for (const [名, 真] of r) console.log('  ' + (真 ? '✅' : '❌') + ' ' + 名)
  console.log(败.length ? '❌ 败 ' + 败.length + '/' + r.length : '✅ 全过（' + r.length + '/' + r.length + '）')
  return 败.length ? 1 : 0
}

if (是主) {
  const 动词 = process.argv[2]
  if (动词 === '自测' || 动词 === '自检') process.exit(自测())
  const 窗 = 参('窗') || process.env.DSH_SESSION_ID || '未知窗'
  const 分钟 = Number(参('分钟') || 默认分钟)
  const 代 = 参('代')                       // ★ 1013 收口：续/放 必须带世代号
  let 果
  if (动词 === '取') 果 = 取(process.argv[3], 窗, 分钟)
  else if (动词 === '续') 果 = 续(process.argv[3], 窗, 分钟, 代)
  else if (动词 === '放') 果 = 放(process.argv[3], 窗, 代)
  else if (动词 === '查') 果 = 查(process.argv[3], { json: 参('json') !== null, 写: 参('写') !== null, 窗 })
  else if (动词 === '清') 果 = 清()
  else { console.log('用法：租约.mjs 取 <件> [--窗 <id>] [--分钟 N] ｜ 续/放 <件> [--窗 <id>] --代 <代> ｜ 查 [件] [--json] [--写 --窗 <id>] ｜ 清 ｜ 自测'); process.exit(2) }
  console.log(果.说); process.exit(果.码)
}
export { 取, 续, 放, 查, 清 }
