#!/usr/bin/env node
// 窗态.mjs —— **机器可读的窗态**（不是给人看的散文）：换窗/掉线后，程序能直接恢复"上一窗卡在哪"
//
// 为什么要它（外部调研 ⇒ 转化）：LangGraph 每步把状态存成 checkpoint（容错执行）、
//   OpenHands 显式 save/restore 会话态（原文 `调研/外部_原文_1007/docs.langchain.com_…checkpointers.md.md:14`、
//   `…docs.openhands.dev_sdk_guides_convo-persistence.md.md:12,14`）。
//   我们已有的交接单是**给人读的散文** ⇒ 本件补**给机器读**的那一份。
//
// 用法：
//   node 神经/窗态.mjs 写 --在办 "<一句>" [--下一步 "<一句>"] [--窗 <id>] [--未结红 N] [--队列条数 N]
//   node 神经/窗态.mjs 读 [最新|上一窗|<窗>] [--窗 <我>] [--人话]   # 默认吐 JSON（机器读）；--人话＝给人看
//   node 神经/窗态.mjs 列 [--json]
//   node 神经/窗态.mjs 自测 | 自检
// ★ 1007 夜按外部核（qwen3.8-max）补：写带账（未结红/队列条数）／读认「最新·上一窗」／读·列有 --json
//   核的原话判据 ⇒ 台账/接续/送核_外部架构转化_1007_4012ebce7f9a.md §四 B1-B3
//
// 落点：`台账/接续/窗态.json`（复用 锁.mjs：带锁＋原子写）；只留最近 20 条。
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { 带锁, 原子写 } from './锁.mjs'

const 根 = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
// ★ 1007 夜修：改成函数、每次现算（模块加载时读 env ⇒ 自测改道会失效、写脏生产账）
const 账 = () => process.env.WINDOW_STATE_FILE || path.join(根, '台账/接续/窗态.json')
const 租约账 = process.env.LEASE_FILE || path.join(根, '台账/接续/租约.json')
const 未结红 = path.join(根, '台账/接续/未结红.json')

const 是主 = (() => { try { return !!process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url)) } catch { return false } })()
const 参 = k => { const i = process.argv.indexOf('--' + k); return i >= 0 ? process.argv[i + 1] : null }

function 读() { try { return JSON.parse(fs.readFileSync(账(), 'utf8')) } catch { return { 窗: [] } } }
function 写(o) { fs.mkdirSync(path.dirname(账()), { recursive: true }); 原子写(账(), JSON.stringify(o, null, 1)) }
function 我的租约(窗) {
  try { const o = JSON.parse(fs.readFileSync(租约账, 'utf8')); return Object.entries(o.件 || {}).filter(([, x]) => x.窗 === 窗 && x.持到 > Date.now()).map(([k]) => k) } catch { return [] }
}
function 未结红数() {
  try { const o = JSON.parse(fs.readFileSync(未结红, 'utf8')); return (o.处理 ? 0 : (o.报警 || []).length) } catch { return 0 }
}
function 写一条(窗, 在办, 下一步, 账) {
  return 带锁('窗态', () => {
    const o = 读(); o.窗 = o.窗 || []
    const 红 = (账 && 账.未结红 != null && 账.未结红 !== '') ? Number(账.未结红) : 未结红数()
    const 队 = (账 && 账.队列条数 != null && 账.队列条数 !== '') ? Number(账.队列条数) : null
    const 条 = { 窗, 在办: 在办 || '', 下一步: 下一步 || '', 持租约: 我的租约(窗), 未结红: 红, 队列条数: 队, 时戳: Date.now() }
    const i = o.窗.findIndex(x => x.窗 === 窗)
    if (i >= 0) o.窗[i] = 条; else o.窗.push(条)
    o.窗 = o.窗.slice(-20); o.at = new Date().toISOString()
    写(o)
    return { 码: 0, 说: '✅ 窗态已记：' + 窗 + ' ｜ 在办「' + 条.在办.slice(0, 40) + '」｜ 持租约 ' + 条.持租约.length + ' 件 ｜ 未结红 ' + 条.未结红 + (条.队列条数 == null ? '' : ' ｜ 队列 ' + 条.队列条数 + ' 条') }
  })
}
// ★ 1007 夜按核补（核 B1/B2 的机器读口）：**给程序解析的那一份**，字段名＝核点名要的
function 一条(x) {
  if (!x) return null
  return {
    窗: x.窗, 在办: x.在办 || '', 下一步: x.下一步 || '',
    账: { 未结红: x.未结红 || 0, 队列条数: (x.队列条数 == null ? null : x.队列条数), 持租约: x.持租约 || [] },
    时戳: x.时戳, 人话时戳: new Date(x.时戳).toLocaleString('zh-CN'),
  }
}
function 印(x) {
  if (!x) return '（没有窗态记录）'
  const t = new Date(x.时戳)
  return '【窗态】' + x.窗 + '（' + t.toLocaleString('zh-CN') + '）\n' +
    '  在办：' + (x.在办 || '—') + '\n' +
    '  下一步：' + (x.下一步 || '—') + '\n' +
    '  持租约：' + ((x.持租约 || []).join('、') || '无') + '  ｜ 未结红：' + (x.未结红 || 0)
}
function 读一条(窗, 选 = {}) {
  const o = 读(); const 表 = (o.窗 || []).slice().sort((a, b) => b.时戳 - a.时戳)
  let x
  if (!窗 || 窗 === '最新') x = 表[0]                                   // 「最新」＝不分窗
  else if (窗 === '上一窗') x = 表.find(y => y.窗 !== 选.自己)          // ★ 核 B2：新窗读上一窗（认 --窗 排除自己）
  else x = 表.filter(y => y.窗 === 窗)[0]
  if (!x) return { 码: 2, 说: JSON.stringify({ 错: '没有窗态记录', 找: 窗 || '最新', 自己: 选.自己 || null }) }
  return { 码: 0, 说: 选.人话 ? 印(x) : JSON.stringify(一条(x), null, 1) }   // ★ 默认 JSON＝给机器读（加 --人话 给人看）
}
function 列(选 = {}) {
  const 表 = (读().窗 || []).slice().sort((a, b) => b.时戳 - a.时戳)
  if (选.json) return { 码: 0, 说: JSON.stringify(表.map(一条), null, 1) }
  return { 码: 0, 说: 表.length ? '窗态（' + 表.length + ' 条，新→旧）：\n' + 表.map(x => '  · ' + x.窗 + ' ｜ ' + new Date(x.时戳).toLocaleString('zh-CN') + ' ｜ ' + (x.在办 || '').slice(0, 40)).join('\n') : '（空）' }
}

function 自测() {
  const 备 = 账, 备份租 = process.env.LEASE_FILE
  const 临时 = path.join(根, '_tmp', '窗态自测-' + process.pid + '.json')
  process.env.WINDOW_STATE_FILE = 临时
  process.env.LEASE_FILE = path.join(根, '_tmp', '租约自测-' + process.pid + '.json')
  if (!/_tmp|自测/.test(String(账())) && !/_tmp|自测/.test(String(process.env.LEASE_FILE || ''))) {
    console.log('⛔ 自测落点没改道 ⇒ 拒跑（否则会写脏生产账）'); return 1
  }
  try { fs.mkdirSync(path.dirname(临时), { recursive: true }) } catch { }
  try { fs.unlinkSync(临时) } catch { }
  const r = []; const ok = (名, 真) => r.push([名, !!真])
  try {
    const a = 写一条('窗甲', '在办甲', '下一步甲')
    ok('① 写一条成功', a.码 === 0)
    const b = 读一条('窗甲')
    ok('② 读回同一条（在办对得上）', /在办甲/.test(b.说))
    ok('③ 下一步也在', /下一步甲/.test(b.说))
    写一条('窗乙', '在办乙', '')
    ok('④ 最新一条＝窗乙', /窗乙/.test(读一条().说))
    ok('⑤ 列表有 2 条', /2 条/.test(列().说))
    写一条('窗甲', '在办甲改', '')
    ok('⑥ 同窗再写＝覆盖不新增', (读().窗 || []).length === 2)
    ok('⑦ 不崩：读不存在的窗', 读一条('不存在的窗').码 === 2)
  } finally {
    process.env.WINDOW_STATE_FILE = 备
    process.env.LEASE_FILE = 备份租
    try { fs.unlinkSync(临时) } catch { }
  }
  const 败 = r.filter(x => !x[1])
  console.log('【窗态 · 自测】')
  for (const [名, 真] of r) console.log('  ' + (真 ? '✅' : '❌') + ' ' + 名)
  console.log(败.length ? '❌ 败 ' + 败.length + '/' + r.length : '✅ 全过（' + r.length + '/' + r.length + '）')
  return 败.length ? 1 : 0
}

if (是主) {
  const 动词 = process.argv[2]
  if (动词 === '自测' || 动词 === '自检') process.exit(自测())
  const 窗 = 参('窗') || process.env.DSH_SESSION_ID || '未知窗'
  let 果
  if (动词 === '写') 果 = 写一条(窗, 参('在办'), 参('下一步'), { 未结红: 参('未结红'), 队列条数: 参('队列条数') })
  else if (动词 === '读') 果 = 读一条(process.argv[3], { 自己: 参('窗') || process.env.DSH_SESSION_ID || '', 人话: 参('人话') !== null })
  else if (动词 === '列') 果 = 列({ json: 参('json') !== null })
  else { console.log('用法：窗态.mjs 写 --在办 "<一句>" [--下一步 "<一句>"] [--窗 <id>] [--未结红 N] [--队列条数 N] ｜ 读 [最新|上一窗|<窗>] [--窗 <我>] [--人话] ｜ 列 [--json] ｜ 自测'); process.exit(2) }
  console.log(果.说); process.exit(果.码)
}
export { 写一条, 读一条, 列 }
