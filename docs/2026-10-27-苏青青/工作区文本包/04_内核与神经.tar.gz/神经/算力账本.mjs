#!/usr/bin/env node
// 算力账本 · 数「每个 provider/model 真被派了几次活」
// 用法: node 算力账本.mjs [--recent N | --all]
// 依据: 会话日志里每个 LLM 请求都有一条 {"type":"request/header", … "config":{"provider":X,"model":Y}}
// ⚠️ 排序按目录内文件的最新 mtime —— 会话目录自身的 mtime 不会随写入更新（会骗人）
import { spawn } from 'node:child_process'
import { readdirSync, statSync, existsSync } from 'node:fs'
import { join } from 'node:path'

const H = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const ROOT = join(H, 'sessions')
const argv = process.argv.slice(2)
const RECENT = argv.includes('--all') ? Infinity : Number(argv[argv.indexOf('--recent') + 1] || 20)

function findDirs(base) {
  const out = []
  if (!existsSync(base)) return out
  for (const ws of readdirSync(base)) {
    const p = join(base, ws)
    try { if (!statSync(p).isDirectory()) continue } catch { continue }
    for (const s of readdirSync(p)) {
      const q = join(p, s)
      try { if (!statSync(q).isDirectory()) continue } catch { continue }
      let newest = 0
      for (const f of readdirSync(q)) { try { newest = Math.max(newest, statSync(join(q, f)).mtimeMs) } catch {} }
      out.push({ dir: q, name: s, mtime: newest })
    }
  }
  return out.sort((a, b) => b.mtime - a.mtime).slice(0, RECENT)
}

function countIn(file) {
  return new Promise((res) => {
    const pairs = new Map()
    const cp = spawn('zstd', ['-dc', file])
    let buf = ''
    cp.stdout.on('data', (d) => {
      buf += d.toString('utf8')
      const RE = /"provider":"([^"]+)","model":"([^"]+)"/g
      let m
      while ((m = RE.exec(buf))) {
        const k = m[1] + '/' + m[2]
        pairs.set(k, (pairs.get(k) || 0) + 1)
      }
      buf = buf.slice(Math.max(0, buf.length - 200))
    })
    cp.on('close', () => res(pairs))
    cp.on('error', () => res(pairs))
  })
}

const dirs = findDirs(ROOT)
const parent = new Map(), child = new Map()
let scanned = 0
for (const d of dirs) {
  const f = ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd'].map((x) => join(d.dir, x)).find((x) => existsSync(x))
  if (!f) continue
  scanned++
  const pairs = await countIn(f)
  const tgt = d.name.startsWith('session-') ? parent : child
  for (const [k, v] of pairs) tgt.set(k, (tgt.get(k) || 0) + v)
}
const show = (title, m) => {
  const tot = [...m.values()].reduce((a, b) => a + b, 0)
  console.log('\n' + title + '  (共 ' + tot + ' 次请求)')
  if (!tot) { console.log('  （无）'); return }
  for (const [k, v] of [...m.entries()].sort((a, b) => b[1] - a[1]))
    console.log('  ' + String(v).padStart(6) + '  ' + k)
}
console.log('算力账本 · 扫了 ' + scanned + ' 个会话（最近 ' + (RECENT === Infinity ? '全部' : RECENT) + ' 个）')
show('【主窗口】', parent)
show('【子代理】', child)
