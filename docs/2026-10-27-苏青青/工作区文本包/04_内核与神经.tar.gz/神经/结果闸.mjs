#!/usr/bin/env node
// ═══════════════════════════════════════════════════════════════════════════════
// 结果闸 · **shadow 档**（只看只记、绝不拦截）
//
// 【它是什么】挂在引擎 `PostToolUse` 钩子上的脚本 —— 每次工具调用返回后，引擎 spawn 本进程，
//   把**一次** JSON 从 **stdin** 喂进来（一行，可能带／不带尾换行），看退出码办事。
//   本档**一律 exit 0**：不 block、不写 stderr、**stdout 一个字都不输出**
//   （契约：exit 0 且 stdout 去空白后以 `{` 开头才被当 JSON 解析 ⇒ 保持空最安全）。
//   用法：`node 神经/结果闸.mjs`（钩子档，stdin 走契约）
//         `node 神经/结果闸.mjs --自测`（链路自证，不读 stdin、不碰生产账）
//         `node 神经/结果闸.mjs --看 [行数]`（把账尾几行印成人话，默认 10 行）
//
// 【四模块耦合 · 四格】
//   法（判据住在哪）：**本文件**，且只在本文件；判据＝下面三张表＋一个定义。
//     ① 输出契约 —— `截断标记[]`（命中即「截断不算结论」）＋ isError 痕迹（字段／文本两路）。
//     ② 重复调用 —— 键 ＝ sha256(工具名 + '\n' + 参数按键排序后的 JSON) 取前 16 位十六进制。
//     ③ 失败分级 —— isError 为真时，拿「工具名 ＋ 命令文本」过 `危险正则[]` ⇒ 危险类／普通失败。
//     · 契约真源（**不许猜**）：`台账/接续/hooks桥接线样例_1009.md` §三（stdin 字段／退出码
//       含义／hookSpecificOutput 写法／**exit 2 时 stdout 根本不解析**）；
//       七字段规约：`台账/接续/错误输出规约_1009.md`；B 批设计与失败模式表：
//       `台账/接续/结果闸_B批设计_1009.md`（§4 十条没有 ⇒ 不许上 enforce）。
//   记忆（什么时候用它）：引擎**每次工具返回都自动喂它** —— 不用我想起来。
//     人手动用只有两种时候：验链路 `--自测`、读尾部人话 `--看`。
//   神经（怎么自己响、挂在哪个必然时刻）：引擎 `PostToolUse` 钩子 spawn（stdin＝payload：
//     `tool_name`／`tool_input`／`tool_response` 等）。现档 = shadow：**只落一行、永远 exit 0**。
//     挂点配置（`hooks.json` / `cordis.patch.yml`）**不在本文件里** —— 那是父窗的活。
//   动作（没做到怎么办）：
//     · 账不涨行 ⇒ 先 `--自测`（链路自证），再核挂点配置里那个路径是不是这一份。
//     · 本脚本自己出错 ⇒ **fail-open 是设计不是故障**（顶层 try/catch 包住一切，绝不把工具调用
//       搞失败）；但「静默失效」必须有人看得见 ⇒ `--看` 尾部会出现 `输入·不是JSON` 这类行。
//     · 升级 warn／enforce：**要改脚本 ＋ 配套失败模式表**（B 批设计 §4），且要老板放行。
//
// 【诚实的边界说明 · 逐条】
//   ★ 它是 **shadow 档**：**只看只记、拦不住任何东西**。升级到 warn／enforce 要改脚本
//     ＋ 配套的失败模式表（缺一不许升）。
//   ★ isError 是**粗判** —— 有的桥把结构化结果**拍平成文本**（桥① `blocksToText`），
//     所以既认 payload 上的字段，也扫文本痕迹；文本命中一律标注「粗判」。
//   ★ 计数文件**无锁**：两个工具同时返回时可能少记一次（shadow 里它只是线索，不是判据）。
//   ★ `结果闸_shadow.jsonl` **只追加、会一直长**；`--看` 只读尾部 64KB，**绝不扫全量**。
//   ★ 写死的常量（要改就在上面那三张表改）：落点根／扫描上限 20 万字符／计数上限 600 键
//     （超了只留最热 300，冷键重新从 1 数起）／换路阈 3。
//   ★ **性能（1009 本机实测 · 读数会变）**：单跑中位 **~0.44 秒/次**（10 连跑 0.468）。
//     大头是 **node 进程启动 ~0.28 秒**，本脚本自己只加 ~0.1 秒，**而且不是落盘造成的**
//     （喂空 stdin、一次盘都不写，同价 0.40–0.43）—— 多出来的是 **ESM 启动**那一截。
//     ⇒ 所以「<100ms」靠 **spawn 一个 node 进程够不着**；要达标得走**常驻**（宿主内钩子），
//     不是把小脚本再瘦一圈。当前挂点 `timeout: 5` 秒 ⇒ 现开销约占 **9%**，能走。
// ═══════════════════════════════════════════════════════════════════════════════
import { readFileSync, appendFileSync, writeFileSync, renameSync, mkdirSync, openSync, readSync, closeSync, statSync } from 'node:fs'
import { createHash } from 'node:crypto'

// ── 判据表（改这里就是改判据；别处不许重写）───────────────────────────────────
const 截断标记 = ['truncated', '[截断]', '被截断', '内容过长', '已省略', '省略了']
const 危险正则 = [/\brm\b/, /\bdelete\b/i, /\bmove\b/i, /\bpatch\b/i, /\brestart\b/i, /结红/, /打烊/]
const 扫描上限 = 200000 // 文本扫描只取前 20 万字符（手机：内存与耗时都要省）
const 计数上限 = 600    // 计数键超它 ⇒ 只留最热的 300（冷键重新从 1 数起）
const 换路阈 = 3        // 同一键第 N 次（≥ 它）⇒ 只记一句「已达换路阈」

// ── 落点（默认逐字不变；沙盒自测可走 DSH_KICKOFF_WS 改道 —— 红线 19④）──────────
const 根 = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
let 账 = 根 + '/台账/接续/结果闸_shadow.jsonl'
let 计 = 根 + '/台账/接续/_结果闸_计数.json'

// ── 小工具 ────────────────────────────────────────────────────────────────────
const 现在 = () => new Date().toISOString()
const 目录 = (p) => p.slice(0, p.lastIndexOf('/'))

function 本地(iso) { // 印人话用：把 ISO 换成设备本地时间（偏移现算，不写死时区）
  const d = new Date(iso)
  if (isNaN(d.getTime())) return String(iso == null ? '' : iso)
  const 偏分 = -d.getTimezoneOffset()
  const 符 = 偏分 >= 0 ? '+' : '-'
  const 时 = String(Math.floor(Math.abs(偏分) / 60)).padStart(2, '0')
  const 分 = String(Math.abs(偏分) % 60).padStart(2, '0')
  const l = new Date(d.getTime() + 偏分 * 60000)
  return l.toISOString().replace('T', ' ').slice(0, 19) + ' (UTC' + 符 + 时 + ':' + 分 + ')'
}

// 规范化：对象按键排序、递归（数组保序 —— 数组顺序是语义的一部分）
function 规范化(v) {
  if (v === null || typeof v !== 'object') return v
  if (Array.isArray(v)) return v.map(规范化)
  const o = {}
  for (const k of Object.keys(v).sort()) o[k] = 规范化(v[k])
  return o
}

// 键 ＝ sha256(工具名 + '\n' + 规范化参数的 JSON) 前 16 位
function 算键(名, 参数) {
  let s
  try { s = JSON.stringify(规范化(参数 === undefined ? null : 参数)) } catch { s = String(参数) }
  return createHash('sha256').update(String(名) + '\n' + s).digest('hex').slice(0, 16)
}

// ── 状态：计数（键 → 次数）。坏了就重建，**不许崩** ──────────────────────────────
function 读计数() {
  try {
    const o = JSON.parse(readFileSync(计, 'utf8'))
    return (o && typeof o === 'object' && !Array.isArray(o)) ? o : {}
  } catch { return {} }
}

function 写计数(o) {
  try {
    if (Object.keys(o).length > 计数上限) {
      const 保 = Object.entries(o).sort((a, b) => b[1] - a[1]).slice(0, 300)
      o = Object.fromEntries(保)
    }
    mkdirSync(目录(计), { recursive: true })
    const 临 = 计 + '.tmp-' + process.pid
    writeFileSync(临, JSON.stringify(o))
    renameSync(临, 计) // 原子替换：半截文件不会被下一个进程读到
  } catch { /* 写不进去 ⇒ 记不上账，但**绝不许**把工具调用搞失败 */ }
}

function 落一行(行) {
  try {
    mkdirSync(目录(账), { recursive: true })
    appendFileSync(账, JSON.stringify(行) + '\n') // 只追加，不扫全量
  } catch { /* 只记录档：写失败也不许抛 */ }
}

// ── 三件检查（轻量：一次字符串扫描 ＋ 两个小文件读写）───────────────────────────
function 判(p, 原始, 畸形) {
  const 检查 = []
  let 键 = '-'
  let 名 = ''

  if (畸形) {
    检查.push('输入·不是JSON（钩子被喂了脏东西）')
    return { at: 现在(), 工具: '', 键, 检查, 结论: 'note' }
  }

  名 = typeof p.tool_name === 'string' ? p.tool_name : ''
  if (!名) 检查.push('输入·没有 tool_name（不像钩子 payload）')

  // ① 输出契约：截断痕迹 ＋ isError
  let 文本 = ''
  try {
    const r = p.tool_response
    文本 = typeof r === 'string' ? r : (r == null ? '' : JSON.stringify(r))
  } catch { 文本 = '' }
  const 扫 = 文本.length > 扫描上限 ? 文本.slice(0, 扫描上限) : 文本
  const 低 = 扫.toLowerCase()
  for (const m of 截断标记) {
    if (低.indexOf(m.toLowerCase()) >= 0) { 检查.push('契约·截断痕迹「' + m + '」·截断不算结论'); break }
  }
  const 字段档 = (p.isError === true || p.is_error === true)
  let isErr = 字段档
  if (!字段档) {
    try { isErr = /["']is_?error\\?["']\s*:\s*true/i.test(原始) } catch { isErr = false }
    // ↑ 文本痕迹：JSON 里嵌 JSON 时引号会被转义成 \" ⇒ 反斜杠要算进去（自测 ⑤ 实测过）
  }
  if (isErr) 检查.push('契约·出现 isError' + (字段档 ? '（字段）' : '（文本痕迹·粗判）'))

  // ② 重复调用：算键 ＋ 只追加／小文件计数
  try {
    if (名) {
      键 = 算键(名, p.tool_input)
      const c = 读计数()
      const n = (Number(c[键]) || 0) + 1
      c[键] = n
      写计数(c)
      if (n >= 2) 检查.push('重复·第' + n + '次同参数调用' + (n >= 换路阈 ? '（已达换路阈 ' + 换路阈 + ' · 只记）' : ''))
    }
  } catch { /* 计数出问题不拖累主判 */ }

  // ③ 失败分级：只在 isError 上判（粗判：工具名 ＋ 命令文本过危险词表）
  if (isErr) {
    let 面 = 名
    try {
      const t = p.tool_input
      const c = (t && typeof t.command === 'string') ? t.command : (t == null ? '' : JSON.stringify(t))
      面 = (名 + ' ' + c).slice(0, 2000)
    } catch { /* 用工具名兜底 */ }
    // ★ 1009 夜修正：错误串在 `tool_response` 里（不在 command 里）⇒ 另取一个「输出面」给可换路/可重试判。
    //   教训：不喂真 payload 就发现不了 —— 原来这两支永远不命中（1009 实测：No such file／timed out 都判成"普通失败"）。
    // ⚠️ 别用 `r` —— 它定义在 ① 的 try 块里（块作用域），出了块就 ReferenceError，被 catch 吞掉 ⇒ 输出面恒为空。
    //   改用 ① 已算好的 `文本`（同一份 tool_response，函数作用域）。
    const 输出面 = 文本.slice(0, 4000)
    const 危 = 危险正则.find((r) => { try { return r.test(面) } catch { return false } })
    // ★ 1009 G6：二档 → 三档（外部核裁决：可重试／可换路／必须停；破坏性动作禁止自动重试；「必须停」优先）
    // ⚠️ 1009 实测：`/timeout/i` 匹配不上 "timed out"（中间有空格）⇒ 补 `timed out`（这条是真 payload 喂出来的）
    const 可重试正则 = [/timeout|timed out/i, /ETIMEDOUT/, /\bbusy\b/i, /\blocked\b|\block\b/i, /EBUSY/, /temporar/i, /ECONN|EAI_AGAIN|network/i, /too many/i]
    const 可换路正则 = [/no such file|ENOENT/i, /not found/i, /permission denied|EACCES|EPERM/i, /invalid|argument|参数/i, /EISDIR|ENOTDIR/]
    const 试性 = 可重试正则.find((r) => { try { return r.test(输出面) } catch { return false } })
    const 换性 = 可换路正则.find((r) => { try { return r.test(输出面) } catch { return false } })
    if (危) 检查.push('失败分级·必须停「' + 危.source + '」·破坏性/未结红/打烊类 ⇒ 禁止自动重试（只记）')
    else if (换性) 检查.push('失败分级·可换路「' + 换性.source + '」·同参重试无意义（只记）')
    else if (试性) 检查.push('失败分级·可重试「' + 试性.source + '」·最多一次（只记，本档不自动执行）')
    else 检查.push('失败分级·普通失败')
  }

  return { at: 现在(), 工具: 名, 键, 检查, 结论: 检查.length ? 'note' : 'ok' }
}

// 一份 stdin（或样例）走完整条链：解析 → 判 → 落一行。空输入 ⇒ 静默返回 null（不落账）
function 处理(原始文本) {
  const 原始 = String(原始文本 == null ? '' : 原始文本).replace(/^\uFEFF/, '').trim()
  if (!原始) return null
  let p = null
  let 畸形 = false
  try { p = JSON.parse(原始) } catch { 畸形 = true }
  if (!畸形 && (p === null || typeof p !== 'object' || Array.isArray(p))) { 畸形 = true; p = null }
  const 行 = 判(p, 原始, 畸形)
  落一行(行)
  return 行
}

// ── stdin：读一段就够；带硬上限，**绝不死等**（钩子超时 5 秒，别把自己拖死）────────
function 读stdin(硬上限ms) {
  return new Promise((解决) => {
    let 文 = ''
    let 完 = false
    const 收 = () => { if (!完) { 完 = true; 解决(文) } }
    try {
      if (process.stdin.isTTY) return 收() // 手动跑、没管道 ⇒ 直接当空输入
      process.stdin.setEncoding('utf8')
      process.stdin.on('data', (d) => { if (文.length < 800000) 文 += d })
      process.stdin.on('end', 收)
      process.stdin.on('error', 收)
      const t = setTimeout(收, 硬上限ms)
      if (t.unref) t.unref()
    } catch { 收() }
  })
}

// ── 看：只读尾部 64KB，印人话 ─────────────────────────────────────────────────
function 读尾部(p, 上限) {
  let fd = -1
  try {
    fd = openSync(p, 'r')
    const sz = statSync(p).size
    if (sz <= 0) return ''
    const 起 = Math.max(0, sz - 上限)
    const buf = Buffer.alloc(Math.min(上限, sz))
    readSync(fd, buf, 0, buf.length, 起)
    let s = buf.toString('utf8')
    if (起 > 0) { const i = s.indexOf('\n'); if (i >= 0) s = s.slice(i + 1) } // 掐掉半行
    return s
  } catch { return null } finally { if (fd >= 0) { try { closeSync(fd) } catch {} } }
}

function 看(n) {
  const 文 = 读尾部(账, 65536)
  if (文 === null) { console.log('（还没有账：「' + 账 + '」不存在）'); return }
  const 行 = 文.split('\n').filter((x) => x.trim())
  const 尾 = 行.slice(-n)
  let 大小 = 0
  try { 大小 = statSync(账).size } catch {}
  console.log('结果闸 · shadow 账尾 ' + 尾.length + ' 行 ｜ ' + 账 + '（' + Math.round(大小 / 1024) + ' KB）')
  if (!尾.length) { console.log('  （账是空的）'); return }
  for (const s of 尾) {
    let o = null
    try { o = JSON.parse(s) } catch {}
    if (!o) { console.log('  ✗ 坏行：' + s.slice(0, 90)); continue }
    const 检查 = Array.isArray(o.检查) ? o.检查 : []
    console.log('  ' + 本地(o.at) + ' ｜ ' + (o.工具 || '(无工具名)') + ' ｜ 键 ' + (o.键 || '-') + ' ｜ ' + (o.结论 || '?'))
    for (const c of 检查) console.log('        · ' + c)
  }
}

// ── 自测：内置样例走**同一条**链（落点＝临时房，不碰生产账）────────────────────
function 自测() {
  const 生产账 = 账
  const 生产计 = 计
  const 房 = 根 + '/.tmp/结果闸-自测-' + process.pid
  let 对 = 0
  const 样例 = [
    { 说明: '① 正常调用（read）', 期望: [],
      文: JSON.stringify({ hook_event_name: 'PostToolUse', tool_name: 'read', tool_input: { file_path: '/x/y.md' }, tool_response: '文件内容正常，没有截断' }) },
    { 说明: '② isError（字段）＋ 危险命令 rm', 期望: ['契约·出现 isError（字段）', '失败分级·必须停「\\brm\\b」·破坏性/未结红/打烊类 ⇒ 禁止自动重试（只记）'],
      文: JSON.stringify({ hook_event_name: 'PostToolUse', tool_name: 'bash', tool_input: { command: 'rm -rf /tmp/x' }, tool_response: '删除失败', isError: true }) },
    { 说明: '③ 输出被截断（无 isError）', 期望: ['契约·截断痕迹「被截断」·截断不算结论'],
      文: JSON.stringify({ hook_event_name: 'PostToolUse', tool_name: 'bash', tool_input: { command: 'cat big.log' }, tool_response: '前 200 行……（输出被截断，全文见落盘）' }) },
    { 说明: '④ 与 ① 同参数再来一次（重复）', 期望: ['重复·第2次同参数调用'],
      文: JSON.stringify({ hook_event_name: 'PostToolUse', tool_name: 'read', tool_input: { file_path: '/x/y.md' }, tool_response: '文件内容正常，没有截断' }) },
    { 说明: '⑤ isError 只以文本痕迹出现（粗判）', 期望: ['契约·出现 isError（文本痕迹·粗判）', '失败分级·普通失败'],
      文: JSON.stringify({ hook_event_name: 'PostToolUse', tool_name: 'read', tool_input: { file_path: '/x/z.md' }, tool_response: '{"isError":true,"text":"读不到"}' }) },
    { 说明: '⑥ 阴性对照：危险命令但**没失败** ⇒ 不该报（参数与 ② 不同，别撞重复键）', 期望: [],
      文: JSON.stringify({ hook_event_name: 'PostToolUse', tool_name: 'bash', tool_input: { command: 'rm -rf /tmp/y' }, tool_response: '删除完成' }) },
    { 说明: '⑦ 畸形输入（不是 JSON）', 期望: ['输入·不是JSON（钩子被喂了脏东西）'],
      文: 'not json' },
  ]

  console.log('结果闸 · --自测（链路自证）')
  console.log('  生产落点（自测**不碰**）：' + 生产账)
  console.log('  自测落点（临时房）：' + 房)
  console.log('')
  try {
    账 = 房 + '/结果闸_shadow.jsonl'
    计 = 房 + '/_结果闸_计数.json'
    mkdirSync(房, { recursive: true })
  } catch (e) { console.log('  临时房建不起来（' + (e && e.message) + '）—— 自测不落盘，只判'); 账 = 生产账; 计 = 生产计 }

  for (const s of 样例) {
    let 行 = null
    try { 行 = 处理(s.文) } catch (e) { 行 = { 检查: ['自测异常：' + (e && e.message)], 结论: '?' } }
    const 检查 = Array.isArray(行 && 行.检查) ? 行.检查 : []
    const 好 = JSON.stringify(检查) === JSON.stringify(s.期望)
    if (好) 对++
    console.log('  ' + (好 ? '✅' : '❌') + ' ' + s.说明)
    console.log('     结论 ' + ((行 && 行.结论) || '?') + ' ｜ 键 ' + ((行 && 行.键) || '-'))
    console.log('     判出：' + (检查.length ? 检查.join(' ／ ') : '（无 · ok）'))
    if (!好) console.log('     期望：' + (s.期望.length ? s.期望.join(' ／ ') : '（无 · ok）'))
  }

  // 自证：账真长了行、计数真写了
  let 行数 = 0
  let 计数文 = '(读不到)'
  try { 行数 = readFileSync(账, 'utf8').split('\n').filter((x) => x.trim()).length } catch {}
  try { 计数文 = readFileSync(计, 'utf8') } catch {}
  console.log('')
  console.log('  账文件实写 ' + 行数 + ' 行（喂了 ' + 样例.length + ' 条 ⇒ 应 ' + 样例.length + ' 行）')
  console.log('  计数文件：' + 计数文)
  console.log('  自测结果：' + 对 + '/' + 样例.length + ' 对 ｜ 退出码 0（本档一律 0）')
  账 = 生产账
  计 = 生产计
  if (对 !== 样例.length) process.exitCode = 0 // 自测即使有偏差也仍 exit 0：本档不许有非 0 退出码
}

// ── 入口 ──────────────────────────────────────────────────────────────────────
const 参数 = process.argv.slice(2)

// 钩子档全兜底：任何异常都吞掉、退出码恒 0（fail-open 是硬要求）
process.on('uncaughtException', () => process.exit(0))
process.on('unhandledRejection', () => process.exit(0))
process.on('warning', () => {})

try {
  if (参数.includes('--自测')) {
    自测()
    process.exit(0)
  }
  if (参数.includes('--看')) {
    const i = 参数.indexOf('--看')
    const v = parseInt(参数[i + 1], 10)
    看(Number.isFinite(v) && v > 0 ? Math.min(v, 200) : 10)
    process.exit(0)
  }
  const 原始 = await 读stdin(2000)
  try { 处理(原始) } catch {}
} catch {}

process.exit(0)
