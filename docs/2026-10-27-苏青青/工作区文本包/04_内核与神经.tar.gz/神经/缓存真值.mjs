#!/usr/bin/env node
// 缓存真值.mjs · 1001 造（老板令「没验的去验一下」⇒ 验"前缀缓存到底命中没有"）
// ════════════════════════════════════════════════════════════════════════════
// 为什么要立这一件：我 1001 在体检报告里写过一句**没验的推断**——
//   「必读卡里混着每步都变的数字 ⇒ 系统提示词每步都变 ⇒ **前缀缓存每步作废**」。
//   日志里其实有真值字段（`assistant/message` 的 usage：`inputTokens` / `cacheReadTokens` / `totalTokens`）
//   ⇒ 这件事**本来就该用我们自己的数据判**，不该拿业界文档推。
//
// 判据（本文件只用日志真值，不用任何估算）：
//   每步命中率 = cacheReadTokens ÷ totalTokens          （totalTokens ≈ 缓存读 + 新入）
//   掉档步    = 命中率 < 阈值（默认 0.5）—— 那才是"缓存被破"的候选，再看它前后发生了什么
//
// 用法：
//   node 神经/缓存真值.mjs                 # 全部会话汇总
//   node 神经/缓存真值.mjs 3ed4c0fb        # 只看含该片段的会话（并列出调档步）
//   node 神经/缓存真值.mjs 3ed4c0fb --细   # 再逐帧找「每轮必读」在系统提示词里的位置
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { 解多帧 } from "./注入计量.mjs";

const H = process.env.DSH_HOME || path.join(os.homedir(), ".dsh");
const 片 = process.argv[2] && !process.argv[2].startsWith("--") ? process.argv[2] : "";
const 细 = process.argv.includes("--细");

function 找日志() {
  const 根 = path.join(H, "sessions");
  const 出 = [];
  for (const ws of fs.readdirSync(根)) {
    const p = path.join(根, ws);
    if (!fs.statSync(p).isDirectory()) continue;
    for (const s of fs.readdirSync(p)) {
      const d = path.join(p, s);
      if (!fs.statSync(d).isDirectory()) continue;
      if (片 && !s.includes(片)) continue;
      for (const f of fs.readdirSync(d)) if (f.endsWith(".zstd")) 出.push(path.join(d, f));
    }
  }
  return 出;
}

const 步 = [];       // {会话, seq, 新入, 缓存读, 合计}
const 帧表 = [];
for (const f of 找日志()) {
  let r; try { r = 解多帧(fs.readFileSync(f)); } catch { continue; }
  const 名 = path.basename(path.dirname(f));
  for (const l of r.文本.split("\n")) {
    if (!l.trim().startsWith("{")) continue;
    let e; try { e = JSON.parse(l); } catch { continue; }
    if (e.type === "assistant/message") {
      const 找用 = (o) => {
        if (!o || typeof o !== "object") return null;
        if (Array.isArray(o)) { for (const x of o) { const y = 找用(x); if (y) return y; } return null; }
        if (o.inputTokens !== undefined) return o;
        for (const k of Object.keys(o)) { const y = 找用(o[k]); if (y) return y; }
        return null;
      };
      const u = 找用(e);
      if (u && u.totalTokens) 步.push({ 会话: 名, seq: e.seq, 新入: u.inputTokens || 0, 缓存读: u.cacheReadTokens || 0, 合计: u.totalTokens, 出: u.outputTokens || 0 });
    } else if (e.type === "request/header") {
      const sp = JSON.stringify(e.data ?? e);
      帧表.push({ 会话: 名, seq: e.seq, sp, 长度: sp.length });
    }
  }
}

if (!步.length) { console.log("🔴 一步 usage 都没读到 ⇒ 别下结论（先查路径/身份）"); process.exit(1); }
const 命中 = (s) => (s.合计 ? s.缓存读 / s.合计 : 0);
const 排序 = [...步].sort((a, b) => 命中(a) - 命中(b));
const 总 = 步.reduce((a, s) => ({ 新入: a.新入 + s.新入, 缓存读: a.缓存读 + s.缓存读, 合计: a.合计 + s.合计, 出: a.出 + s.出 }), { 新入: 0, 缓存读: 0, 合计: 0, 出: 0 });

console.log("══ 缓存真值（只读会话日志，零估算）══");
console.log(`会话 ${new Set(步.map((s) => s.会话)).size} 个 ｜ 步 ${步.length} 步`);
console.log(`合计：新入 ${总.新入.toLocaleString()} ｜ 缓存读 ${总.缓存读.toLocaleString()} ｜ 总输入 ${总.合计.toLocaleString()} ｜ 输出 ${总.出.toLocaleString()}`);
console.log(`★ 全窗缓存命中率 ＝ ${(总.缓存读 / 总.合计 * 100).toFixed(2)}%`);
console.log(`★ 每步命中率：最低 ${(命中(排序[0]) * 100).toFixed(1)}% ｜ 中位 ${(命中(排序[Math.floor(排序.length / 2)]) * 100).toFixed(1)}% ｜ 最高 ${(命中(排序[排序.length - 1]) * 100).toFixed(1)}%`);
const 掉档 = 排序.filter((s) => 命中(s) < 0.5);
console.log(`★ 掉档步（命中 <50%）：${掉档.length} 步${掉档.length ? "（看 seq：那就是缓存被破的时刻）" : " ⇒ **一步都没有**"}`);
for (const s of 掉档.slice(0, 12)) console.log(`    ${s.会话.slice(0, 22)} seq=${s.seq} 命中 ${(命中(s) * 100).toFixed(0)}% ｜ 新入 ${s.新入.toLocaleString()} ｜ 缓存读 ${s.缓存读.toLocaleString()}`);

if (细) {
  console.log("\n── 细：每轮必读在请求里的位置 ──");
  const 帧 = 帧表.filter((f) => f.sp.includes("每轮必读"));
  console.log(`含「每轮必读」的 request/header 帧：${帧.length} / ${帧表.length}`);
  for (const f of 帧.slice(-3)) {
    const i = f.sp.indexOf("每轮必读");
    const 变量位 = f.sp.slice(i, i + 4000).search(/内核 \d+ 条|算于 \d+:\d+/);
    console.log(`  ${f.会话.slice(0, 22)} seq=${f.seq} ｜ header ${f.长度.toLocaleString()} 字符 ｜ 「每轮必读」在第 ${i} 字符（${(i / f.长度 * 100).toFixed(1)}%）｜ 其后 4000 字内出现的变量字样位置：${变量位 < 0 ? "无" : 变量位}`);
  }
}
