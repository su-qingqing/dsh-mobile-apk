#!/usr/bin/env node
// 神经/耗量.mjs —— ★ 本窗真账（token）★ 降本增效的账本，2026-09-27 建
//
// 口径（与前两把尺子都不同层，别混着引用）：
//   ① 旧口径 contains（09-27 12:58 之前那 6 条基线）
//   ② 抬头锚定 200 字（`注入计量.mjs` 默认；12:58 那两条 -新口径）
//   ③ ★ 本工具：**引擎自报的 usage**（日志里每条 assistant/message 与 compaction/summary 都带）
//      —— 单位是 token，是账单本身的单位，**不做任何"字→token"折算**。
//
// 为什么要有它：老板付的是 token，我以前全在算字符（要拿 4.87 字/token 去折）。
//   2026-09-27 实测本窗：usage 记录 1,861 条 ⇒ 真账可直接读，不必折。
//   铁律 **#47（不空转）／#13（不许"我以为"）**：报数只许来自本工具当场跑出来的原始值。
//
// 跑法：
//   node 神经/耗量.mjs              # 本窗（优先 $DSH_SESSION_ID，落空取最新，同 `注入计量.mjs`）
//   node 神经/耗量.mjs <会话号>      # 点名某窗（写 session-xxxx 或 xxxx 都行）
//   node 神经/耗量.mjs selftest      # 自检（夹具判绿 · 含"没有 usage 不许印 0"的反证）
//
// ★ 判据是"正向信号"：本工具只认「真的读到 usage 记录」；一条都读不到 ⇒ 报 ❌，不许印一排 0 糊过去。

import fs from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'
import { 找日志, 解多帧 } from './注入计量.mjs'

export const 版本 = '2026-09-27 13:3x'

// ── 取用量的那一个对象（日志里位置不固定：data.usage / data.message.usage 都出现过）──────
export function 取用量(o, 深 = 0) {
  if (!o || typeof o !== 'object' || 深 > 5) return null
  if (o.inputTokens !== undefined && o.outputTokens !== undefined) return o
  for (const k of Object.keys(o)) {
    const hit = 取用量(o[k], 深 + 1)
    if (hit) return hit
  }
  return null
}

const 数 = (x) => Number(x || 0)
const 均 = (a) => (a.length ? Math.round(a.reduce((s, x) => s + x, 0) / a.length) : 0)
const 分位 = (排, p) => (排.length ? 排[Math.min(排.length - 1, Math.floor(排.length * p))] : 0)

// ── 汇总（纯函数 · 自检直接喂夹具）────────────────────────────────────────────
export function 汇总(事件们) {
  const 类 = {}          // 类名 → { 次, 入, 出, 缓存读, 思考 }
  const 步 = []          // 每步上下文（入＋缓存读＋出）
  const 轮 = new Set()
  let 事件总数 = 0, 无用量 = 0
  for (const e of 事件们) {
    if (!e || typeof e !== 'object') continue
    事件总数++
    const u = 取用量(e)
    if (!u) { 无用量++; continue }
    const 名 = e.type === 'compaction/summary' ? '压缩'
      : e.type === 'assistant/message' ? '正常'
        : '其它（' + e.type + '）'
    const a = 类[名] = 类[名] || { 次: 0, 入: 0, 出: 0, 缓存读: 0, 思考: 0 }
    a.次++
    a.入 += 数(u.inputTokens); a.出 += 数(u.outputTokens)
    a.缓存读 += 数(u.cacheReadTokens) || 数(u.cachedTokens)
    a.思考 += 数(u.reasoningTokens)
    if (e.type === 'assistant/message') {
      if (e.data && e.data.turn !== undefined) 轮.add(e.data.turn)
      步.push(数(u.inputTokens) + (数(u.cacheReadTokens) || 数(u.cachedTokens)) + 数(u.outputTokens))
    }
  }
  const 排 = 步.slice().sort((a, b) => a - b)
  const 合 = { 次: 0, 入: 0, 出: 0, 缓存读: 0, 思考: 0 }
  for (const a of Object.values(类)) { 合.次 += a.次; 合.入 += a.入; 合.出 += a.出; 合.缓存读 += a.缓存读; 合.思考 += a.思考 }
  return { 类, 合, 步数: 步.length, 轮数: 轮.size, 事件总数, 无用量, 每步: { 均: 均(步), 中位: 分位(排, 0.5), 九成: 分位(排, 0.9), 峰: 排.length ? 排[排.length - 1] : 0, 尾100: 均(步.slice(-100)), 尾20: 均(步.slice(-20)) } }
}

// ── 印 ────────────────────────────────────────────────────────────────────
const 千 = (n) => Number(n).toLocaleString('en-US')
export function 印(R, L, 签 = '') {
  const t = new Date()
  const hm = String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0')
  console.log('★ 本窗真账（token · 引擎自报 usage）' + (签 ? ' · ' + 签 : ''))
  if (L && L.文件) console.log('日志：' + L.文件.replace(/^.*\/sessions\//, 'sessions/') + ' ｜ ' + (L.大小 || '') + ' ｜ 算于 ' + hm)
  if (!R.合.次) { console.log('❌ 一条 usage 都没读到（' + R.事件总数 + ' 行事件）⇒ 不许印 0 当"没花钱"，要么口径错、要么日志代不同。'); return }
  console.log('轮 ' + R.轮数 + ' ｜ 步 ' + R.步数 + ' ｜ 带用量事件 ' + R.合.次 + '（无用量 ' + R.无用量 + ' 行）')
  console.log('每步上下文（入＋缓存读＋出）：中位 ' + 千(R.每步.中位) + ' ｜ 均 ' + 千(R.每步.均) + ' ｜ 90% ' + 千(R.每步.九成) + ' ｜ 峰 ' + 千(R.每步.峰) + ' ｜ 尾100步 ' + 千(R.每步.尾100))
  for (const [k, a] of Object.entries(R.类).sort((x, y) => y[1].入 - x[1].入)) {
    const 占 = (v) => ((v / R.合.入) * 100).toFixed(1) + '%'
    console.log('  ' + k.padEnd(16) + ' 次 ' + String(a.次).padStart(5) + ' ｜ 新入 ' + 千(a.入).padStart(13) + '（' + 占(a.入) + '）｜ 出 ' + 千(a.出).padStart(10) + ' ｜ 缓存读 ' + 千(a.缓存读).padStart(13))
  }
  console.log('合计：新入 ' + 千(R.合.入) + ' ｜ 出 ' + 千(R.合.出) + '（其中思考 ' + 千(R.合.思考) + ' ＝ ' + ((R.合.思考 / (R.合.出 || 1)) * 100).toFixed(1) + '%）｜ 缓存读 ' + 千(R.合.缓存读))
  console.log('⇒ 钱 ≈ Σ(每步上下文 × 步数)：减步数／降每步上下文／换窗 —— 三条路，别的都不动账。')
}

// ── 自检 ──────────────────────────────────────────────────────────────────
function 自检() {
  const 绿 = [], 红 = []
  const 判 = (名, 过, 证) => (过 ? 绿 : 红).push(名 + (证 ? '  ← ' + 证 : ''))
  // 夹具①：两条正常 + 一条压缩，用法藏在 data.message.usage（真日志的放法）
  const F1 = [
    { type: 'assistant/message', data: { turn: 1, message: { role: 'assistant', usage: { inputTokens: 100, outputTokens: 10, cacheReadTokens: 1000, reasoningTokens: 6 } } } },
    { type: 'assistant/message', data: { turn: 1, message: { usage: { inputTokens: 200, outputTokens: 20, cacheReadTokens: 2000, reasoningTokens: 4 } } } },
    { type: 'compaction/summary', data: { usage: { inputTokens: 50, outputTokens: 5, cacheReadTokens: 500 } } },
    { type: 'tool/result', data: { 没用量: true } },
  ]
  const r1 = 汇总(F1)
  判('① 次/入/出 算对', r1.合.次 === 3 && r1.合.入 === 350 && r1.合.出 === 35, r1.合.入 + '/' + r1.合.出)
  判('② 压缩单独成类', r1.类['压缩'] && r1.类['压缩'].次 === 1 && r1.类['正常'].次 === 2)
  判('③ 每步上下文＝入＋缓存读＋出', r1.每步.均 === Math.round(((100 + 1000 + 10) + (200 + 2000 + 20)) / 2), String(r1.每步.均))
  判('④ 轮数去重', r1.轮数 === 1, String(r1.轮数))
  判('⑤ 思考占比有数', r1.合.思考 === 10, String(r1.合.思考))
  // 夹具②：没有 usage ⇒ 不许印 0 当结论（合.次 必须 0，且 无用量 要数出来）
  const r2 = 汇总([{ type: 'assistant/message', data: {} }, { type: 'turn/start', data: {} }])
  判('⑥ 没 usage 时合.次=0 且 无用量=2', r2.合.次 === 0 && r2.无用量 === 2, r2.合.次 + '/' + r2.无用量)
  // 夹具③：同一事件里 usage 出现两处 ⇒ 只算一次（防重复计费）
  const r3 = 汇总([{ type: 'assistant/message', data: { usage: { inputTokens: 7, outputTokens: 1 }, message: { usage: { inputTokens: 7, outputTokens: 1 } } } }])
  判('⑦ 双份 usage 只算一次', r3.合.入 === 7 && r3.合.次 === 1, String(r3.合.入))
  // 夹具④：只有一半字段（缺 outputTokens）⇒ 不认
  判('⑧ 半个 usage 不认', 取用量({ usage: { inputTokens: 5 } }) === null)
  // 源码锚：import 即跑不许印话（本文件必须带入口守卫）
  const 源 = fs.readFileSync(new URL(import.meta.url), 'utf8')
  判('⑨ 入口守卫在（import 不印话）', 源.includes('import.meta.url === pathToFileURL'))
  判('⑩ 用的是真源解析器（不自己解 zstd）', 源.includes("from './注入计量.mjs'"))
  for (const g of 绿) console.log('✅ ' + g)
  for (const b of 红) console.log('❌ ' + b)
  console.log(红.length ? '❌ 自检 ' + 红.length + ' 条红' : '✅ 自检 ' + 绿.length + ' 条全绿')
  return 红.length === 0
}

// ── 主 ────────────────────────────────────────────────────────────────────
function 主() {
  const 参 = process.argv[2] || ''
  if (参 === 'selftest' || 参 === '自检') process.exit(自检() ? 0 : 1)
  const L = 找日志(参)
  if (L.错) { console.log('❌ ' + L.错); process.exit(1) }
  let 文本 = ''
  try { 文本 = 解多帧(fs.readFileSync(L.文件)).文本 } catch (e) { console.log('❌ 解不开日志：' + e.message); process.exit(1) }
  const 事件们 = 文本.split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } })
  let 大小 = ''
  try { 大小 = (fs.statSync(L.文件).size / 1048576).toFixed(1) + ' MB' } catch {}
  印(汇总(事件们), { ...L, 大小 }, L.点名 ? L.会话 : '')
}

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) 主()
