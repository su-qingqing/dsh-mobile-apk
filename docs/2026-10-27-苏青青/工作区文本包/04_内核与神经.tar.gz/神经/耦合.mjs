#!/usr/bin/env node
/**
 * 耦合.mjs —— 内核 #68「四模块耦合（四问四格）」的**机器面**（2026-09-27 夜建）
 *
 * ★ 为什么有它：老板 09-27 夜重申（原话）「每一个模块都是内部制成一个体系的，里面的闸门跟尺子
 *   对应的是里面的自我的一个逻辑闭环……四个大模块逻辑闭环，然后四个大模块加起来，整体的一个
 *   逻辑闭环；如果你单一改动一个地方，不与其他的地方联动的话，会导致一个耦合的问题」。
 *   实测：内核 #68（老板 09-21 亲定）此前**零机器面** —— 流程真源 52 条 0 命中「耦合/闭环」、
 *   工具侧 0 个 .mjs/.json 引用它 ⇒ 这正是「嘴挂上了、动作没挂」的必然根因。本仪器＝给 #68 接动作面。
 *
 * ★ 铁律（防"同一件事两个答案"）：**判据只从本尊读** —— 四问的名字、判据话术，一律从
 *   `内核/内核.md` 的 #68 那一条**现读现印**，本文件里**绝不重写**一份。
 *
 * 用法：
 *   node 神经/耦合.mjs            # 印本尊四问 ＋ 数耦合单；缺格 ⇒ 退出码 1
 *   node 神经/耦合.mjs 本尊        # 只印本尊那一条（供别的挂点直接取）
 *   node 神经/耦合.mjs 核          # 只报数（一行，机器读）
 *   node 神经/耦合.mjs selftest    # 双态自证：填满 ⇒ 不算缺；缺一格 ⇒ 算缺
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const 根 = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const P = (p) => path.join(根, p)
const 本尊路径 = '内核/内核.md'
const 单路径 = '台账/接续/耦合单.md'

/** 从本尊（内核/内核.md）现读 #68 那一条 —— 不在本文件里重写判据 */
export function 读本尊() {
  let 行s
  try { 行s = fs.readFileSync(P(本尊路径), 'utf8').split('\n') } catch { return null }
  const i = 行s.findIndex((l) => /^68\.\s/.test(l))
  if (i < 0) return null
  let j = i + 1
  while (j < 行s.length && !/^\d+\.\s/.test(行s[j])) j++
  const 段 = 行s.slice(i, j).join('\n')
  const 四问 = [...段.matchAll(/[①②③④]\s*\*\*(.+?)\*\*\s*→\s*\*\*(.+?)\*\*/g)].map((m) => ({ 问: m[1], 层: m[2] }))
  const 首句 = ((段.match(/^68\.\s*(.+)/) || [])[1] || '').replace(/\*\*/g, '')
  const 判据 = ((段.match(/\*\*判据\*\*：(.+)/) || [])[1] || '').replace(/\*\*/g, '')
  return { 段, 四问, 首句, 判据, 行: i + 1 }
}

/** 一行耦合单 → 缺哪几格（**selftest 与主流程共用这一个函数**，防两把尺子） */
export function 判行(l) {
  const c = l.split('|').map((x) => x.trim()).filter((x, i, a) => !(x === '' && (i === 0 || i === a.length - 1)))
  const 名 = c[1] || '?'
  const 格 = c.slice(2, 6)
  const 空格 = 格.map((g, k) => (!g || g.includes('⬜') ? k + 1 : 0)).filter(Boolean)
  return { 名, 空格 }
}

/** 数耦合单：一行一件·四格（法／记忆／神经／动作） */
export function 数耦合单() {
  const p = P(单路径)
  if (!fs.existsSync(p)) return { 在: false, 总: 0, 缺: [] }
  const 行s = fs.readFileSync(p, 'utf8').split('\n').filter((l) => /^\|\s*\d+\s*\|/.test(l)).map(判行)
  return { 在: true, 总: 行s.length, 缺: 行s.filter((x) => x.空格.length) }
}

// ── 主流程：**只在「直接跑这个文件」时执行** ────────────────────────────────────
//   ⚠️ 09-27 夜实测踩过：没有这道守卫时，打烊/必读卡一 `import` 本文件，顶层就会跑主流程、
//   连 `process.exit(1)` 一起执行 ⇒ **把调用方的进程当场杀掉**（打烊只印了本尊两行就没了、
//   必读卡重建静默失败）。**判据：模块被 import ⇒ 只导出函数，不许有副作用。**
const 是主脚本 = (() => {
  try { return !!process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url) } catch { return false }
})()
if (是主脚本) {
const arg = process.argv[2] || ''
const 本 = 读本尊()
if (!本) { console.log('✗ 读不到内核 #68 本尊（`' + 本尊路径 + '` 里没有 `68. ` 起头那条）—— 先修真源'); process.exit(2) }

if (arg === '本尊') { console.log(本.段); process.exit(0) }

if (arg === 'selftest') {
  const 满 = 判行('| 1 | 合成·填满 | 红线层 | 每轮真动内部件后 | 打烊 §四之四 印 | 报红点名 |')
  const 缺一 = 判行('| 2 | 合成·缺一格 | 红线层 | ⬜ | 打烊 §四之四 印 | 报红点名 |')
  const ok = 满.空格.length === 0 && 缺一.空格.length === 1
  console.log((ok ? '✅' : '✗') + ' selftest：填满⇒缺 ' + 满.空格.length + ' 格（应 0）｜缺一格⇒缺 ' + 缺一.空格.length + ' 格（应 1）')
  process.exit(ok ? 0 : 1)
}

const 单 = 数耦合单()
if (arg === '核') {
  console.log('四模块耦合：本尊 #68 在' + (本 ? '' : '✗') + ' ｜ 耦合单 ' + (单.在 ? 单.总 + ' 件 · 缺格 ' + 单.缺.length : '**不在**'))
  process.exit(单.缺.length || !单.在 ? 1 : 0)
}

console.log('【四模块耦合】内核 #68 本尊（`' + 本尊路径 + '` 第 ' + 本.行 + ' 行 · 判据现读、本仪器不重写）：')
console.log('  ' + 本.首句)
本.四问.forEach((q, i) => console.log('  ' + '①②③④'[i] + ' ' + q.问 + ' → ' + q.层))
if (本.判据) console.log('  判据：' + 本.判据)
console.log('')
if (!单.在) {
  console.log('⚠ `' + 单路径 + '` 不在 —— 本窗若动过内部件，先建它（一行一件 · 四格）')
  process.exit(1)
}
console.log('耦合单：本窗动过 **' + 单.总 + '** 件内部件 · 缺格 **' + 单.缺.length + '** 件')
单.缺.forEach((x) => console.log('  ✗ ' + x.名 + '（缺第 ' + x.空格.join('、') + ' 格）'))
process.exit(单.缺.length ? 1 : 0)
}
