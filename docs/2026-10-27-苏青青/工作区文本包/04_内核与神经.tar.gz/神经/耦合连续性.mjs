#!/usr/bin/env node
/**
 * 耦合连续性体检 —— 改任何生产件／删任何格之前的**第一步**（老板 1010 令「这肯定要落成件」
 *   ＋「不要拿你以为的事实条件去做前置判断」＝红线 13；判据＝没他揪也不会出事）
 * 用法：node 神经/耦合连续性.mjs 查 <路径或词>
 * 退出码：0=两栏都空（可动）｜1=有人读/有人翻（先处置：不许切上游）｜2=判据读不到（fail-closed 红，绝不当绿）
 */
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const WS = process.env.DSH_KICKOFF_WS || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const P = (r) => path.join(WS, r)
const 词 = process.argv.slice(2).filter((x) => x !== '查').join(' ').trim()

if (!词) { console.log('用法：node 神经/耦合连续性.mjs 查 <路径或词>'); process.exit(2) }

// ★ fail-closed：先确认"要扫的目录真的在"，读不到 ⇒ 报红，绝不静默当绿（记忆 0mv191v0w ②）
const 机器目录 = ['工具']
const 人类目录 = ['台账/接续', '台账/轮末', '内核']
const 缺 = [...机器目录, ...人类目录].filter((d) => !fs.existsSync(P(d)))
if (缺.length) { console.log('🔴 fail-closed：要扫的目录读不到 ⇒ 判据失效，不许当绿：' + 缺.join('、')); process.exit(2) }

const 扫 = (dirs) => {
  const 命中 = new Set()
  for (const d of dirs) {
    let out = ''
    try {
      out = execFileSync('grep', ['-rl', 词, P(d)], { encoding: 'utf8', timeout: 60000, maxBuffer: 8e6, stdio: ['ignore', 'pipe', 'ignore'] })
    } catch (e) {
      if (e.status === 1) continue            // rc=1 ⇒ 没匹配＝正常的"空"
      throw e                                  // 其它（rc≥2／超时／spawn 失败）⇒ 真出事
    }
    out.split('\n').filter(Boolean).forEach((f) => 命中.add(path.relative(WS, f)))
  }
  // ★ 1010 夜：**消费者的口径一次定死**（不干净 ⇒ 门会误拦 ⇒ 我早晚开始忽略它 ⇒ 又变成"高级的灯"）：
  //   算消费者＝代码/配置件里的**真引用**；**不算**＝① 备份 ② 临时目录 ③ 取证/留样 ④ 池子内部件
  //   ⑤ **数据档**（.db/.db-wal/.jsonl/.log/媒体：它们是数据，不"读它当前内容"）⑥ 试验场 ⑦ 被查件自身。
  return [...命中].filter((f) => !/\.bak-|_backup\/|\/tmp\/|\/_tmp\/|\/取证\/|\/留样\/|\/池子\/_|\/试验场\//.test(f)
    && !/\.(db|db-wal|db-shm|jsonl|log|zst|png|jpg|jpeg|webp|gif|mp3|mp4|wav)$/i.test(f)
    && !f.endsWith(词)).sort()
}

let 机 = [], 人 = []
try { 机 = 扫(机器目录); 人 = 扫(人类目录) } catch (e) {
  console.log('🔴 fail-closed：扫描本身失败 ⇒ 不许当绿：' + String((e && e.message) || e).slice(0, 120)); process.exit(2)
}

console.log('【耦合连续性体检】词＝' + 词)
console.log('【机器栏】谁把它当上游/下游（' + 机.length + ' 件）')
机.length ? 机.slice(0, 25).forEach((x) => console.log('  · ' + x)) : console.log('  （空）')
console.log('【人栏】谁在交接/打烊/内核物里翻它（' + 人.length + ' 件）')
人.length ? 人.slice(0, 25).forEach((x) => console.log('  · ' + x)) : console.log('  （空）')
console.log('')
// ★ 1010 加：目标"像路径却不存在" ⇒ 先提示"你可能打错了"。
//   否则下面那句"两栏都空 ⇒ 可以动"会被误读成"没连带面"（红线 13：不许拿"我以为"干活）。
const 像路径 = /[\/]/.test(词) || /\.(mjs|js|cjs|json|jsonl|md|ya?ml)$/.test(词)
let 目标在 = true
try { 目标在 = fs.existsSync(path.isAbsolute(词) ? 词 : path.join(WS, 词)) } catch { 目标在 = true }
if (词 && 像路径 && !目标在) console.log('⚠️ **目标不存在**：`' + 词 + '` 在盘上找不到（打错了？路径以工作区为根）⇒ 下面两栏为空 **不代表"没连带面"**，先把名字弄对')
if (机.length) console.log('🔴 有机器消费者 ⇒ **不许切上游**：动了就得连带改这些件，并逐件复验（红线 22／内核 #68）')
else if (人.length) console.log('🟡 只有人消费者 ⇒ **只许"少重抄、多指路"，不许并／删**（记忆 0mv1976iq「记录 ≠ 零件」）')
else console.log('✅ 两栏都空 ⇒ 可以动（仍要先备份＋跑沙盒，红线 5／19）')
process.exit(机.length ? 1 : 0)
