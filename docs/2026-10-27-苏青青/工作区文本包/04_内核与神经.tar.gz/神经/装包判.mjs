#!/usr/bin/env node
// ── 装包判（B11 体检门）────────────────────────────────────────────────────
// 行为规矩 B11：「不在这个 Termux 前缀跑 `pkg upgrade`／装新包 —— 要装先问老板」
//   ⇒ 判据：**本工作区最新那份会话日志**里，`tool/call` 的 bash 命令有没有命中**装包禁词**。
//   用法：node 神经/装包判.mjs [会话日志路径] [--静]
//         不给路径 ⇒ 自己找本工作区**最新**那份会话日志。
//   退出码：0 = 全绿 ｜ 1 = 有命中 ｜ 2 = 没东西可查（**不是通过**）。
//
// 【四模块耦合】
//   法（判据住在哪）：本文件，且只在本文件；判据＝下面 `禁词` 一张表。
//     ① 事件源：会话日志（zstd）里 `tool/call` 的 `arguments.command`（与 B07 门同一条路子）。
//     ② 只禁**系统级包管理器**（pkg／apt／pip／gem 的 install／upgrade）——
//        **不禁 `npm install`／`pnpm install`**：那是本工作区的常规动作，禁了就是假阳性。
//     ③ 命中方式：命令文本小写后 `includes` 禁词；一条命令命中一次，去重后报。
//   记忆（什么时候用它）：怀疑"我们在这个前缀装过东西"时；开工／收轮核 B11 时；`--静` 给挂点。
//   神经（怎么自己响）：⚠️ **本件刚落产物、挂点还没接**（孤儿件，同 B07 起步时）⇒ 建议挂
//     「开工一屏／轮末自检」：`node 神经/装包判.mjs --静`（绿时零字，只靠退出码）；
//     读它落盘的 `台账/接续/装包判.json`（别重算判据）。**挂上之后本行才许改**。
//   动作（没做到怎么办）：红了 ⇒ 停手，把"装了什么、为什么装"写成一句话给老板，
//     并**先问能不能留**（红线 6：先问后做）；孤儿状态本身也要如实说。
//
// 注：日志是**多帧 zstd**，一次解不开就如实退 2（**不许把"没查到"当"没装过"**）。
import { readFileSync, writeFileSync, readdirSync, statSync, mkdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { zstdDecompressSync } from 'node:zlib'

const H = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const 根 = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const argv = process.argv.slice(2)
const 静 = argv.includes('--静')
const 给路径 = argv.find((a) => !a.startsWith('--'))

const 禁词 = ['pkg install', 'pkg upgrade', 'pkg uninstall', 'apt install', 'apt-get install', 'apt upgrade', 'pip install', 'pip3 install', 'gem install']

function 找日志() {
  if (给路径) return 给路径
  // ★ 1010 修 P1「串台」：旧逻辑遍历所有窗取 mtime 最新 ⇒ 多窗并行时会看**别人的窗**。
  //   现在优先认本窗（引擎给的 DSH_SESSION_ID）；认不出才退回"取全局最新"。
  const 本窗 = process.env.DSH_SESSION_ID || ''
  if (本窗) {
    try {
      for (const d of readdirSync(join(H, 'sessions'))) {
        for (const 候选 of ['session-' + 本窗, 本窗]) {
          const p = join(H, 'sessions', d, 候选)
          let files = []
          try { files = readdirSync(p).filter((f) => f.endsWith('.zstd')) } catch { continue }
          let 最好内 = null, 内时 = 0
          for (const f of files) {
            const fp = join(p, f)
            try { const m = statSync(fp).mtimeMs; if (m > 内时) { 内时 = m; 最好内 = fp } } catch { /* 跳过读不到的 */ }
          }
          if (最好内) return 最好内
        }
      }
    } catch { /* 认不出本窗 ⇒ 退回老逻辑 */ }
  }
  const 基 = join(H, 'sessions', '--storage-emulated-0-3--')
  let best = null
  try {
    for (const d of readdirSync(基)) {
      const p = join(基, d)
      let files = []
      try { files = readdirSync(p).filter((f) => f.endsWith('.zstd')) } catch { continue }
      for (const f of files) {
        const fp = join(p, f)
        try { const m = statSync(fp).mtimeMs; if (!best || m > best.m) best = { m, fp } } catch { /* 跳过读不到的 */ }
      }
    }
  } catch { /* 目录不在 ⇒ 下面退 2 */ }
  return best ? best.fp : null
}

function 解(path) {
  const buf = readFileSync(path)
  try { return zstdDecompressSync(buf).toString('utf8') } catch { return null } // 多帧／损坏 ⇒ null（如实退 2）
}

function main() {
  const path = 找日志()
  if (!path) { if (!静) console.log('⚪ 装包判：找不到会话日志（**不是通过**，是没东西可查）'); process.exit(2) }
  const text = 解(path)
  if (text == null) { if (!静) console.log('⚪ 装包判：日志解不开（多帧 zstd／损坏）⇒ 没东西可查，**不是通过**'); process.exit(2) }

  const 命中 = []
  for (const line of text.split('\n')) {
    if (!line || line[0] !== '{') continue
    let o = null
    try { o = JSON.parse(line) } catch { continue }
    const ev = o && o.event ? o.event : o
    const 名 = ev && (ev.type || ev.kind)
    if (名 !== 'tool/call') continue
    const 参 = (ev.data && ev.data.arguments) || ev.arguments || null
    let cmd = ''
    try { cmd = (参 && typeof 参.command === 'string') ? 参.command : (参 == null ? '' : JSON.stringify(参)) } catch { cmd = '' }
    const 低 = cmd.toLowerCase()
    const 词 = 禁词.find((w) => 低.includes(w))
    if (词) 命中.push({ 词, cmd: cmd.slice(0, 160) })
  }
  const 去重 = []
  const 见过 = new Set()
  for (const h of 命中) { const k = h.词 + '|' + h.cmd; if (!见过.has(k)) { 见过.add(k); 去重.push(h) } }

  try {
    mkdirSync(dirname(join(根, '台账/接续/装包判.json')), { recursive: true })
    writeFileSync(join(根, '台账/接续/装包判.json'), JSON.stringify({
      at: new Date().toISOString().slice(0, 16).replace('T', ' '),
      日志: path, 命中数: 去重.length, 命中: 去重.slice(0, 20),
    }, null, 1))
  } catch { /* 落盘失败不影响判定，但下面会说明 */ }

  if (去重.length) {
    console.log('⛔ **装包判 · B11 违规**（这个 Termux 前缀不许装包，要装先问老板）')
    for (const h of 去重.slice(0, 8)) console.log('   ·「' + h.词 + '」← ' + h.cmd)
    process.exit(1)
  }
  if (!静) console.log('✅ 装包判：最新日志里没有系统级装包命令（npm/pnpm 不算）')
  process.exit(0)
}
main()
