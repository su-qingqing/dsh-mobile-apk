#!/usr/bin/env node
// 解析体检（2026-09-23 建）—— 「改完配置，验证它还能不能被解析」（钉子户板 0mu8y8vh2 的第三步）
// 为什么：备份 ＋ 精确替换只保证**字节对了**，不保证**这份 YAML/JSON 还有人读得懂**
//   （少一层缩进、多一个中文引号：全是"改完当场不报错、下次启动才炸"的那种）。
// 四档口径，**不许假绿**：
//   ok   ＝ 解析器读通（JSON 走内建；YAML 借用**引擎自带**的解析器 —— 只读借用、不新装包；许可 ISC/MIT）
//        ⚠️ 只说"**能被解析器读通**"，**不等于**"这份配置语义没问题"（口径收紧，2026-09-23）
//   黄   ＝ 两个库结论不一致（**明说、不静默、不拦**；宿主用哪个库就以哪个为准）
//   红   ＝ 读不了（照报错行号说话）**或**探不到解析器（那是"验不了"，不是"没问题"）
//   跳过 ＝ 后缀不归它管（.md/.mjs/…：**明说跳过，不当绿**）
// ★ 按路径选库（2026-09-23 加）：引擎里**两套 YAML 库并存**（机器事实，读各包 package.json 得来）：
//   `@deepseek-ai/dsh` 本体／`dsh-agent-presets`／`cordis-plugin-include`／`dsh-app-boot` ⇒ **js-yaml@4**
//   `dsh-settings-file`／`dsh-credentials-local`／`dsh-skill-filesystem` ⇒ **yaml@2**
//   ⇒ 认得出路径就按**宿主真正会读它的那个库**验；认不出 ⇒ **两个库都试**，不一致就报黄。
// 用法：node 神经/解析体检.mjs 查 <文件> ｜ selftest
// 退出码：0=ok/黄/跳过 ／ 1=红 ／ 2=用法错
import fs from 'node:fs'
import { createRequire } from 'node:module'

const 引擎自带 = '/data/data/com.dsharnessmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/node_modules'
const 库缓存 = new Map()
/** 只读借一个库（不新装包）：返回 (文本)=>解析，借不到返回 null */
function 借库(名) {
  if (库缓存.has(名)) return 库缓存.get(名)
  const 底座 = [引擎自带 + '/', process.env.DSH_HOME ? process.env.DSH_HOME + '/profiles/web/' : '']
  let 得 = null
  for (const b of 底座) {
    if (!b) continue
    try {
      const m = createRequire(b)(名)
      const f = typeof m.parse === 'function' ? m.parse : (typeof m.load === 'function' ? m.load : null)
      if (f) { 得 = (t) => f.call(m, t); break }
    } catch (e) { /* 换下一个底座 */ }
  }
  if (得) 得.库名 = 名
  库缓存.set(名, 得)
  return 得
}

/** 按路径选库（纯函数）：认得出 ⇒ 宿主真正会读它的那个库；认不出 ⇒ '两个都试' */
export function 选库(路径) {
  const p = String(路径 == null ? '' : 路径)
  if (/\.agent-presets\//.test(p) || /cordis[^/]*\.ya?ml$/i.test(p) || /(^|\/)dsh\.(profile|patch)[^/]*\.ya?ml$/i.test(p)) return 'js-yaml'
  if (/(^|\/)settings\.ya?ml$/i.test(p) || /credentials/i.test(p) || /\.dsh\/skills?\//.test(p)) return 'yaml'
  return '两个都试'
}

export function 后缀(路径) {
  const m = /\.([A-Za-z0-9]+)$/.exec(String(路径 == null ? '' : 路径))
  return m ? m[1].toLowerCase() : ''
}

export function 体检文本(文本, 后缀名, 路径) {
  const t = String(文本 == null ? '' : 文本)
  if (后缀名 === 'json') {
    if (!t.trim()) return { 档: '红', 说明: '空文件 ⇒ JSON 读不了空内容（改坏了？）' }
    try { JSON.parse(t); return { 档: 'ok', 说明: 'JSON 能被解析器读通（内建 JSON.parse）· ' + t.length + ' 字符（只证明能读，不等于语义没问题）' } }
    catch (e) { return { 档: '红', 说明: 'JSON 解析失败：' + String((e && e.message) || e).split('\n')[0] } }
  }
  if (后缀名 === 'yml' || 后缀名 === 'yaml') {
    if (!t.trim()) return { 档: '红', 说明: '空文件 ⇒ YAML 读不了空内容（改坏了？）' }
    const 该用 = 选库(路径), 行数 = t.split('\n').length
    const 试 = (名) => {
      const f = 借库(名)
      if (!f) return { 名, 档: '红', 说明: '借不到 ' + 名 + '（引擎自带的 node_modules 里没有）⇒ 这份我**验不了**，要么补库、要么人工核' }
      try { f(t); return { 名, 档: 'ok' } } catch (e) { return { 名, 档: '红', 说明: '读不了：' + String((e && e.message) || e).split('\n')[0].slice(0, 120) } }
    }
    if (该用 === '两个都试') {
      const a = 试('js-yaml'), b = 试('yaml')
      if (a.档 === 'ok' && b.档 === 'ok') return { 档: 'ok', 说明: '两个库都读通（js-yaml ＋ yaml）· ' + 行数 + ' 行（路径认不出 ⇒ 两个都试）' }
      if (a.档 === 'ok' || b.档 === 'ok') return { 档: '黄', 说明: '**两个库结论不一致** ⇒ ' + (a.档 === 'ok' ? 'js-yaml 过；yaml 报：' + b.说明 : 'yaml 过；js-yaml 报：' + a.说明) + '（宿主用哪个库就以哪个为准）· ' + 行数 + ' 行' }
      return { 档: '红', 说明: '两个库都读不了 ⇒ js-yaml ' + a.说明 + ' ｜ yaml ' + b.说明 }
    }
    const r = 试(该用)
    if (r.档 === 'ok') return { 档: 'ok', 说明: '能被 ' + 该用 + ' 读通（按路径选库：这份的宿主正是用它）· ' + 行数 + ' 行（只证明能读，不等于语义没问题）' }
    return { 档: '红', 说明: 该用 + ' ' + r.说明 }
  }
  return { 档: '跳过', 说明: '后缀 .' + (后缀名 || '（无）') + ' 不归解析体检管（**明说跳过，不当绿**）' }
}

export function 体检(路径) {
  let t
  try { t = fs.readFileSync(路径, 'utf8') } catch (e) { return { 档: '红', 说明: '读不到文件：' + ((e && e.message) || e) } }
  return 体检文本(t, 后缀(路径), 路径)
}

/** 拦不拦：新内容 ok/黄/跳过 ⇒ 放行；新内容红 ⇒ 看改前 —— 改前也红＝老文件本来就坏（只警告），改前 ok＝我改坏的（拦下） */
export function 判(旧档, 新档) {
  if (新档.档 === 'ok') return { 放行: true, 级别: 'ok' }
  if (新档.档 === '跳过') return { 放行: true, 级别: '跳过' }
  if (新档.档 === '黄') return { 放行: true, 级别: '黄·两库不一致（明说，不拦）' }
  if (旧档 && 旧档.档 === '红') return { 放行: true, 级别: '改前就红' }
  return { 放行: false, 级别: '拦下' }
}

function selftest() {
  const 好J = '{ "a": 1, "b": [1, 2] }'
  const 坏J = '{ "a": 1, "b": [1, 2, }'
  const 好Y = 'a: 1\nb:\n  - x\n  - y\n'
  const 坏Y = 'a: 1\nb: [1, 2\n'   // 方括号没收口 ⇒ YAML 必报错（旧样例「缩进不一致」其实**合法**，是自检自己假绿）
  const r = {
    J好: 体检文本(好J, 'json'), J坏: 体检文本(坏J, 'json'),
    Y好: 体检文本(好Y, 'yml'), Y坏: 体检文本(坏Y, 'yml'),
    跳过: 体检文本('随便', 'md'), 空J: 体检文本('   ', 'json'),
    判放行: 判({ 档: 'ok' }, 体检文本(好J, 'json')),
    判拦下: 判({ 档: 'ok' }, 体检文本(坏J, 'json')),
    判老坏: 判({ 档: '红' }, 体检文本(坏J, 'json')),
    判跳过: 判({ 档: 'ok' }, 体检文本('x', 'md')),
  }
  const 清单 = [
    ['① 好 JSON ⇒ ok', r.J好.档 === 'ok'],
    ['② 坏 JSON ⇒ 红', r.J坏.档 === '红'],
    ['③ 好 YAML ⇒ ok（本机借得到解析器）', r.Y好.档 === 'ok'],
    ['④ 坏 YAML ⇒ 红', r.Y坏.档 === '红'],
    ['⑤ 不管辖后缀 ⇒ 跳过（不当绿）', r.跳过.档 === '跳过'],
    ['⑥ 空文件 ⇒ 红（空＝读不了）', r.空J.档 === '红'],
    ['⑦ 判：改前 ok ＋ 改后红 ⇒ **拦下**', r.判拦下.放行 === false],
    ['⑧ 判：改前就红 ⇒ 只警告放行', r.判老坏.放行 === true && r.判老坏.级别 === '改前就红'],
    ['⑨ 判：ok／跳过 ⇒ 放行', r.判放行.放行 === true && r.判跳过.放行 === true],
    ['⑩ 阴性对照：本轮至少产出一条"红"', [r.J坏, r.Y坏, r.空J].every((x) => x.档 === '红')],
    ['⑪ 选库：cordis.patch.yml ⇒ js-yaml', 选库('/p/cordis.patch.yml') === 'js-yaml'],
    ['⑫ 选库：.agent-presets/** ⇒ js-yaml', 选库('/h/.dsh/.agent-presets/suqingqing/preset.yml') === 'js-yaml'],
    ['⑬ 选库：settings.yml ⇒ yaml', 选库('/h/.dsh/settings.yml') === 'yaml'],
    ['⑭ 选库：credentials ⇒ yaml', 选库('/h/.dsh/.credentials.json') === 'yaml'],
    ['⑮ 选库：认不出 ⇒ 两个都试', 选库('/tmp/随便.yml') === '两个都试'],
    ['⑯ 按路径选库：settings.yml 的宿主库（yaml）读通', 体检文本(好Y, 'yml', '/h/.dsh/settings.yml').档 === 'ok'],
    ['⑰ 认不出路径 ⇒ 两个库都试，都过 ⇒ ok（说明里写明）', 体检文本(好Y, 'yml', '/tmp/随便.yml').档 === 'ok' && /两个库都读通/.test(体检文本(好Y, 'yml', '/tmp/随便.yml').说明)],
    ['⑱ 认不出路径 ＋ 坏 YAML ⇒ 红（不是黄）', 体检文本(坏Y, 'yml', '/tmp/随便.yml').档 === '红'],
  ]
  let ok = true
  for (const [名, 合格] of 清单) { if (!合格) ok = false; console.log((合格 ? '✅' : '⛔') + ' ' + 名) }
  console.log('  样例：' + r.J坏.说明 + ' ｜ ' + r.Y好.说明)
  return ok
}

const 是主 = process.argv[1] && /解析体检\.mjs$/.test(process.argv[1])
if (是主) {
  const a = process.argv.slice(2)
  if (a[0] === 'selftest') process.exit(selftest() ? 0 : 1)
  if (a[0] === '查' && a[1]) {
    const r = 体检(a[1])
    console.log((r.档 === 'ok' ? '✅ ' : r.档 === '跳过' ? '⏭ ' : '❌ ') + a[1] + ' ⇒ ' + r.档 + '：' + r.说明)
    process.exit(r.档 === '红' ? 1 : 0)
  }
  console.log('用法：解析体检.mjs 查 <文件> ｜ selftest'); process.exit(2)
}
