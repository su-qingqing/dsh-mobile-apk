#!/usr/bin/env node
/**
 * 记忆注入自测（1002-B/F/G）—— **同一份用例**跑两个对象：生产件（必须红）／暂存镜像（必须绿）
 *
 * 为什么这么写（1001 的经验 `0mupq19qe`）：
 *   ① 先从**真源码里抽块**跑（不复制一份逻辑到测试里 —— 复制会跟本尊分家，等于测了个假的）；
 *   ② 反证（生产件上必须红）与正证（镜像上必须全绿）**用同一份用例**，不写两套。
 *
 * 用法：
 *   node 神经/记忆注入自测.mjs                 # 默认跑生产件 ⇒ 期望：B1/B4 红
 *   MEM_PATH=<暂存镜像>/lib/index.js node 神经/记忆注入自测.mjs   # 期望：全绿
 *   node 神经/记忆注入自测.mjs --件 <某份 index.js>
 * 退出码：0 全绿 ／ 1 有用例失败 ／ 2 抽块失败（源码锚点变了）
 *
 * 用例分两档（**档位写在名字里，别混着报**）：
 *   【行为级】真跑抽出来的函数（B 组）—— rules 到底进没进注入体
 *   【条文级】只查源码里那句判据在不在（F/G 组）—— 弱证据，真正的行为证据在重启后的日志
 */
import fs from 'node:fs'
import path from 'node:path'

const argv = process.argv.slice(2)
const 从参数 = argv.indexOf('--件') >= 0 ? argv[argv.indexOf('--件') + 1] : ''
const 件 = 从参数 || process.env.MEM_PATH ||
  path.join(process.env.HOME || '/data/data/com.dsharnessmobile.shell/files/home',
    '.dsh/profiles/web/node_modules/meow-memory/lib/index.js')

let K
try { K = fs.readFileSync(件, 'utf8') } catch (e) { console.error('⛔ 读不到 ' + 件 + '：' + e.message); process.exit(2) }

// ★ 1013 标死（**不是门，只是让它别再装成活人**）：
//   它判的对象已经从 meow-memory **0.26.0 升到 0.31.0**，而 1002-[BFG] 那批锚点在现役 lib/index.js 里**零命中**
//   ⇒ 下面这些用例**统统失效**（**9/9 红 ≠ 出事了，是判据随对象过时**；B 组行为级也全败，因为它抽块用的锚点在新版里没了）。
//   要让那批行为回来 ⇒ **照 0.31.0 重写本件**，或先确认新版是否自带。
//   来历、实核数据、以及由它升出来的「必然时刻级」发现 ⇒ 成果/交付/1013-过期断言扫描.md。
console.log('⚠️ 本自测的判据已随对象升级失效（0.26.0 → 0.31.0，1002-* 锚点零命中）—— 下面全红≠出事。')
console.log('   要让那批行为回来 ⇒ 照 0.31.0 重写本件；来历见 成果/交付/1013-过期断言扫描.md')

// ───── 从真源码抽块（不复制逻辑）─────
const 抽函数 = (src, 名) => {
  const lines = src.split('\n')
  const i = lines.findIndex((l) => l.startsWith(`function ${名}(`))
  if (i < 0) return null
  let j = i
  while (j < lines.length && lines[j] !== '}') j++
  return lines.slice(i, j + 1).join('\n')
}
const 抽常量 = (src, 名) => {
  const m = src.match(new RegExp('^var ' + 名 + ' = .*$', 'm'))
  return m ? m[0] : null
}
const 块 = {
  CANON: 抽常量(K, 'GLOBAL_PROJECT_CANON'),
  cache: 抽常量(K, 'markerCache') || 'var markerCache = null;',
  marker: 抽函数(K, 'globalProjectMarker'),
  isGlobal: 抽函数(K, 'isGlobalProject'),
  build: 抽函数(K, 'buildInjectionBody'),
}
for (const [k, v] of Object.entries(块)) if (v === null) { console.error(`⛔ 从源码抽不出【${k}】——锚点变了，先去看 ${件}`); process.exit(2) }

// ───── 桩：标签（照真 labels 的键名，值只影响文案，不影响"进没进"）─────
const 标签 = {
  'project.global': '全局',
  'inject.title': '【关于你】',
  'inject.aboutYou': '【关于你】',
  'inject.aboutUser': '【关于用户】',
  'inject.rules': '【设计原则】',
  'inject.guide': '【记忆导引】',
  'inject.sectionFormat': '== {label} ==',
  'inject.guideSearchLine': '查记忆：memory_search',
  'inject.guideProjectLine': '看项目：memory_project',
  'inject.guideProjects': '项目：{list}',
}
const keyedValue = (_群, key) => (key in 标签 ? 标签[key] : key)
const fillTemplate = (t, p) => String(t).replace(/\{(\w+)\}/g, (_, k) => (p && k in p ? String(p[k]) : `{${k}}`))
// 插件里 globalProjectMarker() 要的两件：lbl()（标签查表）与 getPromptLang()（语言）——都给上桩，别让它抛
const lbl = (key) => keyedValue('labels', key)
const getPromptLang = () => 'zh'

const 工厂 = new Function('keyedValue', 'fillTemplate', 'lbl', 'getPromptLang',
  `${块.CANON}\n${块.cache}\n${块.marker}\n${块.isGlobal}\n${块.build}\nreturn { isGlobalProject, buildInjectionBody }`)
let F
try { F = 工厂(keyedValue, fillTemplate, lbl, getPromptLang) } catch (e) { console.error('⛔ 抽出来的块跑不起来（缺依赖？）：' + e.message); process.exit(2) }

const 造库 = (行) => ({
  list: (t, o) => (行[t] || []).filter((r) => !o || !o.status || r.status === o.status),
  listProjectNames: () => [],
})
const 跑 = (行, o = {}) => { const r = F.buildInjectionBody(造库(行), { titleMax: 40, ...o }); return r === null ? '' : r.body }
const 规则 = (id, content, project, importance = 3) => ({ id, content, project, importance, status: 'active' })

// ───── 用例 ─────
const 例 = []
const 加 = (档, 名, 判, 详) => 例.push({ 档, 名, 判, 详 })
const 含 = (体, s) => 体.includes(s)

加('行为级', 'B1·「全局」规则必须进注入体', () => {
  const 体 = 跑({ rules: [规则('r1', '规则甲·不许自作主张重启', '全局')] })
  return 含(体, '规则甲·不许自作主张重启')
}, '库里 rules.project 是字符串「全局」——这条红＝老判据把它滤掉了')
加('行为级', 'B2·别家项目的规则**不许**混进全局块', () => {
  const 体 = 跑({ rules: [规则('r2', '别家项目的私货', '桌宠项目')] })
  return !含(体, '别家项目的私货')
}, '对照：不能为了 B1 把筛选放宽成"全都进"')
加('行为级', 'B3·importance<2 仍不许进', () => {
  const 体 = 跑({ rules: [规则('r3', '随手记的一条', '全局', 1)] })
  return !含(体, '随手记的一条')
}, '对照：老门槛 importance>=2 不许被松掉')
加('行为级', 'B4·project 为空(null) 的仍要进', () => {
  const 体 = 跑({ rules: [规则('r4', '没写归属的老规则', null)] })
  return 含(体, '没写归属的老规则')
}, '对照：别把 null 那条路修丢了')
加('行为级', 'B5·brief（重插）时 rules **仍不进**（省钱约定不许破）', () => {
  const 体 = 跑({ rules: [规则('r5', '一条规则', '全局')] }, { brief: true })
  return !含(体, '一条规则')
}, '对照：1001 的 brief 约定不能被 B 改坏')
加('条文级', 'F1·`priorUser === 0` 这道闸已拿掉', () => {
  return !K.includes('if (priorUser === 0) {') && K.includes('1002-F')
}, '行为证据在重启后的日志：`inserted memory snapshot … (1002-F pid=… priorUser=…)`')
加('条文级', 'F2·注入了会留 pid/priorUser 痕', () => K.includes('1002-F pid=${process.pid} priorUser=${priorUser}'),
  '没有这行 ⇒ 重启后拿不到"补了没补"的凭据')
加('条文级', 'G1·子代理那句「零注入」早退已换成 brief 块', () => {
  const 老 = K.includes('if (agent.session.header.origin === "subagent") return decision;')
  return !老 && K.includes('1002-G') && K.includes('brief: true')
}, '行为证据在重启后：`1002-G subagent brief injected` 日志行')
加('条文级', 'G2·子代理那份**不许**带 user/rules 全量', () => K.includes('brief: true, titleMax: resolved.titleMax'),
  '对照：brief 一开，user/rules 两段自动不进（B5 已在行为级验过）')

// ───── 跑 ─────
console.log(`对象：${件}\n`)
let 败 = 0, 红 = []
for (const c of 例) {
  let ok = false, err = ''
  try { ok = c.判() } catch (e) { ok = false; err = '（用例自己抛了：' + e.message + '）' }
  if (!ok) { 败++; 红.push(c.档.slice(1, 3) + c.名.slice(0, 3)) }
  console.log(`  ${ok ? '✅' : '❌'} 【${c.档}】${c.名}${err}`)
  console.log(`       ↳ ${c.详}`)
}
console.log(`\n通过 ${例.length - 败} / 失败 ${败}` + (败 ? `  ｜ 红的是：${红.join('、')}` : ''))
process.exit(败 ? 1 : 0)
