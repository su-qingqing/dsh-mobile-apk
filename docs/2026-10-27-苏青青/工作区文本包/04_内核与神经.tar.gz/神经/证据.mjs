#!/usr/bin/env node
// M3 · 可重放证据 v0.2（2026-09-18 夜升级）
// v0.1：交付话写 `[证据: <名称>]` ⇒ 按登记表重跑那条命令（原样保留）
// v0.2：把 `PerryLink/dsh-research-report` 的 6 条机制搬进本工具（**不装它的包** —— 它要求进 dsh.profile.bundles，撞红线）
//   (a) 内容寻址快照 objects/<sha256>，读时重算哈希 ⇒ 篡改会被发现，而不是被信任
//   (b) 逐字核验：那一行里的数字必须在快照里逐字定位；字面不同但数值等价 ⇒ insufficient（诚实中间态，不冒充通过）
//   (c) claim ↔ evidence 绑定 + 四级 verdict（verified / insufficient / disproven / contradicted）
//   (d) 封印：manifest.json + seal = sha256(canonical(manifest))
//   (e) fail-loud：出现 disproven / contradicted ⇒ **拒绝封印**（无旋钮）
//   (f) 证伪账本 disproofs.jsonl（negative knowledge：证据没变时，同一 claim 强制回到 disproven）
// 用法：
//   node 神经/证据.mjs list | run <名称> | check <文件>     # v0.1
//   node 神经/证据.mjs snap [名称…]                          # 跑并落内容寻址快照
//   node 神经/证据.mjs verify <文件>                         # 逐字核验 + 四级 verdict
//   node 神经/证据.mjs seal <文件>                           # 核验 + 封印（fail-loud）
//   node 神经/证据.mjs vseal <封印目录>                      # 仅凭封印目录重算（零网络零模型）
//   node 神经/证据.mjs attest [会话id|latest]                # 从会话日志独立取证（时间戳证据）
//   node 神经/证据.mjs --selftest                            # 离线自测（含"篡改一字节必须报红"）
import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'

const WS = '/storage/emulated/0/3'
const DSH = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh'
const TMPBASE = path.join(DSH, 'tmp')
let ROOT = path.join(WS, '成果/证据')
let OBJD = path.join(ROOT, 'objects')
let SEALDIR = path.join(ROOT, '密封')
let DIS = path.join(ROOT, 'disproofs.jsonl')
function setRoot(r) { ROOT = r; OBJD = path.join(r, 'objects'); SEALDIR = path.join(r, '密封'); DIS = path.join(r, 'disproofs.jsonl') }
const out = (s = '') => process.stdout.write(s + '\n')
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex')

const REG = {
  '内核条数与指纹': { cmd: ['node', WS + '/神经/基线.mjs'], expect: /hashCore|内核 \d+ 条/, what: '内核正文指纹与条数（#36）' },
  '回归集': { cmd: ['node', WS + '/工具/回归/跑全部.mjs'], expect: /❌ 0/, what: '事故回归集 9 条用例全绿' },
  '体检': { cmd: ['node', WS + '/神经/体检.mjs'], expect: /全绿/, what: '内核机械项体检 15/15' },
  '闸门自测': { cmd: ['node', WS + '/神经/闸门自测.mjs'], expect: /全绿/, what: '闸门自测 135/135（09-19：旧 86 ＋ I 组 30 ＋ J 组 19；含 CLI 端到端 3 条、人话盖章全勾/验收通过/行尾动词，以及反向句护栏 J15–J17）' },
  '收手门双证': { cmd: ['node', WS + '/工具/收手门/双证.mjs'], expect: /双证通过：4\/4/, what: '收手门抹掉能力必变红（旧版红 16 条 / 只抹人侧开关红 2 / 只抹完成门红 9）' },
  '步数表': { cmd: ['node', WS + '/神经/步数表.mjs'], expect: /本轮步数/, what: '本会话步数 ＋ 上下文离压缩线还有多远（秒级，只读日志尾巴）', volatile: true },
  '并发冲突': { cmd: ['node', WS + '/工具/试验场/冲突测试.mjs'], expect: /全过/, what: 'M2 并发认领恰好一个持有者 + 台账零改动' },
  '常驻延迟': { cmd: ['node', WS + '/工具/试验场/基准_常驻vs冷启动.mjs'], expect: /常驻形态达标/, what: '常驻连接 vs CLI 的延迟对比' },
  '装配树唯一性': { cmd: ['node', WS + '/工具/装机闸门/装配树.mjs', 'web'], expect: /id 全部唯一/, what: '装机闸门盲区补丁：装配树 188 条 id 唯一' },
  '界面断言自测': { cmd: ['node', WS + '/工具/试验场/界面断言.mjs', 'selftest'], expect: /全绿：\d+\/\d+/, what: '界面断言仪器 7 组对照全绿（含 23 处注入缺陷分档：易 8·中 8·难 7）' },
  '界面断言双证': { cmd: ['node', WS + '/工具/试验场/双证_界面断言.mjs'], expect: /用例有效（不是永远绿）/, what: '抹掉仪器特征必变红（用例有效性反证，防"永远绿"）' },
  '干净房间自测': { cmd: ['node', WS + '/工具/沙盒/干净房间.mjs', 'selftest'], expect: /全绿：\d+\/\d+/, what: '干净房间 8 组对照全绿（正常/崩溃/白名单内/越界/孤儿/软链逃逸/契约/无遗留）' },
  '干净房间双证': { cmd: ['node', WS + '/工具/沙盒/双证_干净房间.mjs'], expect: /用例有效（不是永远绿）/, what: '干净房间抹掉特征必变红（5/5）' },
  '验收包自测': { cmd: ['node', WS + '/工具/交付/验收包.mjs', 'selftest'], expect: /✅ \d+\/\d+ 全绿/, what: '验收包 10/10（含 4 例缺陷注入：漏判定/留⬜/缺⑥/写「最好用」⇒ 必须全红）' },
  '验收包判齐': { cmd: ['node', WS + '/工具/交付/验收包.mjs', 'check', WS + '/台账/验收/成果/验收/第3批第四段_验收包_0919.md'], expect: /验收包：齐/, what: '第 3 批第四段结案单逐项判齐（对着开工卡 [5] 全 11 条）' },
  '对照单闸自测': { cmd: ['node', WS + '/工具/交付/对照单闸.mjs', 'selftest'], expect: /用例 13 条｜✅ 13｜❌ 0/, what: '对照单闸 9 组对照全绿（缺表态/没点名/文件不存在/垃圾单/「否」无依据 ⇒ 红；达标/有依据/只认表态行/不看 mtime ⇒ 绿）' },
  '对照单闸双证': { cmd: ['node', WS + '/工具/交付/双证_对照单闸.mjs'], expect: /双证成立/, what: '抹掉结构检查 ⇒ 一行垃圾对照单从红变绿（证明这条检查承重，不是永远绿）' },
  '看得见自测': { cmd: ['node', WS + '/工具/试验场/看得见.mjs', 'selftest'], expect: /用例 13 条｜✅ 13｜❌ 0/, what: '看得见（像素判据）13 组对照全绿（含 ffmpeg 外部锚点＋全图微偏平均差＋透明像素提醒）：0%／1.000%补丁／100%整幅／单像素越阈值／阈值内／尺寸不同报错／16位深报错／编解码往返' },
  '看得见双证': { cmd: ['node', WS + '/工具/试验场/双证_看得见.mjs'], expect: /双证成立/, what: '抹掉「--expect 超出判红」⇒ 差异 1.000% 的用例从红变绿（证明这条判定承重）' },
  '经验账本自测': { cmd: ['node', WS + '/工具/记忆/经验账本.mjs', 'selftest'], expect: /全绿 \d+\/\d+/, what: '经验账本（MisakaNet 证据阶梯）自测：解析／五级定级／外部锚点／否定语境／反模式校验／触发正反用例' },
  '经验账本双证': { cmd: ['node', WS + '/工具/台账/双证_经验账本.mjs'], expect: /双证成立：抹掉特征必变红/, what: '经验账本抹掉特征必变红（5 个变异：命令识别／触发匹配／字段校验／证据永不假设／否定语境）' },
  '分档跑自测': { cmd: ['node', WS + '/工具/沙盒/分档跑.mjs', 'selftest'], expect: /全绿 \d+\/\d+/, what: '分档跑（四判＋挂载表＋回执链）自测：拒/问一次/要分类/允许 四档 ＋ 字面未知兜底 ＋ 回执链篡改检测' },
  '分档跑双证': { cmd: ['node', WS + '/工具/沙盒/双证_分档跑.mjs'], expect: /双证成立/, what: '分档跑抹掉整档必变红（拒／问一次／未知兜底／回执链 4 个变异）' },
  '钉子户板': { cmd: ['node', WS + '/工具/记忆/钉子户.mjs', '查'], expect: /✅ 声称全部核得上；真值口径＝③ 的 \d+ 条/, what: '内核 #65：「摆出来 ≠ 拦得住」的坑每条都挂机器能核的产物/条文锚，核不上就红（板＝记忆/教训/钉子户.md）' },
  '插行门': { cmd: ['node', WS + '/工具/台账/插行.mjs', '自检'], expect: /自检 7\/7 过/, what: '插行门：往结构化台账插/删行 —— 列数不符**拒写、一个字节不动**；删＝先算齐下标再倒序 splice（坑 0mubkp0fk · 做法库 #242）' },
  '派活门': { cmd: ['node', WS + '/神经/派活.mjs', '自检'], expect: /自检 3\/3 过/, what: '派活门：生成"带相关坑原文"的派活单；捞不到坑又不写理由 ⇒ 拒派（坑 0mu7k5dcx · 子代理 fresh 上下文，坑不会自己到达它）' },
  '检索门': { cmd: ['node', WS + '/神经/检索门.mjs', '自检'], expect: /自检 4\/4 过/, what: '检索门：开源/市场检索**名字＋能力词两遍缺一即红**（坑 0mu6ydy73）' },
  '按来源门': { cmd: ['node', WS + '/神经/按来源.mjs', '自检'], expect: /自检 4\/4 过/, what: '按来源门：日志多来源混写 ⇒ 判版本按来源过滤、不取尾巴（坑 0mu63gt4t；实测生产 1690 条 vs 自测噪声 20483 条）' },
  '多实例门': { cmd: ['node', WS + '/工具/装机闸门/多实例.mjs', '自检'], expect: /自检 3\/3 过/, what: '多实例门：自研插件三条铁律（实例 pid／owned 守卫／两轮探测）扫描；③ 号用例＝2026-09-23 抓到的**假阳性回归**（坑 0mu5he2km ＋ 0mu8ice76）' },
  '接续核路径': { cmd: ['node', WS + '/工具/跨窗/接续.mjs', '核', WS + '/神经/按来源.mjs', WS + '/工具/取证'], expect: /✅ 2 个路径都在/, what: '接手时"别人给你的路径"先挨个核在不在；有一个不在就红（坑 0mu85gc6n，曝光 20 次·被纠正过）' },
  '取证六件套': { cmd: ['node', WS + '/工具/取证/取证.mjs', '列'], expect: /✅ 六件齐/, what: '会话日志取证六件套已进工作区（zdump/ztail/zstat/zshape/zdef/zgrep ＋ sesmgr 源码留样；坑 0mu2grqzb）' },
  '重复插入自测': { cmd: ['node', WS + '/工具/装机闸门/重复插入.mjs', 'selftest'], expect: /全绿 \d+\/\d+/, what: '重复插入（cordis.patch.yml 同 id 被 insert 两次）检测器自测' },
  '动态插件门': { cmd: ['node', WS + '/工具/装机闸门/动态插件.mjs', '自检'], expect: /自检 8\/8 过/, what: '动态 Cordis 插件三坑扫描门自检：阴性／阳性／特异性三对照（坑 0mu5w4wuo；批③第一刀）' },
  '上膛闸': { cmd: ['node', WS + '/工具/回归/上膛.mjs', '自检'], expect: /自检 12\/12 过/, what: '仪器上膛三对照门自检：阴性／阳性／特异性 ＋ 能力三态（坑 0mu8ice76；批③第二刀）' },
  '双证（回归集）': { cmd: ['node', WS + '/工具/回归/上膛.mjs', '双证'], expect: /双证 3\/3 成立/, what: '回归集正反双证（原 工具/回归/双证.mjs；批③第六刀并入上膛闸）—— 抹掉生产修复特征，对应用例必须变红；崩溃不算变红' },
  '看门狗闸': { cmd: ['node', WS + '/工具/装机闸门/看门狗.mjs', '自检'], expect: /自检 11\/11 过/, what: '看门狗闸自检：子进程的命要系在父进程上（阴性／阳性／特异性 ＋ 判据范围四态；坑 0mu5fqqli；批③第三刀）' },
  'id闸': { cmd: ['node', WS + '/工具/记忆/id闸.mjs', '自检'], expect: /自检 15\/15 过/, what: '记忆 id 引用闸自检：引用必须落到唯一一条记忆（死引用／歧义＝❌；短前缀＝⚠️；坑 0mu1icsi5；批③第四刀）' },
  '行形状闸': { cmd: ['node', WS + '/工具/台账/行形状闸.mjs', '自检'], expect: /自检 3\/3 过/, what: '台账行形状闸自检：按本块表头判宽窄／缺行首竖线也必红／历史节只报不判（坑 0mubkp0fk；批③第五刀）' },
}

function ensure() { for (const d of [ROOT, OBJD, SEALDIR]) fs.mkdirSync(d, { recursive: true }) }
const objPath = (h) => path.join(OBJD, h.slice(0, 2), h)

function putObject(text) {
  ensure()
  const h = sha(text); const p = objPath(h)
  if (fs.existsSync(p)) return { hash: h, path: p, reused: true }
  fs.mkdirSync(path.dirname(p), { recursive: true })
  fs.writeFileSync(p, text)
  return { hash: h, path: p, reused: false }
}
function getObject(h) {
  const p = objPath(h)
  if (!fs.existsSync(p)) return { ok: false, reason: 'missing' }
  const text = fs.readFileSync(p, 'utf8')
  if (sha(text) !== h) return { ok: false, reason: 'tampered', text }
  return { ok: true, text }
}
function latestIdx() {
  const p = path.join(ROOT, 'latest.json')
  try { return JSON.parse(fs.readFileSync(p, 'utf8')) } catch { return {} }
}

function run(name, quiet) {
  const e = REG[name]
  if (!e) { out(`❌ 没登记这条证据：${name}\n   已登记：${Object.keys(REG).join(' / ')}`); return { ok: false, text: null } }
  let text = '', code = 0
  try { text = execFileSync(e.cmd[0], e.cmd.slice(1), { encoding: 'utf8', timeout: 300000, maxBuffer: 32 * 1024 * 1024 }) }
  catch (err) { text = String(err.stdout || err.message || ''); code = err.status == null ? -1 : err.status }
  const hit = e.expect.test(text)
  if (!quiet) {
    out(`[证据] ${name} —— ${e.what}`)
    out(`  命令：${e.cmd.join(' ')}`)
    out(`  关键行：${(text.split('\n').filter(l => e.expect.test(l)).slice(-2).join(' ｜ ') || '(无匹配行)')}`)
    out(`  判定：${hit ? '✅ 真值成立' : '❌ 与期望不符'}（退出码 ${code}）`)
  }
  return { ok: hit, text, code }
}

function snap(names) {
  const list = names.length ? names : Object.keys(REG)
  const rows = []
  for (const n of list) {
    const r = run(n, true)
    if (r.text == null) continue
    const o = putObject(r.text)
    rows.push({ name: n, hash: o.hash, reused: o.reused, at: new Date().toISOString(), exit: r.code, ok: r.ok, volatile: !!REG[n].volatile })
    out(`  ${r.ok ? '✅' : '❌'} ${n.padEnd(14)} ${o.hash.slice(0, 16)}… ${o.reused ? '(同内容，复用)' : '(新对象)'}${REG[n].volatile ? ' [易变]' : ''}`)
  }
  ensure()
  if (rows.length) fs.appendFileSync(path.join(ROOT, 'journal.jsonl'), rows.map(r => JSON.stringify(r)).join('\n') + '\n')
  const idx = latestIdx()
  let okIdx = {}; try { okIdx = JSON.parse(fs.readFileSync(path.join(ROOT, 'latestOk.json'), 'utf8')) } catch {}
  for (const r of rows) { idx[r.name] = r.hash; okIdx[r.name] = { ok: r.ok, code: r.code } }
  fs.writeFileSync(path.join(ROOT, 'latestOk.json'), JSON.stringify(okIdx, null, 1))
  fs.writeFileSync(path.join(ROOT, 'latest.json'), JSON.stringify(idx, null, 1))
  out(`\n✅ 落快照 ${rows.length} 条 ⇒ ${path.relative(WS, ROOT)}/objects/（同内容只存一次）`)
  return idx
}

const nums = (t) => [...String(t).matchAll(/\d[\d,]*(?:\.\d+)?/g)].map(m => m[0].replace(/,/g, ''))
function locateLit(snapText, lit) {
  if (snapText.includes(lit)) return 'exact'
  const a = Number(lit)
  if (!Number.isNaN(a) && nums(snapText).map(Number).includes(a)) return 'numeric'
  return 'none'
}
function disproofed(claimText, hash) {
  if (!fs.existsSync(DIS)) return null
  const rows = fs.readFileSync(DIS, 'utf8').trim().split('\n').filter(Boolean).map(l => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  return rows.find(r => r.claimHash === sha(claimText) && r.evidenceHash === hash) || null
}
function verdictOf(name, lits, claimText, idx) {
  const h = (idx || latestIdx())[name]
  if (!h) return { v: 'unverified', why: '没有快照（先跑 snap）', hash: null }
  if (claimText) { const d = disproofed(claimText, h); if (d) return { v: 'disproven', why: '证伪账本命中：证据未变，同一 claim 强制 disproven（' + (d.reason || '') + '）', hash: h } }
  let okIdx2 = {}; try { okIdx2 = JSON.parse(fs.readFileSync(path.join(ROOT, 'latestOk.json'), 'utf8')) } catch {}
  const rec = okIdx2[name]
  const recOk = (rec && typeof rec === 'object') ? rec.ok : rec
  const recCode = (rec && typeof rec === 'object') ? rec.code : 0
  if (recCode && recCode !== 0) return { v: 'disproven', why: '命令崩溃（退出码 ' + recCode + '）—— 易变项也不例外，执行失败不许当波动放过', hash: h }
  if (recOk === false) return (REG[name] && REG[name].volatile)
    ? { v: 'insufficient', why: '易变证据：上次判定不成立（易变项不判死，需人工看）', hash: h }
    : { v: 'disproven', why: '命令上次跑不成立（退出码或期望未满足）—— 不许靠这行没数字就冒充通过', hash: h }
  const o = getObject(h)
  if (!o.ok) return { v: 'contradicted', why: o.reason === 'tampered' ? '快照被篡改（重算哈希对不上）' : '快照缺失', hash: h }
  if (!lits.length) return { v: 'verified', why: '该行没有数字，命令可重跑核对', hash: h }
  const miss = [], numOnly = []
  for (const l of lits) { const r = locateLit(o.text, l); if (r === 'none') miss.push(l); else if (r === 'numeric') numOnly.push(l) }
  if (miss.length) return (REG[name] && REG[name].volatile)
    ? { v: 'insufficient', why: '易变证据：数字与上次快照不同（易变项的正常波动，不判死）：' + miss.join(' / '), hash: h }
    : { v: 'disproven', why: '数字不在快照里：' + miss.join(' / '), hash: h }
  if (numOnly.length) return { v: 'insufficient', why: '数值等价但字面不同（需人工确认）：' + numOnly.join(' / '), hash: h }
  return { v: 'verified', why: '数字全部逐字命中快照', hash: h }
}
const ICON = { verified: '✅', insufficient: '🟡', disproven: '❌', contradicted: '⛔' }
const MARK = { verified: '[已核实]', insufficient: '[证据不足]', disproven: '[已证伪]', contradicted: '[与证据矛盾]' }

function parseClaims(text) {
  const rows = []
  const skipped = []
  text.split('\n').forEach((line, i) => {
    const m = line.match(/\[证据[:：]\s*([^\]|]+)(?:\|\s*([^\]]+))?\]/)
    if (m && m[1].trim() === 'X') { skipped.push(i + 1) }   // 字面量占位符（写模板用的），下面逐条打印
    else if (m) rows.push({ line: i + 1, name: m[1].trim(), hint: (m[2] || '').trim(), text: line.replace(/\[证据[:：][^\]]*\]/g, '').trim() })
  })
  return { rows, skipped }
}
function verifyFile(file) {
  const text = fs.readFileSync(file, 'utf8')
  const parsed = parseClaims(text)
  const claims = parsed.rows
  const skippedN = parsed.skipped
  if (!claims.length) { out(`⚠️ ${file} 里没有 [证据: X] 标记 —— 按 M3 口径，这份交付话的证据不可重放`); return { bad: 1, rows: [] } }
  const idx = latestIdx()
  const rows = claims.map(c => Object.assign({}, c, verdictOf(c.name, nums(c.hint || c.text), c.text, idx)))
  out(`扫到 ${rows.length} 条证据标记，逐条核验：\n`)
  if (skippedN.length) out("  ⏭️ 跳过 " + skippedN.length + " 处**字面量占位符** [证据: X]（第 " + skippedN.join("、") + " 行）—— 只跳过名字恰好是 X 的，其它名字一律照核\n")
  for (const r of rows) {
    out(`  ${ICON[r.v]} 第${r.line}行 [${r.name}] → ${r.v} ${MARK[r.v]}`)
    out(`      ${r.why}${r.hash ? '（快照 ' + r.hash.slice(0, 12) + '…）' : ''}`)
  }
  const bad = rows.filter(r => r.v === 'disproven' || r.v === 'contradicted').length
  const weak = rows.filter(r => r.v === 'unverified' || r.v === 'insufficient').length
  out(`\n${bad === 0 && weak === 0 ? '✅ 全部已核实' : `🟡 已核实 ${rows.length - bad - weak} / 证据不足或未核实 ${weak} / 已证伪或矛盾 ${bad}`}`)
  return { bad, weak, rows, text }
}

function writeDisproof(r) {
  ensure()
  fs.appendFileSync(DIS, JSON.stringify({ claimHash: sha(r.text), text: r.text.slice(0, 160), evidenceHash: r.hash, verdict: r.v, reason: r.why, at: new Date().toISOString() }) + '\n')
}
const canon = (m) => JSON.stringify({ at: m.at, claimsSha: m.claimsSha, evidence: Object.fromEntries(Object.entries(m.evidence).sort()), reportSha: m.reportSha, ack: (m.ack || []).slice().sort() })
function seal(file, ackList) {
  const ack = ackList || []
  const vr = verifyFile(file)
  const rows = vr.rows || []
  const hard = rows.filter(r => r.v === 'disproven' || r.v === 'contradicted')
  const weakAll = rows.filter(r => r.v === 'insufficient' || r.v === 'unverified')
  const unacked = weakAll.filter(r => !ack.includes(r.name))
  for (const r of hard) writeDisproof(r)
  if (!rows.length || hard.length) {
    out(`\n❌ **拒绝封印**（fail-loud，无旋钮）：${hard.length} 条被证伪或与证据矛盾${rows.length ? '' : '；且文件里没有证据标记'}`)
    out('   处置：先修数字或重跑 snap，再 seal。证伪项已记入 disproofs.jsonl。')
    return { ok: false }
  }
  if (unacked.length) {
    out('\n❌ **拒绝封印**：' + unacked.length + ' 条属"未核实/证据不足"，**必须显式认可**才放行（防止用一个 volatile 标签静默混过封印）')
    for (const r of unacked) out('   · ' + r.name + ' → ' + r.v + '：' + r.why)
    out('   处置：确实属易变/无快照项 ⇒ 重跑 seal 并加 --ack=' + [...new Set(unacked.map(r => r.name))].join(','))
    return { ok: false }
  }
  const at = new Date().toISOString()
  const slug = path.basename(file).replace(/\.[^.]+$/, '')
  const dir = path.join(SEALDIR, slug + '-' + at.replace(/[-:T]/g, '').slice(0, 15))
  fs.mkdirSync(dir, { recursive: true })
  const reportSha = sha(vr.text)
  const evidence = {}; for (const r of rows) if (r.hash) evidence[r.name] = r.hash
  const claimsSha = sha(JSON.stringify(rows.map(r => [r.line, r.name, r.v])))
  const manifest = { at, claimsSha, evidence, reportSha, file: path.relative(WS, file), ack: ack.slice().sort() }
  const sealHash = sha(canon(manifest))
  fs.writeFileSync(path.join(dir, 'report.md'), vr.text)
  fs.writeFileSync(path.join(dir, 'claims.json'), JSON.stringify(rows, null, 1))
  fs.writeFileSync(path.join(dir, 'verification.jsonl'), rows.map(r => JSON.stringify({ line: r.line, name: r.name, verdict: r.v, why: r.why, hash: r.hash })).join('\n') + '\n')
  fs.writeFileSync(path.join(dir, 'manifest.json'), JSON.stringify(manifest, null, 1))
  fs.writeFileSync(path.join(dir, 'seal.txt'), sealHash + '\n')
  const weak = rows.filter(r => r.v === 'unverified' || r.v === 'insufficient')
  out(`\n✅ 已封印 ⇒ ${path.relative(WS, dir)}/`)
  out(`   seal = ${sealHash}`)
  out(`   证据 ${Object.keys(evidence).length} 条已绑定哈希 ｜ ${weak.length ? weak.length + ' 条带诚实缺口标记（' + [...new Set(weak.map(r => MARK[r.v]))].join(' ') + '）' : '无缺口'}`)
  return { ok: true, dir, sealHash }
}

function vseal(dir) {
  const mf = path.join(dir, 'manifest.json')
  if (!fs.existsSync(mf)) { out('❌ 这里没有 manifest.json'); return { ok: false } }
  const manifest = JSON.parse(fs.readFileSync(mf, 'utf8'))
  const stored = fs.readFileSync(path.join(dir, 'seal.txt'), 'utf8').trim()
  const recomputed = sha(canon(manifest))
  const report = fs.readFileSync(path.join(dir, 'report.md'), 'utf8')
  let reportOk = sha(report) === manifest.reportSha
  const evRows = []
  for (const [n, h] of Object.entries(manifest.evidence)) {
    const o = getObject(h)
    evRows.push({ name: n, hash: h, ok: o.ok, why: o.ok ? '对象哈希重算一致' : (o.reason === 'tampered' ? '对象被篡改' : '对象缺失') })
  }
  const claims = JSON.parse(fs.readFileSync(path.join(dir, 'claims.json'), 'utf8'))
  const idx = {}
  for (const [n, h] of Object.entries(manifest.evidence)) idx[n] = h
  const recheck = claims.map(c => Object.assign({}, c, verdictOf(c.name, nums(c.hint || c.text), c.text, idx)))
  const evBad = evRows.filter(r => !r.ok).length, clBad = recheck.filter(r => r.v === 'disproven' || r.v === 'contradicted').length
  const ok = stored === recomputed && reportOk && evBad === 0 && clBad === 0
  out(`封印核验（零网络、零模型，只凭这个目录）：`)
  out(`  seal 重算：${stored === recomputed ? '✅ 一致' : '⛔ 不一致（manifest 被改过）'}`)
  out(`  report 哈希：${reportOk ? '✅ 一致' : '⛔ 不一致（报告被改过）'}`)
  for (const r of evRows) out(`  证据 ${r.name}：${r.ok ? '✅' : '⛔'} ${r.why}`)
  out(`  claim 重查：${clBad === 0 ? '✅ 全部仍然成立' : '⛔ ' + clBad + ' 条不再成立'}`)
  out(`\n${ok ? '✅ 封印成立，未被篡改' : '⛔ 封印不成立（有对象被改/被删，或 claim 不再成立）'}`)
  try { fs.writeFileSync(path.join(dir, 'verifier-note.md'), `# 核验记录\n\n- 时间：${new Date().toISOString()}\n- seal 重算：${stored === recomputed ? '一致' : '不一致'}\n- report 哈希：${reportOk ? '一致' : '不一致'}\n- 证据对象：${evBad === 0 ? '全部一致' : evBad + ' 个异常'}\n- claim 重查：${clBad === 0 ? '全部成立' : clBad + ' 条不再成立'}\n- 结论：${ok ? '封印成立' : '封印不成立'}\n`) } catch {}
  return { ok }
}

function attest(which) {
  const sessions = path.join(DSH, 'sessions/--storage-emulated-0-3--')
  if (!fs.existsSync(sessions)) { out('❌ 找不到会话目录：' + sessions); return { ok: false } }
  let sid = which
  const _dirs = fs.readdirSync(sessions)
  if (!sid || sid === 'latest') {
    const ds = _dirs.map(d => ({ d, t: fs.statSync(path.join(sessions, d)).mtimeMs })).sort((a, b) => b.t - a.t)
    sid = ds[0] && ds[0].d
  } else {
    sid = _dirs.find(x => x === sid) || _dirs.find(x => x.startsWith(sid)) || _dirs.find(x => x.includes(sid)) || sid
  }
  const f = ['session.v4.jsonl.zstd', 'session.v3.jsonl.zstd', 'session.jsonl.zstd'].map((x) => path.join(sessions, sid, x)).find((x) => fs.existsSync(x))
  if (!f) { out('❌ 找不到该会话日志（v4／v3 都没有）：' + path.join(sessions, sid)); return { ok: false } }
  const raw = execFileSync('zstd', ['-dc', f], { encoding: 'utf8', maxBuffer: 512 * 1024 * 1024, timeout: 120000 })
  const tcRe = /\{"type":"tool-call","id":"([^"]+)","name":"([^"]+)"/g
  const counts = {}; const timeline = []; const ids = new Set()
  const lines = raw.split('\n')
  for (const line of lines) {
    let m
    while ((m = tcRe.exec(line))) {
      ids.add(m[1]); counts[m[2]] = (counts[m[2]] || 0) + 1
      if (timeline.length < 400) timeline.push({ id: m[1], tool: m[2] })
    }
  }
  const callCount = ids.size
  const n = lines.length
  ensure()
  const payload = JSON.stringify({ session: sid, at: new Date().toISOString(), logFile: f, logSha: sha(raw), lines: n, toolCalls: callCount, counts, timeline }, null, 1)
  const o = putObject(payload)
  out(`独立取证（时间戳证据，来源=会话日志原文，不是我的陈述）：`)
  out(`  会话 ${sid}｜日志 ${n} 行｜sha256 ${sha(raw).slice(0, 16)}…`)
  out(`  工具调用 ${callCount} 次（按 tool-call 事件的唯一 id 去重），前 12 名：`)
  Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 12).forEach(([k, v]) => out(`    ${String(v).padStart(4)} × ${k}`))
  out(`\n  证据对象 ⇒ objects/${o.hash.slice(0, 2)}/${o.hash.slice(0, 16)}…`)
  out(`  用途：回答"某个工具到底干过什么"—— 拿这份清单与我的交付话对照，对不上就是我说错了`)
  return { ok: true, hash: o.hash, counts }
}

function selftest() {
  fs.mkdirSync(TMPBASE, { recursive: true })
  const tmp = fs.mkdtempSync(path.join(TMPBASE, 'ev-'))
  setRoot(tmp)
  const log = []
  const T = (name, cond, extra) => { log.push(`${cond ? '✅' : '❌'} ${name}${extra ? ' — ' + extra : ''}`); return cond }
  // 1 内容寻址 + 复用
  const text = '装配树 profile = web ｜ 条目 = 188 ｜ 错误行 = 0\n✅ 装配树 id 全部唯一'
  const o1 = putObject(text); const o2 = putObject(text)
  T('内容寻址：同内容只存一次', o1.hash === o2.hash && o2.reused === true)
  fs.writeFileSync(path.join(tmp, 'latest.json'), JSON.stringify({ '装配树唯一性': o1.hash }))
  // 2 逐字核验通过
  const c1 = '装配树 188 条，错误 0 行'
  const v1 = verdictOf('装配树唯一性', nums(c1), c1)
  T('逐字核验：数字全命中 ⇒ verified', v1.v === 'verified', v1.v)
  // 3 数字不在快照里 ⇒ disproven
  const c2 = '装配树 999 条'
  const v2 = verdictOf('装配树唯一性', nums(c2), c2)
  T('数字不在快照 ⇒ disproven', v2.v === 'disproven', v2.v + ' / ' + v2.why)
  // 4 数值等价但字面不同 ⇒ insufficient（诚实中间态）
  const c3 = '错误 0.0 行'
  const v3 = verdictOf('装配树唯一性', nums(c3), c3)
  T('数值等价字面不同 ⇒ insufficient', v3.v === 'insufficient', v3.v)
  // 4b 易变项：数字不同 ⇒ insufficient（不判死）—— 必须趁对象完好时测
  REG['装配树唯一性'].volatile = true
  const v8 = verdictOf('装配树唯一性', nums('装配树 777 条'), '装配树 777 条')
  T('易变项：数字不同 ⇒ insufficient（不判死）', v8.v === 'insufficient', v8.v)
  delete REG['装配树唯一性'].volatile
  // 4c 命令崩溃（exit≠0）⇒ 恒 disproven，易变项也不例外
  const okBak = fs.existsSync(path.join(tmp, 'latestOk.json')) ? fs.readFileSync(path.join(tmp, 'latestOk.json'), 'utf8') : '{}'
  fs.writeFileSync(path.join(tmp, 'latestOk.json'), JSON.stringify({ '装配树唯一性': { ok: true, code: 7 } }))
  REG['装配树唯一性'].volatile = true
  const v10 = verdictOf('装配树唯一性', nums(c1), c1)
  T('命令崩溃（exit≠0）⇒ disproven（易变项也不例外）', v10.v === 'disproven', v10.v)
  delete REG['装配树唯一性'].volatile
  fs.writeFileSync(path.join(tmp, 'latestOk.json'), okBak)
  // 5 ★ 篡改一个字节 ⇒ contradicted
  fs.writeFileSync(objPath(o1.hash), text.replace('188', '189'))
  const v4 = verdictOf('装配树唯一性', nums(c1), c1)
  T('★ 篡改一字节 ⇒ contradicted', v4.v === 'contradicted', v4.v + ' / ' + v4.why)
  // 6 封印 fail-loud（对象已被篡改 ⇒ 必须拒绝）
  const badFile = path.join(tmp, 'bad.md'); fs.writeFileSync(badFile, '装配树 188 条 [证据: 装配树唯一性]\n')
  const s1 = seal(badFile)
  T('fail-loud：被篡改 ⇒ 拒绝封印', s1.ok === false)
  // 7 修复对象后能封上 + vseal 成立
  fs.writeFileSync(objPath(o1.hash), text)
  const goodFile = path.join(tmp, 'good.md'); fs.writeFileSync(goodFile, '装配树 188 条，错误 0 行 [证据: 装配树唯一性]\n')
  const s2 = seal(goodFile)
  T('修复后封印成功', s2.ok === true, s2.sealHash ? 'seal=' + s2.sealHash.slice(0, 12) + '…' : '')
  const v5 = s2.dir ? vseal(s2.dir) : { ok: false }
  T('vseal：只凭封印目录重算 ⇒ 成立', v5.ok === true)
  // 8 封印后再篡改对象 ⇒ vseal 必须报不成立
  if (s2.dir) { fs.writeFileSync(objPath(o1.hash), text + '!'); const v6 = vseal(s2.dir); T('封印后篡改对象 ⇒ vseal 报不成立', v6.ok === false) }
  // 9 negative knowledge：证伪账本命中 ⇒ 强制 disproven
  fs.writeFileSync(objPath(o1.hash), text)
  const d = JSON.parse(fs.readFileSync(DIS, 'utf8').trim().split('\n')[0])
  const v7 = verdictOf('装配树唯一性', nums(d.text), d.text)
  T('证伪账本命中 ⇒ 强制 disproven', v7.v === 'disproven')
  // 9b ack 机制：证据不足项必须显式认可才让封印
  REG['装配树唯一性'].volatile = true
  const volFile = path.join(tmp, 'vol.md'); fs.writeFileSync(volFile, '装配树 777 条 [证据: 装配树唯一性]\n')
  const s3 = seal(volFile)
  T('证据不足项未 ack ⇒ 拒绝封印', s3.ok === false)
  const s4 = seal(volFile, ['装配树唯一性'])
  T('证据不足项已 ack ⇒ 放行封印', s4.ok === true)
  delete REG['装配树唯一性'].volatile
  out('════ 证据.mjs v0.2 离线自测 ════')
  log.forEach(l => out('  ' + l))
  const pass = log.filter(l => l.startsWith('✅')).length
  out(`\n${pass === log.length ? '✅ 自测全绿' : '❌ 自测有红'}：${pass}/${log.length}`)
  out(`（临时目录 ${tmp}，未碰真实台账）`)
  return pass === log.length
}

const [cmd, arg] = process.argv.slice(2)
if (process.argv.includes('--selftest')) { process.exit(selftest() ? 0 : 1) }
else if (cmd === 'list') {
  out('可重放证据登记表（交付话里写 [证据: <名称>]）\n')
  Object.keys(REG).forEach((k, i) => out(`  ${String(i + 1).padStart(2)}. ${k.padEnd(14)} —— ${REG[k].what}${REG[k].volatile ? '（易变）' : ''}`))
  out('\n  · 这些是**能重跑的命令**，不是"我说有出处" ⇒ 兑现公约 §4.0 的"凡数字回源"')
  out('  · v0.2 起还支持 snap / verify / seal / vseal / attest（内容寻址 + 逐字核验 + 封印）')
} else if (cmd === 'run') { const r = run(arg || Object.keys(REG)[0]); process.exit(r.ok ? 0 : 1) }
else if (cmd === 'check') { const r = verifyFile(arg || ''); process.exit(r.bad ? 1 : 0) }
else if (cmd === 'snap') { snap(process.argv.slice(3)); process.exit(0) }
else if (cmd === 'verify') { const r = verifyFile(arg || ''); process.exit(r.bad ? 1 : 0) }
else if (cmd === 'seal') { if (!arg) { console.log('用法：node 神经/证据.mjs seal <报告文件> [--ack=名1,名2]  —— 报告里要写 [证据: X] 标记；没给文件不再抛 ENOENT'); process.exit(2) } const a = (process.argv.find(x => x.startsWith('--ack=')) || '').slice(6).split(',').filter(Boolean); const r = seal(arg, a); process.exit(r.ok ? 0 : 1) }
else if (cmd === 'vseal') { const r = vseal(arg || ''); process.exit(r.ok ? 0 : 1) }
else if (cmd === 'attest') { const r = attest(arg); process.exit(r.ok ? 0 : 1) }
else out('用法：node 神经/证据.mjs list | run <名称> | check <文件> | snap | verify <文件> | seal <文件> | vseal <目录> | attest [会话id] | --selftest')
