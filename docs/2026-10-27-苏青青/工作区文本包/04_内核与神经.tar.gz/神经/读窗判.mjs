#!/usr/bin/env node
// ── 读窗判（D02 体检门）──────────────────────────────────────────────
// 治动作集 D02：「读上一窗**只点名读一小段**（`read_window` limit≤10）／已关的窗用 `工具/跨窗/接续.mjs`；**禁止整篇考古**」
//   原判据挂着 none（why＝"要看我怎么读的"）⇒ 本件把它变成机器可判。
//   判据：扫本工作区**最新**那份会话日志，看 `read_window` 调用里 `limit` 有没有 **> 10**。
// 用法：node 神经/读窗判.mjs [日志] [--静]   退 0 全绿／1 有超读／2 没东西可查（**不是通过**）
// 【四模块耦合】法＝本文件（判据只此一处）｜记忆＝要读别的窗口之前／轮末｜神经＝⚠️ **挂点未接**（孤儿件，待接轮末自检，照 B07/B11 的样）｜动作＝超读 ⇒ 改成点名读一小段
import { readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { zstdDecompressSync } from 'node:zlib'
const H = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
const 根 = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const argv = process.argv.slice(2); const 静 = argv.includes('--静'); const 给 = argv.find((a) => !a.startsWith('--'))
function 找日志() {
  if (给) return 给
  const 基 = join(H, 'sessions', '--storage-emulated-0-3--'); let b = null
  try { for (const d of readdirSync(基)) { const p = join(基, d); let fs2 = []
      try { fs2 = readdirSync(p).filter((f) => f.endsWith('.zstd')) } catch { continue }
      for (const f of fs2) { const fp = join(p, f); try { const m = statSync(fp).mtimeMs; if (!b || m > b.m) b = { m, fp } } catch {} } } } catch {}
  return b ? b.fp : null
}
const p = 找日志()
if (!p) { if (!静) console.log('⚪ 读窗判：找不到会话日志（**不是通过**）'); process.exit(2) }
let t = ''
try { t = zstdDecompressSync(readFileSync(p)).toString('utf8') } catch { if (!静) console.log('⚪ 读窗判：日志解不开（多帧／损坏）⇒ 没东西可查，**不是通过**'); process.exit(2) }
const 超 = []; let 总 = 0
for (const line of t.split('\n')) {
  if (!line || line[0] !== '{') continue
  let o = null; try { o = JSON.parse(line) } catch { continue }
  const ev = o && o.event ? o.event : o
  if (!ev || (ev.type || ev.kind) !== 'tool/call') continue
  const 参 = (ev.data && (ev.data.arguments || ev.data.input)) || ev.arguments || ev.input || null
  if (!参 || typeof 参 !== 'object') continue
  const 名 = String(参.name || 参.tool || 参.toolName || '')
  if (!/read_window/i.test(名)) continue
  const a = 参.arguments || 参.input || {}; 总++
  const lim = Number(a.limit)
  if (Number.isFinite(lim) && lim > 10) 超.push('limit=' + lim)
}
try { writeFileSync(join(根, '台账/接续/读窗判.json'), JSON.stringify({ at: new Date().toISOString().slice(0, 16).replace('T', ' '), 日志: p, read_window调用: 总, 超读: 超.length, 样本: 超.slice(0, 10) }, null, 1)) } catch {}
if (超.length) { console.log('⛔ **读窗判 · D02 超读**（limit>10 ＝ 违反"只点名读一小段"）共 ' + 超.length + ' 次：' + 超.slice(0, 6).join(' ')); process.exit(1) }
// ★ 1009 夜修（红线 23 口径 + 本文件头部自己的契约"2＝没东西可查，不是通过"）：
//   实测旧版「本窗 0 次 read_window 调用」时返回 **0（绿）** ⇒ 把"没查到"当成了"通过"
//   （内核 #71：假绿比不报更坏）。挂点还没接（孤儿件），此刻改不会造出假红。
if (总 === 0) { if (!静) console.log('⚪ 读窗判：本窗 0 次 read_window 调用 ⇒ 没东西可查，**不是通过**'); process.exit(2) }
if (!静) console.log('✅ 读窗判：' + 总 + ' 次 read_window 调用，没有 limit>10')
process.exit(0)
