#!/usr/bin/env node
// 调度器 v1 —— 把「靠自觉清单」变成机器每次能摆到我面前的一行
//
// 老板 2026-09-19 原话（这一线的由来）：
//   「我们怎么样才能**意识到**这个下意识的一个清单呢？……我们是不是可以**做一个钩子出来**，
//    然后去让这个钩子去**调动**这个我们靠自觉的一个进行的一个步骤呢？……
//    那它这种方式实现过后，那它是不是就是说**不用靠自觉了**？也就是说**我知道这件事情我要做**」
//
// 设计（为什么逻辑放这儿、不放插件里）：
//   · 插件只做**薄接线**（取本会话状态 → 调这个 → 把返回的一行附加到工具结果）
//   · 逻辑在这儿 ⇒ **改了立刻生效**（插件按 mtime 动态 import）／**能离线测**（不用重启）／**风险最低**
//   · 真源仍然是 `工具/台账/流程定义.mjs`（24 条工具动作）—— 动作集改一条，这里自动跟着变
//
// 只读、零副作用。用法：
//   node 神经/调度.mjs                      # 拿"现在这个会话"的状态行（用当前进程参数模拟）
//   node 神经/调度.mjs --calls "命令1|命令2" --steps 7
//   node 神经/调度.mjs selftest             # 阴性对照：已知输入必须推出已知漏项
import fs from 'node:fs';
import path from 'node:path';
const ROOT = '/storage/emulated/0/3';
const SEG_ORDER = ['一·接手', '二·干活', '三·留档', '四·交付', '五·收尾'];

// 真源按 mtime 缓存：文件没改 ⇒ 复用；改了 ⇒ 重新加载（不重启也生效）
let _cache = { mtime: -1, flow: null };
async function loadFlow() {
  const p = ROOT + '/工具/台账/流程定义.mjs';
  try {
    const mt = fs.statSync(p).mtimeMs;
    if (_cache.mtime === mt && _cache.flow) return _cache.flow;
    const m = await import('file://' + p + '?v=' + mt);
    _cache = { mtime: mt, flow: Array.isArray(m.FLOW) ? m.FLOW : [] };
    return _cache.flow;
  } catch (e) { return null; }   // 真源坏了 ⇒ 返回 null，调用方 fail-open（宁可不说话，也不打扰）
}

// 主函数：喂"本会话到目前为止"的现场，返回一行
let _lastSit = ''
export async function plan(现场 = {}) {
  // ★ 2026-09-27 阈值上调（老板纠正后）：步数＝工具调用数，本机实测常见轮 20~60 步、长活轮 120~180；
  //   旧默认 12/20 ⇒ 仪器在第 20 步就喊「成本已高」，**在简单活上从早喊到晚**（老板当场质疑：
  //   「闸门是拿来让你做一次性干不完的活、容易被压死的活，你拿来给自己上压力干嘛呢？」）⇒ 提到 40/80。
  const { calls = [], steps = 0, warnAt = 40, costAt = 80, his = '' } = 现场;
  // ★ B1 路由层（0922 架构迭代包）：先算「现在是什么情境」。
  //   为什么放这儿：插件按 mtime 动态 import 本文件 ⇒ **改判据不用重启**；
  //   为什么不用真源：真源坏了（loadFlow 返回 null）时**情境照样要出声** —— 它是传入端，不是账。
  let 情 = null
  try {
    const sp = ROOT + '/神经/情境.mjs'
    const sm = await import('file://' + sp + '?v=' + fs.statSync(sp).mtimeMs)
    if (typeof sm.判 === 'function') {
      情 = sm.判({ his, call: calls[calls.length - 1] || '' })
      if (情 && 情.key !== _lastSit) { _lastSit = 情.key; try { if (typeof sm.记 === 'function') sm.记(情) } catch (eR) { /* 记账坏了不打扰 */ } }
    }
  } catch (eS) { 情 = null }   // fail-open：情境层坏了绝不打断状态行

  const flow = await loadFlow();
  if (!flow || !flow.length) {
    return 情 ? { level: 'ok', line: 情.line, seg: '', missing: [], allMissing: 0, steps, 情境: 情.key } : null
  }

  const text = calls.join('\n');
  const done = new Map();
  for (const a of flow) { let hit = false; try { hit = new RegExp(a.re).test(text) } catch (e) { hit = false } done.set(a.name, hit); }

  // ① 走到哪一段 = **最靠后的、已经有动作被跑过的段**
  let seg = SEG_ORDER[0];
  for (const s of SEG_ORDER) if (flow.some(a => a.seg === s && done.get(a.name))) seg = s;

  // ② 这一段里还没做的（最多报 3 条，按流程顺序）
  // ★ 1009 夜修根（老板令「先去把那个丢三落四的问题修完了」）—— 两条口径修正：
  //   ① **停用件不算漏**：`活:false` 的按需件结构上永远不会被跑到 ⇒ 旧口径下五·收尾**恒漏 4 条以上**，那个数永不为零。
  //   ② **五·收尾 段改「结果口径」**：不再问"这条命令的字面出现过没有"，改问**盘上产物齐不齐**
  //      （真源＝`工具/开工/收尾欠项.mjs 算()`，与轮末挂点同源；只读现算、无子进程、失败 fail-open）。
  //   为什么必须改：1009 实测同一刻两个仪器给出**相反读数** —— `调度` 报「漏 ①窗口资产采集 ②收手门 ③冻结校验 等 13 项」，
  //   而 `收尾欠项` 报「收尾干净」。每轮都印一个消不掉的数 ⇒ **报警疲劳 ⇒ 真漏被淹**（这才是"丢三落四"能被感觉到的原因）。
  const 活件 = flow.filter(a => a.活 !== false);
  let 缺名 = 活件.filter(a => a.seg === seg && !done.get(a.name)).map(a => a.name);
  if (seg === '五·收尾') {
    try {
      const m = await import('file://' + ROOT + '/工具/开工/收尾欠项.mjs');
      const R = m.算 ? m.算(ROOT) : null;
      if (R) 缺名 = R.欠 ? (R.缺 || [R.一行]) : [];
    } catch (e) { /* 收尾欠项坏了 ⇒ 退回字面口径（fail-open，宁可不说话也不误报） */ }
  }
  const missing = 缺名.slice(0, 3);
  const allMissing = 缺名.length;

  // ③ 越线：**拆轮，不是砍活**（老板 2026-09-19：「正确的做法是拆分成两步来做」）
  //   ★★ 2026-09-27 老板纠正 —— 这台仪器**只为「一次性干不完的活、容易被压死的活」出声**：
  //     「闸门是拿来让你做一次性干不完的活，容易被压死的活，你拿来给自己上压力干嘛呢？……
  //      用的地方用不上，不该用的地方，然后又拼命拿来给自己用得上压力」
  //   ⇒ 三条**同时**满足才喊：① **重活**（本轮出现写文件/写代码/改配置）② **本段确实还有活没做**
  //     ③ 步数越线。**简单活（只读/只查/只报表）一律不喊** —— 它不再是我的压力表。
  //   ⇒ 措辞＝事实＋自带边界：这行是**内部判据**，**不许写进给老板的报表**。
  const head = [];
  let level = 'ok';
  const 重活 = calls.some((t) => /\b(Write|Edit|MultiEdit)\b|\.(mjs|js|ts|tsx|py|sh|ya?ml|json)\b/.test(String(t)));
  if (重活 && missing.length && steps >= costAt) { level = 'red'; head.push('［内部判据·不进老板报表］本轮 ' + steps + ' 步 · 重活且本段还有活 —— 拆轮：剩下的落成下一步（不是砍活）'); }
  else if (重活 && missing.length && steps >= warnAt) { level = 'warn'; head.push('［内部判据·不进老板报表］本轮 ' + steps + ' 步 · 重活 —— 下一轮拆开做'); }

  // ★ H1（2026-09-22 老板批"可以做"）：**落点化** —— 把"该做没做"落成**一行能跑的命令**（只给第一条，行要短）
  const cmdOf = (nm) => { const a = flow.find((x) => x && x.name === nm); return a && a.cmd ? String(a.cmd).replace(/^`|`$/g, '').split('（')[0].trim() : '' }
  let line = '〔本轮 ' + steps + ' 步 · ' + seg + '〕';
  if (missing.length) {
    line += '漏：' + missing.map((m, i) => ('①②③'[i] || '') + m).join(' ') + (allMissing > 3 ? ' 等 ' + allMissing + ' 项' : '');
    const c1 = cmdOf(missing[0])
    if (c1) line += ' ⇒ 先跑：' + (c1.length > 46 ? c1.slice(0, 45) + '…' : c1)
  } else line += '本段齐';

  // ★ H1（老板批"可以做"）：**执行账本** —— 只在"这次工具调用里真的出现了那条命令"时记一行（**绝不自动执行**）
  //   为什么要有它：把"做了没有"从印象变成数（现状反例：状态行天天印，跑库一屏仍只 9/32）。
  try {
    const fs2 = fs, path2 = path
    const LEDGER = ROOT + '/台账/接续/执行账.json'
    let lg = {}
    try { lg = JSON.parse(fs2.readFileSync(LEDGER, 'utf8')) || {} } catch (e) { lg = {} }
    let dirty = false
    for (const a of flow) {
      if (!a || !a.cmd) continue
      const bare = String(a.cmd).replace(/^`|`$/g, '').split('（')[0].trim()
      if (bare.length < 8) continue
      if (!text.includes(bare)) continue
      lg[a.name] = lg[a.name] || { count: 0 }
      lg[a.name].count++
      lg[a.name].last = new Date().toISOString().slice(0, 16).replace('T', ' ')
      lg[a.name].cmd = bare
      dirty = true
    }
    if (dirty) { fs2.mkdirSync(path2.dirname(LEDGER), { recursive: true }); fs2.writeFileSync(LEDGER, JSON.stringify(lg, null, 1) + '\n') }
  } catch (eL) { /* fail-open：账本坏了也不许打扰 */ }

  // ★ B1：情境行**搭在同一条行上**（P1 §三 噪音预算：一个时刻最多一条、复用现有行、不新开行）
  const pre = 情 ? 情.line + ' ｜ ' : ''
  return { level, line: pre + (head.length ? head.join(' ｜ ') + ' ｜ ' : '') + line, seg, missing, allMissing, steps, 情境: 情 ? 情.key : '' };
}

// ── 命令行（★ 只有**直接运行**才跑；被插件 import 时绝不能跑） ────────
// 2026-09-19 实测到的 bug：插件 `await import()` 这个文件时，顶层 CLI 一并执行 ⇒ 往引擎 stdout
// 打了无关的两行（自测日志里当场看见）。守卫＝看 `process.argv[1]` 是不是本文件。
const isDirectRun = !!process.argv[1] && /\u8c03\u5ea6\.mjs$/.test(process.argv[1]);
const argv = isDirectRun ? process.argv.slice(2) : [];
const get = (k, d) => { const i = argv.indexOf('--' + k); return i >= 0 && argv[i + 1] !== undefined ? argv[i + 1] : d; };

if (isDirectRun && argv.includes('selftest')) {
  // 阴性对照：**已知输入必须推出已知漏项**（不是"跑起来就算过"）
  const cases = [
    { name: '空会话 ⇒ 应停在「一·接手」并提示漏项', 现场: { calls: [], steps: 1 }, 期望: (r) => r.seg === '一·接手' && r.missing.length > 0 },
    { name: '只跑了库 ⇒ 仍应提示接手段还有漏项', 现场: { calls: ['node /storage/emulated/0/3/工具/开工/库.mjs'], steps: 2 }, 期望: (r) => r.seg === '一·接手' && !r.missing.includes('跑库一屏') },
    { name: '写了台账 ⇒ 段位该推进到「三·留档」或更后', 现场: { calls: ['node 工具/开工/库.mjs', 'bash: echo x >> 台账/在办.md'], steps: 5 }, 期望: (r) => SEG_ORDER.indexOf(r.seg) >= 2 },
    // ★ 2026-09-27 判据换了（老板：这台仪器只为「一次性干不完、容易被压死的活」出声）⇒ 用例跟着换，
    //   否则自检永远是假红（内核 #71：假红比不报更坏）。步数**单独**不再构成任何告警。
    { name: '简单活 191 步 ⇒ 不许喊拆轮（简单活不是压力表）', 现场: { calls: ['grep -n x 台账/在办.md'], steps: 191 }, 期望: (r) => r.level === 'ok' && !/拆轮/.test(r.line) },
    { name: '重活 41 步 + 有漏项 ⇒ 黄，且必须是「拆开/拆轮」不是「停下」', 现场: { calls: ['Edit 工具/x.mjs'], steps: 41 }, 期望: (r) => r.level === 'warn' && /拆开|拆轮/.test(r.line) && !/停/.test(r.line) },
    { name: '重活 81 步 + 有漏项 ⇒ 红，且那行自带「不进老板报表」', 现场: { calls: ['Edit 工具/x.mjs'], steps: 81 }, 期望: (r) => r.level === 'red' && /不进老板报表/.test(r.line) },
    { name: '重活 + 越线，但本段齐 ⇒ 不喊（没有"干不完的部分"就不叫压死）', 现场: { calls: (await import('file://' + ROOT + '/工具/台账/流程定义.mjs')).FLOW.filter((a) => a.seg === '三·留档').flatMap((a) => [String(a.cmd || ''), String(a.name || '')]).concat(['Edit 工具/x.mjs']), steps: 99 }, 期望: (r) => r.allMissing === 0 && !/拆轮|拆开/.test(r.line) },
  ];
  let pass = 0;
  for (const c of cases) {
    const r = await plan(c.现场);
    const ok = r ? c.期望(r) : false;
    console.log((ok ? '✅' : '❌') + ' ' + c.name + (ok ? '' : '  → 实际：' + JSON.stringify(r)));
    if (ok) pass++;
  }
  const all = pass === cases.length;
  console.log(all ? '\n✅ selftest ' + pass + '/' + cases.length + ' 全过' : '\n❌ selftest ' + pass + '/' + cases.length + ' —— 调度器判据坏了');
  process.exit(all ? 0 : 1);
}

if (isDirectRun) {
const calls = get('calls', '').split('|').filter(Boolean);
const steps = Number(get('steps', 0));
const r = await plan({ calls, steps });
if (!r) { console.log('（真源读不到 ⇒ fail-open，不输出状态行）'); process.exit(2); }
console.log(r.line);
console.log('  段=' + r.seg + ' 漏=' + (r.missing.join('、') || '无') + ' 共漏 ' + r.allMissing + ' 项 level=' + r.level);
}
