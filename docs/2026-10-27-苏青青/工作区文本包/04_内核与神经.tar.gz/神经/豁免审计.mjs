#!/usr/bin/env node
// 豁免审计.mjs —— 外部独立核（qwen3.8-max）整改 ⑧：`exemptDirs` 自救口**审计化**
//
// 核原话（判决页 `送核_连续性升机器面与门审计收口_1010_8080d36ad613.md:124-130`）：
//   「`exemptDirs` 作为自救口可以保留，否则起不来时没有逃生通道。但它必须满足四条：
//     ① 登记：谁豁免、为什么豁免；② 限时：不能永久豁免；
//     ③ 回补：豁免期间改动必须事后补检；④ 可见：连续体检也要能看豁免区，至少报黄。」
//   核的警告：「否则『合法绕道』会变成长期盲区」「自救口会变长期后门」。
//
// 真身（**我不改它**）：`@dsh-user/dsh-kickoff-gate/lib/index.js:46`
//   `exemptDirs: ['台账','记忆','调研','内核','.dsh-kickoff','_backup','_事故']`
//   ⇒ 改插件＝动门本体（红线 3／5：第三方插件 + 启动路径高危）⇒ 本件**在插件外**做审计层。
//
// 「限时」的正解（不是"到期取消"）：这七个目录**必须长期豁免**，否则自救口没了 ——
//   所以限时 = **每 N 天必须复核一次登记**（到期未复核 ⇒ 报警）。这治的是"变成长期盲区"，不是取消自救。
//
// 用法：
//   node 神经/豁免审计.mjs 查                 # 逐条：目录｜为什么｜上次复核｜下次复核｜剩余｜状态
//   node 神经/豁免审计.mjs 回补               # 豁免区本轮动过的件 ⇒ 逐个补检（调连续体检）
//   node 神经/豁免审计.mjs 复核 <目录> --说 "…"  # 复核登记（下次复核推到 N 天后，留痕）
//   node 神经/豁免审计.mjs 一屏                # 一行读数（绿时零字；给轮末自检/pins 用）
//   node 神经/豁免审计.mjs selftest            # 阴性/阳性对照（造临时房，不碰生产）
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3';
const 登记路 = (ws) => path.join(ws, '台账/闸门/豁免登记.json');
const 今天 = () => new Date().toISOString().slice(0, 10);
const 距天 = (d) => Math.round((new Date(d + 'T00:00:00Z') - new Date(今天() + 'T00:00:00Z')) / 86400000);

/** 纯函数：给登记 + 今天 ⇒ 每条的状态（在期／临期／过期）—— 判据只有这一处，别在别处重写一份（内核 #68） */
export const 判状态 = (登记, 今 = 今天()) => {
  const 临 = Number(登记.临期门槛天 ?? 3);
  return (登记.目录 || []).map((d) => {
    const 剩 = Math.round((new Date(d.复核 + 'T00:00:00Z') - new Date(今 + 'T00:00:00Z')) / 86400000);
    const 状 = 剩 < 0 ? '过期' : 剩 <= 临 ? '临期' : '在期';
    return { ...d, 剩, 状 };
  });
};

const 读登记 = (ws) => JSON.parse(fs.readFileSync(登记路(ws), 'utf8'));

/** 回补：豁免区里**本窗动过**的件，逐个补检（就是核要的"豁免期间改动必须事后补检"） */
export function 回补(ws = WS, 件们 = null) {
  const 登 = 读登记(ws);
  const 豁免名 = (登.目录 || []).map((d) => d.名);
  let 件 = 件们;
  if (!件) {
    try {
      const j = JSON.parse(fs.readFileSync(path.join(ws, '台账/接续/本窗写过.json'), 'utf8'));
      件 = (j.件 || []).filter((f) => typeof f === 'string');
    } catch { 件 = []; }
  }
  const 区内 = 件.filter((f) => 豁免名.some((n) => f === n || f.startsWith(n + '/')))
    .filter((f) => !/(^|\/)_backup\//.test(f) && !/\.bak-/.test(f));
  const 列 = [];
  for (const f of 区内.slice(0, 40)) {
    const r = spawnSync('node', [path.join(ws, '神经/连续体检.mjs'), '件', f], { encoding: 'utf8', timeout: 90000 });
    const 出 = String(r.stdout || '').trim().split('\n');
    // ★ 判据只认 🔴（悬空＝改动把引用弄断了 —— 那才是"补检"要找的东西）；
    //   🟡（没人消费）对**文档类**没有意义（.md 本来就不被 import）⇒ 不算非绿，否则回补口一开就满屏黄。
    列.push({ 件: f, 判: /🔴/.test(出[0] || '') ? '红' : '绿', 行: 出[0] || '(读不到)' });
  }
  return { 豁免名, 区内, 列, 非绿: 列.filter((x) => x.判 !== '绿').length };
}

/** 一屏读数（绿时零字 —— 老板定的规矩：修好后那行字就不再出现） */
export function 一屏(ws = WS) {
  let 登; try { 登 = 读登记(ws) } catch { return '⚠️ 豁免登记读不到（台账/闸门/豁免登记.json）⇒ fail-closed：别当绿' }
  const 条 = 判状态(登);
  const 过期 = 条.filter((x) => x.状 === '过期'), 临期 = 条.filter((x) => x.状 === '临期');
  if (过期.length) return '【豁免审计】🔴 过期 ' + 过期.length + ' 条（' + 过期.map((x) => x.名).join('、') + '）⇒ node 神经/豁免审计.mjs 复核 <目录> --说 "…"';
  if (临期.length) return '【豁免审计】🟡 临期 ' + 临期.length + ' 条（' + 临期.map((x) => x.名 + '·剩' + x.剩 + '天').join('、') + '）';
  return '';
}

const 是主 = (() => { try { return !!process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url)) } catch { return false } })();

if (是主) {
  const [cmd, 参] = process.argv.slice(2);
  if (cmd === '查') {
    let 登; try { 登 = 读登记(WS) } catch { console.log('❌ 读不到 ' + 登记路(WS)); process.exit(2) }
    const 条 = 判状态(登);
    console.log('🔓 豁免审计 · 真身 ' + 登.真身);
    console.log('   登记 ' + 条.length + ' 条 ｜ 复核周期 ' + 登.复核周期天 + ' 天 ｜ 临期门槛 ' + (登.临期门槛天 ?? 3) + ' 天');
    for (const x of 条) console.log('   · ' + (x.状 === '在期' ? '✅' : x.状 === '临期' ? '🟡' : '🔴') + ' ' + x.名 + ' ｜ 下次复核 ' + x.复核 + '（剩 ' + x.剩 + ' 天）｜ 为什么：' + String(x.为什么).slice(0, 46) + '…');
    console.log('   ' + (一屏(WS) || '✅ 全在期'));
    process.exit(条.some((x) => x.状 === '过期') ? 1 : 0);
  }
  if (cmd === '回补') {
    const r = 回补(WS);
    console.log('🔁 回补 · 豁免区（' + r.豁免名.join('、') + '）本轮动过 ' + r.区内.length + ' 件 ｜ 非绿 ' + r.非绿);
    for (const x of r.列) console.log('   ' + (x.判 === '绿' ? '✅' : x.判 === '黄' ? '🟡' : '🔴') + ' ' + x.行);
    process.exit(r.非绿 ? 1 : 0);
  }
  if (cmd === '复核') {
    if (!参) { console.log('用法：豁免审计.mjs 复核 <目录|全部> --说 "为什么继续豁免／复核了什么"'); process.exit(2) }
    const i = process.argv.indexOf('--说');
    if (i <= 0) { console.log('❌ 复核必须带 --说 "…"（核要的是"谁复核＋为什么"，不是打个空勾）'); process.exit(2) }
    const 登 = 读登记(WS);
    const 新 = new Date(Date.now() + Number(登.复核周期天 || 30) * 86400000).toISOString().slice(0, 10);
    let 动 = 0;
    for (const d of 登.目录) if (参 === '全部' || d.名 === 参) { d.复核 = 新; 动++ }
    if (!动) { console.log('❌ 没有这个目录：' + 参); process.exit(2) }
    登.复核留痕 = [...(登.复核留痕 || []), { at: 今天(), 动作: '复核 ' + 参 + ' ⇒ 下次 ' + 新, 说: process.argv[i + 1] }];
    fs.writeFileSync(登记路(WS), JSON.stringify(登, null, 1));
    console.log('✅ 已复核 ' + 动 + ' 条（' + 参 + '）⇒ 下次复核 ' + 新 + ' ｜ 说：' + process.argv[i + 1]);
    process.exit(0);
  }
  if (cmd === '一屏') { const s = 一屏(WS); if (s) console.log(s); process.exit(0) }
  if (cmd === 'selftest' || cmd === '自检') {
    const os = await import('node:os');
    const 房 = fs.mkdtempSync(path.join(os.tmpdir(), '豁免审计-'));
    const 造 = (复核日) => ({ 临期门槛天: 3, 复核周期天: 30, 目录: [{ 名: '台账', 为什么: 'x', 复核: 复核日 }, { 名: '内核', 为什么: 'x', 复核: 复核日 }] });
    const 今 = '2026-10-10';
    const 案 = [
      ['在期：复核日 +20 天 ⇒ 在期', 判状态(造('2026-10-30'), 今)[0].状 === '在期'],
      ['临期：复核日 +2 天 ⇒ 临期（门槛 3）', 判状态(造('2026-10-12'), 今)[0].状 === '临期'],
      ['过期：复核日昨天 ⇒ 过期', 判状态(造('2026-10-09'), 今)[0].状 === '过期'],
      ['边界：正好 0 天 ⇒ 临期不算过期', 判状态(造('2026-10-10'), 今)[0].状 === '临期'],
      ['读数：过期 ⇒ 一屏出字（不许绿时也印）', (() => { fs.mkdirSync(path.join(房, '台账/闸门'), { recursive: true }); fs.writeFileSync(path.join(房, '台账/闸门/豁免登记.json'), JSON.stringify(造('2020-01-01'))); return 一屏(房).includes('🔴') })()],
      ['读数：全在期 ⇒ 一屏零字', (() => { fs.writeFileSync(path.join(房, '台账/闸门/豁免登记.json'), JSON.stringify(造('2099-01-01'))); return 一屏(房) === '' })()],
      ['fail-closed：登记读不到 ⇒ 报（不静默）', (() => { const 房2 = fs.mkdtempSync(path.join(os.tmpdir(), '豁免审计2-')); const r = 一屏(房2); fs.rmSync(房2, { recursive: true, force: true }); return r.includes('读不到') })()],
      // ⚠️ 1010 实犯（连续体检头部就写着这条，我又犯一次 ⇒ 它被自己的样本判成硬停）：自测样本
      //   **不许在盘上放整条路径字面量** —— 要用前缀拼出来（照抄 连续体检.mjs 自检的写法）。
      ['回补：豁免区过滤（台账里的件被认出）', (() => { const 前1 = '台账/', 前2 = '工具/', 前3 = '内核/'; const r = 回补(房, [前1 + 'a.md', 前2 + 'b.mjs', 前3 + 'c.md']); return r.区内.length === 2 && r.区内.includes(前3 + 'c.md') })()],
    ];
    let 过 = 0;
    for (const [名, ok] of 案) { console.log((ok ? '✅' : '❌') + ' ' + 名); if (ok) 过++ }
    fs.rmSync(房, { recursive: true, force: true });
    console.log('自检 ' + 过 + '/' + 案.length);
    process.exit(过 === 案.length ? 0 : 1);
  }
  console.log('用法：豁免审计.mjs 查 ｜ 回补 ｜ 复核 <目录> --说 "…" ｜ 一屏 ｜ selftest');
  process.exit(2);
}
