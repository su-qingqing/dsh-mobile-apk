#!/usr/bin/env node
/**
 * 资产.mjs v1 · 2026-09-23 —— 「① 资产（换窗还在、不必被调用就该在场）」的**入口／出口／时间闸**。
 * 为什么有它：`内核/资产.md` 早写着入口的三件事（① **他亲口说** ② 落这里 ③ 进 `$DSH_HOME/AGENTS.md` 注入行），
 *   但**只有条文、没有机器路径**；而且它自己的「诚实缺口」写着：**打烊单默契表那些「他纠正我 → 我改 → 我记住」还没归拢进来**。
 * 外部顾问（千问 3.8-max，2026-09-23）四条建议里，跟我们已有重合的**不重复造**，采纳这三条：
 *   ① **入口挂在既有动作上、不造新仪式**，**每窗至多 1 条增量**（反例：按「星星」关键词自动写 ⇒ 情绪话被误当默契）
 *   ② **出口分两类**：**已升格的资产条目绝不落**；**候选可落**（留痕＝挪位置，原文不删）
 *   ③ **时间闸要带探针词**（防「**0 命中 ≠ 没有**」把真资产误落）；**身份锚不设闸**
 *   ＋ 他的第 4 条「**不做独立模块**，只做 user 记忆子集 ＋ `资产.md` 一行指针」：**我们本来就是文件＋一行，不新增模块**。
 * ⚠️ **参数（90 天／探针词表／每窗 1 条）＝ 阈值 ⇒ 按老板 09-23 令归「他亲审」**，这里只放默认值并标出来源。
 * 用法：node 神经/资产.mjs 查 ｜ 候选 "<话>" [--出处 …] [--谁 老板|我] ｜ 升 <id前缀> ｜ 归拢 [--写] ｜ 复查 [--天 90] [--落] ｜ 核
 */
import fs from 'node:fs'
import path from 'node:path'
const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const P = (...a) => path.join(WS, ...a)
const 条 = process.argv.slice(2), 动词 = 条[0] || '查'
const 实参 = (名) => { const i = process.argv.indexOf(名); return i > 0 ? process.argv[i + 1] : null }
const 账 = P('记忆', '资产候选.json')
const 资产 = P('内核', '资产.md')
// ── ★ 尺子（阈值）：改这些要他亲审 —— 括号里是来源
const 天 = Number(实参('--天') || 90)                    // 千问建议 90 天（他标为推测参数）
const 探针 = ['星星', '默契', '我们之间', '称呼', '口令', '较真', '★', '打烊']  // 等价词探针（千问建议 3 组，我按我们自己的词典扩到 8）
const 每窗上限 = 1                                        // 千问建议：每窗至多 1 条增量
const 读账 = () => { try { return JSON.parse(fs.readFileSync(账, 'utf8')) } catch { return { 候选: [] } } }
const 写账 = (d) => { d.at = new Date().toISOString(); fs.writeFileSync(账, JSON.stringify(d, null, 1)) }
const 在 = (d) => (d.候选 || []).filter((x) => x.状态 === '候选')
if (动词 === '核') {
  const 断 = [
    ['资产文件在场', fs.existsSync(资产)],
    ['探针词表非空（尺子在场）', 探针.length >= 3],
    ['每窗上限＝1（不刷屏）', 每窗上限 === 1],
    ['账可读', Array.isArray(读账().候选)],
  ]
  let 过 = 0; for (const [名, 真] of 断) { if (真) 过++; console.log('  ' + (真 ? '✅' : '❌') + ' ' + 名) }
  console.log('\n  自检：' + 过 + '/' + 断.length + (过 === 断.length ? ' 全绿' : ' ⚠️ 有红')); process.exit(过 === 断.length ? 0 : 1)
}
if (动词 === '候选') {
  const 话 = 条[1]
  if (!话 || 话.length < 6) { console.error('❌ 用法：资产.mjs 候选 "<一句话>" [--出处 …] [--谁 老板|我]'); process.exit(1) }
  const d = 读账()
  const 今 = new Date().toISOString().slice(0, 10)
  const 本窗 = d.候选.filter((x) => x.放入 === 今).length
  if (本窗 >= 每窗上限) console.log('  ⚠️ 今天已有 ' + 本窗 + ' 条候选 —— 上限 ' + 每窗上限 + '/窗（防堆积）⇒ 我先只报给你，不写第二条')
  const id = '资-' + Math.random().toString(36).slice(2, 8)
  d.候选.push({ id, 话, 出处: 实参('--出处') || '', 谁: 实参('--谁') || '老板', 放入: 今, 状态: '候选' })
  写账(d)
  // 留痕：原文进档案（挪位置不丢）
  const 档 = P('记忆', '历史遗留', '默契候选_' + 今.replace(/-/g, '') + '.md')
  fs.mkdirSync(P('记忆', '历史遗留'), { recursive: true })
  if (!fs.existsSync(档)) fs.writeFileSync(档, '# 默契候选（' + 今 + '）· 留痕用：**原文一字不删**；升格后才进 `内核/资产.md`\n\n')
  fs.appendFileSync(档, '- [' + id + '] ' + 话 + (实参('--出处') ? ' ｜出处：' + 实参('--出处') : '') + '\n')
  console.log('  ✅ 候选 ' + id + '（今天第 ' + (本窗 + 1) + ' 条）｜留痕 ' + 档.replace(WS + '/', ''))
  console.log('     **入口条件**（不许跳）：① 他**亲口说** ② **提纯成一句结论** ⇒ `提纯 <id> --成 "…"` ③ `升` 落进 `内核/资产.md` ④ 进 `$DSH_HOME/AGENTS.md` 注入行')
  process.exit(0)
}
if (动词 === '提纯') {
  // ★ 提纯（老板口径：他的原话是**依据的根源**，不是能直接用的东西）⇒ 一句结论才配当资产候选
  const k = 条[1]; const 成 = 实参('--成'); const d = 读账(); const x = (d.候选 || []).find((y) => y.id.startsWith(k))
  if (!x) { console.error('❌ 没有这个候选：' + k); process.exit(1) }
  if (!成 || 成.length < 6) { console.error('❌ 用法：资产.mjs 提纯 <id前缀> --成 "<一句结论>"'); process.exit(1) }
  x.提纯 = 成; x.提纯于 = new Date().toISOString().slice(0, 10); 写账(d)
  console.log('  ✂️ ' + x.id + ' 已提纯 ⇒ ' + 成)
  console.log('     （过程原文仍在候选账里，一个字没删；升格要他亲口说）')
  process.exit(0)
}
if (动词 === '升') {
  const k = 条[1]; const d = 读账(); const x = 在(d).find((y) => y.id.startsWith(k))
  if (!x) { console.error('❌ 没有这个候选：' + k); process.exit(1) }
  if (x.谁 !== '老板') { console.error('❌ 入口条件①：**他亲口说**才能升（这条记的是「' + x.谁 + '」）'); process.exit(2) }
  if (!x.提纯) { console.error('❌ 升格前先提纯：`资产.mjs 提纯 ' + x.id + ' --成 "<一句结论>"`（过程不能直接当资产）'); process.exit(3) }
  const 用 = x.提纯 || x.话
  const t = fs.readFileSync(资产, 'utf8').trimEnd()
  const n = (t.match(/^\| \*\*\d+\*\*/gm) || []).length + 1
  fs.writeFileSync(资产, t + '\n| **' + n + '** | （待起名） | ' + 用 + ' | 老板 ' + x.放入 + ' |\n')
  x.状态 = '已升'; x.升于 = new Date().toISOString().slice(0, 10); 写账(d)
  console.log('  ✅ 已升进 `内核/资产.md` 第 ' + n + ' 行（候选 ' + x.id + '）')
  console.log('     ⚠️ **还差第三件**：把它加进 `$DSH_HOME/AGENTS.md` 的注入行（不然新窗说不出它 ⇒ 它还只是文档）')
  process.exit(0)
}
if (动词 === '归拢') {
  // 从打烊单的「默契表」段抓表行 ⇒ 转成候选（他纠正我的那些来回：**过程**，要提纯成结论才配当资产）
  const dir = P('台账', '轮末'); let 命中 = 0, 新 = 0
  const 文件 = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.startsWith('打烊_') && f.endsWith('.md')).sort() : []
  const d = 读账()
  for (const f of 文件) {
    const 行 = fs.readFileSync(path.join(dir, f), 'utf8').split('\n')
    let 进 = false
    for (const ln of 行) {
      if (/^##\s/.test(ln)) { 进 = /默契表/.test(ln); continue }
      if (!进 || !/^\|/.test(ln) || /^\|[\s\-:|]+\|$/.test(ln)) continue
      const 格 = ln.split('|').map((s) => s.trim()).filter(Boolean)
      if (格.length < 3 || /原文|原话|过程/.test(格[0])) continue
      if (/他纠正的原话|当时我在干什么|落在哪个环节|下次挂在哪一刻|怎么填/.test(格.join(''))) continue
      命中++
      const 话 = 格.slice(1).join(' ｜ ').slice(0, 200)
      if (d.候选.some((x) => x.话 === 话)) continue
      新++
      if (process.argv.includes('--写')) d.候选.push({ id: '资-' + Math.random().toString(36).slice(2, 8), 话, 出处: f + ' 默契表', 谁: '老板', 放入: new Date().toISOString().slice(0, 10), 状态: '候选' })
    }
  }
  if (process.argv.includes('--写')) 写账(d)
  console.log('  🔎 归拢：扫了打烊单 ' + 文件.length + ' 张 ｜ 默契表里 ' + 命中 + ' 条来回 ｜ 新增候选 ' + 新 + (process.argv.includes('--写') ? '（已写）' : '（干跑，要写加 --写）'))
  console.log('     ⚠️ 那些是**过程**（他纠正我的来回）⇒ 升格前先**提纯成一句结论**；本工具不替他提纯。')
  process.exit(0)
}
if (动词 === '复查') {
  const 真落 = process.argv.includes('--落'); const 现 = Date.now(); const d = 读账()
  // 探针：近 N 天工作区文本里有没有等价词命中（近似，防 0 命中假阴性；只扫工作区，不扫会话原文）
  const 近文 = []
  for (const dir of ['台账', '内核', '记忆']) {
    const 走 = (p, 深) => { let 项 = []; try { 项 = fs.readdirSync(p, { withFileTypes: true }) } catch { return }
      for (const e of 项) { const q = path.join(p, e.name)
        if (e.isDirectory()) { if (深 < 2 && !/历史遗留|_backup/.test(q)) 走(q, 深 + 1); continue }
        if (!/\.(md|json)$/.test(e.name)) continue
        try { if (现 - fs.statSync(q).mtimeMs <= 天 * 86400000) 近文.push(fs.readFileSync(q, 'utf8')) } catch { } } }
    走(P(dir), 0)
  }
  const 全 = 近文.join('\n')
  const 候 = 在(d).filter((x) => 现 - Date.parse(x.放入 || '') >= 天 * 86400000)
  console.log('\n🧹 资产候选复查（时间闸）· 判据：候选 ≥ ' + 天 + ' 天 ＋ **探针词一个都没命中**（近 ' + 天 + ' 天工作区文本）⇒ 候选落')
  console.log('   ⚠️ 阈值 ' + 天 + ' 天／探针 ' + 探针.length + ' 词 ＝ **待他亲审**（来源：千问 3.8-max 建议＋我扩充）｜已升格的资产**绝不落**')
  for (const x of 候) {
    const 中 = 探针.filter((w) => x.话.includes(w) || 全.includes(w)).filter((w) => x.话.includes(w))
    const 真中 = 探针.filter((w) => 全.includes(w))
    if (真中.length) { console.log('   · ' + x.id + ' ⇒ **留**（探针命中：' + 真中.slice(0, 4).join('/') + '）'); continue }
    console.log('   · ' + x.id + ' ⇒ 候选落 ｜' + String(x.话).slice(0, 50))
    if (真落) { x.状态 = '已落'; x.落于 = new Date().toISOString().slice(0, 10) }
  }
  if (!候.length) console.log('   ✅ 没有到期的候选')
  if (真落) 写账(d)
  process.exit(0)
}
const d = 读账()
console.log('★ 资产候选 · 在场 ' + 在(d).length + ' 条 ｜ 已升 ' + d.候选.filter((x) => x.状态 === '已升').length + ' ｜ 已落 ' + d.候选.filter((x) => x.状态 === '已落').length)
for (const x of d.候选) console.log('   [' + x.状态 + '] ' + x.id + ' ｜' + (x.提纯 ? '✂️ ' + x.提纯 : '（未提纯）' + String(x.话).slice(0, 64)) + (x.判断 ? ' ｜ ⇒ ' + x.判断 : ''))
console.log('\n   入口三件：① 他亲口说 ② `升` ⇒ `内核/资产.md` ③ 进 `$DSH_HOME/AGENTS.md` 注入行 ｜ 上限 ' + 每窗上限 + ' 条/窗 ｜ 闸 ' + 天 + ' 天＋探针（待他亲审）')
