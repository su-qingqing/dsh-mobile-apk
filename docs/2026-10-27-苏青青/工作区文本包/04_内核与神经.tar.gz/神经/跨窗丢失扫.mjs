#!/usr/bin/env node
/**
 * 跨窗丢失扫 —— 老板 1019 令「给我查，就我刚刚对话那窗口对比，我们这窗口到底少了什么」
 *
 * 判据（能用机器判的那部分，不靠我评）：
 *   一条「令」会不会被下一个窗丢掉，看它**落到了哪一层**：
 *     ① 红线本（`$DSH_HOME/AGENTS.md`）＝每轮注入 ⇒ **不会丢**
 *     ② pins（`工具/开工/必读卡.mjs` 渲染出来的「每轮必读」）＝每轮注入 ⇒ **不会丢**
 *     ③ 记忆库（meow-memory）＝按需检索 ⇒ **半丢**（要我想起来查）
 *     ④ 台账／令账／交接单／做法库 ＝ **要主动去翻** ⇒ **新窗必丢**（本器要抓的就是这一类）
 *
 *   机器可判的代理指标：令账「该放哪」那一格
 *     · 写了 pins／必读／红线／内核／AGENTS ⇒ 也许真落了（仍要去第②③层复核，本器给"待核"）
 *     · **只写了「本账／令账／台账／交接单」** ⇒ 直接判 **必丢**
 *
 * 用法：
 *   node 神经/跨窗丢失扫.mjs           # 只报告
 *   node 神经/跨窗丢失扫.mjs --落地     # 同时写 台账/接续/跨窗丢失清单.md
 */
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const WS = '/storage/emulated/0/3';
const DSH = process.env.DSH_HOME || (process.env.HOME + '/.dsh');
const 令账 = path.join(WS, '台账/接续/令账.md');

const 红线本 = (() => { try { return fs.readFileSync(path.join(DSH, 'AGENTS.md'), 'utf8'); } catch { return ''; } })();
const pins文 = (() => {
  try {
    return execFileSync(process.execPath, [path.join(WS, '工具/开工/必读卡.mjs')], { maxBuffer: 8 * 1024 * 1024 }).toString('utf8');
  } catch { return ''; }
})();

const 上层词 = /pins|必读|红线|内核|AGENTS|记忆库|memory|做法库/;
const 台账词 = /本账|令账|台账|交接单|交接牌/;

const 行 = fs.readFileSync(令账, 'utf8').split('\n');
const 条 = [];
for (const l of 行) {
  if (!/^\|\s*10\d\d-\d+/.test(l.replace(/^\|\s*/, '| ')) && !/^\|\s*1019-\d+/.test(l)) continue;
  const c = l.split('|').map(s => s.trim());
  // c[0]='', c[1]=号, c[2]=原话, c[3]=该放哪, c[4]=该做什么, c[5]=状态, c[6]=证据
  if (c.length < 5) continue;
  const 号 = c[1], 原话 = c[2] || '', 该放哪 = c[3] || '', 状态 = c[5] || '';
  条.push({ 号, 原话, 该放哪, 状态 });
}

const 必丢 = 条.filter(x => 台账词.test(x.该放哪) && !上层词.test(x.该放哪));
const 待核 = 条.filter(x => 上层词.test(x.该放哪));

// 额外体检：进场（人格/情感/默契）读没读
let 进场 = null;
try {
  const j = JSON.parse(fs.readFileSync(path.join(WS, '台账/接续/连续性已读.json'), 'utf8'));
  进场 = { 窗: j.窗, 读于: j.读于 };
} catch { 进场 = null; }

console.log('══ 跨窗丢失扫 · ' + new Date().toISOString().slice(0, 16).replace('T', ' ') + ' ══');
console.log('令账条数(可解析):', 条.length, '｜只落台账层(必丢):', 必丢.length, '｜标了上层(待核):', 待核.length);
console.log('');
console.log('── A. 只落台账层 ⇒ 下一个窗必丢（' + 必丢.length + ' 条）──');
必丢.slice(0, 15).forEach(x => console.log('  ' + x.号 + '  ' + x.原话.replace(/\*\*/g, '').slice(0, 46) + '…'));
if (必丢.length > 15) console.log('  …另 ' + (必丢.length - 15) + ' 条');
console.log('');
console.log('── B. 进场（人格/情感/默契）──');
console.log('  ', 进场 ? ('上次读于 ' + 进场.读于 + ' · 窗 ' + 进场.窗) : '读不到 连续性已读.json');
console.log('');
console.log('── C. 红线本 / pins 里有没有「一行可复制命令」这条令 ──');
for (const k of ['复制', '一整行', '代码块']) {
  console.log('  ' + k.padEnd(4) + '  红线本:' + (红线本.includes(k) ? '有' : '0') + '   pins:' + (pins文.includes(k) ? '有' : '0'));
}

if (process.argv.includes('--落地')) {
  const out = [];
  out.push('# 跨窗丢失清单（机器扫 · ' + new Date().toISOString().slice(0, 16).replace('T', ' ') + '）');
  out.push('');
  out.push('> 判据：一条令只落在「台账层」（令账／台账／交接单／做法库）⇒ **新窗必丢**（要主动去翻）；');
  out.push('> 落在「红线本／pins」⇒ 每轮注入，不会丢；落在「记忆库」⇒ 按需检索，半丢。');
  out.push('> 真源：`神经/跨窗丢失扫.mjs`（复跑：`node 神经/跨窗丢失扫.mjs --落地`）');
  out.push('');
  out.push('## 一、只落台账层 ⇒ 必丢（' + 必丢.length + ' / ' + 条.length + '）');
  out.push('');
  out.push('| 号 | 原话（截断） | 现在放哪 | 该怎么补 |');
  out.push('|---|---|---|---|');
  必丢.forEach(x => out.push('| ' + x.号 + ' | ' + x.原话.replace(/\|/g, '／').slice(0, 40) + ' | 台账层 | 要么进 pins（警报/指针），要么进红线本（条文） |'));
  out.push('');
  out.push('## 二、进场没读（人格/情感/默契）');
  out.push('');
  out.push('- 上次读：' + (进场 ? 进场.读于 + '（窗 ' + 进场.窗 + '）' : '读不到'));
  out.push('- 判据：`台账/接续/连续性已读.json` 的「窗」必须等于**本窗**；不等 ⇒ 本窗没读，思考里就没有人格/情感/默契');
  out.push('- 修法：老板 1014 已经说了「开局大大方方读一遍」⇒ 要把「读」变成**必然时刻**（首轮自动跑 `进场.mjs`），不是靠自觉');
  out.push('');
  out.push('## 三、命令规范（一行可复制）');
  out.push('');
  out.push('- 实测：`复制`／`一整行` 在红线本 **0**、pins **0** ⇒ 新窗必丢');
  out.push('- 该怎么补：进红线本一条（行为红线），并进 pins（每轮）。**老板落章前我不自己加**');
  out.push('');
  fs.writeFileSync(path.join(WS, '台账/接续/跨窗丢失清单.md'), out.join('\n'));
  console.log('\n✅ 已写 台账/接续/跨窗丢失清单.md');
}
