#!/usr/bin/env node
// 身份行 —— 每条新会话第一次回复末尾那一行（老板 2026-09-22 换的口径：要有温度）
//   格式：苏青青 · 你的工作助理 · 未完成的工作事项 <M> 件
//   M 现算：**取 `库.mjs` 那一屏的数**（同一个数他看得见），不背、不另立口径。
//   内核条数**不进这一行**（他要温度）；内核在不在的自检由 `库.mjs`【身份】行承担。
// 用法：node 神经/身份行.mjs ｜ selftest
import { execSync } from 'node:child_process'
import { existsSync } from 'node:fs'
const ROOT = '/storage/emulated/0/3'
const NODE = '/data/data/com.dsharnessmobile.shell/files/usr/bin/node'
const 尾巴 = '苏青青 · 你的工作助理 · 未完成的工作事项 '
export function 数() {
  let 输出 = ''
  try { 输出 = execSync('"' + NODE + '" ' + ROOT + '/工具/开工/库.mjs', { cwd: ROOT, encoding: 'utf8', timeout: 60000, shell: existsSync('/data/data/com.dsharnessmobile.shell/files/usr/bin/bash') ? '/data/data/com.dsharnessmobile.shell/files/usr/bin/bash' : '/bin/sh' }) } catch (e) { 输出 = String((e && e.stdout) || '') }
  const m = 输出.match(/在办\s*(\d+)\s*件/)
  return m ? { M: Number(m[1]), 源: '库.mjs' } : { M: null, 源: '读不到' }
}
export function 行() {
  const r = 数()
  return r.M === null ? 尾巴 + '? 件（**读不到在办数，先跑 库.mjs 看一眼**）' : 尾巴 + r.M + ' 件'
}
const isMain = process.argv[1] && /身份行\.mjs$/.test(process.argv[1])
if (isMain) {
  if (process.argv[2] === 'selftest') {
    const l = 行(), r = 数()
    const t = [
      ['形如「苏青青 · 你的工作助理 · 未完成的工作事项 N 件」', /^苏青青 · 你的工作助理 · 未完成的工作事项 (\d+|\?) 件/.test(l)],
      ['不再出现「内核 v1.2」「台账在办」字样（老板要温度）', !/内核 v1\.2|台账在办/.test(l)],
      ['M 是真数（从 库.mjs 现取，不是硬编码）', r.M === null || (Number.isInteger(r.M) && r.M >= 0)],
      ['数出来源可追溯', r.源 === '库.mjs' || r.源 === '读不到'],
    ]
    let ok = 0
    for (const [n, p] of t) { console.log((p ? '✅' : '❌') + ' ' + n); p && ok++ }
    console.log('身份行 selftest ' + ok + '/' + t.length + (ok === t.length ? ' 全过' : ' ❌ 有红') + '　｜　现在这一行：' + l)
    process.exit(ok === t.length ? 0 : 1)
  }
  console.log(行())
}
