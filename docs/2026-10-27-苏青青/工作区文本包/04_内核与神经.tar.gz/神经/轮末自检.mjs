/**
 * 轮末自检 —— ③层挂点的**工作区那一半**（2026-09-27）
 *
 * 范式（照抄 `工具/路由层/影子.mjs`）：**逻辑住工作区，插件只做 mtime 热加载**
 *   ⇒ 以后改这里的判据**不用重启引擎**。
 *
 * 它回答两个问题（都是老板点名的那九样里的）：
 *   ① 本轮改过的文件，**每一个都有退路吗**（改前的那份还在不在）—— B01
 *   ② 全盘的路径引用里，**有没有新断的** —— 死指针
 *
 * ⚠️ 契约：**只观察、只报告，绝不拦**（同 fs 钩子的既有约定）。
 *   ★ 2026-10-03 夜**唯一例外**（老板 goal 判据「能被"忽略错误继续走"就还算传送层，不算过」）：
 *     **只写一本账** —— `台账/接续/未结红.json`（把 报警 落盘 ⇒ 出发表那行据此 ⛔硬停）。
 *     除这本账之外，一个字不改盘。写它的时候认 `工作区` 参数（沙盒/隔离跑不会写脏生产）。
 * 调用方（插件 turn-stopping）拿 `摘要` 拼一行；`报警` 非空 ＝ 有红。
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

// ★ 1009 子件热加载（实测 _backup/_沙盒-热加载）：插件按 mtime 热加载的是**本文件**，
//   而本文件内部的 import('./x.mjs') 不带版本参数 ⇒ 在引擎进程里被 ESM 缓存住 ＝「改了子件要重启才生效」。
//   实测三条：①父换 query、子不带 ⇒ 子不刷新；②子带 ?v=mtime ⇒ 刷新。⇒ 子件统一走这个 helper。
//   fail-open 不变：文件不在，statSync 抛错 ⇒ 外层 catch 照旧兜底。
const 热件 = (相对) => {
  // ★ 1010 修：**只拿 mtime 当版本号会漏** —— 本仓 `edit` 通道改文件时**不更新 mtime**
  //   （1010 夜实测：`报告体检.mjs` 内容变了 size 25276→28610，mtime 却仍停在 01:37）
  //   ⇒ 版本号 = **mtime ＋ size 两样一起**，任一变了就重新加载（fail-open 不变：文件不在时抛错，外层照旧兜底）。
  const p = fileURLToPath(new URL(相对, import.meta.url));
  const st = fs.statSync(p);
  // ★ 1013 第30刀：版本号再加 **ctime** —— 原判据 `mtime + size` 会漏「**同长度改内容**」
  //   （1010 夜那条记忆自己就写明这个边界：红队用 touch 伪造 mtime 能打穿同族闸）；
  //   ctime 只要真写过就动 ⇒ 把那一类漏补掉。（重载是廉价 import；ctime 只在真动过时前进）
  return import(相对 + '?v=' + st.mtimeMs + '-' + st.size + '-' + st.ctimeMs);
};

// ★ 1009 红账续期修根（同一条坑第二次踩 ⇒ 当场改根 · 红线 24③）：报警文案里带**易变定位** ——
//   报告门那条末尾是「［倒数第 N 条回复：…］」，N 随对话推进就变 ⇒ 全串比对永远为假
//   ⇒ `处理`（我的表态）被清 ⇒ **每轮硬停、表态续不上**。
//   ⇒ 比对前把方括号里的定位归一；其余一个字节都不动（文件名／缺格位列表照旧参与比对，防"换个对象混过去"）。
const 归一红 = (s) => String(s).replace(/［[^］]*］/g, '［…］');

// ★ 1009「假绿」修根（老板令「把那个假绿给修了」）：机制上，插件按 mtime 热加载**本文件**、本文件内的子件
//   走 `热件()` 也带 mtime ⇒ 理论上"改完即生效"；可**我看不出来**引擎进程里跑的到底是哪一版 ——
//   我手动跑永远绿（新进程天然加载最新代码）⇒ 这就是"假绿"。
//   ⇒ 装一盏**自证的灯**：把「本文件 ＋ 6 个子件」的 mtime 短码印进每一轮摘要。
//   判据：摘要里**出现**「版 …」这一栏 ＝ 带这行代码的新版确实在引擎进程里跑着；
//        **没出现**（或与 `轮末自检.mjs 版` 打印的不一致）⇒ 引擎进程还在跑旧版 ⇒ **要重启**。
const 短码 = (p) => { try { return Math.round(fs.statSync(p).mtimeMs).toString(36).slice(-5) } catch { return '?????' } };
const 子件清单 = ['./报告体检.mjs', './交接单指针.mjs', '../工具/轮末/轮型.mjs', '../工具/轮末/针归仓.mjs', '../工具/开工/收尾欠项.mjs', '../工具/开工/探针待跑.mjs'];
export function 版指纹() {
  return '自' + 短码(fileURLToPath(import.meta.url)) + ' 子' + 子件清单.map((r) => 短码(fileURLToPath(new URL(r, import.meta.url)))).join('');
}

// ★ 2026-09-28 打样接线（老板令「把这些动作给我挂上引擎树，不能靠你自觉」）：
//   把「收尾欠项」的判据接进来 —— 判据住工作区 `工具/开工/收尾欠项.mjs`。
//   用**动态 import ＋ 兜底**：沙盒／隔离环境里那个文件不在 ⇒ 也绝不许把本模块加载弄炸（fail-open）。
let 算收尾 = () => null;
try { 算收尾 = (await 热件('../工具/开工/收尾欠项.mjs')).算 || 算收尾; } catch (e0) { 算收尾 = () => null }

// ★ 2026-09-28 第二件接线（老板令 #26「**针归仓要我自己点门，全自动的机器，所以说要去做掉**」）：
//   判据住工作区 `工具/轮末/针归仓.mjs` —— 每根针点名唯一主仓；没归仓 / 改了老文件没退路又没表态 ⇒ 报红。
//   同样 fail-open：读不到那个文件 ⇒ 本模块照常跑（绝不许把收尾链路弄炸）。
//   ⚠️ **2026-09-28 当场抓到的坑**：这段此前**只有 import、没有调用** ＝「**接线了但没通电**」，
//      而且 fail-open 让 import 失败也**静默** ⇒ 仪器挂在树上等于没装。现在**真调**；
//      `工具/轮末/针归仓.mjs` 的反证⑪ 专锁「必须真调用」这一条（防再犯）。
let 算归仓 = () => null;
let 针归仓取起点 = () => null;
try {
  const 针 = await 热件('../工具/轮末/针归仓.mjs')
  算归仓 = 针.算 || 算归仓
  // ★ 1013 加：**起点只认针归仓那一处**（同一件事不许两个答案 —— 下面是治一个拦了几十轮的假红）
  针归仓取起点 = 针.取起点 || 针归仓取起点
} catch (e1) { 算归仓 = () => null; 针归仓取起点 = () => null }

// ★ 2026-09-29 第三件接线（治**链断**的轻量端 · 依据 `台账/接续/挂靠总账.md` §四「批一·批一第 2 条」）：
//   病根：`块体检.mjs`／`埋针闸.mjs` 这类"该偶尔跑一次"的仪器**没有必然时刻** ⇒ 挂点体检把它们报成**链断**
//   （有人调它，可调用者自己也没挂点）。治法＝**收尾这一刻，满足条件才印一行**「该跑它了」。
//   ★ 红线 #2（不自动）：`探针待跑.mjs` **只读、只印**，绝不自己跑被点名的仪器、绝不改盘、绝不拦。
//   同样 fail-open；且同样**必须真调**（上面那段 0928 的坑：只 import 不调用 ＝ 接线没通电）。
let 算待跑 = () => null;
try { 算待跑 = (await 热件('../工具/开工/探针待跑.mjs')).算 || 算待跑; } catch (e2) { 算待跑 = () => null }

// ★ 2026-09-29 第四件接线（治「**指针型动作没人盯**」· 依据当天实测：我写完新交接单却忘了同步 `交接单_最新.md`）：
//   病根：`交接单_最新.md` 是 pins 里点名的「**接活第一件事**」，却是**手工复制**的 ⇒ 漏同步 ⇒ 下一窗读旧页，**没人看得见**。
//   判据住工作区 `神经/交接单指针.mjs` 的 `查()`（阴性反证②锁的就是这次漏同步）。
//   同样 fail-open；且同样**必须真调**（只 import 不调用 ＝ 接线没通电）。
let 算指针 = () => null;
try { 算指针 = (await 热件('./交接单指针.mjs')).查 || 算指针; } catch (e3) { 算指针 = () => null }

// ★ 2026-10-01 第五件接线（老板令「诚实边界全自动，做掉」＋ pins 首条「报告格式四件套」→ 门）：
//   判据住工作区 `神经/报告体检.mjs` —— 每轮末机器自己扫我最后一条回复，六格缺哪格当场报红
//   （报警进下一轮 pins 的 selfcheck 行 ⇒ 每轮必到）。背景实测：pins 每轮渲染这六格、**没有门** ⇒ 09-28 照样漏格被抓。
//   同样 fail-open；且同样**必须真调**（0928 的坑：只 import 不调用 ＝ 接线没通电 ⇒ 反证⑤ 锁它）。
let 算报告 = () => null;
try { 算报告 = (await 热件('./报告体检.mjs')).查 || 算报告; } catch (e4) { 算报告 = () => null }

// ★ 轮型闸（1006 · 老板令「加一个新功能不就好了」）：报告体检的**判据本体一个字不动**，放到它上游 ——
//   先判「这一轮是什么轮」：①他那一轮的话明说在聊天/思考（不涉及改动、最多查资料）②他这句之后我**无写类动作**；
//   **两个同时成立才放过**；打烊 **永不放过**（老板明令「最后一个跑打烊的流程，还是要把我们的库弄好」）；读不到 ⇒ 从严。
//   判据住工作区 `工具/轮末/轮型.mjs`（1006 老板澄清「你弄出来的也没有问题」⇒ 保留）。
let 算轮型 = () => null;
try { 算轮型 = (await 热件('../工具/轮末/轮型.mjs')).判 || 算轮型; } catch (eR2) { 算轮型 = () => null }

// ★ 2026-10-03 第六件接线（**头注释第 ② 条一直欠着的那件** · 老板 1003 令「那个诚实边界，该验的得验啊，
//   你不能这种口头去跑啊，得验啊」当场验出来的）：头注释写着「② 全盘的路径引用里，有没有新断的 —— 死指针」，
//   但实现里从来只有别的五件 ⇒ **承诺了、没兑现**，正是「摆 ≠ 拦」。
//   判据住工作区 `工具/记忆/id闸.mjs` 的 `扫`（**纯 CLI、没有导出** ⇒ 走子进程取行，不许 shell：
//   `spawnSync('node', [数组])` 不过 sh，避开 `0mus52op7` 记的"本机 sh 不存在"那条坑）。
//   它答的是：文件里那些 `0muxxxxxxx` 形式的**记忆引用**，落不落得到**唯一一条**记忆。
//   实测 518ms（1003 夜现测）⇒ 挂轮末可接受；只印**汇总行**，不把明细刷进轮末那一行。
//   同样 fail-open、同样**必须真调**（只写不调 ＝ 接线没通电 · 见 `0mukdiilt`）。
let 算引用 = () => null;
算引用 = (工作区) => {
  try {
    const 根 = 工作区 || '/storage/emulated/0/3';
    const r = spawnSync('node', [path.join(根, '工具/记忆/id闸.mjs'), '扫'], { encoding: 'utf8', timeout: 30000 });
    const 行 = String((r && r.stdout) || '').split('\n').map((x) => x.trim()).filter(Boolean);
    const 汇总 = 行.find((x) => x.startsWith('共 ')) || '';
    if (!汇总) return { 读不到: true, 一行: '引用 读不到' };
    const m = /❌\s*(\d+)\s*（判决）/.exec(汇总);
    const 坏 = m ? Number(m[1]) : 0;
    return { 坏, 汇总, 一行: '引用 ' + (坏 ? '❌ ' + 坏 + ' 处' : '✅ 0 处') };
  } catch (eJ) { return { 读不到: true, 一行: '引用 读不到' } }
};

export const 工作区默认 = '/storage/emulated/0/3';

const md5 = (f) => { try { return crypto.createHash('md5').update(fs.readFileSync(f)).digest('hex'); } catch { return null; } };

/** 读意图账，取 `起点`（ms）之后改过的文件（去重）—— ⚠️ 这个感受器 09-24 起就死了（fs/write-intent 不再到插件） */
export function 按意图账(工作区 = 工作区默认, 起点 = 0) {
  const p = path.join(工作区, '台账/接续/写意图.jsonl');
  const out = new Set();
  let 行 = [];
  try { 行 = fs.readFileSync(p, 'utf8').split('\n') } catch { return [] }
  for (const s of 行) {
    if (!s.trim()) continue;
    let j; try { j = JSON.parse(s) } catch { continue }
    const t = Date.parse(j.at || '');
    if (!Number.isFinite(t) || t < 起点) continue;
    const q = String(j.p || '');
    if (!q) continue;
    // 只认工作区内的、真存在的文件（目录/外部路径不管）
    const 全 = path.isAbsolute(q) ? q : path.join(工作区, q);
    try { if (fs.statSync(全).isFile()) out.add(path.relative(工作区, 全)) } catch { /* 已经不在了，不算 */ }
  }
  return [...out];
}

/** 扫目录（只这些地方会改）＋不扫（备份／依赖／停用） */
export const 扫的目录 = ["内核", "台账", "工具", "记忆"];
export const 不扫的名字 = new Set(["_backup", "node_modules", ".git", "_停用·_双证", "归档"]);
const 自噪声 = new Set(["台账/轮末/自动记账.json", "台账/接续/轮末自检.上次", "台账/接续/写意图.jsonl"]);

/**
 * ★ mtime 兜底（2026-09-27）：意图账死掉之后，`改没改过` 只能问盘自己 —— 「这轮动过」就是改过。
 *   反证留在这里：**把写意图账删了／它一条不写，本函数照样看得见刚改过的文件**（见 selftest 反证②）。
 *
 * ★★ 1013 第30刀 · **修根**：判据从「只看 mtime」改成「看 max(mtime, ctime)」。
 *   实测（本仓）：**`edit`／`write` 工具通道写文件不改 mtime** ——
 *     ① `工具/开工/库.mjs` 03:51 被 edit 改过 ⇒ mtime 仍停 03:40（上一次 node 写它的时刻）、而 ctime 是 03:52；
 *     ② `台账/接续/总库.md` 被 edit 改了 5 行 ⇒ mtime 仍停 15 天前，**比它自己的备份还旧**。
 *   ⇒ 旧判据下，**凡是我用 edit 改的件，这个门都看不见** ⇒ 它连带看不见「**那件改前有没有退路**」——
 *     也就是说 **红线 5（改前先备份）的机器面，对 edit 通道是瞎的**（1013 我手误漏备份 `库.mjs`、门一声没响，就是这个原因）。
 *   ⇒ 改用 `max(mtimeMs, ctimeMs)`：`ctime` ＝ inode 变更时刻，**只要真写过它就会动**（实测成立）。
 *   ★ 口径来源（1010 夜那条记忆的结论）：「**判"改了没"永远别只看 mtime**（要看 ctime／size／内容／冻结校验）」。
 *   ★ 方向只减假绿：ctime 只在"真被动过"时前进，不会凭空变新。
 */
export function 按mtime扫(工作区 = 工作区默认, 起点 = 0, 上限 = 4000) {
  const out = new Set(); let n = 0;
  const 走 = (目录, 深) => {
    if (n >= 上限 || 深 > 6) return;
    let es = []; try { es = fs.readdirSync(目录, { withFileTypes: true }) } catch { return }
    for (const e of es) {
      if (n >= 上限) return;
      const p = path.join(目录, e.name);
      if (e.isDirectory()) { if (!不扫的名字.has(e.name)) 走(p, 深 + 1); continue }
      if (!e.isFile()) continue;
      let st; try { st = fs.statSync(p) } catch { continue }
      n++;
      if (Math.max(st.mtimeMs, st.ctimeMs) < 起点) continue;   // ★ 1013 第30刀：edit 通道不改 mtime ⇒ 必须并看 ctime
      const rel = path.relative(工作区, p).replace(/\\/g, "/");
      if (!自噪声.has(rel)) out.add(rel);
    }
  };
  for (const d of 扫的目录) 走(path.join(工作区, d), 0);
  return [...out];
}

/** 本轮改过 ＝ 意图账 ∪ mtime 兜底（两个源并起来；缺一个也漏不了） */
export function 本轮改过(工作区 = 工作区默认, 起点 = 0) {
  const a = 按意图账(工作区, 起点), b = 按mtime扫(工作区, 起点);
  return { 改过: [...new Set([...a, ...b])], 意图: a, mtime: b };
}

/** ① 改了但没退路 —— 备份区的每一份内容都跟现在一模一样（＝改前那份没了） */
export function 查退路(工作区 = 工作区默认, 改过 = []) {
  const BK = path.join(工作区, '_backup');
  // ★ 1010 · 生成物登记（治"门假红"）：脚本每次现写的件被算成"手改正文"⇒ 每轮报一条假红 ⇒ 报警疲劳
  //   （千问判决点名的那族）。登记在 `神经/生成物.json` 的件**没有 .bak 也不报**（退路＝重跑生成它的脚本）；
  //   但**登记表自己读不到 ⇒ 照报**（fail-closed：记忆 `0muj8d14o` 闸门响了自己开门那族）。
  let 生成物 = {};
  try { 生成物 = JSON.parse(fs.readFileSync(path.join(工作区, '神经/生成物.json'), 'utf8')).件 || {} } catch { 生成物 = {} }
  let 备份们 = [];
  try { 备份们 = fs.readdirSync(BK, { recursive: true }).map(String).filter((x) => { try { return fs.statSync(path.join(BK, x)).isFile() } catch { return false } }) } catch { return { 没退路: [], 无备份: [] } }
  const 没退路 = [], 无备份 = [];
  for (const rel of 改过) {
    if (生成物[rel] || 生成物[path.basename(rel)]) continue;
    const 基 = path.basename(rel), 压平 = rel.replace(/\//g, '_');
    const 相关 = 备份们.filter((b) => { const n = path.basename(b);
      return n.startsWith(基 + '.bak-') || n.startsWith(基 + '.前') ||
             n.startsWith(压平 + '.bak-') || n.startsWith(压平 + '.前') || n.startsWith(压平 + '.'); });
    if (!相关.length) { 无备份.push(rel); continue }
    const 我 = md5(path.join(工作区, rel));
    // 任一份内容 ≠ 现在 ⇒ 有"改前"的样子 ＝ 有退路
    if (!相关.some((b) => md5(path.join(BK, b)) !== 我)) 没退路.push(rel);
  }
  return { 没退路, 无备份 };
}

/** 件现在读得出吗？—— 轮末"改坏"的机器判据（mjs/cjs/js ⇒ `node --check`；json ⇒ parse；**其余一概不猜、不报**） */
export function 读不出判(工作区, rel) {
  if (!/\.(mjs|cjs|js|json)$/i.test(rel)) return null;
  const 全 = path.join(工作区, rel);
  let st; try { st = fs.statSync(全) } catch { return '盘上没了' }
  if (!st.isFile()) return '不是文件';
  if (st.size > 8e6) return null;
  try {
    if (/\.json$/i.test(rel)) { JSON.parse(fs.readFileSync(全, 'utf8')); return null }
    const z = spawnSync(process.env.DSH_NODE || 'node', ['--check', 全], { encoding: 'utf8', timeout: 20000 });
    if (z.status === 0) return null;
    const 行 = String(z.stderr || '').split('\n').map((x) => x.trim()).filter(Boolean).find((x) => /Error/.test(x)) || ('rc=' + z.status);
    return '语法不过·' + 行.slice(0, 80);
  } catch (e) { return '读不出·' + String((e && e.message) || e).slice(0, 60) }
}

/* ★ 1010 · **耦合连续性挂轮末**（长期任务③「连续性」最后一段）—— 第七件接线。
   病根（改前实测）：`神经/耦合连续性.mjs` 原有两处挂点 —— ① `神经/改文件.mjs` 保护之十（**写入之前**，
   只管路过的通道）② `工具/开工/必读卡.mjs:221` pins 一行（我看见它，但**不点门**）⇒ **改完之后没人回头查**：
   一件有机器消费者的东西被我改坏（语法/JSON 读不出）⇒ 只有我下次手工跑它才看得见
   （外部核原话：「只停在改文件时印一下，它会是一个很高级的灯」）。
   治法：挂在**必然时刻**（本函数＝每轮末真跑的那一处）—— 只对**本轮真改过、且现在读不出**的件跑一次本尊：
     · rc=1（有机器消费者）⇒ **红**（进 `报警` → 落 `台账/接续/未结红.json`）
     · rc=2（判据 fail-closed）⇒ **红**（判据自己读不到 ⇒ 最危险的绿，见记忆 `0muj8d14o`）
     · rc=0（机器栏空）⇒ 灰：印一行"没人用"，**不红**（防报警疲劳）
   自清零：报警**每轮现算** ⇒ 修回读得出 ⇒ 下一条命令里这条自己从 `报警` 里消失（不用我手清、一个字节不改盘）。
   防假绿：账上点到名的件**下一轮接着复查**（否则"这轮没碰它"＝红自己变绿）。
   成本：本尊一次实测 **6.7s**（全盘 grep）⇒ **只在"读不出"候选出现时才调它**，候选上限 20 件、每件 25s 超时（截断印出来）。
   ⚠️ fail-open：判据缺失/超时/抛错 ⇒ 印一行"没量到"，**绝不许把轮末自检弄炸**（照 B07／采集 的现成样板）。 */
export function 查耦合(工作区 = 工作区默认, 改过 = [], 旧报警 = []) {
  const 判据 = path.join(工作区, '神经/耦合连续性.mjs');
  const 上限 = 20;
  const 候选 = [];
  const 加 = (x) => { const r = String(x || '').replace(/\\/g, '/').replace(/^\.\//, '').trim(); if (r && !候选.includes(r)) 候选.push(r) };
  // ① 账上点到名的（修好之前不许因"这轮没碰它"而假绿）—— 只认本器自己的红
  for (const a of (Array.isArray(旧报警) ? 旧报警 : [])) {
    if (!/^耦合连续性：/.test(String(a))) continue;
    const m = /〈([^〉]+)〉/.exec(String(a)); if (m) 加(m[1]);
  }
  // ② 本轮改过的（超上限只截断，不静默 —— 截断数印在读数里）
  let 截 = 0;
  for (const rel of (Array.isArray(改过) ? 改过 : [])) { if (候选.length >= 上限) { 截++; continue } 加(rel) }
  const 报警 = [], 明细 = [];
  if (!fs.existsSync(判据)) return { 报警: ['耦合连续性：判据读不到（' + 判据 + '）⇒ fail-closed：先修它，别当绿'], 一行: '耦合 ⚠️ 判据读不到', 明细, 查了: 0, 读不出: 0, 截 };
  let 读不出数 = 0, 查了 = 0;
  for (const rel of 候选) {
    const 因 = 读不出判(工作区, rel);
    if (!因) continue;
    读不出数++;
    let r = null;
    try { r = spawnSync(process.env.DSH_NODE || 'node', [判据, '查', rel], { encoding: 'utf8', timeout: 25000, env: { ...process.env, DSH_KICKOFF_WS: 工作区 } }) } catch (eS) { r = null }
    const rc = r && typeof r.status === 'number' ? r.status : null;
    if (rc === null) { 明细.push(rel + ' ⏭ 没量到（超时／跑不动）⇒ fail-open 不拦'); continue }
    查了++;
    if (rc === 1) {
      const 机 = String(r.stdout || '').split('\n').filter((l) => /^  · /.test(l)).map((l) => l.trim().slice(2));
      报警.push('耦合连续性：〈' + rel + '〉现在读不出（' + 因 + '），却有 ' + 机.length + ' 件机器消费者在用（' + 机.slice(0, 3).join('、') + (机.length > 3 ? ' 等' : '') + '）⇒ 修回读得出，或连带改这些件（红线 22／内核 #68）；表态放行：node 神经/轮末自检.mjs 结红 --说 "…"');
    } else if (rc === 2) {
      const 尾 = String(r.stdout || '').trim().split('\n').filter(Boolean).pop() || '';
      报警.push('耦合连续性：查 〈' + rel + '〉时判据 fail-closed（rc=2）：' + 尾.slice(0, 120) + ' ⇒ 先修判据，别当绿');
    } else {
      明细.push(rel + '（' + 因 + '）· 机器栏空 ⇒ 没人在用，不红');
    }
  }
  const 一行 = '耦合 ' + (报警.length ? '🔴 ' + 报警.length + ' 件（有机器消费者却被改坏）' : (读不出数 ? '⚠️ ' + 读不出数 + ' 件读不出·无消费者' : '✅')) + (截 ? '（候选截断 ' + 截 + '）' : '');
  return { 报警, 一行, 明细, 查了, 读不出: 读不出数, 截 };
}

/** 主入口：插件热加载调这个 */
export function 跑一轮(现场 = {}) {
  const 工作区 = 现场.工作区 || 工作区默认;
  let 起点 = Number(现场.起点 || 0);
  let 起点来路 = '票';
  if (!(起点 > 0)) {
    // ★★ 1013 **根修**（治一道拦了几十轮的假红）：原来这里缺票就「回看 24 小时」——
    //   而 24h 会把**同工作区别的窗**刚写的件算进"本轮动过"（本仓常态：同时开着好几个窗）。
    //   **1013 实例**：`工具/书库/书库.mjs` 是 00:24 另一个窗写的，我这轮 18:36 才开工，
    //   于是 `查退路` 每轮都报「改了没留改前的样子」⇒ **每轮留一道假红、每轮都要结一次红**。
    //   上一窗已经诊断出来了，但结论只写在 `工具/_tmp/交接单加⑦第四件.mjs` 里、**从没端到老板面前**。
    //   正解＝**收敛到一处**：起点只由 `工具/轮末/针归仓.mjs` 的 `取起点()` 算
    //   （它的口径＝`现场 > max(轮次锚, 本窗开工登记) > 6h`，且**把来路印出来**）。轮末自检不再自己定一份。
    //   它是谁写的／什么条件会回来：苏青青 1013；条件＝有人把这段改回"自己的 24h 兜底"。
    try {
      const r = 针归仓取起点(工作区, 现场)
      if (r && r.起点 > 0) { 起点 = r.起点; 起点来路 = '针归仓·' + r.来路 }
    } catch (e0) { /* 热件取不到 ⇒ 保持下面的兜底，不炸 */ }
  }
  // 兜底仍在（**只是不再当主路**）：针归仓也取不到时，才回看 24h
  if (!(起点 > 0)) { 起点 = Date.now() - 24 * 3600 * 1000; 起点来路 = '起点缺·按24h（针归仓热件也没取到）' }
  let 改过 = 现场.改过, 意图 = [], mtime = [];
  if (!改过) { const r = 本轮改过(工作区, 起点); 改过 = r.改过; 意图 = r.意图; mtime = r.mtime }
  const { 没退路, 无备份 } = 查退路(工作区, 改过);
  const 报警 = [];
  if (没退路.length) 报警.push('改了没留改前的样子：' + 没退路.slice(0, 5).join('、') + (没退路.length > 5 ? ' 等 ' + 没退路.length + ' 件' : ''));
  const 摘要 = 改过.length
    ? '本轮改过 ' + 改过.length + ' 件（意图 ' + 意图.length + ' · mtime ' + mtime.length + '）｜ 退路 ' + (没退路.length ? '❌ ' + 没退路.length : '✅ 齐') + (无备份.length ? ' ｜ 新建·不判 ' + 无备份.length : '')
    : '本轮没改文件（意图 0 · mtime ' + mtime.length + '）';
  // ★ 收尾欠项（本窗打样件）：在**收尾那一刻**把"本窗还差哪几件"摆出来，不靠自觉。
  let 收尾 = null;
  try {
    收尾 = 算收尾(工作区);
    if (收尾 && 收尾.报红 && 收尾.报红.length) 报警.push('收尾：' + 收尾.报红.join('、'));
  } catch (eR) { 收尾 = null }
  // ★ 针归仓（老板令 #26「针归仓要我自己点门，**全自动的机器**，所以说要去做掉」）：每根针点名唯一主仓 ＋ 逼我表态。
  let 归仓 = null;
  try {
    归仓 = 算归仓(工作区, 现场);
    if (归仓 && Array.isArray(归仓.红) && 归仓.红.length) 报警.push('针归仓：' + 归仓.红[0] + (归仓.红.length > 1 ? ' 等 ' + 归仓.红.length + ' 处' : ''));
  } catch (eG) { 归仓 = null }
  // ★ 待跑清单（治链断的轻量端）：**只在满足条件时印**（没有待跑 ⇒ 一行"待跑 0 ✅"，不念旧账）。
  //   ⚠️ 它**不进 报警**：报警＝红（有账要结）；待跑＝灰（有条命令该跑）—— 两码事，别混。
  let 待跑 = null;
  try { 待跑 = 算待跑(工作区, { 会话id: 现场.会话id || process.env.DSH_SESSION_ID }) } catch (eT) { 待跑 = null }
  // ★ 交接单指针闸（见上段接线）：指针过期 ⇒ 进 报警（红）；新鲜 ⇒ 在摘要尾巴印一枚 ✅（省得我再去点门）。
  let 真指针 = null;
  try {
    const q = 算指针(工作区);
    if (q && q.ok === false) { 真指针 = q; 报警.push('交接单指针：' + q.说 + (q.修法 ? ' ⇒ ' + q.修法 : '')) }
    else if (q && q.ok === true) 真指针 = q;
  } catch (eZ) { 真指针 = null }
  // ★ 报告体检（第五件接线 · 2026-10-01）：末条若像"给老板的报告" ⇒ 六格缺哪格当场报红；不是报告 ⇒ 跳过（不假红）。
  let 报告 = null, 轮型 = null;
  try {
    // ★ 1006：先过「轮型闸」—— 聊天/思考轮（他明说 ＋ 我无写类动作）⇒ 放过；打烊/干活 ⇒ 照旧严。
    轮型 = 算轮型({ 工作区 });
    if (轮型 && 轮型.放过 === true) { /* 聊天轮：放过报告体检，不假红 */ }
    else {
      报告 = 算报告({ 工作区 });
      if (报告 && Array.isArray(报告.报警) && 报告.报警.length) 报警.push(报告.报警[0]);
    }
  } catch (eB) { 报告 = null }
  // ★ 引用闸（第六件 · 2026-10-03 夜）：记忆引用落不到唯一一条 ⇒ 进 报警；正常 ⇒ 摘要尾巴印一枚。
  //   ⚠️ 与 `自举.mjs` 触发表里那条 `id闸` 不算重复：那条只"报编号（该做）"，这里**真跑**出读数
  //   （1003 记的「报了，但报的是编号」的真形态 —— 这层就是补上"真跑"）。
  let 引用 = null;
  try { 引用 = 算引用(工作区) } catch (eJ2) { 引用 = null }
  if (引用 && 引用.坏 > 0) 报警.push('引用闸：' + 引用.坏 + ' 处记忆引用落不到唯一一条（明细 `node 工具/记忆/id闸.mjs 扫`）');
  const 报告尾 = 报告 && 报告.摘要 ? ' ｜ ' + 报告.摘要.replace(/^报告体检·/, '报告 ') : '';
  const 指针尾 = 真指针 ? (真指针.ok === true ? ' ｜ 指针 ✅' : ' ｜ 指针 ❌') : '';
  const 引用尾 = 引用 && 引用.一行 ? ' ｜ ' + 引用.一行 : '';
  // ★ 未结红账（2026-10-03 夜 · **第一件"真拦截"样板** —— 老板 goal 判据：「能被"忽略错误继续走"就还算传送层，不算过」）：
  //   报警非空 ⇒ 落盘 `台账/接续/未结红.json`（处理=null）⇒ **出发表那行会 ⛔硬停**：我下次动手前被拦，
  //   必须先 `node 神经/轮末自检.mjs 结红 --说 "…"` 表态、或他批「假红」才放行。
  //   红若还在 ⇒ 下一次轮末重写账（内容一变 ⇒ "已表态"作废，防"改一个字就绕过"）。
  //   全绿 ⇒ 账清零（＝自己消账，不用我手清）。
  // ★ 1010 · 耦合连续性（第七件接线 · 判据与理由见本文件上方 `查耦合`）——
  //   ⚠️ **它必须排在下面那块"写账"之前**（旧账要在被重写之前读到 ⇒ 否则"上一轮点到名的件"就变成本轮自己 ⇒ 防假绿失效）。
  let 旧账 = null; try { 旧账 = JSON.parse(fs.readFileSync(path.join(工作区, '台账/接续/未结红.json'), 'utf8')) } catch { 旧账 = null }
  let 耦合 = null;
  try {
    耦合 = 查耦合(工作区, 改过, (旧账 && 旧账.报警) || []);
    if (耦合 && Array.isArray(耦合.报警)) for (const x of 耦合.报警) 报警.push(x);
  } catch (eC) { 耦合 = null }   // fail-open：判据炸了也不许断链（读不到会由 查耦合 内部报 fail-closed 红）
  let 未结红 = null;
  try {
    const 账路 = path.join(工作区, '台账/接续/未结红.json');
    const 旧 = 旧账;
    const 同 = 旧 && Array.isArray(旧.报警) && JSON.stringify(旧.报警.map(归一红)) === JSON.stringify(报警.map(归一红));
    未结红 = { at: new Date().toISOString(), 报警, 处理: (报警.length && 同 && 旧.处理) ? 旧.处理 : null };
    fs.mkdirSync(path.dirname(账路), { recursive: true });
    fs.writeFileSync(账路, JSON.stringify(未结红, null, 1));
  } catch (eW) { 未结红 = null }
  // ★ 1009 挂「窗口资产采集」（D 主线 · 第二条 · 老板「你下一步自己去做啊，跑个长期任务」）——
  //   病根（机器可查）：`流程定义.mjs` 里它的挂点依据原文＝「轮末靠我想起来」⇒ 该做的事全靠我记起来。
  //   治法：**轮末**（必然时刻 —— 本函数就是每轮末真跑的那一处）自己跑本尊、把读数印进摘要 ⇒ 不用我记得跑它。
  //   本尊＝`工具/跨窗/采集.mjs`（实测 0.2 秒：扫交接单 → 逐条 ls 验路径 → 刷新 `台账/接续/窗口资产表.md`）。
  //   证伪：① 摘要里出现「窗口资产 …」读数 ② `挂点体检.mjs` 的 E 靠自觉桶里「窗口资产采集」消失（29→28）。
  //   ⚠️ fail-open：跑不动只印「读不到」，**绝不许**把轮末自检弄炸（照认人表／件门／停手线的现成样板）。
  //   ⚠️ 它刷新的是**机器生成件**（没有 .bak- ⇒ 下一轮落进「新建·不判」、不进报警）—— 已核过 `查退路` 源码再动手。
  let 采集 = null;
  try {
    const _rc = spawnSync('node', [path.join(工作区, '工具/跨窗/采集.mjs')], { encoding: 'utf8', timeout: 60000 });
    const _oc = String(_rc.stdout || '');
    const _rd = (_oc.match(/资产 \d+ 条，在 \d+，找不到 \d+/) || [''])[0];
    采集 = _rd ? '窗口资产 ' + _rd : null;
  } catch { 采集 = null }
  const 采集尾 = ' ｜ ' + (采集 || '⚠️ 窗口资产读不到（跑 `node 工具/跨窗/采集.mjs` 看原因）');
  // ★ 1009 挂「B07 失败重试体检」（外部核判据 G2 · 把"条文级·不可靠"变成机器可判）——
  //   病根：动作集 B07「同一条路失败两次就停」的判据原文＝「⚠️ 条文级·不可靠：机器判不了，只能人读」。
  //   治法：**轮末**（必然时刻 —— 本函数就是每轮末真跑的那一处）真跑本尊，把读数印进摘要。
  //   本尊＝`神经/失败重试判.mjs`（实测 **0.29s**；`--静` 绿时零字；130 份日志回归**零崩**）。
  //   证伪：① 摘要里出现「B07 …」读数 ② 我连撞同一面墙三次 ⇒ 读数变 ❌。
  //   ★ 口径（外部核）：**只报红、不阻断** —— 不 push 进 报警／未结红（那会每轮锁死＝"过度拦截"）。
  //   ⚠️ fail-open：跑不动只印「读不到」，绝不许把轮末自检弄炸（照采集／件门／认人表的现成样板）。
  let B07 = null;
  try {
    const _rb = spawnSync('node', [path.join(工作区, '神经/失败重试判.mjs'), '--静'], { encoding: 'utf8', timeout: 30000 });
    const _rc2 = (typeof _rb.status === 'number') ? _rb.status : null;
    if (_rc2 === 0) B07 = 'B07 ✅ 0 条';
    else if (_rc2 === 2) B07 = 'B07 ⚠️ 没东西可查';
    else if (_rc2 === 1) {
      const _ob = String(_rb.stdout || '').split('\n').map((x) => x.trim()).filter(Boolean).join(' ');
      const _mb = /违规\s*(\d+)\s*条/.exec(_ob);
      B07 = 'B07 ❌ ' + (_mb ? _mb[1] : '有') + ' 条违规（同一条路连败 ≥3 · 只报红不阻断）';
    }
  } catch { B07 = null }
  const B07尾 = ' ｜ ' + (B07 || '⚠️ B07 读不到（跑 `node 神经/失败重试判.mjs` 看原因）');
  // ★ 1009 夜：B11 装包门（新件 · 照 B07 现成挂法：只报红不阻断、fail-open、读不到只印字）
  let B11 = null;
  try {
    const _rb3 = spawnSync('node', [path.join(工作区, '神经/装包判.mjs'), '--静'], { encoding: 'utf8', timeout: 30000 });
    const _rc3 = (typeof _rb3.status === 'number') ? _rb3.status : null;
    if (_rc3 === 0) B11 = 'B11 ✅ 0 条';
    else if (_rc3 === 2) B11 = 'B11 ⚠️ 没东西可查';
    else if (_rc3 === 1) B11 = 'B11 ❌ 有系统级装包命令（要装先问老板 · 只报红不阻断）';
  } catch { B11 = null }
  const B11尾 = ' ｜ ' + (B11 || '⚠️ B11 读不到（跑 `node 神经/装包判.mjs` 看原因）');
  let 牌尾 = ' ｜ 交接牌 ⚠️ 读不出';
  try { 牌尾 = ' ｜ 交接牌 ' + (fs.existsSync(path.join(工作区,'台账/接续/交接牌.json')) ? '✅ 有（主观＋客观）' : '⚠️ 无（上一窗没写牌）') } catch { }
  let 读窗 = null;
  try {
    const _rw = spawnSync('node', [path.join(工作区, '神经/读窗判.mjs'), '--静'], { encoding: 'utf8', timeout: 30000 });
    const _rc4 = (typeof _rw.status === 'number') ? _rw.status : null;
    if (_rc4 === 0) 读窗 = 'D02 ✅ 0 条';
    else if (_rc4 === 2) 读窗 = 'D02 ⚠️ 没东西可查';
    else if (_rc4 === 1) 读窗 = 'D02 ❌ 有 limit>10 的超读（只报红不阻断）';
  } catch { 读窗 = null }
  const 读窗尾 = ' ｜ ' + (读窗 || '⚠️ D02 读不到');
  // ★ 1010 连续尾（老板令「关于系统的连续性的问题，一定要着重处理」）：
  //   本轮动过的件，各自报"接没接上" —— 悬空（它引用的东西盘上没了）／没人消费。
  //   判据本体住 `神经/连续体检.mjs`（热加载）。**只印不拦**（第一版不硬停：悬空判据还可能有假红）。
  let 连续 = null, 连续红 = 0, 连续硬停 = 0, 连续待办 = 0;
  try {
    const _lc = spawnSync('node', [path.join(工作区, '神经/连续体检.mjs'), '一屏'], { encoding: 'utf8', timeout: 90000 });
    const _s = String(_lc.stdout || '').trim();
    if (_s) 连续 = _s.split('\n')[0];
    // ★ 1010 01:3x · 外部独立核（qwen3.8-max）判决「最硬的一句」——**红必须进放行链**：
    //   「连续体检解决了'看得见悬空'，但还没解决'不放行悬空'…如果只停在'改文件时印一下'，它会是一个很高级的灯。」
    //   ⇒ 悬空（它引用的东西在盘上真没了）**进 `报警`** ＝ 复用既有的「未结红 ⇒ 硬停 ＋ 表态放行」链，不另造门。
    //   降噪在上游：运行时拼的路径／占位举例／自测样本只记"疑似"，不算红（`连续体检.mjs` 头部有记）。
    // ★ 1010 ⑥ 外部核整改：一屏改成"档位"输出后，这里必须跟着改 —— 原来那条「数 🔴」会因不再有 🔴 而恒读 0
    //   ⇒ **门静默变绿**（最危险的一种绿）。
    连续硬停 = Number((_s.match(/🛑\s*硬停\s*(\d+)/) || [])[1] || 0);
    连续待办 = Number((_s.match(/待办\s*(\d+)/) || [])[1] || 0);
    连续红 = 连续硬停;   // 兼容旧名（下游只认"红数"的地方＝硬停数）
  } catch { 连续 = null }
  // ★ 1010 ⑥（核：「关键悬空进硬停」＋「红进放行链」）：**硬停档 ⇒ 进报警**（要表态才放行）；
  //   待办档 ⇒ 只印不拦（核也警告过"过度拦截"：全进硬停会每轮锁死）。二者都在连续尾里可见。
  if (连续硬停 > 0) 报警.push('连续性【🛑 硬停档】' + 连续硬停 + ' 件（悬空且有人在真用它／每轮必到面点名它，或连续未处理已升级）⇒ 跑 `node 神经/连续体检.mjs 本轮` 看是哪件；修它，或表态 `node 神经/轮末自检.mjs 结红 --说 "…"`');
  // ★ 1010 · fail-closed（记忆 `0muj8d14o` 的教训：**判据自己抛了、catch 把 deny 转成 allow ⇒ 闸门响了自己开门**）
  //   判据读不到 ⇒ 不许当绿：**读不到也要报**（否则"连续体检.mjs 没了/报错"＝门静默失效，最危险的一种绿）。
  if (!连续) 报警.push('连续性判据读不到（`神经/连续体检.mjs` 缺失或报错）⇒ fail-closed：先修它，别当绿');
  const 连续尾 = ' ｜ ' + (连续 || '⚠️ 连续体检读不到（跑 `node 神经/连续体检.mjs 本轮`）');
  // ★ 1010 件引用尾（老板点名「幻觉控制也没补」）：判据住 神经/引用体检.mjs —— 查**路径引用**
  //   盘上在不在（与第 250 行那个查**记忆 id** 的「引用闸」互补，两件事，故变量名避让：件引用）。
  let 件引用 = null;
  try {
    const _yi = spawnSync('node', [path.join(工作区, '神经/引用体检.mjs'), '--报告'], { encoding: 'utf8', timeout: 60000 });
    const _ti = String(_yi.stdout || '').trim();
    件引用 = _ti.split('\n')[0] || null;
    if (_yi.status === 1) 报警.push('件引用体检·查无此件：最近一份报告里有盘上没有的路径（多半是我说的幻觉）⇒ 跑 node 神经/引用体检.mjs --报告 看是哪条，再核真名或改口');
    else if (_yi.status !== 0 && _yi.status !== 1 && _yi.status !== 2) 报警.push('件引用体检·fail-closed：判据读不到 rc=' + _yi.status + ' ⇒ 先修它，别当绿');
  } catch (e) { 报警.push('件引用体检·fail-closed：抛异常 ⇒ 先修它，别当绿') }
  const 件引用尾 = 件引用 ? (' ｜ ' + 件引用) : '';

  // ★ 1010 · 断言尾（「幻觉控制补齐」第⑥件 · 老板原话「没有正确的前提，总是用自己以为的事情去干活」）：
  //   判据住 神经/断言体检.mjs —— 查我**话里的把握程度与出处**（应该是／我以为／结论词没出处／
  //   沙盒绿当生产绿／旧读数当现状）。红 ⇒ 进 报警（未结红 ⇒ 硬停）；黄 ⇒ 只在尾巴印一行（不假红）。
  //   与件引用尾互补：那条查**路径在不在盘上**，这条查**话里有没有出处**（红线 13 的机器面）。
  let 断言黄 = null;
  try {
    const _dy = spawnSync('node', [path.join(工作区, '神经/断言体检.mjs'), '--报告'], { encoding: 'utf8', timeout: 60000 });
    const _ty = String(_dy.stdout || '').trim();
    const _line = _ty.split('\n')[0] || '';
    if (_dy.status === 1) {
      报警.push('断言体检·未标定的猜测／无出处的结论：最近一份报告里有"我以为"形态的话（红线 13）⇒ 跑 node 神经/断言体检.mjs --报告 看是哪条，补出处或改成「未验」');
    } else if (_dy.status === 0 && /🟡/.test(_line)) {
      断言黄 = _line.replace(/^🟡\s*/, '断言 ')
    } else if (_dy.status !== 0 && _dy.status !== 1 && _dy.status !== 2) {
      报警.push('断言体检·fail-closed：判据读不到 rc=' + _dy.status + ' ⇒ 先修它，别当绿');
    }
  } catch (e) { 报警.push('断言体检·fail-closed：抛异常 ⇒ 先修它，别当绿') }
  const 断言黄尾 = 断言黄 ? (' ｜ ' + 断言黄) : '';
  /* ★ 1010 三闸尾 —— 老板「门的架构」那一问的**当场落地**（原话：「门越来越多…实际用上的门就越来越少，
     挂靠动作加钩子的设计为什么用不上了？能不能换个方式重新用上来」）。
     机器读数（`node 工具/流程/跑.mjs 核` 现算）：一堆门标着**死**，其中这几件明明「✅ 可自动」（有可跑命令、
     认迹 ✅）却**没人挂** ⇒ 触发表写了条件也永远不被拉起。**换形式＝把它挂到机器必然经过的时刻**（这里＝轮末）。
     实测耗时：路由层自检 1.3s／id闸 0.19s／行形状闸 0.17s（合计 ~1.7s，可挂）；`回归/跑全部` 81s 太慢 ⇒ 不挂这。
     **块作用域**：内部变量不外泄 —— 上轮我在这文件里插"件引用尾"时撞了已有的 `引用` 名、`node --check` 连炸两次。 */
  {
    const 闸 = [
      ['路由层自检', '工具/路由层/自检.mjs', []],
      ['id闸', '工具/记忆/id闸.mjs', ['自检']],
      ['行形状闸', '工具/台账/行形状闸.mjs', ['自检']]
    ];
    const 坏 = [];
    for (const [名, 路, 参] of 闸) {
      try {
        const z = spawnSync('node', [path.join(工作区, 路), ...参], { encoding: 'utf8', timeout: 30000 });
        const o = String(z.stdout || '').trim().split('\n').filter(Boolean).pop() || '';
        if (z.status !== 0 || /❌/.test(o) || !/✅|过/.test(o)) 坏.push(名 + '（' + (o.slice(0, 60) || 'rc=' + z.status) + '）');
      } catch (e) { 坏.push(名 + '（跑不动）'); }
    }
    if (坏.length) 报警.push('三闸自检【🔴】' + 坏.join('；') + ' ⇒ 三件都是只读自检，报红多半真有东西不对：修它，或表态 `轮末自检.mjs 结红 --说 "…"`');
  }
  // ★ 1010 · 出口尾（外部独立核判决第 7 条「必须同批做出口观察账」）：**只印不拦** ——
  //   核的原话：做"观察账"，**别做"零净增硬考核"**（那会逼出假动作：分类搬家／拆件假减／改定义）。
  //   进 pins 的条件留到"候选退休清到接近 0"再说（现在 50 多件长期挂着 ⇒ 加进 pins 只会变成噪音）。
  let 出口 = null;
  try {
    const _ck = spawnSync('node', [path.join(工作区, '神经/出口账.mjs'), '一屏'], { encoding: 'utf8', timeout: 90000 });
    const _s2 = String(_ck.stdout || '').trim();
    if (_s2) 出口 = _s2.split('\n')[0];
  } catch { 出口 = null }
  const 出口尾 = 出口 ? (' ｜ ' + 出口) : '';   // **绿时零字**
  // ★ 1010 ⑧ 豁免审计（外部核整改 ⑧「登记／限时／回补／可见」）：登记**过期 ⇒ 进报警**（限时才算有牙）；
  //   临期只在读数里出现；判据读不到 ⇒ fail-closed（不静默）。真身与登记 ⇒ `台账/闸门/豁免登记.json`。
  let 豁免 = null;
  try {
    const _ex = spawnSync('node', [path.join(工作区, '神经/豁免审计.mjs'), '一屏'], { encoding: 'utf8', timeout: 60000 });
    const _s3 = String(_ex.stdout || '').trim();
    豁免 = _s3.split('\n')[0] || '';
  } catch { 豁免 = '⚠️ 豁免审计读不到（神经/豁免审计.mjs）' }
  if (/🔴/.test(豁免)) 报警.push('豁免审计【🔴 过期】' + 豁免.replace(/^【[^】]*】/, '') + ' ⇒ 复核它：node 神经/豁免审计.mjs 复核 <目录> --说 "…"（或表态结红）');
  else if (/读不到/.test(豁免)) 报警.push('豁免审计判据读不到（神经/豁免审计.mjs 缺失或报错）⇒ fail-closed：先修它，别当绿');
  const 豁免尾 = 豁免 ? (' ｜ ' + 豁免) : '';
  // ★ 1013 迭代 3.0 · **红线 20 的 Promote 第二步**（书 §4.3.3 原话：「**Sometimes you promote the obligation, not
  //   the instrument that discovered it**」）：**只在"这一轮真动过插件源码"时才跑一次「工具名体检」**。
  //   为什么这么挂：① **不新增门**（复用已有的 `agent/turn-stopping`／轮末自检本来就在跑）—— 守老板 1009。
  //   ② 它读 19 MB 会话日志 ≈ 20 s ⇒ **不能每轮白跑**（这就是"贵、但只在必要时"的那一类：代价换证据）。
  //   ③ 红线 20 的病是"名字带中文／怪字符 ⇒ API 400 把**整包**请求锯掉 ⇒ 整窗收发全断"（1001 实炸近 2 小时）
  //      —— 后果重，**但存量已经是 0** ⇒ 该做的是"每次动工具面就复验一次"，不是拦在前面（书 §4.4.3 七问）。
  //   ④ 它还顺手刷新 `台账/接续/工具名体检.json`（开窗一屏读的那份）⇒ 治"json 过期没人跑"。
  let 名检 = null;
  try {
    const 动过插件 = (改过 || []).some((f) => String(f).includes('工具/件/真源/'))
    if (动过插件) {
      const _n = spawnSync('node', [path.join(工作区, '神经/工具面核.mjs')], { encoding: 'utf8', timeout: 120000 })
      const _o = String(_n.stdout || '').trim().split('\n').filter(Boolean).pop() || ''
      const _全 = String(_n.stdout || '') + String(_n.stderr || '')
      if (_n.status !== 0 || /非法|过长|❌/.test(_全)) {
        报警.push('工具名体检【🔴】' + _o.slice(0, 90) + ' ⇒ 红线 20：名字带中文／怪字符会让 API 400 **锯掉整包**（1001 实炸近 2 小时）；改它，或表态结红')
        名检 = _o
      } else 名检 = null   // ★ **绿时零字**（我们自己的惯例：修好了就别天天弹）—— 它跑没跑过，看 `台账/接续/工具名体检.json` 的 `at` 字段（那才是证据）
    }
  } catch { 名检 = null }
  const 名检尾 = 名检 ? (' ｜ 工具名体检 ' + 名检.replace(/^✅\s*/, '')) : '';
  // ★ 1010 · 耦合连续性尾（第七件接线）：绿 ⇒ 一枚 ✅；有"读不出"候选但没人消费 ⇒ ⚠️＋件数；红／fail-closed 都在 `报警` 里（见 `查耦合`）
  const 耦合尾 = ' ｜ ' + ((耦合 && 耦合.一行) || '⚠️ 耦合连续性没量到（fail-open）');
  const 版尾 = ' ｜ 版 ' + 版指纹() + B11尾 + 牌尾 + 读窗尾 + 连续尾 + 件引用尾 + 断言黄尾 + 出口尾 + 豁免尾 + 耦合尾 + 名检尾;
  return { 改过, 意图, mtime, 没退路, 无备份, 报警, 归仓, 待跑, 真指针, 报告, 引用, 耦合, 未结红, 采集, B07, 摘要: 摘要 + (收尾 && 收尾.一行 ? ' ｜ ' + 收尾.一行 : '') + (归仓 && 归仓.一行 ? ' ｜ ' + 归仓.一行 : '') + (待跑 && 待跑.一行 ? ' ｜ ' + 待跑.一行 : '') + 指针尾 + 报告尾 + 引用尾 + 采集尾 + B07尾 + 版尾, 收尾, 起点, 起点来路 };
}

// ── 自检（node 神经/轮末自检.mjs selftest）──────────────────────────
if (process.argv[1] && process.argv[1].endsWith('轮末自检.mjs') && process.argv[2] === 'selftest') {
  const T = [];
  const ok = (名, 条件, 注 = '') => T.push([名, !!条件, 注]);
  // 阳性① 造一个"改了但备份跟它一样"的假现场 ⇒ 必须报红
  ok('阳性① 备份内容与当前一致 ⇒ 判为没退路', (() => {
    const r = 查退路('/storage/emulated/0/3', ['神经/轮末自检.mjs']);
    return Array.isArray(r.没退路);
  })());
  // 阳性② 真改过的文件（本轮刚建的）必须有记录
  ok('阳性② 本轮改过能读出东西', 本轮改过('/storage/emulated/0/3', 0).改过.length > 0, '条数见下');
  // 阴性 起点在未来 ⇒ 一条都没有
  ok('阴性 起点设在未来 ⇒ 零条（不许瞎报）', 本轮改过('/storage/emulated/0/3', Date.now() + 86400000).改过.length === 0);
  // ★ 反证①（2026-09-27 加）：假现场里**没有意图账**，mtime 兜底仍必须看得见"刚刚改过"的文件
  ok('反证① 意图账缺席时，mtime 扫看得见刚改的文件', (() => {
    const W = '/storage/emulated/0/3/_backup/0927-轮末自检/假现场';
    fs.mkdirSync(W + '/台账', { recursive: true });
    fs.writeFileSync(W + '/台账/刚改.md', 'x' + Date.now());
    const got = 按mtime扫(W, Date.now() - 60000);
    return got.includes('台账/刚改.md') && !fs.existsSync(W + '/台账/接续/写意图.jsonl');
  })(), '假现场无意图账');
  // ★ 反证②（同批）：一个传感器死了，**不许**因此报"没改文件"
  ok('反证② 意图账空 ⇒ 本轮改过仍看得见（不瞎报没改文件）', (() => {
    const W = '/storage/emulated/0/3/_backup/0927-轮末自检/假现场';
    const r = 本轮改过(W, Date.now() - 60000);
    return r.意图.length === 0 && r.改过.includes('台账/刚改.md');
  })());
  // ★ 反证③（2026-09-28）：**接线了但没通电** —— 仪器必须在链路里**真被调用**（不是「只 import 就算接了」）
  ok('反证③ 针归仓在链路里真被调用（不是「只 import」）', (() => { const rr = 跑一轮({ 起点: 0 }); return !!rr.归仓 && typeof rr.归仓.结论 === 'string' })());
  // ★ 反证④（2026-09-29 加 · 同族第四例）：待跑清单也必须在链路里**真被调用**，
  //   且它的条件不满足时**不许乱报**（没有待跑 ⇒ 待=[]）。治的是"链断"的轻量端（见文件头那段）。
  ok('反证④ 待跑清单在链路里真被调用（且无待跑时不乱报）', (() => { const rr = 跑一轮({ 起点: 0 }); return !!rr.待跑 && Array.isArray(rr.待跑.待) && typeof rr.待跑.一行 === 'string' })());
  // ★ 反证⑤（2026-10-01 加 · 同族第五例）：报告体检必须**真被调用**（末条不是报告时不许乱报）。
  ok('反证⑤ 报告体检在链路里真被调用', (() => { const rr = 跑一轮({ 起点: 0 }); return !!rr.报告 && typeof rr.报告.摘要 === 'string' })());
  // ★ 反证⑥（2026-10-03 夜加 · 同族第六例 · 老板令「那个诚实边界，该验的得验啊」当场验出来的那件）：
  //   引用闸必须**真被调用**，且必须**真从盘上取到汇总行** —— "只 import 不调用"那条老坑就锁在这。
  ok('反证⑥ 引用闸在链路里真被调用（且真取到汇总行）', (() => { const rr = 跑一轮({ 起点: 0 }); return !!rr.引用 && typeof rr.引用.一行 === 'string' && (rr.引用.读不到 === true || /^共 /.test(String(rr.引用.汇总 || ''))) })());
  // ★ 反证⑦（2026-10-10 加 · 同族第七例 · 长期任务③「连续性」最后一段）：耦合连续性必须在链路里**真被调用** ——
  //   「只 import 不调用／接线没通电」那条老坑（0928 见文件头 · 记忆 `0mukdiilt`）就锁在这。
  ok('反证⑦ 耦合连续性在链路里真被调用', (() => { const rr = 跑一轮({ 起点: 0 }); return !!rr.耦合 && typeof rr.耦合.一行 === 'string' && Array.isArray(rr.耦合.报警) })());
  // ★ 反证⑧（同批 · **双证**：红要真红、绿要真绿 · 全程在 `_backup` 的**假工作区**里跑，不碰生产一个字节）：
  //   一对「坏件 ＋ 真消费者」⇒ 报警里必须出现「耦合连续性：」；把坏件修好 ⇒ 必须**自己消失**。
  //   为什么要它：光有⑦只能证明"被调用了"，证明不了"该响的时候会响"（＝很高级的灯）。
  ok('反证⑧ 有机器消费者＋读不出 ⇒ 真红；修好 ⇒ 真绿（隔离假现场）', (() => {
    const W = '/storage/emulated/0/3/_backup/0927-轮末自检/耦合假现场';
    try {
      fs.rmSync(W, { recursive: true, force: true });
      for (const d of ['神经', '台账/接续', '台账/轮末', '内核']) fs.mkdirSync(path.join(W, d), { recursive: true });
      fs.copyFileSync(fileURLToPath(new URL('./耦合连续性.mjs', import.meta.url)), path.join(W, '神经/耦合连续性.mjs'));
      // 消费者：正文里带**它的相对路径**（判据口径＝"代码/配置件里的真引用"，见 `耦合连续性.mjs:38`）
      fs.writeFileSync(path.join(W, '神经/消费者.mjs'), "// 消费 神经/被消费件.mjs\nimport './被消费件.mjs'\n");
      const 坏件 = path.join(W, '神经/被消费件.mjs');
      fs.writeFileSync(坏件, 'export const x = ({ {\n');            // 语法不过 ＝ 读不出
      const r1 = 查耦合(W, ['神经/被消费件.mjs'], []);
      const 红过 = Array.isArray(r1.报警) && r1.报警.some((x) => /^耦合连续性：/.test(x));
      fs.writeFileSync(坏件, 'export const x = 1\n');              // 修回读得出
      const r2 = 查耦合(W, ['神经/被消费件.mjs'], []);
      const 绿了 = Array.isArray(r2.报警) && r2.报警.length === 0;
      return 红过 && 绿了;
    } catch (e8) { return false }
  })(), '假现场：坏件＋真消费者 ⇒ 红；修好 ⇒ 绿');
  let 过 = 0;
  for (const [名, 好, 注] of T) { console.log((好 ? '  ✅ ' : '  ❌ ') + 名 + (注 ? '  ← ' + 注 : '')); if (好) 过++ }
  const r = 跑一轮({ 起点: 0 });
  console.log('\n  当前真实现场：' + r.摘要 + '  ← 起点来路：' + r.起点来路);
  if (r.没退路.length) console.log('  ❌ 没退路的：' + r.没退路.slice(0, 8).join('、'));
  console.log('  本轮改过 ' + r.改过.length + ' 件（意图 ' + r.意图.length + ' · mtime ' + r.mtime.length + '）：' + r.改过.slice(0, 6).join('、'));
  console.log('\n' + (过 === T.length ? '✅ 轮末自检 自检通过 ' + 过 + '/' + T.length : '❌ ' + 过 + '/' + T.length));
  process.exit(过 === T.length ? 0 : 1);
}

// ── 结红（2026-10-03 夜 · **第一件"真拦截"的出口**）────────────────────────────
//   出发表里那行 ⛔硬停 会把"有未结红"的我拦住 ⇒ 这里是**唯一放行通道**（逃生闸）。
//   语义：**表态**（`--说 "<怎么处理／为什么是假红>"`）⇒ 账上写 `处理` ⇒ 本轮放行；
//         **判成假红必须他批**（`--他批 "<理由>"`）—— 不许我自己把红消掉。
//   真修掉了 ⇒ 下一次 `跑一轮` 重算报警为空 ⇒ **账自己清零**（不需要我手清）。
if (process.argv[1] && process.argv[1].endsWith('轮末自检.mjs') && process.argv[2] === '结红') {
  const 参 = process.argv.slice(3)
  const 取 = (k) => { const i = 参.indexOf(k); return i >= 0 ? String(参[i + 1] || '') : '' }
  const 说 = 取('--说'), 他批 = 取('--他批')
  // ★ 1009：结红也要能改道（红线 19④「账／锁／开关都要认 DSH_KICKOFF_WS」）—— 否则沙盒验不了它，
  //   而"没跑过沙盒"正是这条线上最容易踩的假绿。
  const 账路 = path.join(process.env.DSH_KICKOFF_WS || 工作区默认, '台账/接续/未结红.json')
  let 账 = null; try { 账 = JSON.parse(fs.readFileSync(账路, 'utf8')) } catch { 账 = null }
  if (!账 || !Array.isArray(账.报警) || !账.报警.length) { console.log('✅ 账是清的（没有未结红）⇒ 不用结'); process.exit(0) }
  // ★ 已表过态的不许再逼一次（1003 夜实测补）：同一条红表过态 ⇒ 轮末重写时 `处理` 会保住（见"唯一例外"那段）
  //   ⇒ 这里得认它，否则"被叫来结红"会白跑一趟（语义：`处理` 非空、且报警没变 ＝ 这条已经结过了）。
  if (账.处理 && Array.isArray(账.处理.报警) && 账.处理.报警.map(归一红).join('｜') === 账.报警.map(归一红).join('｜')) {
    console.log('✅ 这条红已经结过了（' + 账.处理.at + '），报警没变 ⇒ 不用重表。')
    console.log('   要改口／补说明 ⇒ 带上 --说 或 --他批 再跑一次。')
    for (const a of 账.报警) console.log('     · ' + a)
    if (!说 && !他批) process.exit(0)
  }
  if (!说 && !他批) {
    console.log('❌ 必须先表态。用法：轮末自检.mjs 结红 --说 "<这条红怎么处理／为什么是假红>"   或   --他批 "<理由>"（假红要老板批）')
    console.log('   当前未结红：'); for (const a of 账.报警) console.log('     · ' + a)
    process.exit(2)
  }
  账.处理 = { at: new Date().toISOString(), 说: 说 || '', 他批: 他批 || null, 报警: 账.报警 }
  fs.writeFileSync(账路, JSON.stringify(账, null, 1))
  console.log('✅ 已表态（' + (他批 ? '他批·判为假红' : '处理说明') + '）⇒ 出发表那行不再硬停。')
  if (他批) console.log('   ⚠️ 判成假红要留他批的原话（已存进 ' + 账路 + '）')
  console.log('   未结红 ' + 账.报警.length + ' 条：'); for (const a of 账.报警) console.log('     · ' + a)
  process.exit(0)
}

// ── 版（假绿灯 · node 神经/轮末自检.mjs 版）─────────────────────────
// 用法：把这里打出来的串，跟每轮摘要尾「｜ 版 …」那栏对照 ——
//   ① 摘要里**有**这栏、且串一致 ⇒ 引擎进程里跑的就是当前盘上这版（我的改动已生效）；
//   ② 摘要里**没有**这栏 ⇒ 引擎进程还在跑旧版 ⇒ **要重启**（叫老板）。
if (process.argv[1] && process.argv[1].endsWith('轮末自检.mjs') && process.argv[2] === '版') {
  console.log(版指纹());
  process.exit(0)
}
