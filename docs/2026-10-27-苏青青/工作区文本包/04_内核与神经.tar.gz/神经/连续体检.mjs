#!/usr/bin/env node
// 连续体检.mjs —— 「连续性」横轴的判据本体（老板 1009 夜问：「为什么当初在改的时候没有把连续性
//   这些东西考虑进去？以前埋的坑，当场就能发现，现在埋的坑越来越深」）
//
// 它答的是一个此前**没人问**的问题：**我动了这一件，它跟别的件还接得上吗？**
//   · 反向：**谁在引用它 / 谁在消费它**（改它 ⇒ 这些地方可能被影响）
//   · 正向：**它引用的东西还在不在**（悬空 ⇒ 当场红，不用等老板"感觉不对"）
//   · 出口：有没有"嘴"（每轮必到的地方点名它）—— 没人消费又没嘴 ⇒ 🟡
//
// 口径照抄 `工具/台账/挂点体检.mjs`（2026-09-28 定）：
//   真调用 ＝ 代码件里的调用点（import / await import / spawn / 绑定路径）
//   登记   ＝ .json/.yml 里提到它（账、清单），不算"有人在调它"
//   文档点名 ＝ 只在 .md 里被提到（**那只是"有人提过它"，不算挂点**）
//   有嘴   ＝ 出现在"每轮必到"的口子的打印串里（库一屏 / pins / 打烊 / 轮末自检）
//
// ★ 假红降噪（1010 建件当场抓到）：自测里 `path.join(现场, '台账/…')` 这种**运行时拼的路径**，
//   盘上当然没有 ⇒ 判"疑似·动态路径"，**不算悬空**（否则新仪器一上来就报两个假红）。
// ★ 性能（1010 当天改）：一次全库扫描建**倒排索引**（文件名 → 谁提到它），查件 O(1)；
//   原来"每件都遍历全库内容"在 3796 个文本件上太慢（改文件通道每次都要跑它）。
//
// 契约（照抄 `神经/交接单指针.mjs`）：**只观察、只报告，绝不拦、绝不改盘**。
//
// 用法：
//   node 神经/连续体检.mjs 件 <相对路径>      # 单件：谁引用它 / 它引用谁悬空没 / 判定
//   node 神经/连续体检.mjs 本轮               # 本窗动过的件（读 台账/接续/本窗写过.json）逐个跑
//   node 神经/连续体检.mjs 一屏               # 只印一行读数（给库/轮末自检用；绿时零字）
//   node 神经/连续体检.mjs 落盘               # 写 台账/接续/连续体检.md
//   node 神经/连续体检.mjs selftest ｜ 自检    # 阴性对照：造的样本必须判对（不碰生产）
//
// ★ 沙盒：工作区根认 `DSH_KICKOFF_WS`（默认逐字 '/storage/emulated/0/3'）—— 红线 19④，
//   自测时必须改道，否则"自测"会把生产写脏。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const WS = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3';
const 码后缀 = new Set(['.mjs', '.js', '.sh', '.cjs']);          // 真调用只认代码件
const 文本后缀 = new Set([...码后缀, '.json', '.yml', '.yaml', '.md', '.txt']);
const 跳过目录 = new Set(['node_modules', '_backup', '.git', 'sessions', '.dsh-meow', '.combo-cache', 'tmp']);
// 「有嘴」＝每轮必到 / 每窗必到的口子（点名了它 ⇒ 至少有人会看见）
const 嘴件 = [
  '工具/开工/库.mjs',        // 开工一屏
  '工具/开工/必读卡.mjs',    // pins（每轮渲染）
  '工具/开工/打烊.mjs',      // 收轮
  '神经/轮末自检.mjs',  // 每轮末机器自检
];
// 文本里出现的「带后缀的文件名」——倒排索引的 token
const TOKEN = /[\w\u4e00-\u9fa5][\w\u4e00-\u9fa5.\-/]*\.(?:mjs|js|cjs|sh|json|md|yml|yaml)/g;
// 占位举例（注释/文档里写 `import('./x.mjs')` 这种）：盘上没有也**不判红**（1010 实犯 —— 轮末自检注释里的例子报了红）
const 占位名 = (p) => /(^|\/)(x|y|z|foo|bar|baz|xxx|示例|举例|某)\.(mjs|js|cjs|md|json|sh|yml)$/i.test(p);

/** 建倒排索引：basename → Set(提到它的相对路径) */
function 建倒排(工作区) {
  const 倒排 = new Map();
  const 记 = (基, 相对) => { if (!倒排.has(基)) 倒排.set(基, new Set()); 倒排.get(基).add(相对) };
  const 看 = (相对, 绝对) => {
    let s = '';
    try { const st = fs.statSync(绝对); if (st.size > 3 * 1024 * 1024) return; s = fs.readFileSync(绝对, 'utf8') } catch { return }
    const 本基 = path.basename(相对);
    for (const m of s.matchAll(TOKEN)) {
      const 基 = path.basename(m[0]);
      if (基.length < 4 || 基 === 本基) continue;   // 太短的名字噪音大（如 a.js）
      记(基, 相对);
    }
  };
  const 走 = (dir, 相对dir) => {
    let 项 = [];
    try { 项 = fs.readdirSync(dir, { withFileTypes: true }) } catch { return }
    for (const e of 项) {
      if (e.name.includes('.bak-')) continue;
      const p = path.join(dir, e.name);
      const 相 = (相对dir ? 相对dir + '/' : '') + e.name;
      if (e.isDirectory()) { if (!跳过目录.has(e.name)) 走(p, 相); continue }
      if (!e.isFile() || !文本后缀.has(path.extname(e.name))) continue;
      看(相, p);
    }
  };
  for (const d of ['工具', '内核', '台账', '记忆', '调研']) 走(path.join(工作区, d), d);
  try { for (const f of fs.readdirSync(工作区)) if (f.endsWith('.md')) 看(f, path.join(工作区, f)) } catch { }
  return 倒排;
}

let _索引 = null;
export const 取索引 = (工作区) => (_索引 ||= 建倒排(工作区));   // ★ 1010 导出：给 `出口账.mjs` 复用（内核 #68：判据只许现读，不许在别处重写一份）

/** 从一个件的内容里抽出**它引用的路径**（用于悬空检查）；按行判"是不是运行时拼的" */
function 抽引用(内容, 本件相对) {
  const 出 = new Map();   // 路径 → { 动态 }
  const 本目录 = path.posix.dirname(本件相对);
  const 是动态行 = (行) => /path\.(join|resolve)\(\s*[^'"`]/.test(行) || /os\.tmpdir|mkdtemp/.test(行) || (行.includes('+') && /['"][^'"]*\//.test(行));
  for (const 行 of 内容.split('\n')) {
    const 动 = 是动态行(行);
    const 记 = (p) => { const _旧 = 出.get(p); if (!_旧) 出.set(p, { 动态: 动 }); else if (动 && !_旧.动态) 出.set(p, { 动态: true }) };
    for (const m of 行.matchAll(/(?:from|import|require)\s*\(?\s*['"`](\.{1,2}\/[^'"`]+)['"`]/g)) {
      记(path.posix.normalize(path.posix.join(本目录, m[1])));
    }
    for (const m of 行.matchAll(/['"`](\/?)(工具|内核|台账|记忆|调研|桌宠项目)\/([\w\u4e00-\u9fa5./-]+\.(?:mjs|js|sh|json|md|yml|yaml))['"`]/g)) {
      记(m[2] + '/' + m[3]);
    }
  }
  return [...出].map(([路径, v]) => ({ 路径, 动态: v.动态 }));
}

/** 判据本体：单件的连续性 */
export function 查件(相对, 工作区 = WS, 索引 = null) {
  const 倒排 = 索引 || 取索引(工作区);
  const 绝对 = path.join(工作区, 相对);
  let 内容 = null;
  try { 内容 = fs.readFileSync(绝对, 'utf8') } catch { }
  const 基 = path.basename(相对);
  const 真调用 = [], 点名 = [], 嘴 = [], 悬空 = [], 疑似 = [];
  // ★ 1010 · **"件不在盘上"＝疑似，不是悬空**（判据假红第 4 类，与注释／生成物／阳性对照同一课）：
  //   `本窗写过.json` 是一本**流水**，里面记着"动过又删掉"的件（一次性样本／反证 —— 1010 我造过 `_反证真悬空.mjs`
  //   去验判据，用完删掉，这里就报红）。"件没了" ≠ "件坏了"：我没有删除审计，不能假设删除是错的 ⇒ 记进"疑似"（判黄）。
  if (内容 === null) 疑似.push({ 谁: 相对, 说: '件不在盘上（动过又不在 ⇒ 多半是主动删的一次性样本）' });
  if (内容 !== null) {
    // ★ 1010 · **注释不算引用**（治假红）：整行 `//` 注释里写着的 import/路径不该判悬空。
    //   1010 实犯：阳性对照探针把"怎么用它"写进注释 ⇒ 注释里那条不存在的路径被当成真引用 ⇒
    //   门把自己样本的说明书报成红（＝千问判决点名的"门假红"那族）。只剥**整行**注释，不碰行内字符串。
    const 去注释 = 内容.split('\n').filter((l) => !/^\s*\/\//.test(l)).join('\n');
    for (const r of 抽引用(去注释, 相对)) {
      if (fs.existsSync(path.join(工作区, r.路径))) continue;
      if (r.动态 || 占位名(r.路径)) 疑似.push({ 谁: 相对, 说: '运行时拼的／占位举例、盘上没有：' + r.路径 });
      else 悬空.push({ 谁: 相对, 说: '它引用的 ' + r.路径 + ' 不在盘上' });
    }
  }
  for (const f of (倒排.get(基) || [])) {
    if (f === 相对) continue;
    const 是码 = 码后缀.has(path.extname(f));
    const 是嘴 = 嘴件.includes(f) || f.endsWith('AGENTS.md');
    if (是嘴) 嘴.push(f);
    else if (是码) 真调用.push(f);
    else 点名.push(f);
  }
  // ★ 1010 · **阳性对照件**（命名含 harness／阳性对照／探针_）**故意**引用盘上没有的件，来测「悬空判据会不会报」——
  //   例：`工具/沙盒/试挂点/错误写法harness.mjs:25` 的 `写('神经/好件.mjs', …)` 是它**要造的**目标路径，**不是 import**。
  //   ⇒ 它们的悬空是**设计**不是病：不算红、标 🧪。不这么做的话，每建一个对照就红一次，
  //     最后我只能把判据关掉/绕开 —— 那正是外部核点名的假动作。
  const 是阳性对照 = /harness|阳性对照|探针_/i.test(基);
  let 判 = '绿';
  if (悬空.length && !是阳性对照) 判 = '红';
  else if (!真调用.length && !嘴.length) 判 = '黄';
  const 一行 = '连续 ' + 基 + '：调用 ' + 真调用.length + ' ｜ 嘴 ' + 嘴.length + ' ｜ 登记/点名 ' + 点名.length + ' ｜ 悬空 ' + 悬空.length + ' ⇒ ' + (判 === '红' ? '🔴' : 判 === '黄' ? '🟡' : '🟢') + (是阳性对照 && 悬空.length ? '（🧪 阳性对照·悬空是设计）' : '');
  return { 件: 相对, 真调用, 点名, 嘴, 悬空, 疑似, 判, 一行, 是阳性对照 };
}

/** 本轮动过的件（读 台账/接续/本窗写过.json） */
export function 本轮件(工作区 = WS, 限 = 60) {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(工作区, '台账/接续/本窗写过.json'), 'utf8'));
    const 件 = (j.件 || []).filter((f) => typeof f === 'string')
      .filter((f) => !/(^|\/)_backup\//.test(f) && !/\.bak-/.test(f))
      .filter((f) => !/^(台账|记忆)\//.test(f) || /\.(mjs|js|sh)$/.test(f))
      .filter((f) => 文本后缀.has(path.extname(f)));
    return 件.slice(0, 限);
  } catch { return [] }
}

/** ★ 1010 · ⑥ 外部核整改：把「红／黄」升成**带档位的红**。核原话：「关键悬空进硬停；疑似进待办；连续未处理升级」。
 *   判据全取自现有读数（不发明新概念）：
 *     硬停 = 有悬空 **且**（有人在真调用它 ∨ 每轮必到面点名它）⇒ 缺件会踩到开工／交班／Stop 链
 *     待办 = 有悬空但没人消费（先记账）｜或只有「疑似」（低置信：动态路径／占位／件不在盘）⇒ 不硬停，但必须复核
 *     印   = 其余（绿，随时可删）
 */
export const 档位 = (r) => {
  if (r.悬空.length && (r.真调用.length || r.嘴.length)) return '硬停';
  if (r.悬空.length || r.疑似.length) return '待办';
  return '印';
};
export const 连N = 3;   // 连续未处理多少轮 ⇒ 升级（核：「N 可先设 3」）
const 账路径 = (工作区) => path.join(工作区, '台账/接续/连续体检账.json');
/** 记一轮账：同一件连续出现 ⇒ 连续 +1；连续 ≥ 连N 仍没处理 ⇒ 待办升硬停（核的「红升级路径」）。
 *  ⚠️ 只写自己的账，不动被体检的件。件不再出现（＝处理了／没了）⇒ 从账上消失（自动清）。 */
export const 记账 = (列, 工作区 = WS) => {
  let 旧 = { 轮: 0, 件: {} };
  try { 旧 = JSON.parse(fs.readFileSync(账路径(工作区), 'utf8')) } catch { /* 头一次跑：没账正常 */ }
  const 轮 = (旧.轮 || 0) + 1;
  const 件 = {}; const 升级 = [];
  for (const x of 列) {
    const 档 = x.档 || 档位(x);
    if (档 === '印') continue;
    const 前 = (旧.件 && 旧.件[x.件]) || null;
    const 连续 = 前 ? (前.连续 || 1) + 1 : 1;
    // ★ 1010 ⑥ 外部核：「关键悬空进硬停；疑似进待办；连续未处理升级」＋「注释/占位疑似 ⇒ 不硬停」
    //   ⇒ **只有真悬空才升级**；疑似只记连续轮数、等人工复核（复核留痕后不再升级，防错升）。
    const 类 = x.悬空.length ? '悬空' : '疑似';
    const 复核 = (前 && 前.复核) || null;
    const 终档 = (!复核 && 类 === '悬空' && 档 === '待办' && 连续 >= 连N) ? '硬停' : 档;
    if (终档 !== 档) 升级.push(x.件 + '（悬空-无人消费，连续 ' + 连续 + ' 轮未处理 ⇒ 升硬停档）');
    件[x.件] = { 档: 终档, 本档: 档, 类, 连续, 复核, 说: (x.悬空[0] && x.悬空[0].说) || (x.疑似[0] && x.疑似[0].说) || '' };
  }
  try {
    fs.mkdirSync(path.dirname(账路径(工作区)), { recursive: true });
    fs.writeFileSync(账路径(工作区), JSON.stringify({ 轮, 更新: new Date().toISOString().slice(0, 19), 连N, 件 }, null, 1));
  } catch { /* 写不动就不写，读数照给（不因为记账失败而报假红） */ }
  return { 轮, 升级, 件 };
};

export function 扫(工作区 = WS, 件们 = null) {
  const 索引 = 取索引(工作区);
  const 列 = (件们 || 本轮件(工作区)).map((f) => 查件(f, 工作区, 索引)).map((x) => ({ ...x, 档: 档位(x) }));
  return {
    列,
    硬停: 列.filter((x) => x.档 === '硬停').length,
    待办: 列.filter((x) => x.档 === '待办').length,
    红: 列.filter((x) => x.判 === '红').length,
    黄: 列.filter((x) => x.判 === '黄').length,
    绿: 列.filter((x) => x.判 === '绿').length,
  };
}

// ───────────────────────── CLI ─────────────────────────
const 是主 = (() => { try { return !!process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url)) } catch { return false } })();

if (是主) {
  const [cmd, 参] = process.argv.slice(2);
  if (cmd === '件') {
    if (!参) { console.log('用法：连续体检.mjs 件 <相对路径>'); process.exit(2) }
    const r = 查件(参);
    console.log(r.一行);
    console.log('  真调用：' + (r.真调用.join('、') || '（无）'));
    console.log('  有嘴：' + (r.嘴.join('、') || '（无）'));
    console.log('  登记/点名：' + (r.点名.length ? r.点名.slice(0, 6).join('、') + (r.点名.length > 6 ? ' …共' + r.点名.length : '') : '（无）'));
    if (r.悬空.length) for (const s of r.悬空) console.log('  🔴 ' + s.说);
    if (r.疑似.length) for (const s of r.疑似.slice(0, 3)) console.log('  ⚪（不判）' + s.说);
    process.exit(r.判 === '红' ? 1 : 0);
  }
  if (cmd === '本轮' || cmd === '落盘') {
    const R = 扫(WS);
    const 账 = 记账(R.列, WS);
    console.log('连续体检 · 本轮 ' + R.列.length + ' 件 ⇒ 绿 ' + R.绿 + ' ｜ 黄 ' + R.黄 + ' ｜ 红 ' + R.红 + ' ｜ 🛑 硬停 ' + R.硬停 + ' ｜ 🟡 待办 ' + R.待办 + '（第 ' + 账.轮 + ' 轮）');
    for (const u of 账.升级) console.log('  ⚠️ ' + u);
    for (const [件名, 记] of Object.entries(账.件)) if (记.档 === '硬停' && 记.本档 !== '硬停') console.log('  🛑 ' + 件名 + '（连续 ' + 记.连续 + ' 轮未处理 ⇒ 已升硬停档，须处理或挂账）');
    for (const x of R.列) {
      if (x.判 === '绿') continue;
      console.log('  ' + x.一行);
      for (const s of x.悬空) console.log('     🔴 ' + s.说);
    }
    if (cmd === '落盘') {
      const 行 = ['# 连续体检 · ' + new Date().toLocaleString('zh-CN') + '（机器生成，只读）', '', '判据：`神经/连续体检.mjs`（真调用／嘴／登记点名／悬空）', '', '| 件 | 判定 | 真调用 | 嘴 | 登记/点名 | 悬空 |', '|---|---|---|---|---|---|'];
      for (const x of R.列) 行.push('| ' + x.件 + ' | ' + x.判 + ' | ' + x.真调用.length + ' | ' + x.嘴.length + ' | ' + x.点名.length + ' | ' + x.悬空.map((s) => s.说).join('；') + ' |');
      行.push('', '读数：绿 ' + R.绿 + ' ｜ 黄 ' + R.黄 + ' ｜ 红 ' + R.红);
      const 落 = path.join(WS, '台账/接续/连续体检.md');
      fs.writeFileSync(落, 行.join('\n') + '\n');
      console.log('已落盘 ' + 落);
    }
    process.exit(R.红 ? 1 : 0);
  }
  if (cmd === '复核') {
    // ★ 1010 ⑥ 外部核 B8（「疑似也要闭环：谁复核／何时复核／是否转真红／是否豁免」）：疑似清单必须能销账，否则它会变垃圾桶。
    //   用法：连续体检.mjs 复核 <相对路径> --说 "为什么它不是病"
    if (!参) { console.log('用法：连续体检.mjs 复核 <相对路径> --说 "…"'); process.exit(2) }
    const 说i = process.argv.indexOf('--说');
    if (说i <= 0) { console.log('❌ 复核必须带 --说 "…"（核要的是"谁复核＋为什么"，不是打个空勾）'); process.exit(2) }
    const p = 账路径(WS);
    let 账 = { 轮: 0, 件: {} };
    try { 账 = JSON.parse(fs.readFileSync(p, 'utf8')) } catch { }
    账.件[参] = { ...(账.件[参] || { 档: '待办', 本档: '待办', 类: '疑似', 连续: 0 }), 复核: new Date().toISOString().slice(0, 16) + ' ' + process.argv[说i + 1] };
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, JSON.stringify(账, null, 1));
    console.log('✅ 已记复核：' + 参 + ' ⇒ ' + process.argv[说i + 1] + '（不再计入升级；件没了会自动销账）');
    process.exit(0);
  }
  if (cmd === '一屏') {
    const R = 扫(WS);
    const 账 = 记账(R.列, WS);   // ★ 1010 ⑥：每跑一次记一轮（连续未处理 ⇒ 升级的必要条件）
    const 升 = 账.升级.length ? ' ｜ ⚠️ 升级 ' + 账.升级.length + ' 件（悬空连续未处理）' : '';
    const 待复核 = Object.entries(账.件).filter(([, v]) => v.类 === '疑似' && !v.复核).length;
    const 疑 = 待复核 ? ' ｜ 疑似待复核 ' + 待复核 + '（销账：node 神经/连续体检.mjs 复核 <件> --说 "…"）' : '';
    if (!R.硬停 && !R.待办) console.log('连续体检 ✅ ' + R.列.length + ' 件全接上' + 升);
    else console.log('【连续体检】🛑 硬停 ' + R.硬停 + ' ｜ 🟡 待办 ' + R.待办 + '（' + R.列.length + ' 件 · 第 ' + 账.轮 + ' 轮）' + 升 + 疑 + ' ⇒ node 神经/连续体检.mjs 本轮');
    process.exit(0);
  }
  if (cmd === 'selftest' || cmd === '自检') {
    const os = await import('node:os');
    const 房 = fs.mkdtempSync(path.join(os.tmpdir(), '连续体检-'));
    fs.mkdirSync(path.join(房, '神经'), { recursive: true });
    fs.writeFileSync(path.join(房, '神经/甲甲.mjs'), "export const a=1\n");
    fs.writeFileSync(path.join(房, '神经/乙乙.mjs'), "import './甲甲.mjs'\nexport const b=2\n");
    fs.writeFileSync(path.join(房, '神经/丙丙.mjs'), "import './不存在.mjs'\n");
    fs.writeFileSync(path.join(房, '神经/丁丁.mjs'), "const p = path.join(临时房, '神经/戊戊.mjs')\n");
    // ★ 1010 ⑥ 新增：造一个「悬空 ＋ 每轮必到面点名它」的件 ⇒ 必须判**硬停档**
    fs.mkdirSync(path.join(房, '工具/开工'), { recursive: true });
    fs.writeFileSync(path.join(房, '神经/庚庚.mjs'), "import './不存在庚.mjs'\n");
    fs.writeFileSync(path.join(房, '工具/开工/库.mjs'), '// 每轮必到口子：点名 神经/庚庚.mjs\n');
    const 索 = 建倒排(房);
    const 前 = '神经/';   // ★ 拼出来：selftest 里不许出现"整条路径字面量"，否则连续体检把自己的样本当成悬空引用（1010 实犯）
    const 甲 = 查件(前 + '甲甲.mjs', 房, 索);
    const 乙 = 查件(前 + '乙乙.mjs', 房, 索);
    const 丙 = 查件(前 + '丙丙.mjs', 房, 索);
    const 丁 = 查件(前 + '丁丁.mjs', 房, 索);
    const 案 = [
      ['甲有真调用（乙引用它）⇒ 绿', 甲.判 === '绿' && 甲.真调用.includes(前 + '乙乙.mjs')],
      ['乙没人消费 ⇒ 黄', 乙.判 === '黄'],
      ['丙引用不存在的件 ⇒ 红', 丙.判 === '红' && 丙.悬空.length === 1],
      ['件不在盘上 ⇒ 疑似、不判悬空（1010 改判：删掉的样本不是病）', 查件(前 + '己己.mjs', 房, 索).判 !== '红' && 查件(前 + '己己.mjs', 房, 索).疑似.length === 1],
      ['丁＝运行时拼的路径 ⇒ 疑似、不判红', 丁.判 !== '红' && 丁.疑似.length === 1],
      ['档位：悬空但没人消费 ⇒ 待办', 档位(丙) === '待办'],
      ['档位：悬空 ＋ 每轮必到面点名它 ⇒ 硬停', 档位(查件(前 + '庚庚.mjs', 房, 索)) === '硬停'],
      ['档位：绿件 ⇒ 印', 档位(甲) === '印'],
    ];
    // ★ 1010 ⑥ 新增：连续未处理 ⇒ 升级（同一件连记 3 轮 ⇒ 待办升硬停）
    const 丙档 = { ...丙, 档: 档位(丙) };
    记账([丙档], 房); 记账([丙档], 房);
    const 账三 = 记账([丙档], 房);
    案.push(['连续 ' + 连N + ' 轮未处理 ⇒ 待办升硬停档', 账三.件[丙.件] && 账三.件[丙.件].档 === '硬停' && 账三.升级.length === 1]);
    案.push(['账认 DSH_KICKOFF_WS（不写生产）', fs.existsSync(path.join(房, '台账/接续/连续体检账.json'))]);
    let 过 = 0;
    for (const [名, ok] of 案) { console.log((ok ? '✅' : '❌') + ' ' + 名); if (ok) 过++ }
    fs.rmSync(房, { recursive: true, force: true });
    console.log('自检 ' + 过 + '/' + 案.length);
    process.exit(过 === 案.length ? 0 : 1);
  }
  console.log('用法：连续体检.mjs 件 <路径> ｜ 本轮 ｜ 一屏 ｜ 落盘 ｜ selftest');
  process.exit(2);
}
