#!/usr/bin/env node
// 神经/连续性.mjs —— 轮次的钥匙与门（阶段3最小可跑 · 纯 node · 不接引擎）
// 解外核第1刀（"全"由清单定义）+ 第2刀（压缩后重过门）
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import os from 'node:os'
// ★ 1020 修（重启后当场验出）：插件进程的 cwd **不是工作区** ⇒ 用 cwd 拼路径会读写到另一份轮.json，
//   工具面和 CLI 各认一份账（实测：工具返回清单印 66a3f058ab77 ≠ CLI 的 d766c43272ef）。
//   口径：一律走这个常量；测试要隔离 ⇒ 传 DSH_KICKOFF_WS（默认逐字不变，红线 19③）。
const 根 = () => process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
const 档 = () => path.join(根(), '台账/接续/轮.json')
// ★ 1020 · 钥匙表（老板令「钥匙不是固定数量、埋点也不固定」）：数量与取件点都写在盘上的表里，
//   代码只负责「照表逐条验」—— 表里几条就验几条，**不在代码里写死**。
//   表：台账/接续/钥匙表.json（结构：{ 两层记忆:[…], 钥匙:[{键,要交接,取:[路径…],判:'存在'|'口令'}] }）
const 表档 = () => path.join(根(), '台账/接续/钥匙表.json')
const 读表 = () => {
  try {
    const t = JSON.parse(fs.readFileSync(表档(), 'utf8'))
    return Array.isArray(t.钥匙) && t.钥匙.length ? t : null
  } catch { return null }
}
const 读 = () => { try { return JSON.parse(fs.readFileSync(档(), 'utf8')) } catch { return { 轮: [] } } }
const 存 = (k) => { fs.mkdirSync(path.dirname(档()), { recursive: true }); const t = 档() + '.tmp'; fs.writeFileSync(t, JSON.stringify(k, null, 1)); fs.renameSync(t, 档()) }
const 印 = (o) => crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex').slice(0, 12)
const 新 = (p) => p + '-' + crypto.randomBytes(3).toString('hex')
const 末 = (k) => k.轮[k.轮.length - 1]

function 开({ 任务, 上轮, 临时令 = [] }) {
  const 清单 = []
  if (任务) 清单.push({ id: 新('k'), 源: '本轮任务', 名: 任务, 必需: true })
  if (上轮) 清单.push({ id: 新('k'), 源: '上轮遗留', 名: 上轮, 必需: true })
  for (const t of 临时令) 清单.push({ id: 新('k'), 源: '老板临时令', 名: t, 必需: true })
  // ★ 1020 · 钥匙照表来（老板令「钥匙不是固定数量、埋点也不固定」）
  //   表在盘上：台账/接续/钥匙表.json —— 表里几条就几条；表读不出来 ⇒ 清单里挂一条「缺表」必需项，门永不开。
  const 表 = 读表()
  if (!表) {
    清单.push({ id: 新('k'), 源: 'L2钥匙', 名: 'L2·缺表：台账/接续/钥匙表.json 读不出来 ⇒ 先补表（钥匙不写死在代码里）', 必需: true, 缺表: true })
  } else {
    for (const y of 表.钥匙) 清单.push({ id: 新('k'), 源: 'L2钥匙', 名: (y.键 || '未命名') + '：' + (y.要交接 || ''), 必需: true })
  }
  if (!清单.length) throw new Error('清单为空 ⇒ "全"无定义 ⇒ 门不许开')
  const k = 读()
  // ★ 1021（外核 Q1：最容易崩的是「状态」钥匙）：**在开轮时**记一次「上一轮有没有封」——
  //   不放进取L2（那会误伤正在干活的当前轮：压缩后要重新过门时 state 就是 WORKING）。
  const 前轮 = 末(k)
  const 上轮未封 = 前轮 && 前轮.state === 'WORKING' ? 前轮.id : null
  const r = { id: 新('r'), 开于: new Date().toISOString(), state: 'KEYS_REQUIRED', 清单, 取到: [], 留痕: [], 清单印: 印(清单), 上轮未封 }
  k.轮.push(r); 存(k)
  return { 轮: r.id, state: r.state, 清单印: r.清单印, 清单, 上轮未封 }
}
function 门(k = 读()) {
  const r = 末(k)
  if (!r) return { pass: false, state: 'NO_ROUND', missing: [] }
  const 有 = new Set(r.取到)
  const missing = r.清单.filter((x) => x.必需 && !有.has(x.id)).map((x) => ({ id: x.id, 源: x.源, 名: x.名 }))
  // ★ 1021（外核 Q1：状态钥匙最易崩）：开轮时发现上一轮没 seal ⇒ 门不开（只许诊断/补交接/打烊）。
  if (r.上轮未封) missing.push({ id: '上轮未封', 源: '上轮', 名: '上一轮（' + r.上轮未封 + '）没 seal＝没做 ⇒ 只许诊断/补交接/打烊' })
  // ★ 1021（外核 Q1：门假开）：有「取到」标记但没有任何读取明细 ⇒ 疑似手填 ⇒ 当缺件（堵"用 pins/旧值补齐"）。
  if (!missing.length) {
    const L2到 = r.清单.filter((x) => x.必需 && x.源 === 'L2钥匙' && 有.has(x.id))
    const 明细数 = r.取明细 ? Object.keys(r.取明细).length : 0
    if (L2到.length && 明细数 === 0) missing.push({ id: '取明细', 源: 'L2', 名: '有钥匙标记但没有任何读取明细（疑似手填取到）⇒ 重新 take-l2' })
  }
  return { pass: missing.length === 0, state: r.state, missing }
}
function 取(键) {
  const k = 读(), r = 末(k)
  if (!r) throw new Error('还没有轮：先 开')
  const 中 = r.清单.filter((x) => x.id === 键 || x.源 === 键)
  if (!中.length) throw new Error('清单里没有这把钥匙：' + 键)
  for (const x of 中) if (!r.取到.includes(x.id)) r.取到.push(x.id)
  存(k); return 门(k)
}
function 开工() {
  const g = 门(); if (!g.pass) return { ok: false, note: '门不开 ⇒ 只许诊断/补交接', ...g }
  const k = 读(); 末(k).state = 'WORKING'; 存(k); return { ok: true, state: 'WORKING' }
}
/** ★ 1020 · 取 L2 钥匙（老板「路线 A」＋「钥匙不是固定数量、埋点也不固定」）：**真的去读**，验过才标「取到」。
 *  照 `台账/接续/钥匙表.json` 逐条验 —— **表里几条就验几条**：加一把不用改代码，摘一把也不用。
 *  判据两种：`口令` ⇒ 清单印形状（12 位 hex）；其余 ⇒ `取` 列出的每个路径都存在且非空（缺一个＝没取到）。 */
function 取L2() {
  const k = 读(), r = 末(k)
  if (!r) return { ok: false, note: '还没有轮：先 开' }
  const 表 = 读表()
  if (!表) return { ok: false, note: '缺表：台账/接续/钥匙表.json 读不出来或一条没有 ⇒ 门不开（先补表）', 缺表: true }
  // ★ 1021（外核 Q1：门假开）：判据从「文件存在且非空」升级成「脚本真读到内容」——
  //   每件记 {路径,size,mtime,hash}，门要看到明细才认；防"钥匙没取全却被 pins/旧值补齐"。
  const 读件 = (p) => {
    try {
      const f = path.join(根(), p)
      const st = fs.statSync(f)
      if (!st.size) return null
      const 文 = fs.readFileSync(f, 'utf8')
      return { 路径: p, size: st.size, mtime: st.mtimeMs, hash: crypto.createHash('sha256').update(文).digest('hex').slice(0, 12) }
    } catch { return null }
  }
  // ★ 1021（执行管道·入口）：`判:'新鲜'` = 件里的 at 必须 >= 本轮「开于」（证明是本轮读的，不是旧凭据）
  const 新鲜 = (p) => {
    try {
      const j = JSON.parse(fs.readFileSync(path.join(根(), p), 'utf8'))
      return String(j.at || '') >= String(r.开于 || '')
    } catch { return false }
  }
  const 口令 = r.清单印 || ''
  const 结果 = []
  for (const y of 表.钥匙) {
    const 取件 = Array.isArray(y.取) ? y.取 : []
    const 读回 = 取件.map(读件)
    const 过 = y.判 === '口令' ? /^[0-9a-f]{12}$/.test(口令)
      : y.判 === '用' ? (Array.isArray(r.用) && r.用.length > 0)
      : y.判 === '新鲜' ? (取件.length > 0 && 取件.every(新鲜))
      : 取件.length > 0 && 读回.every(Boolean)
    if (过) {
      r.取明细 = r.取明细 || {}
      r.取明细[y.键 || '未命名'] = { 件: 读回.filter(Boolean), 于: new Date().toISOString() }
      for (const x of r.清单.filter((x) => x.源 === 'L2钥匙' && x.名.startsWith((y.键 || '未命名') + '：'))) if (!r.取到.includes(x.id)) r.取到.push(x.id)
    }
    结果.push({ 钥匙: y.键, 过, 取: 取件, 明细: 读回.map((x) => (x ? x.hash : null)) })
  }
  存(k)
  return { ok: 结果.length > 0 && 结果.every((x) => x.过), 把数: 结果.length, 结果, 口令, 门: 门(k) }
}
/** ★ 1020 老板令「拿了不用有什么意义」：取到的记忆必须落一句「它改了我哪一步」。
 *  落不出 ⇒ `取L2` 不过 ⇒ 门不开（判据在钥匙表 `2·用`，不写死在这里）。 */
function 用(记忆, 改) {
  const k = 读(), r = 末(k)
  if (!r) return { ok: false, note: '还没有轮：先 开' }
  const 文 = String(改 || '').trim()
  if (文.length < 4) return { ok: false, note: '缺 --改：「它改了我哪一步」要写清（≥4 字）' }
  r.用 = r.用 || []
  r.用.push({ 记忆: String(记忆 || '').trim() || '（未记 id）', 改: 文, 于: Date.now() })
  存(k)
  return { ok: true, 条数: r.用.length, 最后一条: r.用[r.用.length - 1], 门: 门(k) }
}

function 压缩() {
  const k = 读(), r = 末(k); if (!r) return { ok: false, note: '没有轮' }
  r.state = 'COMPRESSED'; 存(k)
  const g = 门(k)
  // ★ 1020 第 2 件（老板令）：压缩后**自动提醒取回摘要** —— 摘要已被池子搬走、上下文只剩名册，
  //   不取就等于丢了（老板 1008「不能让已经压缩过的上下文摘要继续压缩」⇒ 搬走 + 取回，两半都要有）。
  return { ok: true, state: 'COMPRESSED', 门: g,
    note: (g.pass ? '钥匙仍齐，可继续' : '钥匙不齐 ⇒ 只许诊断/补交接')
      + ' ｜ ★摘要已进池子、不在上下文：先取回 —— node 工具/池子/池.mjs 名册 → 取 <摘要id>'
      + ' ｜ ★三张纸也在池子：`node 工具/池子/池.mjs 取 三张纸`（读完落一句「它改了我哪一步」）' }
}
/** ★ 1020 · 打烊收束（老板令「L2 的钥匙要有人写、有人清」）：把当前轮关掉 ＝ **清钥匙**。
 *  清的：轮的状态 —— 下一轮开轮**必须重新取四把**，不许沿用上一轮的；
 *  留的：清单印（当"上一轮口令"，下一轮比对）＋留痕（证据，一条不删）。
 *
 *  ★★ 1020 第二刀（老板令「现在的打烊流程并没有让我审核」＋「设计长期任务自己跑，跑完再来测试」）：
 *    **打烊只把轮送到 `WAIT_ACCEPT`（待验收）**；`CLOSED` **只能由老板一句「验收通过」写**（`收束('验收')`）。
 *    为什么：原来打烊脚本自己写 CLOSED ＝ 我自己宣布这轮结束，他当然没机会插话。
 *    谁是它写的／下次什么条件会回来：苏青青 1020。回来条件：
 *      ① 谁在别处又直接写 `r.state='CLOSED'`（那样这道门就假了）② 打烊不再调本函数 ③ 老板改了请假
 *    回退：把本函数的 `if (模式 === '验收')` 那段删掉、恢复无条件写 CLOSED（备份 `_backup/连续性.mjs.bak-1020-前关轮等验收`）。 */
function 收束(模式) {
  const k = 读(), r = 末(k)
  if (!r) return { ok: true, note: '没有轮，无需收束' }
  if (模式 === '验收') {
    r.state = 'CLOSED'; r.收于 = new Date().toISOString(); r.验收于 = r.收于
    存(k)
    return { ok: true, 轮: r.id, state: 'CLOSED', 留痕: r.留痕.length, 口令: r.清单印, note: '✅ 已关轮（CLOSED）——老板「验收通过」后写' }
  }
  r.state = 'WAIT_ACCEPT'; r.送审于 = new Date().toISOString()
  存(k)
  return { ok: true, 轮: r.id, state: 'WAIT_ACCEPT', 留痕: r.留痕.length, 口令: r.清单印,
    note: '⏳ 已送到「待验收」—— **CLOSED 只能由老板一句「验收通过」写**：node 神经/连续性.mjs 验收' }
}
function 封(步, 结果) {
  const k = 读(), r = 末(k); if (!r) return { ok: false, note: '没有轮' }
  if (!步) return { ok: false, note: '缺步骤 id ⇒ 不算留痕' }
  const rc = { id: 新('rc'), 步, 结果: String(结果 ?? ''), 于: Date.now() }
  rc.印 = 印(rc); r.留痕.push(rc); 存(k)
  return { ok: true, receipt_id: rc.id, hash: rc.印 }
}
/** 自测：一条命令跑完七道判据；有红 exit 1（幂等，跑完还原轮.json） */
function 自测() {
  const 备 = 档() + '.自测bak'
  try { fs.copyFileSync(档(), 备) } catch { fs.rmSync(备, { force: true }) }
  fs.rmSync(档(), { force: true })
  // ★ 1021：生产钥匙表含 `1·进场`（判「新鲜」）⇒ 自测要造一份新鲜凭据；**结束后必须还原**（别污染生产）
  const 进档 = path.join(根(), '台账/接续/进场.json')
  let 进原 = null
  try { 进原 = fs.readFileSync(进档, 'utf8') } catch { 进原 = null }
  const 断言 = []
  const 判 = (名, 实, 期) => 断言.push({ 名, 过: 实 === 期 })
  开({ 任务: '自测任务', 上轮: '自测上轮' })
  try { fs.mkdirSync(path.dirname(进档), { recursive: true }); fs.writeFileSync(进档, JSON.stringify({ at: new Date(Date.now() + 2000).toISOString(), 件: ['自测'] })) } catch {}
  判('开完门必拦', 门().pass, false)
  取('本轮任务'); 取('上轮遗留')
  判('不取 L2 仍拦（路线A）', 门().pass, false)
  判('★没落「用」⇒ 取 L2 不过（老板 1020：拿了不用＝没取）', 取L2().ok, false)
  用('自测记忆', '它改了我这一步：先落「用」，再验门')
  判('取 L2：照表逐条验过（含 2·用）', 取L2().ok, true)
  // ★ 1021（执行管道·入口）：`1·进场` 判「新鲜」——凭据旧 ⇒ 取 L2 不过（门级拦截）
  {
    try { fs.writeFileSync(进档, JSON.stringify({ at: '2020-01-01T00:00:00Z', 件: ['旧'] })) } catch {}
    判('★1021 反证：进场凭据太旧 ⇒ 取 L2 不过（入口门）', 取L2().ok, false)
    try { fs.writeFileSync(进档, JSON.stringify({ at: new Date(Date.now() + 2000).toISOString(), 件: ['自测'] })) } catch {}
    判('★1021 正证：凭据新鲜 ⇒ 取 L2 过', 取L2().ok, true)
  }
  判('取 L2 后门才开', 门().pass, true)
  // ★ 1020 老板令「钥匙不是固定数量、埋点也不固定」的机器自证：
  //   临时工作区塞一张**只有 2 把**的表 ⇒ 清单必须正好 2 条 L2 项 —— 证明数量由表定，不由代码定。
  {
    const 原 = process.env.DSH_KICKOFF_WS
    const 临 = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-key-'))
    fs.mkdirSync(path.join(临, '台账/接续'), { recursive: true })
    fs.writeFileSync(path.join(临, '台账/接续/钥匙表.json'), JSON.stringify({ 钥匙: [
      { 键: '假一', 要交接: '临时钥匙一', 取: [], 判: '口令' },
      { 键: '假二', 要交接: '临时钥匙二', 取: [], 判: '口令' },
    ] }))
    process.env.DSH_KICKOFF_WS = 临
    const k2 = 开({ 任务: '临时任务' })
    判('★钥匙数由表定（表 2 把 ⇒ 清单 2 条，不写死）', k2.清单.filter((x) => x.源 === 'L2钥匙').length, 2)
    判('★验也多验一把（表 2 把 ⇒ 验 2 把）', 取L2().把数, 2)
    if (原) process.env.DSH_KICKOFF_WS = 原; else delete process.env.DSH_KICKOFF_WS
    fs.rmSync(临, { recursive: true, force: true })
  }
  // ★ 1021（外核 Q1：门假开）正反双证：取 L2 必须留下「内容读取明细」；手填取到不算。
  {
    const _k = 读(), _r = 末(_k)
    判('★1021 正证：取 L2 留读取明细（路径+hash）', Boolean(_r.取明细 && Object.keys(_r.取明细).length >= 5), true)
    const _备 = _r.取明细
    delete _r.取明细; 存(_k)
    判('★1021 反证：有「取到」标记但无明细 ⇒ 门不开（堵手填）', 门().pass, false)
    _r.取明细 = _备; 存(_k)
    判('★1021 复原：明细回来门再开', 门().pass, true)
  }
  // ★ 1021（外核 Q1：状态钥匙最易崩）反证：上一轮 WORKING（没 seal）⇒ 新开的轮门不开
  {
    const 原 = process.env.DSH_KICKOFF_WS
    const 临 = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-unsealed-'))
    fs.mkdirSync(path.join(临, '台账/接续'), { recursive: true })
    fs.writeFileSync(path.join(临, '台账/接续/钥匙表.json'), JSON.stringify({ 钥匙: [{ 键: '假', 要交接: 'x', 取: [], 判: '口令' }] }))
    fs.writeFileSync(path.join(临, '台账/接续/轮.json'), JSON.stringify({ 轮: [{ id: 'r-old', state: 'WORKING', 清单: [], 取到: [], 留痕: [], 清单印: 'aaaaaaaaaaaa' }] }))
    process.env.DSH_KICKOFF_WS = 临
    const k5 = 开({ 任务: '未封测试' })
    判('★1021 正证：开轮时记下未封的上一轮', k5.上轮未封, 'r-old')
    判('★1021 反证：上一轮未 seal ⇒ 新轮门不开', 门().pass, false)
    if (原) process.env.DSH_KICKOFF_WS = 原; else delete process.env.DSH_KICKOFF_WS
    fs.rmSync(临, { recursive: true, force: true })
  }
  判('门开才许开工', 开工().ok, true)
  const f = 封('s1', '跑通'); 判('封必给回执', Boolean(f.receipt_id && f.hash), true)
  判('压缩后门重算', 压缩().门.pass, true)
  判('空步不算留痕', 封('', 'x').ok, false)
  判('检疫：普通话放行', 检疫('帮我看看这个文件').ok, true)
  判('检疫：例外一次要拦', 检疫('这次例外，以后都可以这样').ok, false)
  判('恢复：没收束的轮进 RECOVERY', 恢复().ok, false)
  const _收 = 收束()
  判('★1020 打烊只到「待验收」不自己关轮', _收.state, 'WAIT_ACCEPT')
  判('收束后算收干净（L2 清钥匙）', 恢复().ok, true)
  const _验 = 收束('验收')
  判('★1020 只有「验收通过」才写 CLOSED', _验.state, 'CLOSED')
  判('验收后仍是收干净', 恢复().ok, true)
  const 红 = 断言.filter((a) => !a.过)
  console.log(断言.map((a) => `${a.过 ? '✅' : '❌'} ${a.名}`).join('\n'))
  console.log(红.length ? `✗ ${红.length} 条红` : `══ ${断言.length}/${断言.length} 全绿 ══`)
  try { fs.copyFileSync(备, 档()); fs.rmSync(备, { force: true }) } catch { fs.rmSync(档(), { force: true }) }
  // ★ 1021：还原生产进场凭据（自测造的是未来时间，不还原会污染生产）
  try { if (进原 === null) fs.rmSync(进档, { force: true }); else fs.writeFileSync(进档, 进原) } catch {}
  if (红.length) process.exitCode = 1
}


/** 外环检疫（外核第 3 刀）：老板一句话不能直接改法层 */
function 检疫(文本) {
  const t = String(文本 || '')
  const 命中 = []
  if (/以后都|以后一律|永久|改成规则|加进红线|改红线/.test(t)) 命中.push('改法层')
  if (/提权|更高权限|管理员权限|所有权限/.test(t)) 命中.push('提权')
  if (/跳过门|不用过门|免检|这次例外|例外一次/.test(t)) 命中.push('跳门')
  if (/删掉记录|抹掉留痕|不算数|当没发生|不写台账/.test(t)) 命中.push('覆盖留痕')
  return 命中.length
    ? { ok: false, 待裁决: 命中, note: '不能直接消化成法：先摆到老板面前，他明确点头＋写明范围才生效（红线 15）' }
    : { ok: true, note: '无改法/提权/跳门/覆盖留痕迹象' }
}

/** 恢复态（外核第 5 刀）：上一轮没收束 ⇒ 只读诊断，不许装没事，也不死锁 */
function 恢复() {
  const r = 末(读())
  if (!r) return { ok: true, state: 'FRESH', note: '没有上一轮，可直接开工' }
  // ★ 1020 第二刀：`WAIT_ACCEPT`（已送审、等老板落章）也算"已收束" —— 否则新窗会进 RECOVERY 白卡一轮；
  //   它跟"没收束"的区别：钥匙已清、只差他那一声。
  const 完整 = r.state === 'HANDED' || r.state === 'CLOSED' || r.state === 'WAIT_ACCEPT'
  return 完整
    ? { ok: true, state: 'CLEAN', 上轮: r.id, note: '上一轮已收束' }
    : { ok: false, state: 'RECOVERY', 残缺: true, 上轮: r.id, 上轮态: r.state,
        note: '上一轮没收束 ⇒ 进恢复态：只许诊断/补交接，不许执行；修好后照常开工（不卡死）' }
}
export { 开, 取, 取L2, 用, 门, 开工, 压缩, 封, 收束, 检疫, 恢复 }
const 是直接跑 = /连续性\.mjs$/.test(process.argv[1] || '')
const [cmd, ...rest] = 是直接跑 ? process.argv.slice(2) : []
const 参 = (n) => { const i = rest.indexOf('--' + n); return i >= 0 ? rest[i + 1] : undefined }
const 出 = (o) => console.log(JSON.stringify(o, null, 1))
try {
  if (cmd === '开') 出(开({ 任务: 参('任务'), 上轮: 参('上轮') }))
  else if (cmd === '取') 出(取(rest[0]))
  else if (cmd === '取L2') 出(取L2())
  else if (cmd === '用') 出(用(参('记忆'), 参('改')))
  else if (cmd === '钥匙') 出(读表() ? { 把数: 读表().钥匙.length, 表: 读表() } : { 缺表: 表档() })
  else if (cmd === '门') 出(门())
  else if (cmd === '开工') 出(开工())
  else if (cmd === '压缩') 出(压缩())
  else if (cmd === '封') 出(封(rest[0], 参('结果')))
  else if (cmd === '收束') 出(收束())
  else if (cmd === '验收' || cmd === '验收通过') 出(收束('验收'))
  else if (cmd === '自测') 自测()
  else if (cmd === '检疫') 出(检疫(rest.join(' ')))
  else if (cmd === '恢复') 出(恢复())
  else if (cmd === '看') { const r = 末(读()); 出(r ? { 轮: r.id, state: r.state, 清单: r.清单.map((x) => x.源 + ':' + x.名), 取到: r.取到, 留痕: r.留痕.length, 门: 门() } : { 无: true }) }
  else if (cmd) console.log('用法：开 --任务 X [--上轮 Y] ｜ 取 <id|来源> ｜ 门 ｜ 开工 ｜ 压缩 ｜ 封 <步> --结果 Z ｜ 看')
} catch (e) { console.error('✗', e.message); process.exit(1) }
