#!/usr/bin/env node
// 送核.mjs —— 送外部独立核 ＋ 真调用 ＋ 落台账（可多次送，台账留痕）
//
// ★★ 2026-10-22 老板当面纠正（原话保真）：「还有那一任务一送是我写的，还是你写的？我从来没说过
//   一任务一送吧，命令是你一开始自己加的」。
//   ⇒ 这里原来写着「老板 2026-10-07 令原话：一个任务只能送一次」—— **那是伪造归属**：是我的推断被我
//     写成了他的话。硬闸已拆（拦不拦 恒 false）：同一任务可以反复送，送过几次由台账看得见。
//   ⇒ 判据：凡在本文件里出现「老板…令／原话」，必须有出处（台账:行 或 对话原话）；没有就写「我的推断」。
//
// 用法：
//   node 神经/送核.mjs 查 <任务名>                 # 这任务送过没？（查台账）
//   node 神经/送核.mjs 送 <任务名> --件 <材料文件>  # 真送（默认 qwen3.8-max）；送过 ⇒ 只提醒、不拦（1022 起）
//        [--模型 qwen3.8-max|qwen3.8-flash] [--重送 <理由>] [--干跑]
//   node 神经/送核.mjs 账                          # 送核台账
//   node 神经/送核.mjs 自测 | 自检                 # 不联网、不花钱
//
// key 解析顺序（★ 2026-10-07 加：壳体一重整 settings/credentials，手写的 key 就没了 ⇒ 多留一条命）：
//   ① 环境变量 BAILIAN_API_KEY ② $DSH_HOME/.bailian-key（600 私密文件） ③ $DSH_HOME/.credentials.yaml
//
// ★ 纪律：只印回话，**绝不印 key**；台账只落指纹（sha256 前 12）＋任务名，不落正文。
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const 根 = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const H = process.env.DSH_HOME || '/data/data/com.dsharnessmobile.shell/files/home/.dsh'
// ★ 1007 夜修：改成函数、每次现算（模块加载时读 env ⇒ 自测改道会失效、写脏生产账）
const 台账 = () => process.env.SEND_REVIEW_LEDGER || path.join(根, '台账/接续/送核台账.json')
const 落点 = path.join(根, '台账/接续')
const BASE = process.env.BAILIAN_BASE || 'https://dashscope.aliyuncs.com/compatible-mode/v1'

const 是主 = (() => { try { return !!process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url)) } catch { return false } })()

function 读台账() { try { return JSON.parse(fs.readFileSync(台账(), 'utf8')) } catch { return { 单: [] } } }
function 写台账(t) {
  const f = 台账()
  fs.mkdirSync(path.dirname(f), { recursive: true })
  const 临时 = f + '.tmp-' + process.pid
  const fd = fs.openSync(临时, 'w'); fs.writeFileSync(fd, JSON.stringify(t, null, 1)); fs.fsyncSync(fd); fs.closeSync(fd)
  fs.renameSync(临时, f)   // 原子落盘
}
function 指纹(任务, 材料) { return crypto.createHash('sha256').update(任务 + '\u0000' + 材料).digest('hex').slice(0, 12) }
function key解析() {
  if (process.env.BAILIAN_API_KEY) return { k: process.env.BAILIAN_API_KEY, 源: 'env' }
  try { const s = fs.readFileSync(path.join(H, '.bailian-key'), 'utf8').trim(); if (s) return { k: s, 源: '$DSH_HOME/.bailian-key' } } catch { }
  try {
    const m = fs.readFileSync(path.join(H, '.credentials.yaml'), 'utf8').match(/^\s*BAILIAN_API_KEY:\s*(.+)$/m)
    if (m && m[1].trim() && !/\*/.test(m[1])) return { k: m[1].trim(), 源: '.credentials.yaml' }
  } catch { }
  return null
}
function 找过(任务) { return (读台账().单 || []).filter(x => x.任务 === 任务) }
// ★ 1022 起：硬闸拆了 —— 老板说「一任务一送」他从没定过，那是我自己加的。
//   函数名保留（自测与历史调用还在用），但**恒不拦**；送过几次走台账看，不阻断。
function 拦不拦() { return false }

async function 送(任务, 材料, 模型, 干跑, 重送理由) {
  const 指 = 指纹(任务, 材料)
  const 旧 = 找过(任务)
  const 真送过 = 旧.filter(x => x.状态 !== "干跑")   // ★ 干跑不算送过（否则干跑一次就把真送也闸死了）
  // ★ 1022：不再拦。送过就提醒一句，然后照送（老板要的是"改完再扔回去"）。
  if (旧.length) {
    console.log('ℹ️ 『' + 任务 + '』之前送过 ' + 旧.length + ' 次（不拦，只提醒）')
    for (const x of 旧) console.log('   · ' + x.at + ' · ' + x.模型 + ' · 指纹 ' + x.指纹 + ' · ' + (x.状态 || ''))
  }
  const kk = key解析()
  if (!kk && !干跑) {
    console.log('❌ 没有可用的 BAILIAN_API_KEY（试了 env / $DSH_HOME/.bailian-key / $DSH_HOME/.credentials.yaml）')
    console.log('   ⇒ 送核送不出去（端点与网络已验通：`…/compatible-mode/v1` 能回 401）。')
    return 2
  }
  const 条 = { at: new Date().toISOString(), 任务, 指纹: 指, 模型, 材料字符: 材料.length, 状态: 干跑 ? '干跑' : '送出中', key源: kk ? kk.源 : '干跑' }
  if (重送理由) 条.重送理由 = 重送理由
  if (干跑) {
    const t = 读台账(); t.单.push(条); 写台账(t)
    console.log('🔸 干跑：不联网。指纹 ' + 指 + ' ｜ 材料 ' + 材料.length + ' 字 ｜ 模型 ' + 模型 + ' ｜ key 源 ' + 条.key源)
    return 0
  }
  // ★ 流式（1007 修根 · 老坑 0mugfukit）：非流式时服务端要**整个回答生成完**才发响应头
  //   ⇒ 撞 Node 内置 5 分钟响应头上限，报错只剩 `The operation was aborted due to timeout`（看不出病因）。
  //   改流式后：头立刻到、边生成边收；掐的判据从「总时长」改成「空转」——180 秒没有新内容才掐。
  const 控 = new AbortController()
  let 空转 = setTimeout(() => 控.abort(new Error('180 秒没有任何新内容')), 180000)
  const 续命 = () => { clearTimeout(空转); 空转 = setTimeout(() => 控.abort(new Error('180 秒没有任何新内容')), 180000) }
  const 发 = (额外) => fetch(BASE + '/chat/completions', {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + kk.k },
    // ★ 1022 修：原来写死 `temperature: 0` ⇒ 4sapi 的 gpt-6.1-sol 直接 400
    //   （"Unsupported value: 'temperature' does not support 0 with this model. Only the default (1) value is supported"）
    //   ⇒ 默认**不传**，服务端用默认值；真要压温度用环境变量 SEND_TEMP。
    body: JSON.stringify({ model: 模型, ...(process.env.SEND_TEMP ? { temperature: Number(process.env.SEND_TEMP) } : {}), stream: true, ...额外, messages: [{ role: 'user', content: 材料 }] }),
    signal: 控.signal,
  })
  let r
  try {
    r = await 发({ stream_options: { include_usage: true } })
    if (!r.ok && r.status === 400) {
      const 试 = await r.text()   // 有的口不认 stream_options ⇒ 摘了重发一次
      if (/stream_options/.test(试)) r = await 发({})
      else {
        clearTimeout(空转)
        条.状态 = '失败 HTTP 400'; 条.回话 = 试.slice(0, 400).replace(/sk-[A-Za-z0-9]+/g, 'sk-打码')
        const t = 读台账(); t.单.push(条); 写台账(t)
        console.log('❌ HTTP 400：' + 条.回话); return 1
      }
    }
  } catch (e) {
    clearTimeout(空转)
    条.状态 = '失败 ' + (e?.message || '网络异常')
    const t = 读台账(); t.单.push(条); 写台账(t)
    console.log('❌ 异常：' + (e?.message || e)); return 1
  }
  if (!r.ok) {
    const txt = await r.text(); clearTimeout(空转)
    条.状态 = '失败 HTTP ' + r.status
    条.回话 = txt.slice(0, 400).replace(/sk-[A-Za-z0-9]+/g, 'sk-打码')
    const t = 读台账(); t.单.push(条); 写台账(t)
    console.log('❌ HTTP ' + r.status + '：' + 条.回话)
    return 1
  }
  const 读流 = r.body.getReader(); const 码器 = new TextDecoder()
  let 缓 = '', 回话 = '', 用量 = null
  for (; ;) {
    const { done, value } = await 读流.read()
    if (done) break
    续命()
    缓 += 码器.decode(value, { stream: true })
    const 行们 = 缓.split('\n'); 缓 = 行们.pop()
    for (const 行原 of 行们) {
      const s = 行原.trim(); if (!s.startsWith('data:')) continue
      const 体 = s.slice(5).trim(); if (!体 || 体 === '[DONE]') continue
      try {
        const o = JSON.parse(体)
        const d = o.choices?.[0]?.delta?.content
        if (d) 回话 += d
        if (o.usage) 用量 = o.usage
      } catch { }
    }
  }
  clearTimeout(空转)
  const j = { usage: 用量 }
  const 文件 = path.join(落点, '送核_' + 任务.replace(/[^\w\u4e00-\u9fa5-]/g, '') + '_' + 指 + '.md')
  fs.writeFileSync(文件, '# 外部独立核 · ' + 任务 + '\n\n- 时间：' + 条.at + '\n- 模型：' + 模型 + '\n- 任务指纹：' + 指 + '\n- 材料：' + 材料.length + ' 字\n- 用量：' + JSON.stringify(j.usage || {}) + '\n\n---\n\n## 核的回话（原文，未改一字）\n\n' + 回话 + '\n')
  条.状态 = '成功'; 条.用量 = j.usage; 条.回话字符 = 回话.length; 条.回话落点 = path.relative(根, 文件)
  const t = 读台账(); t.单.push(条); 写台账(t)
  console.log('✅ 送出成功 ｜ ' + 模型 + ' ｜ 用量 ' + JSON.stringify(j.usage || {}))
  console.log('   回话落点：' + 条.回话落点 + '（' + 回话.length + ' 字）')
  return 0
}

function 自测() {
  const 备 = 台账
  const 临时 = path.join(根, '_tmp', '送核自测-' + process.pid + '.json')
  process.env.SEND_REVIEW_LEDGER = 临时
  if (!/_tmp|自测/.test(String(台账())) && !/_tmp|自测/.test(String(process.env.LEASE_FILE || ''))) {
    console.log('⛔ 自测落点没改道 ⇒ 拒跑（否则会写脏生产账）'); return 1
  }
  try { fs.mkdirSync(path.dirname(临时), { recursive: true }) } catch { }
  try { fs.unlinkSync(临时) } catch { }
  const r = []; const ok = (名, 真) => r.push([名, !!真])
  ok('① 指纹稳定且区分材料', 指纹('甲', 'A') === 指纹('甲', 'A') && 指纹('甲', 'A') !== 指纹('甲', 'B'))
  ok('② 指纹＝12 位十六进制', /^[0-9a-f]{12}$/.test(指纹('x', 'y')))
  const t = { 单: [{ at: '2026-01-01T00:00:00Z', 任务: '自测任务', 指纹: 'aaaaaaaaaaaa', 模型: 'qwen3.8-max', 状态: '成功' }] }
  写台账(t)
  ok('③ 已送过的任务 ⇒ 闸认得出来', 找过('自测任务').length === 1 && 找过('别的任务').length === 0)
  ok('④ 台账原子写后能读回', 读台账().单.length === 1)
  const k = key解析()
  ok('⑤ key 解析：要么给串、要么给 null（不抛）', k === null || typeof k.k === 'string')
  ok('⑥ 同一任务第二次真送 ⇒ **不再拦**（1022 老板：他没定过一任务一送）', 拦不拦([{ 状态: '成功' }], null) === false)
  ok('⑦ 干跑也不拦', 拦不拦([{ 状态: '干跑' }], null) === false)
  ok('⑧ 送过几次 ⇒ 台账查得到（这是替代硬闸的记账）', 找过('自测任务').length === 1)
  if (备 && fs.existsSync(备)) fs.writeFileSync(临时, fs.readFileSync(备))   // 还原
  else { try { fs.unlinkSync(临时) } catch { } }
  process.env.SEND_REVIEW_LEDGER = 备
  const 败 = r.filter(x => !x[1])
  console.log('【送核 · 自测】')
  for (const [名, 真] of r) console.log('  ' + (真 ? '✅' : '❌') + ' ' + 名)
  console.log(败.length ? '❌ 败 ' + 败.length + '/' + r.length : '✅ 全过（' + r.length + '/' + r.length + '）')
  return 败.length ? 1 : 0
}

if (是主) {
  const 动词 = process.argv[2]
  const 参 = k => { const i = process.argv.indexOf('--' + k); return i >= 0 ? process.argv[i + 1] : null }
  if (动词 === '自测' || 动词 === '自检') process.exit(自测())
  else if (动词 === '查') {
    const 任务 = process.argv[3]
    if (!任务) { console.log('用法：送核.mjs 查 <任务名>'); process.exit(2) }
    const 旧 = 找过(任务)
    console.log(旧.length ? '⛔ 已送过 ' + 旧.length + ' 次：\n' + 旧.map(x => '   · ' + x.at + ' ' + x.模型 + ' 指纹' + x.指纹 + ' ' + x.状态).join('\n') : '✅ 没送过')
    process.exit(0)
  } else if (动词 === '账') {
    const t = 读台账()
    console.log('送核台账：' + (t.单 || []).length + ' 条')
    for (const x of t.单 || []) console.log('  · ' + x.at + ' ｜ ' + x.任务 + ' ｜ ' + x.模型 + ' ｜ ' + x.状态 + (x.回话落点 ? ' ｜ ' + x.回话落点 : '') + (x.状态 === '成功' ? (x.判决 ? ' ｜ ✅已判' : ' ｜ ⚪未判') : ''))
    process.exit(0)
  } else if (动词 === '判') {
    const 任务 = process.argv[3]; const 判 = 参('判'); const 落 = 参('落')
    if (!任务 || !判) { console.log('用法：送核.mjs 判 <任务名> --判 "<我的判断>" [--落 "<文件:行>"]'); process.exit(2) }
    const t = 读台账(); const 组 = (t.单 || []).filter(x => x.任务 === 任务 && x.状态 === '成功')
    const 末 = 组[组.length - 1]
    if (!末) { console.log('⛔ 台账里没有「' + 任务 + '」的成功记录 ⇒ 先送再判'); process.exit(3) }
    末.判决 = 判; if (落) 末.落地 = 落; 末.判于 = new Date().toISOString()
    写台账(t)
    console.log('✅ 已判：' + 任务 + '\n   判：' + 判 + (落 ? '\n   落：' + 落 : ''))
    process.exit(0)
  } else if (动词 === '待判') {
    const t = 读台账(); const 未 = (t.单 || []).filter(x => x.状态 === '成功' && !x.判决)
    console.log(未.length ? '⚪ 送过但没判的：' + 未.length + ' 条\n' + 未.map(x => '  · ' + x.at + ' ｜ ' + x.任务 + ' ｜ ' + (x.回话落点 || '')).join('\n') : '✅ 全部判过（送核三件套② 没欠账）')
    process.exit(未.length ? 1 : 0)
  } else if (动词 === '送') {
    const 任务 = process.argv[3]; const 件 = 参('件')
    if (!任务 || !件) { console.log('用法：送核.mjs 送 <任务名> --件 <材料文件> [--模型 qwen3.8-max] [--干跑] [--重送 <理由>]'); process.exit(2) }
    送(任务, fs.readFileSync(件, 'utf8'), 参('模型') || 'qwen3.8-max', process.argv.includes('--干跑'), 参('重送'))
      .then(c => process.exit(c)).catch(e => { console.log('❌ 异常：' + e.message); process.exit(1) })
  } else { console.log('用法：送核.mjs 查 <任务> ｜ 送 <任务> --件 <材料文件> [--模型 …] [--干跑] [--重送 <理由>] ｜ 账 ｜ 自测'); process.exit(2) }
}
export { 指纹, 找过, key解析 }
