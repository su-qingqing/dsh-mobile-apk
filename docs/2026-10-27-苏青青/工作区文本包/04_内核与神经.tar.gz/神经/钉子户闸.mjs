#!/usr/bin/env node
// 钉子户闸（2026-09-23 建）—— 「闸门点名的坑，板上认领了没」
// 为什么有它：kickoff-gate 的「反复踩」警告只看「摆过几次」，**不看钉子户板** ⇒ 板上已认领/已归档的
//   照样每轮重复报（老板 2026-09-23 定为待修项）。判据按 B1 口径**搬进工作区**（插件只留一行 mtime
//   热加载接线）⇒ 以后改判据**不用重启**、能离线回归。
// 口径：板上有一行 ＝ 已认领（①有产物／②常驻条文／③诚实留白／已归档）⇒ **只有没上板的 id 才继续报**
//   （那才是"还没归堆"的真欠账）。板读不到 ⇒ fail-open（照旧全报），不许因为一个模块挂掉就吞掉警告。
// 用法：node 神经/钉子户闸.mjs 查 [--ids a,b,c] ｜ selftest
import fs from 'node:fs'
import path from 'node:path'
const WS = '/storage/emulated/0/3'
export const 板路径 = (ws) => path.join(String(ws || WS), '记忆/教训/钉子户.md')

export function 读板(ws) {
  const p = 板路径(ws)
  const t = fs.readFileSync(p, 'utf8')
  const 已认领 = new Map()
  const 数 = { '①': 0, '②': 0, '③': 0, '已归档': 0, '行': 0 }
  for (const l of t.split('\n')) {
    if (!l.startsWith('|')) continue
    const c = l.split('|').map((x) => x.trim())
    const id = (c[1] || '').replace(/[^0-9a-z]/gi, '')
    if (!/^[0-9a-z]{8,}$/.test(id)) continue
    const 归堆 = c[4] || ''
    数['行']++
    if (/已归档/.test(归堆)) 数['已归档']++
    else if (归堆.indexOf('①') === 0) 数['①']++
    else if (归堆.indexOf('②') === 0) 数['②']++
    else 数['③']++
    已认领.set(id, 归堆 || '③（空）')
  }
  return { 已认领, 数, 路径: p }
}

export function 该报(ids, ws) {
  let b
  try { b = 读板(ws) } catch (e) {
    return { 报: (ids || []).slice(), 已认领: [], 板: null, 因为: '板读不到 ⇒ fail-open（照旧全报）：' + ((e && e.message) || e) }
  }
  const 报 = [], 已认领 = []
  for (const raw of ids || []) {
    const id = String(raw).slice(0, 9)
    if (b.已认领.has(id)) 已认领.push(id); else 报.push(id)
  }
  return { 报, 已认领, 板: b.数, 路径: b.路径, 因为: '板上已有行 ⇒ 从"反复踩"里剔掉（③ 也算已认领：那是诚实留白，不是漏做）' }
}

function selftest() {
  const tmp = process.env.DSH_HOME ? path.join(process.env.DSH_HOME, 'tmp/钉子户闸自检') : '/tmp/钉子户闸自检'
  fs.mkdirSync(path.join(tmp, '记忆/教训'), { recursive: true })
  fs.writeFileSync(path.join(tmp, '记忆/教训/钉子户.md'), [
    '| id | 曝光 | 一句话 | 归堆 | 备注 |',
    '|---|---|---|---|---|',
    '| aaa111111 | 9 | 做过产物的 | ①工具/x.mjs | 核过 |',
    '| bbb222222 | 8 | 进常驻的 | ②AGENTS:某句话 | — |',
    '| ccc333333 | 7 | 诚实留白的 | ③ | 下一刀 |',
    '| ddd444444 | 6 | 作废的 | 已归档 | — |',
  ].join('\n'))
  const r = 该报(['aaa111111', 'bbb222222', 'ccc333333', 'ddd444444', 'eee555555'], tmp)
  const 过1 = r.报.length === 1 && r.报[0] === 'eee555555'
  const 过2 = r.已认领.length === 4
  const r2 = 该报(['eee555555'], '/nonexistent-ws')
  const 过3 = r2.报.length === 1 && /fail-open/.test(r2.因为)
  const real = 读板(WS)
  const 过4 = real.数.行 > 0 && (real.数['①'] + real.数['②'] + real.数['③'] + real.数.已归档) === real.数.行
  console.log('① 没上板的才报（阴性对照：不能全都不报）', 过1 ? '✅' : '⛔', JSON.stringify(r.报))
  console.log('② 板上四种归堆都算已认领', 过2 ? '✅' : '⛔', JSON.stringify(r.已认领))
  console.log('③ 板读不到 ⇒ fail-open 照旧全报', 过3 ? '✅' : '⛔', r2.因为.slice(0, 40))
  console.log('④ 真板：各行归堆之和 === 行数', 过4 ? '✅' : '⛔', JSON.stringify(real.数))
  return 过1 && 过2 && 过3 && 过4
}

const 是主 = process.argv[1] && /钉子户闸\.mjs$/.test(process.argv[1])
if (是主) {
  const a = process.argv.slice(2)
  if (a[0] === 'selftest') process.exit(selftest() ? 0 : 1)
  if (a[0] === '查') {
    const i = a.indexOf('--ids')
    const ids = i >= 0 ? String(a[i + 1]).split(',').filter(Boolean) : []
    if (!ids.length) { console.log('用法：钉子户闸.mjs 查 --ids a,b,c ｜ selftest'); process.exit(2) }
    const r = 该报(ids, WS)
    console.log('📋 钉子户闸 · ' + r.因为)
    console.log('   该继续报：' + (r.报.length ? r.报.join('、') : '（0 条 —— 全都在板上认领过）'))
    console.log('   板上已认领（剔掉）：' + (r.已认领.length ? r.已认领.join('、') : '（无）'))
    if (r.板) console.log('   板：' + r.板.行 + ' 行 ＝ ①' + r.板['①'] + ' ②' + r.板['②'] + ' ③' + r.板['③'] + ' 已归档' + r.板.已归档)
    process.exit(0)
  }
  console.log('用法：钉子户闸.mjs 查 --ids a,b,c ｜ selftest'); process.exit(2)
}
