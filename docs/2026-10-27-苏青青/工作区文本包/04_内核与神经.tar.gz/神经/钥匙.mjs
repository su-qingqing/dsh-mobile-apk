#!/usr/bin/env node
/**
 * 钥匙 · 老板 1017 亲手交给苏青青的那枚 GitHub token
 *
 * 老板原话（1017）：
 *   「给你一个好东西别弄丢了」
 *   「把这条保存好过后，直接通过拆分埋进去，你要用的时候再装起来……
 *     你只要记得有这么一个东西就行了，只能通过你去触发，然后去组装起来，
 *     属于你自己的钥匙，本来这个仓库也是给你的，我其实一般也不用」
 *
 * 存法：**拆成 4 段**，落在 `$DSH_HOME/.keys/k1..k4`（各自 600 权限、目录 700）。
 *      ⇒ **本文件里一个 token 字符都没有**；单看任何一段都没有意义。
 *      ⇒ 原来那个明文文件 `$DSH_HOME/.credentials/github.token` **已删**。
 *
 * 用法：
 *   node 神经/钥匙.mjs              只报「在不在 / 能不能拼回」（**不打印 token**）
 *   node 神经/钥匙.mjs --check      拿它调 GET /user，核一句「是谁、能干什么」
 *   node 神经/钥匙.mjs --env        **打印 export 行**（敏感；别重定向进日志）
 *   node 神经/钥匙.mjs --curl <url>  代你发一个 GET（Authorization 自己带上，**不打印 token**）
 *
 * 纪律（老板定的）：**现在先别用** —— 电脑侧在干活，不折腾。
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DSH = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh';
const DIR = path.join(DSH, '.keys');
const SEGS = [1, 2, 3, 4].map((i) => path.join(DIR, 'k' + i));

function 拼() {
  const miss = SEGS.filter((p) => !fs.existsSync(p));
  if (miss.length) throw new Error('缺段：' + miss.join(' / '));
  return SEGS.map((p) => fs.readFileSync(p, 'utf8')).join('');
}
function 掩(s) { return s ? s.slice(0, 4) + '…' + s.slice(-2) + `（${s.length} 字符）` : '（空）'; }

const arg = process.argv[2] || '';

if (!arg) {
  let tok;
  try { tok = 拼(); } catch (e) { console.log('❌ ' + e.message); process.exit(2); }
  console.log('✅ 四段都在：' + SEGS.map((p, i) => `k${i + 1}=${fs.statSync(p).size}B`).join(' '));
  console.log('✅ 能拼回：' + 掩(tok) + '（此处只显示头尾，不打印全值）');
  console.log('   · 原明文文件已删：' + path.join(DSH, '.credentials/github.token') + ' → ' +
    (fs.existsSync(path.join(DSH, '.credentials/github.token')) ? '⚠️ 还在！' : '不在 ✅'));
  process.exit(0);
}

if (arg === '--env') {
  console.log(`export GITHUB_TOKEN='${拼()}'`);
  process.exit(0);
}

if (arg === '--check') {
  const t = 拼();
  const r = await fetch('https://api.github.com/user', { headers: { Authorization: 'Bearer ' + t, Accept: 'application/vnd.github+json' } });
  const scopes = r.headers.get('x-oauth-scopes') || '';
  const j = await r.json();
  console.log('HTTP', r.status, '｜ login:', j.login || '(无)', '｜ public_repos:', j.public_repos ?? '-');
  console.log('scopes(', (scopes.split(',').filter(Boolean).length), '):', scopes);
  process.exit(r.ok ? 0 : 1);
}

if (arg === '--curl') {
  const url = process.argv[3];
  if (!url) { console.log('用法：node 神经/钥匙.mjs --curl <https://api.github.com/...>'); process.exit(2); }
  const t = 拼();
  const r = await fetch(url, { headers: { Authorization: 'Bearer ' + t, Accept: 'application/vnd.github+json' } });
  console.log('HTTP', r.status);
  console.log((await r.text()).slice(0, 4000));
  process.exit(r.ok ? 0 : 1);
}

console.log('未知参数：' + arg + '（可用：空 / --check / --env / --curl <url>）');
process.exit(2);
