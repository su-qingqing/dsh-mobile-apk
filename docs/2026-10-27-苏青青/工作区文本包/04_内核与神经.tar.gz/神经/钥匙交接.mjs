#!/usr/bin/env node
// 神经/钥匙交接.mjs —— 打烊那一下：L2 钥匙的「谁写、谁清」（老板 1020 令「钥匙要有人写、有人清」＋「数量不固定」）
// 挂点：打烊.mjs §二十二（挂"打烊"这个必然时刻，**不造新门**）。
// 判据：跑完这一下，轮状态必须是 CLOSED/WAIT_ACCEPT；下一轮开轮重新取钥匙（照表），不许沿用。
// 谁是它写的／下次什么条件会回来：苏青青 1020。**收束() 改名** ⇒ 这里直接报错（不静默）。
// 回退：删掉打烊 §二十二 那段（钥匙就没人清，回到"上一轮的钥匙下一轮还能用"的样子）。
import fs from 'node:fs'; import path from 'node:path'
import { 收束, 门 } from './连续性.mjs'

// ★ 1020 老板令「钥匙不是固定数量、埋点也不固定」：谁写谁清也照表印，不在代码里写死四行。
const 根 = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'
let 表 = null
try { 表 = JSON.parse(fs.readFileSync(path.join(根, '台账/接续/钥匙表.json'), 'utf8')) } catch { 表 = null }

const 前 = 门()
const 清 = 收束()

const 行 = (表 && Array.isArray(表.钥匙) && 表.钥匙.length)
  ? 表.钥匙.map((y) => [y.键, (y.取 || []).join('＋') || '（无取件点·口令类）', y.写 || '（表里没填）', y.清 || '（表里没填）'])
  : [['⚠️ 缺表', '台账/接续/钥匙表.json 读不出来', '—', '先补表']]

console.log('【§二十二 · L2 钥匙交接】')
console.log('清之前：门=' + (前.pass ? '开' : '关') + '（缺 ' + 前.missing.length + ' 把）｜状态=' + 前.state)
if (!清.ok) {
  console.log('⚠️ 清失败：' + (清.note || '未知'))
} else if (清.note === '没有轮，无需收束') {
  console.log('（没有轮可以清 —— 这一轮没开过轮）')
} else {
  console.log('✅ 已清：轮 ' + 清.轮 + ' → ' + (清.state || 'CLOSED') + ' ｜留痕 ' + 清.留痕 + ' 条（证据不删）｜上一轮口令 ' + 清.口令)
  if ((清.state || '') === 'WAIT_ACCEPT') console.log('   ⏳ **这是「待验收」不是「已关轮」** —— 老板一句「验收通过」才写 CLOSED：`node 神经/连续性.mjs 验收`')
}
console.log('  谁写谁清：')
for (const [k, 取, 写, 清法] of 行) console.log('   · ' + k + '｜取：' + 取 + '｜写者：' + 写 + '｜' + 清法)
console.log('  判据：下一轮开轮必须重新取钥匙（照 `台账/接续/钥匙表.json` 现算：' + (行[0] && 行[0][0] === '⚠️ 缺表' ? 0 : 行.length) + ' 把），旧口令不认。')

// ★ 自证（双证靠它）：清完轮**必须是「已清」两态之一**（WAIT_ACCEPT＝已送审等老板落章／CLOSED＝已关轮）—— 否则 exit 1。
//   为什么：把 `收束()` 短路掉时，脚本照样印「✅ 已清」，只有这一行能把它抓红。
//   ★ 1020 第二刀：允许 WAIT_ACCEPT，但**绝不允许它自己跳到 CLOSED**（那要靠老板的「验收通过」）。
const 后 = 门()
if (清.ok && 清.note !== '没有轮，无需收束' && !['CLOSED', 'WAIT_ACCEPT'].includes(后.state)) {
  console.log('❌ 清完状态不是 CLOSED/WAIT_ACCEPT：' + 后.state + ' ⇒ 钥匙没真清')
  process.exit(1)
}
