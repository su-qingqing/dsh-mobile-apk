#!/usr/bin/env node
// 钩子体检 v2 —— 判「一条规矩到底拦不拦得住」，不是数它写了几条。
// v1 的错（2026-09-26 自查出）：只拿 txt/judge 匹配，把「红蓝对抗」误判成"零条文" ——
//   它其实写在动作的 src（法源）字段里 ＋ 公约 §七 ＋ 做法库 ＋ 流程定义。
//   ⇒ 口径太窄 = 假红。v2 全字段匹配，但**分字段报**，把"真动作条文"和"只引了法源"分开。
import { ACTS_BEHAVIOR } from './动作集定义.mjs';

const 可执行 = /(\.mjs|\.sh|node\s|npm\s|--[a-z]|｜\s*核：|\|\s*核：)/;
const 人判词 = /(他能|他说|被追问|指出|勾选|说出口|当面|看一眼)/;
const 档 = a => {
  const j = String(a.judge || '');
  if (可执行.test(j)) return '门';
  if (人判词.test(j)) return '需人判';
  return '条文级';
};

// 命中分三层：动作层（txt/judge/viol＝真给了动作）／法源层（src＝只引了出处）／全无
const 命中 = (a, re) => {
  if (re.test(String(a.txt || '') + String(a.judge || '') + String(a.viol || ''))) return '动作层';
  if (re.test(String(a.src || ''))) return '法源层';
  return null;
};

const 老板点的 = [
  ['双绿反向测试',   /(反向|反证|双绿|故意破坏)/],
  ['红蓝对抗',       /(红蓝|对抗)/],
  ['生产区保存回退', /(备份|回退|留样|快照)/],
  ['语音错字',       /(错字|同音|语音)/],
  ['没读明白就停下问', /(不懂|读不懂|停下|先问|确认)/],
  ['跨窗口',         /(窗口|跨窗)/],
  ['成本',           /(成本|token|算力|花钱)/],
  ['预埋针',         /(预埋|针)/],
  ['系统提示词',     /(提示词|注入|AGENTS)/],
];

const 计 = { 门: 0, 需人判: 0, 条文级: 0 };
const 清单 = ACTS_BEHAVIOR.map(a => ({ id: a.id, 档: 档(a) }));
清单.forEach(x => 计[x.档]++);

console.log('══ 钩子体检 v2 · 行为动作 ' + ACTS_BEHAVIOR.length + ' 条 ══');
console.log('  门       ' + String(计.门).padStart(2) + ' 条  ← judge 里带真命令，机器能反复跑');
console.log('  需人判   ' + String(计.需人判).padStart(2) + ' 条  ← 判据要老板本人看/说，造不出机器反测');
console.log('  条文级   ' + String(计.条文级).padStart(2) + ' 条  ← ★ 写了但机器判不了＝靠我记得＝换窗即忘');
console.log('');
console.log('══ 老板点的九样 · 分三层看 ══');
console.log('  （动作层＝真给了动作 ｜ 法源层＝只在 src 里引了出处 ｜ 全无＝真断）');
for (const [名, re] of 老板点的) {
  const 动 = [], 源 = [];
  for (const a of ACTS_BEHAVIOR) {
    const h = 命中(a, re);
    if (h === '动作层') 动.push(a.id + (档(a) === '门' ? '★' : ''));
    else if (h === '法源层') 源.push(a.id);
  }
  const 旗 = 动.length === 0 && 源.length === 0 ? '❌ 真断（哪儿都没有）'
           : 动.length === 0 ? '⚠️ 只引了法源·没有动作'
           : 动.some(x => x.endsWith('★')) ? '✅ 动作层有·且带门'
           : '⚠️ 动作层有·但一条门都没有';
  console.log('  ' + 名.padEnd(9) + 旗.padEnd(24) + '动作[' + 动.join(' ') + '] 法源[' + 源.join(' ') + ']');
}
console.log('');
console.log('  ★ = 该条 judge 带可执行命令（门）');
console.log('');
console.log('⚠️⚠️ **本器是粗筛，不是判决** —— 它按**字面词**匹配，实测会假红（2026-09-26 一天内三次三答案）：');
console.log('   ①「红蓝对抗」靠 src 里的字命中 A08 —— 而 A08 的 txt 是「送 qwen3.8-flash 独立核」**明明有动作**，只是没写那四个字；');
console.log('   ②「预埋针」的正则 /预埋|针/ 命中了 C08 原话里的「**针对**我们的任务」—— 单字匹配的经典假红；');
console.log('   ③ C08 的真身是「新件准入三问」，跟预埋针不是一回事。');
console.log('   ⇒ **词匹配只配粗筛候选；判决必须人读那一条动作的原文**（内核 #71：判不了的绝不猜、假红比不报更坏）。');
