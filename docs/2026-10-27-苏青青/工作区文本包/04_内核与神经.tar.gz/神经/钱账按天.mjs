// 钱账·按天（1007 夜老板令：「论证一下我们这两天花了多少钱？以及比以前少了多少」）
// 读法：zstd -dc（多帧！zlib.zstdDecompressSync 只解第一帧 ⇒ 会误判成空文件，记忆 0muj2k5xf）
// 数据源：引擎自报 usage（assistant/message 与 compaction/summary 的 data.usage）
//  ★ 实测形状：{inputTokens(未命中), cacheReadTokens(命中), outputTokens, totalTokens＝三者之和}
// 价目：★ 官方页现取（2026-10-07 拉 https://api-docs.deepseek.com/zh-cn/quick_start/pricing/ · HTTP 200）
//   deepseek-flash（settings.yaml 当前在用）每百万 token：
//     输入·缓存命中 空闲 ¥0.02 ／ 高峰 ¥0.04
//     输入·未命中   空闲 ¥1    ／ 高峰 ¥2
//     输出          空闲 ¥4    ／ 高峰 ¥8
//   高峰时段＝周一至周五（不含法定节假日）北京时间 9:00-12:00、14:00-18:00；其余（含周末/节假日全天）＝空闲
//   ⇒ 本条按**每条事件自己的时刻**分档算钱（不是整窗一刀切），另给空闲/高峰两列做上下界
// 用法：node _tmp/钱账按天.mjs [--限 N]
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { 每百万 } from './价目.mjs'

const S = (process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh') + '/sessions'
const 限 = (() => { const i = process.argv.indexOf('--限'); return i >= 0 ? Number(process.argv[i + 1]) : 0 })()
const 价 = { 未命中: 每百万.未命中.空闲 / 1e6, 命中: 每百万.命中.空闲 / 1e6, 输出: 每百万.输出.空闲 / 1e6 }  // 1018 收口：从 价目.mjs 取

function 收usage(o, out) {
  if (!o || typeof o !== 'object') return
  if (Array.isArray(o)) { for (const x of o) 收usage(x, out); return }
  if (typeof o.inputTokens === 'number' && typeof o.outputTokens === 'number') {
    out.push({ 未: o.inputTokens, 中: Number(o.cacheReadTokens || 0), 出: o.outputTokens })
    return
  }
  if (typeof o.prompt_tokens === 'number' && typeof o.completion_tokens === 'number') {
    const c = Number(o.prompt_tokens_details?.cached_tokens || 0)
    out.push({ 未: Math.max(0, o.prompt_tokens - c), 中: c, 出: o.completion_tokens })
    return
  }
  for (const v of Object.values(o)) 收usage(v, out)
}
function 找时间(o) {
  for (const k of ['time', 'at', 'timestamp', 'ts']) if (typeof o[k] === 'number' && o[k] > 1e12) return o[k]
  return null
}
function 走目录(d, acc) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, e.name)
    if (e.isDirectory()) 走目录(p, acc)
    else if (/^session.*\.jsonl\.zstd$/.test(e.name)) acc.push(p)
  }
  return acc
}
const 日 = (ms) => new Date(ms + 8 * 3600e3).toISOString().slice(0, 10)
const 时 = (ms) => new Date(ms + 8 * 3600e3).toISOString().slice(11, 16)
// 高峰判据（北京时间 · 周一~周五 9-12/14-18）——注意：法定节假日无法在本地判定，这里按"工作日日历"算，
//   节假日（如国庆 10-01~10-08）会被**高估成高峰** ⇒ 真实账单只会更便宜（保守方向，写在输出里）
function 是高峰(ms) {
  const d = new Date(ms + 8 * 3600e3)
  const 周 = d.getUTCDay(), h = d.getUTCHours()
  return 周 >= 1 && 周 <= 5 && ((h >= 9 && h < 12) || (h >= 14 && h < 18))
}
const 单次钱 = (u, 倍) => (u.未 * 价.未命中 + u.中 * 价.命中 + u.出 * 价.输出) * 倍

let 文件 = 走目录(S, []).sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)
if (限) 文件 = 文件.slice(0, 限)
console.error('  待处理日志 ' + 文件.length + ' 个')

const 新桶 = () => ({ 未命中: 0, 命中: 0, 输出: 0, 步: 0, 高峰步: 0, 钱: 0, 空闲价: 0, 高峰价: 0 })
const 按天 = new Map(), 会话 = new Map(), 总 = 新桶()

for (const f of 文件) {
  let t
  try { t = execFileSync('zstd', ['-dc', f], { maxBuffer: 1 << 30 }).toString() } catch { console.error('  跳过（解压失败）' + f); continue }
  const sid = path.basename(path.dirname(f))
  for (const l of t.split('\n')) {
    if (!l || l.charCodeAt(0) !== 123) continue
    let o; try { o = JSON.parse(l) } catch { continue }
    const us = []; 收usage(o, us)
    if (!us.length) continue
    const ms = 找时间(o)
    if (!ms) continue
    const d = 日(ms), 峰 = 是高峰(ms) ? 1 : 0
    for (const u of us) {
      const 加 = (B) => {
        B.未命中 += u.未; B.命中 += u.中; B.输出 += u.出; B.步++; B.高峰步 += 峰
        B.钱 += 单次钱(u, 峰 ? 2 : 1); B.空闲价 += 单次钱(u, 1); B.高峰价 += 单次钱(u, 2)
      }
      if (!按天.has(d)) 按天.set(d, { ...新桶(), 会话: new Set() })
      const A = 按天.get(d); 加(A); A.会话.add(sid)
      if (!会话.has(sid)) 会话.set(sid, { ...新桶(), 首: ms, 末: ms, 日: new Set() })
      const B = 会话.get(sid); 加(B); B.首 = Math.min(B.首, ms); B.末 = Math.max(B.末, ms); B.日.add(d)
      加(总)
    }
  }
}
const M = (n) => (n / 1e6).toFixed(1)
const W = (n) => (n / 1e4).toFixed(0)

console.log('\n【按天】本地日 ｜ 步数 ｜ 会话 ｜ 未命中(万) ｜ 命中(万) ｜ 输出(万) ｜ ¥按时刻 ｜ ¥全空闲 ｜ ¥全高峰')
for (const d of [...按天.keys()].sort()) {
  const A = 按天.get(d)
  console.log('  ' + d + ' ｜' + String(A.步).padStart(6) + ' ｜' + String(A.会话.size).padStart(4) + ' ｜' +
    W(A.未命中).padStart(9) + ' ｜' + W(A.命中).padStart(9) + ' ｜' + W(A.输出).padStart(7) + ' ｜ ¥' +
    A.钱.toFixed(2).padStart(7) + ' ｜ ¥' + A.空闲价.toFixed(2).padStart(7) + ' ｜ ¥' + A.高峰价.toFixed(2))
}
console.log('\n【合计】步 ' + 总.步 + '（高峰时段 ' + 总.高峰步 + ' 步）｜ 未命中 ' + M(总.未命中) + 'M ｜ 命中 ' + M(总.命中) + 'M ｜ 输出 ' + M(总.输出) + 'M')
console.log('  按时刻 ¥' + 总.钱.toFixed(2) + ' ｜ 全空闲 ¥' + 总.空闲价.toFixed(2) + ' ｜ 全高峰 ¥' + 总.高峰价.toFixed(2) +
  ' ｜ 总 token ' + M(总.未命中 + 总.命中 + 总.输出) + 'M')
fs.writeFileSync('/storage/emulated/0/3/_tmp/钱账按天.json', JSON.stringify({
  生成于: new Date().toISOString(), 文件数: 文件.length, 价目: 'deepseek-flash 官方分档（2026-10-07 现取）', 总,
  按天: Object.fromEntries([...按天].map(([d, A]) => [d, { ...A, 会话: A.会话.size }])),
  会话: Object.fromEntries([...会话].map(([s, B]) => [s, { ...B, 日: [...B.日] }])),
}, null, 1))
console.log('  明细 ⇒ _tmp/钱账按天.json')
