// 神经/锁.mjs —— 跨窗互斥锁 ＋ 原子写（零依赖 · 老板 1007 夜令「先修并发五处裸奔」）
// 
// 为什么有它：缺口⑧ ①「文件没锁」—— 三份给人看的 markdown（在办／待你决／三窗交接）
//   与 `台账/轮末/开工登记.json` 此前只有「乐观锁」（写前记指纹、变了就拒绝覆盖＝事后发现），
//   **没有互斥**（两个窗同时写 ⇒ 后写的把前写的盖掉，只留一句"被改过"）。
//   本件补的正是**事前互斥**：O_EXCL 抢锁 → 干活 → 释放；写文件统一走「临时文件＋rename」原子替换。
// 原语（不许装包 · 0922 P6 调研结论）：fs.openSync(p,'wx') 互斥 ／ rename 原子替换 ／ fsync 落盘。
//
// 用法：
//   import { 带锁, 拿锁, 放锁, 原子写, 锁目录 } from '../内核/锁.mjs'
//   await 带锁('队列-待你决', () => { ... })      // 同步回调也可以
//   原子写(某路径, 内容字符串)
// 命令行： node 神经/锁.mjs 自测    ← 真争锁两态（一成一败）＋ 原子写回读 ＋ 陈旧锁抢占
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const 根 = process.env.DSH_KICKOFF_WS || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
export const 锁目录 = path.join(根, '_锁')

// ═══ ★★ 1013 收口 · 世代号（治「过期占用不得顶掉现役」）══════════════════════════
// 病（1013 现跑复现，脚本 `_backup/1013-4.0收口/世代沙盒/复现-旧.mjs`）：
//   甲持锁 → 甲超时被判"陈旧" → 乙抢走（**这步是对的：新胜旧**）→ **甲干完活放锁**
//   ⇒ 旧代码 `放锁` 是**无条件 unlink** ⇒ 它删掉的是**乙的**锁 ⇒ 第三者也能进 ⇒ 乙、丙同时"持锁"。
//   根因：盘上只写 `{pid, at, 窗, 名}` ＝「谁持有」，**没有"第几代"** ⇒ 分不清"这把锁是不是我那一把"。
// 改法（每一条占位加「代」；清占位时比世代；旧世代不许清新世代）：
//   ① 锁文件加 `代`（每次创建现摇一个）；② 放锁 = **比对后删**（盘上代 ≠ 我的代 ⇒ 拒删）；
//   ③ 抢陈旧 = **比对后删**（只删"我刚判陈旧的那一份"，不许删别人刚建的新锁）。
// 兼容：`放锁(名)` 不带代时，用本进程 `拿锁` 时记下的代（仓库内调用方都是"先拿后放"⇒ 不用改一行）。
const 现役代 = new Map()   // 名 → 本进程最后一次成功拿到的代
const 摇代 = () => Date.now().toString(36) + '-' + process.pid.toString(36) + '-' + Math.random().toString(36).slice(2, 8)

const 睡 = ms => { try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms) } catch { const t = Date.now(); while (Date.now() - t < ms) {} } }
const 安全名 = 名 => String(名).replace(/[^0-9A-Za-z\u4e00-\u9fa5_.-]/g, '_')
const 锁路径 = 名 => path.join(锁目录, 安全名(名) + '.lock')

/** 拿锁：成功 → {ok:true, 名, 抢了陈旧?}；超时 → {ok:false, 名, 因} */
export function 拿锁(名, { 等毫秒 = 3000, 陈旧毫秒 = 30000 } = {}) {
  fs.mkdirSync(锁目录, { recursive: true })
  const p = 锁路径(名), 起 = Date.now()
  let 抢过陈旧 = false
  while (true) {
    // ① 试着独占创建（这就是互斥本体：谁创建成功谁是主）
    try {
      const 代 = 摇代()
      const fd = fs.openSync(p, 'wx')
      fs.writeSync(fd, JSON.stringify({ pid: process.pid, at: Date.now(), 窗: process.env.DSH_SESSION_ID || '', 名, 代 }))
      fs.closeSync(fd)
      // ★ 读回自证：万一同一步里有别人把我刚建的锁清掉/换了，我**不许**自认持锁（否则又是"两段临界区重叠"）
      let 是我的 = false
      try { 是我的 = (JSON.parse(fs.readFileSync(p, 'utf8')).代 === 代) } catch { 是我的 = false }
      if (!是我的) { if (Date.now() - 起 > 等毫秒) return { ok: false, 名, 因: '建锁后被换人（读回比对不符）' }; 睡(80); continue }
      现役代.set(名, 代)
      return { ok: true, 名, 路径: p, 代, 抢了陈旧: 抢过陈旧 }
    } catch (e) {
      if (e.code !== 'EEXIST') return { ok: false, 名, 因: e.code }
    }
    // ② 锁在：看是不是"陈旧锁"（持锁者死了/忘了放 ⇒ 否则会永久卡住）
    let 陈旧 = false, 文0 = null
    try {
      文0 = fs.readFileSync(p, 'utf8')
      const j = JSON.parse(文0)
      if (Date.now() - (j.at || 0) > 陈旧毫秒) 陈旧 = true
      else if (j.pid && !活进程(j.pid)) 陈旧 = true          // 持锁进程已不在 ⇒ 也算陈旧
    } catch { 陈旧 = true; 文0 = null }                        // 读不出来 ⇒ 半截锁，算陈旧
    if (陈旧) {
      // ★★ 1013 收口：**比对后才删** —— 只删"我刚判陈旧的那一份"
      //   （否则：我判旧 → 别人抢陈旧成功建了新锁 → 我这一刀删掉的是**现役的**锁）
      let 还是那一份 = false
      try { 还是那一份 = (fs.readFileSync(p, 'utf8') === 文0) } catch { 还是那一份 = (文0 === null) }
      if (还是那一份) { try { fs.unlinkSync(p) } catch {}; 抢过陈旧 = true }
      continue
    }
    // ③ 还早 ⇒ 等一会儿再来
    if (Date.now() - 起 > 等毫秒) return { ok: false, 名, 因: '等待超时（' + 等毫秒 + 'ms）· 另一窗正持锁' }
    睡(80)
  }
}

function 活进程(pid) { try { process.kill(pid, 0); return true } catch { return false } }

/** 放锁（详版）：**比世代** —— 盘上的代 ≠ 我的代 ⇒ 拒删（旧世代不许清新世代） */
export function 放锁详(名, 代) {
  const p = 锁路径(名)
  const 我的 = 代 || 现役代.get(名)
  let 文 = null
  try { 文 = fs.readFileSync(p, 'utf8') } catch { 现役代.delete(名); return { 删了: false, 因: '锁不在（可能已被回收）', 代: 我的, 盘上代: undefined } }
  let j = null; try { j = JSON.parse(文) } catch {}
  const 盘上 = j && j.代
  if (我的 && 盘上 && 盘上 !== 我的) {
    // ★ 这就是缺口本体被堵住的那一格：过期/已换人的持有者，不许清新持有者的占位
    return { 删了: false, 因: '现役已换人（盘上代 ' + 盘上 + ' ≠ 我的代 ' + 我的 + '）⇒ 旧世代不许清新世代', 代: 我的, 盘上代: 盘上 }
  }
  if (!我的 && 盘上) return { 删了: false, 因: '我没有代（没在本进程拿过这把锁）⇒ 不删别人的锁', 代: undefined, 盘上代: 盘上 }
  if (我的 && !盘上) {
    // 盘上是老格式（无代）：只认"确实是我自己的进程"才删，否则不动
    if (j && j.pid && j.pid !== process.pid) return { 删了: false, 因: '盘上无代且 pid 不是本进程 ⇒ 不删', 代: 我的, 盘上代: undefined }
  }
  try { fs.unlinkSync(p); 现役代.delete(名); return { 删了: true, 因: '代相符', 代: 我的, 盘上代: 盘上 } }
  catch (e) { return { 删了: false, 因: e.code || String(e), 代: 我的, 盘上代: 盘上 } }
}

export function 放锁(名, 代) { return 放锁详(名, 代).删了 }

/** 带锁：拿不到锁**不硬干**，抛出（调用方决定重试还是报红）—— 避免"锁形同虚设" */
export function 带锁(名, fn, 选项 = {}) {
  const r = 拿锁(名, 选项)
  if (!r.ok) throw new Error('⛔ 拿不到锁「' + 名 + '」：' + r.因)
  try { return fn(r) } finally { 放锁(名) }
}

/** 原子写：写临时文件 → fsync → rename 覆盖（读者永远看到"完整的旧版或完整的新版"，看不到半截） */
export function 原子写(文件, 内容) {
  fs.mkdirSync(path.dirname(文件), { recursive: true })
  const tmp = 文件 + '.tmp-' + process.pid
  const fd = fs.openSync(tmp, 'w')
  try { fs.writeSync(fd, 内容); fs.fsyncSync(fd) } finally { fs.closeSync(fd) }
  fs.renameSync(tmp, 文件)
  return 文件
}

/** 带锁 ＋ 原子写的"读-改-写"（队列/登记这类共享件的标准动作） */
export function 带锁改(名, 文件, 变换, 选项 = {}) {
  return 带锁(名, () => {
    let 旧 = null
    try { 旧 = fs.readFileSync(文件, 'utf8') } catch {}
    原子写(文件, 变换(旧))
    return 文件
  }, 选项)
}

// ─────────────────────────── 自测（真跑两态） ───────────────────────────
// ★ 1007 夜（上膛门的阳性对照逮到的真病）：**「是主」要比 realpath** ——
//   经符号链接调用时（例：副本落在 /data/user/0/… 而 import.meta.url 解析成 /data/data/…），
//   用 path.resolve 比字符串会判不相等 ⇒ **自测静默不跑、退 0** ⇒ 假绿。
const 是主 = (() => { try { return !!process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url)) } catch { return false } })()
// ★ 1007 夜：`自检` 与 `自测` **都认** —— 上膛门造副本后调的是 `自检`（原来只认 `自测` ⇒ 副本恒绿、阳性假过）
if (是主 && ['自测', '自检'].includes(process.argv[2])) {
  const 子 = process.argv[3]
  const 账 = path.join(根, '_锁', '自测-争抢.jsonl')
  if (子 === '抢') {          // 子进程角色：抢锁 → 把临界区起止写进同一本账 → 持 800ms
    const 等 = Number(process.argv[4] || 300), 标 = process.argv[5] || 'X'
    const r = 拿锁('测试-争抢', { 等毫秒: 等 })
    if (r.ok) {
      fs.appendFileSync(账, JSON.stringify({ 标, 事件: 'START', t: Date.now(), pid: process.pid }) + '\n')
      睡(800)
      fs.appendFileSync(账, JSON.stringify({ 标, 事件: 'END', t: Date.now() }) + '\n')
      放锁('测试-争抢'); console.log('OK')
    } else console.log('FAIL')
    process.exit(0)
  }
  const { spawn } = await import('node:child_process')
  const 我 = fileURLToPath(import.meta.url)
  // ⚠️ 本机实测（1007 夜）：`process.execPath` 指向 **linker64**（不是 node 本体），
  //    且该前缀里没有 sh ⇒ spawn(process.execPath, …) 会报 "bad ELF magic"（把 .mjs 当可执行文件）。
  //    起子进程必须给**真 node 的绝对路径**：
  const 找node = () => [process.env.DSH_NODE, '/data/data/com.dsharnessmobile.shell/files/usr/bin/node',
    '/data/data/com.termux/files/usr/bin/node', '/usr/local/bin/node', '/usr/bin/node']
    .find(c => c && fs.existsSync(c)) || (process.execPath.endsWith('linker64') ? null : process.execPath)
  const NODE = 找node()
  let 过 = 0, 败 = 0
  const 断言 = (名, 条件, 注 = '') => { if (条件) { 过++; console.log('  ✅ ' + 名 + (注 ? ' · ' + 注 : '')) } else { 败++; console.log('  ❌ ' + 名 + (注 ? ' · ' + 注 : '')) } }

  console.log('【锁 · 自测】工作区 ' + 根)
  const 起 = (等ms, 标) => new Promise(res => {
    const c = spawn(NODE, [我, '自测', '抢', String(等ms), 标])
    let out = ''; c.stdout.on('data', d => out += d)
    c.on('close', () => res(out.trim()))
  })
  if (!NODE) {
    console.log('  ⚠️ 本机找不到真 node ⇒ **跨进程这几条没测**（不许当测过）；同进程互斥见下面那条')
  } else {
    // 真态一：互斥的真判据＝**两段临界区不许重叠**（等的够久本来就该拿到 —— 那叫排队，不叫偷）
    try { fs.unlinkSync(账) } catch {}
    const [c1, c2] = await Promise.all([起(3000, 'A'), 起(3000, 'B')])
    const 行 = fs.readFileSync(账, 'utf8').trim().split('\n').filter(Boolean).map(s => JSON.parse(s))
    const 段 = {}; for (const l of 行) { 段[l.标] = 段[l.标] || {}; 段[l.标][l.事件] = l.t }
    const A = 段.A || {}, B = 段.B || {}
    const 齐 = A.START && A.END && B.START && B.END
    const 重叠 = 齐 && Math.min(A.END, B.END) > Math.max(A.START, B.START)
    断言('互斥（真跑：两进程临界区**不重叠**）', 齐 && !重叠,
      'A 持 ' + (A.END - A.START) + 'ms ／ B 持 ' + (B.END - B.START) + 'ms ／ 重叠=' + 重叠 + '（' + 行.length + ' 条账）')
    断言('排队（等得够久 ⇒ 两个都干成，不丢活）', c1 === 'OK' && c2 === 'OK', JSON.stringify([c1, c2]))
    // 真态二：**不偷锁** —— 只肯等 300ms 的那个撞上持锁 800ms 的 ⇒ 必须如实失败
    try { fs.unlinkSync(账) } catch {}
    const [d1, d2] = await Promise.all([起(1500, 'C'), 起(300, 'D')])
    断言('不偷锁（等不到 ⇒ 如实失败，不硬闯）', [d1, d2].filter(s => s === 'FAIL').length >= 1, JSON.stringify([d1, d2]))
    try { fs.unlinkSync(账) } catch {}
  }
  睡(900)
  // 真态二：锁释放后能拿到
  断言('释放后可再取', 拿锁('测试-争抢', { 等毫秒: 300 }).ok)
  放锁('测试-争抢')
  // 真态三：陈旧锁可被抢（模拟持锁者死了）
  const p = 锁路径('测试-陈旧'); fs.writeFileSync(p, JSON.stringify({ pid: 999999, at: Date.now() - 999999 }))
  const r3 = 拿锁('测试-陈旧', { 等毫秒: 200 })
  断言('陈旧锁自动抢占（持锁者已死）', r3.ok && r3.抢了陈旧 === true)
  放锁('测试-陈旧')
  // 真态四：原子写回读一致 ＋ 不留临时件
  const t = path.join(根, '_锁', '自测-原子写.txt')
  原子写(t, '第一版'); const v1 = fs.readFileSync(t, 'utf8')
  原子写(t, '第二版更长一些的内容'); const v2 = fs.readFileSync(t, 'utf8')
  const 残留 = fs.readdirSync(path.join(根, '_锁')).filter(f => f.includes('.tmp-'))
  断言('原子写（覆盖后回读一致 · 无临时残留）', v1 === '第一版' && v2 === '第二版更长一些的内容' && 残留.length === 0, '残留 ' + 残留.length + ' 个')
  fs.unlinkSync(t)
  // 假态五：拿不到锁时 带锁() 必须抛（不许默默硬干）
  const holder = 拿锁('测试-占用', { 等毫秒: 100 })
  let 抛了 = false
  try { holder.ok && 带锁('测试-占用', () => {}, { 等毫秒: 150 }) } catch { 抛了 = true }
  放锁('测试-占用')
  断言('拿不到锁 ⇒ 抛出（不硬干）', 抛了)
  // ★★ 真态六：**世代号**（1013 收口 · 治「过期占用不得顶掉现役」）—— 四条成对，缺一不算
  {
    const 名 = '测试-世代', p2 = 锁路径(名)
    try { fs.unlinkSync(p2) } catch {}
    const 甲 = 拿锁(名, { 等毫秒: 100 })
    const j6 = JSON.parse(fs.readFileSync(p2, 'utf8')); j6.at = Date.now() - 999999; fs.writeFileSync(p2, JSON.stringify(j6))   // 甲超时 ⇒ 判陈旧
    const 乙 = 拿锁(名, { 等毫秒: 100 })                       // 过期 ⇒ 新世代接管
    断言('新胜旧：陈旧锁能被新世代抢走（代换人 · 盘上代跟着换）',
      甲.ok && 乙.ok && 乙.抢了陈旧 === true && !!乙.代 && 乙.代 !== 甲.代 && JSON.parse(fs.readFileSync(p2, 'utf8')).代 === 乙.代,
      '甲代 ' + 甲.代 + ' → 乙代 ' + 乙.代)
    const 旧放 = 放锁详(名, 甲.代)                              // ★ 缺口本体：旧世代来清占
    断言('旧不许顶新：旧世代的「放锁」不删现役的锁（且盘上代没变）',
      旧放.删了 === false && fs.existsSync(p2) && JSON.parse(fs.readFileSync(p2, 'utf8')).代 === 乙.代, '因：' + 旧放.因)
    const 第三者 = 拿锁(名, { 等毫秒: 200 })
    断言('后果堵住了：现役还持着 ⇒ 第三者拿不到（两段临界区不会重叠）', 第三者.ok === false, '因：' + (第三者.因 || ''))
    断言('现役自己放 ⇒ 删掉（正常路没被堵）', 放锁详(名, 乙.代).删了 === true && !fs.existsSync(p2))
    try { fs.unlinkSync(p2) } catch {}
  }
  console.log(败 === 0 ? '\n✅ 全过（' + 过 + '/' + (过 + 败) + '）' : '\n❌ 有失败（过 ' + 过 + ' · 败 ' + 败 + '）')
  process.exit(败 === 0 ? 0 : 1)
}
