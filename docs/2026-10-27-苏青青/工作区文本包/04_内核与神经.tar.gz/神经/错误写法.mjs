#!/usr/bin/env node
// 错误写法体检（1009 立 · G7 的「体检项」那一半）
//
// 为什么有它：外部独立核（千问 3.8）判 —— G7「错误信息写法」**不该独立成件**，它的正确位置是
//   「G3 输出契约 ＋ G6 失败分级 ＋ **脚本模板** ＋ **体检项** 的文本基础」。
//   真源：`台账/接续/错误输出规约_1009.md`（七字段：code / summary / hint / retryable / dangerous / truncated / evidence）
// 判据（他的原话）：重点是「**模型能读懂下一步该干什么**」，**不是**让脚本变成完美 API。
//   ⇒ 所以本件**只算覆盖率、只列裸错误**，**不判"必须全改"**，也**不许拿覆盖率当 KPI**。
//
// 【四模块耦合】
//   法（判据住哪）：本文件。七字段的定义只许从规约那份抄，不许在别处重写。
//   记忆（何时用它）：新写仪器前照一下；想知道"我们现在有多少件会说人话的错误"时跑它。
//   神经（怎么响、挂哪）：**已接** —— 落盘 `台账/接续/错误写法体检.json`，
//     由 `工具/开工/库.mjs`【自检】区每窗开工读一行（照「工具名体检」那段的成熟形状）。
//   动作（没做到怎么办）：覆盖率低 ⇒ **别一次改几百件**（会造一堆改动），先给**新件**用模板。
//
// 用法：node 神经/错误写法.mjs [--前 N] [--列] [--不落]
// 退出码：0 = 跑完（**覆盖率低不是错**）｜ 2 = 扫不到件（没东西可查，不算通过）
import fs from 'node:fs'
import path from 'node:path'

const W = process.env.DSH_KICKOFF_WS || '/storage/emulated/0/3'   // 沙盒改道（红线 19④）
const 根 = path.join(W, '工具')
const i前 = process.argv.indexOf('--前')
const 前 = i前 > 0 ? (process.argv[i前 + 1] || '12') : '12'
const 要列 = process.argv.includes('--列')
const 不落 = process.argv.includes('--不落')

// ── 收集（跳过备份／实验场／插件源码／node_modules）────────────────────────
// ★ 第一版把 602 件全算进来（含 `_tmp` 实验场与 `件/` 里的插件源码）⇒ 前 8 条全是打包产物。
//   仪器 ＝ 我们自己写的工具；实验场与插件源码不算。
const 件 = []
let 内核件 = 0
const 走 = (d, 是内核) => {
  let es
  try { es = fs.readdirSync(d, { withFileTypes: true }) } catch { return }
  for (const e of es) {
    const p = path.join(d, e.name)
    if (e.isDirectory()) {
      if (e.name === '_backup' || e.name === 'node_modules' || e.name === '.git') continue
      if (e.name === '_tmp' || e.name === '件') continue
      走(p, 是内核 || e.name === '内核')
    } else if (e.name.endsWith('.mjs') || e.name.endsWith('.cjs') || e.name.endsWith('.js')) {
      件.push(p)
      if (是内核) 内核件++
    }
  }
}
走(根, false)
if (!件.length) { console.log('⚠️ 扫不到任何脚本（' + 根 + '）—— **这不是通过，是没东西可查。**'); process.exit(2) }

// ── 判 ────────────────────────────────────────────────────────────────────
// 口径：按**字段名出现**（宽口径，会多算 —— 诚实写在输出里），另单列"含 hint（下一步）"这一项，
//   因为它才是外部核说的重点（模型能不能读懂下一步）。
const 字段 = ['code', 'summary', 'hint', 'retryable', 'dangerous', 'truncated', 'evidence']
const 统计 = Object.fromEntries(字段.map((f) => [f, 0]))
const 裸 = []      // 印了错误、但**一个字都不说下一步**
let 有错误输出 = 0
for (const p of 件) {
  let s
  try { s = fs.readFileSync(p, 'utf8') } catch { continue }
  const 印错 = /console\.error\(|❌|⛔/.test(s)
  if (印错) 有错误输出++
  for (const f of 字段) if (new RegExp('\\b' + f + '\\b').test(s)) 统计[f]++
  if (印错 && !/\bhint\b/.test(s)) 裸.push(path.relative(W, p))
}

// ── 落盘（给 库.mjs【自检】读；沙盒改道认 DSH_KICKOFF_WS）──────────────────
if (!不落) {
  try {
    const 现在 = new Date()
    const pp = (x) => String(x).padStart(2, '0')
    const 体 = {
      at: 现在.toISOString().slice(0, 16).replace('T', ' '),
      at本机: 现在.getFullYear() + '-' + pp(现在.getMonth() + 1) + '-' + pp(现在.getDate()) + ' ' +
        pp(现在.getHours()) + ':' + pp(现在.getMinutes()) + ':' + pp(现在.getSeconds()),
      口径: '扫 工具/ 全树（跳过 _backup/_tmp/件/node_modules）；字段按名字出现＝宽口径会多算；只算覆盖率、不判必须全改',
      总数: 件.length,
      内核件,
      有错误输出,
      字段: 统计,
      说下一步: 统计.hint,
      裸错误数: 裸.length,
      裸错误前10: 裸.slice(0, 10),
    }
    const 文 = JSON.stringify(体, null, 1)
    JSON.parse(文)   // 写完必须验一次（我们真踩过：手拼 JSON 里的直引号把文件写坏）
    const 落点 = path.join(W, '台账/接续/错误写法体检.json')
    fs.mkdirSync(path.dirname(落点), { recursive: true })
    fs.writeFileSync(落点, 文)
  } catch (e) {
    console.log('（落盘失败，不影响本次结论：' + e.message + '）')
  }
}

console.log('\n📝 错误写法体检（G7 的体检项）· ' + 件.length + ' 件脚本（其中 `神经/` ' + 内核件 + ' 件）')
console.log('   ⚠️ 口径：扫的是 **`工具/` 全树**（含 cdp／沙盒／音乐插件等实验与工具目录）；')
console.log('      字段**按名字出现**算 ⇒ **宽口径、会多算**（要看真输出还得读那件）。')
console.log('')
for (const f of 字段) console.log('   · ' + f.padEnd(11) + 统计[f] + ' 件')
console.log('')
console.log('   ★ **会说"下一步"的（含 hint）**：' + 统计.hint + ' / ' + 件.length + ' 件')
console.log('   ▲ 印了错误、**却不说下一步**的：' + 裸.length + ' / ' + 有错误输出 + ' 件（有错误输出的）')
if (要列 || 裸.length) {
  const n = Math.max(0, Number(前) || 0)
  console.log('')
  console.log('   ── 裸错误（前 ' + n + ' 条；**不是"必须全改"**，是"下一件别这么写"）──')
  for (const p of 裸.slice(0, n)) console.log('     · ' + p)
  if (裸.length > n) console.log('     … 还有 ' + (裸.length - n) + ' 条（--前 N 看更多）')
}
console.log('')
console.log('   ⇒ 用法（外部核口径）：**重点是模型能读懂下一步**，不是让脚本变成完美 API。')
console.log('      ① 新写仪器 ⇒ 错误里至少给 `summary`（发生了什么）＋ `hint`（下一步干什么）；')
console.log('      ② 破坏性动作 ⇒ 加 `dangerous`；输出可能被截 ⇒ 加 `truncated`；')
console.log('      ③ **不许一次改 ' + 件.length + ' 件** —— 那是拿覆盖率当 KPI。')
console.log('')
process.exit(0)
