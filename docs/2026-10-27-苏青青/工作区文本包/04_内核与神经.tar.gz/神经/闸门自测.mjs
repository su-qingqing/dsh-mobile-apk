/**
 * 开工闸门 自测（v1 回归 + v2 开工检索）—— 假 ctx 挂**真 apply**，不碰生产。
 * 用法：node 神经/闸门自测.mjs
 */
const GATE = process.env.GATE_PATH || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh/profiles/web/node_modules/@dsh-user/dsh-kickoff-gate/lib/index.js'
const MEMDB = '/storage/emulated/0/3/.dsh-meow/memory.db'
// ★ 2026-09-22 复跑抓到：固定 testws ⇒ 两个窗同时跑就抢同一个 `收手.db` ⇒ `database is locked`。
//   按 C11（同一问题第三次改根）：**测试工作区按 pid 独立**，谁也不碰谁。
const WS = '/storage/emulated/0/3/.dsh-kickoff/testws-' + process.pid
const SID = 'TEST-SID-0001'
const P = '/storage/emulated/0/3/桌宠项目/闸门.js'
const EXEMPT = '/storage/emulated/0/3/台账/在办.md'

import { mkdirSync, writeFileSync, rmSync, readFileSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
const LOG = '/data/data/com.dsharnessmobile.shell/files/home/.dsh/kickoff-gate.log'
import { DatabaseSync } from 'node:sqlite'

const { apply } = await import(GATE)

let pass = 0, fail = 0
const ok = (n, c, extra) => { if (c) { pass++; console.log('  ✅ ' + n) } else { fail++; console.log('  ❌ ' + n + (extra ? '  → ' + extra : '')) } }
const allow = async () => ({ kind: 'allow' })
const accept = async () => ({ kind: 'accept' })

function mk(cfg) {
  const L = {}
  const ctx = {
    get: () => undefined,
    on: (n, f) => { (L[n] = L[n] || []).push(f); return () => {} },
    effect: (f) => { f(); return () => {} },
    logger: { warn: () => {}, info: () => {} },
  }
  apply(ctx, Object.assign({ workspace: WS, memoryDb: MEMDB, lessonCacheMs: 0, hitLedger: WS + '/hits.json' }, cfg || {}))
  return L
}
const pre = (L, name, args, sid) => L['tools/pre-execute'][0]({ name, arguments: args, agent: { id: sid || SID } }, allow)
const post = (L, name, args, result, sid) => L['tools/post-execute'][0](
  { name, arguments: args, agent: { id: sid || SID } }, result, accept)
const say = (L, text, sid) => L['agent/pre-step'][0](
  { agent: { id: sid || SID }, messages: [{ role: 'user', content: [{ type: 'text', text }] }] }, allow)

console.log('\n=== A 组：v1 回归（行为必须与固化版逐项一致）===')
{
  const L = mk()
  const r1 = await pre(L, 'write', { file_path: P })
  ok('A1 无卡 write 实现文件 → deny', r1.kind === 'deny', JSON.stringify(r1).slice(0, 80))
  ok('A2 理由里带【开工闸门】+ sessionId', String(r1.reason).includes('【开工闸门】') && String(r1.reason).includes(SID))
  const r2 = await pre(L, 'write', { file_path: EXEMPT })
  ok('A3 豁免目录（台账）→ 放行', r2.kind === 'allow')
  const r3 = await pre(L, 'edit', { file_path: '/storage/emulated/0/3/工具/x.mjs' })
  ok('A4 无卡 edit → deny', r3.kind === 'deny')
  const r4 = await pre(L, 'bash', { command: 'echo hi > /storage/emulated/0/3/桌宠项目/b.js' })
  ok('A5 无卡 bash 写文件 → deny', r4.kind === 'deny')
  const r5 = await pre(L, 'bash', { command: 'ls -la /storage/emulated/0/3' })
  ok('A6 bash 只读 → 放行', r5.kind === 'allow')
  const r6 = await pre(L, 'bash', { command: "cat > /storage/emulated/0/3/台账/x.md <<'EOF'" })
  ok('A7 bash 写豁免目录 → 放行', r6.kind === 'allow')
  const r7 = await pre(L, 'read', { file_path: P })
  ok('A8 read 工具 → 放行', r7.kind === 'allow')
}
{
  mkdirSync(WS + '/.dsh-kickoff', { recursive: true })
  // 0927 补：B3（09-26 老板令「尺子主动去用也要埋」，dsh-kickoff-gate:1144-1153）会让「卡里没写【尺子】」的会话回 accept 提醒
  //   ⇒ 本用例原本的意图是「有卡 + 没写过这个目标 ⇒ 放行」，所以卡里补上【尺子】行，把 B3 让开；B3 自己的行为另立 A9c 断言。
  writeFileSync(WS + '/.dsh-kickoff/card-' + SID + '.md', '# 测试卡\n【尺子】闭环六格尺（神经/闭环.mjs）\n')
  const L = mk()
  const NEWP = P + '.a9-' + process.pid
  // ★ 1001 新增（老板令 A+C「取做成个动作」）：**有卡、但本会话自最近一次压缩以来没取过长期记忆** ⇒ 先拦一次
  //   ⚠️ 用**另一个路径**：被拦的那次写也会占 CStore 认领 ⇒ 用同一路径会把下面的 A9 撞成「已经写过」（1001 实撞）
  const rm = await pre(L, 'write', { file_path: NEWP + '-m' })
  ok('A9m 有卡但没取过长期记忆 → 拦一次（理由里给"怎么取"）', rm.kind === 'deny' && /取＝动作/.test(String(rm.reason)), JSON.stringify(rm).slice(0, 110))
  // 取一次（走**真事件路**：session/event 的 tool/call，不直接改内部状态）⇒ 闸门开
  L['session/event'][0]({ id: SID }, { type: 'tool/call', data: { name: 'memory_search' } })
  const r = await pre(L, 'write', { file_path: NEWP })
  ok('A9 有卡 + 本会话没写过这个目标 → 放行（严格判据，误拦会被抓住）', r.kind === 'allow', JSON.stringify(r))
  const r2 = await pre(L, 'write', { file_path: NEWP })
  ok('A9b 同会话重复写同一目标 → 认领提醒', r2.kind === 'accept' && /已经写过/.test(r2.content || ''), JSON.stringify(r2))
  // ★ 1001 新增 A9n：**压缩一发生 ⇒ 旗子归零 ⇒ 必须重新取**（治"压缩把长期记忆吃掉、模型还不知道去取"）
  L['session/event'][0]({ id: SID }, { type: 'compaction/end' })
  const rn = await pre(L, 'write', { file_path: P + '.a9n-' + process.pid })
  ok('A9n 压缩之后 → 同一周期内要重新取（拦一次）', rn.kind === 'deny' && /取＝动作/.test(String(rn.reason)), JSON.stringify(rn).slice(0, 110))
  // 再取一次 ⇒ 恢复放行（证明闸门不是死的）
  L['session/event'][0]({ id: SID }, { type: 'tool/call', data: { name: 'memory_project' } })
  const rn2 = await pre(L, 'write', { file_path: P + '.a9n2-' + process.pid })
  ok('A9o 再取一次 → 恢复放行（闸门不是死的）', rn2.kind === 'allow', JSON.stringify(rn2).slice(0, 110))
  // ⚠️ 这里**故意不测** B3「卡里没写【尺子】⇒ 提醒」：实测把卡文件改短后本会话仍是 allow（{"kind":"allow"}）
  //   ⇒ 插件读卡是**会话首（或首个工具调用）缓存**，中途改卡不影响本会话 ⇒ 要测 B3 必须换一个新会话（SID）另开一段。
  //   09-27 我写过一个用同一会话换卡的 A9c，自测里当场红（allow）—— 那是我造的坏用例，不是插件坏，已删。
  rmSync(WS + '/.dsh-kickoff/card-' + SID + '.md')
}
{
  const L = mk({ enforce: false })
  const r = await pre(L, 'write', { file_path: P })
  ok('A10 enforce:false → 只观察（放行）', r.kind === 'allow')
}

console.log('\n=== B 组：v2 开工检索 ===')
let blockText = ''
{
  const L = mk()
  await say(L, '我们要把开工闸门的记忆检索做出来，内核不能再重复踩坑了，要按流程干活')
  const r = await post(L, 'write', { file_path: P, content: '// 开工闸门 记忆检索 踩坑' }, { isError: false, content: [{ type: 'text', text: '原始工具结果' }] })
  const blocks = (r && r.content) || []
  ok('B1 结果里多出 1 块', blocks.length === 2, 'got ' + blocks.length)
  ok('B2 含【开工闸门·记忆检索】', blocks.length > 1 && String(blocks[1].text).includes('【开工闸门·记忆检索】'))
  ok('B3 原始结果原样保留', blocks[0] && blocks[0].text === '原始工具结果')
  ok('B4 kind 仍是 accept', r.kind === 'accept')
  blockText = blocks.length > 1 ? String(blocks[1].text) : ''

  const ids = [...blockText.matchAll(/`([0-9a-z]{9})`/g)].map((m) => m[1])
  ok('B5 至少给出 1 条带 id 的坑', ids.length >= 1, 'ids=' + ids.join(','))
  if (ids.length) {
    const db = new DatabaseSync(MEMDB, { readOnly: true })
    const bad = ids.filter((id) => !db.prepare("select 1 from lesson where id like ? and status='active'").get(id + '%'))
    db.close()
    ok('B6 这些 id 在库里真实存在且 active（没编）', bad.length === 0, '假的: ' + bad.join(','))
  } else { ok('B6 这些 id 在库里真实存在且 active（没编）', false, '无 id') }

  const r2 = await post(L, 'write', { file_path: P, content: '// 开工闸门 记忆检索 踩坑' }, { isError: false, content: [{ type: 'text', text: '原始工具结果' }] })
  const b2 = (r2 && r2.content) || []
  const dup = ids.filter((id) => b2.length > 1 && String(b2[1].text).includes(id))
  ok('B7 同一个 id 不重复出现（去重生效）', dup.length === 0, '重复: ' + dup.join(','))
}
{
  const L = mk()
  const r = await post(L, 'write', { file_path: P, content: 'x' }, { isError: true, content: [{ type: 'text', text: 'EACCES 报错' }] })
  ok('B8 失败结果(isError) → 原样返回，绝不被改写', r && r.kind === 'accept' && r.content === undefined, JSON.stringify(r))
}
{
  const L = mk()
  let called = false
  const r = await L['tools/post-execute'][0]({ name: 'write', arguments: { file_path: P }, agent: { id: SID } },
    { isError: false, content: [{ type: 'text', text: 'x' }] },
    async () => { called = true; return { kind: 'block', feedback: [{ type: 'text', text: '别人要拦' }] } })
  ok('B9 下游已 block → 不插手（尊重别人的决策）', called && r.kind === 'block' && r.content === undefined, JSON.stringify(r))
}
{
  const L = mk()
  await say(L, '开工闸门的记忆检索')
  const r = await post(L, 'bash', { command: 'ls -la /storage/emulated/0/3' }, { isError: false, content: [{ type: 'text', text: 'x' }] })
  ok('B10 bash 只读 → 不触发检索（不加噪音）', r.content === undefined)
  const r2 = await post(L, 'write', { file_path: EXEMPT, content: '台账' }, { isError: false, content: [{ type: 'text', text: 'x' }] })
  // ★ v2.5 口径已变（交付测试 bug#3）：豁免写入原来断言「不触发检索」，现在**改成就该触发**。
  //   拦截那一半在此守住；「查不查」那一半由 G2 用独立 sid 断言（避免本组 sid 的已展示去重干扰）。
  ok('B11 【v2.5 口径已变】豁免目录写入：拦截不变（放行）', r2.kind === 'accept')
}
{
  const L = mk({ memoryDb: '/nonexistent/不存在.db' })
  await say(L, '开工闸门 记忆检索 踩坑')
  const r = await post(L, 'write', { file_path: P, content: 'abc' }, { isError: false, content: [{ type: 'text', text: 'x' }] })
  /* ★ 2026-09-18 口径变更（治 bug#11）：旧口径是「记忆库打不开 ⇒ 原样返回」——
     那等于**一个字都不说**，检索静默失效、没有任何信号（他自己就是被这种无声失败咬过）。
     新口径：**照样不拦不抛**（fail-open 不变），但必须**显式告知这一轮没查**，且同一会话只报一次。
     —— 改的是口径不是断言强度：B12 仍然要求「不拦」，只是加上了「不许沉默」。 */
  ok('B12 记忆库打不开 → 不拦不抛，且显式告知「这一轮没查」',
    r && r.kind === 'accept' && Array.isArray(r.content) && r.content.some((b) => /没查|记忆库打不开/.test(String((b && b.text) || ''))),
    JSON.stringify(r))
  const r2 = await post(L, 'write', { file_path: P, content: 'abc' }, { isError: false, content: [{ type: 'text', text: 'x' }] })
  ok('B12b 同一会话第二次不再重复刷（只报一次）', r2 && r2.kind === 'accept' && r2.content === undefined, JSON.stringify(r2))
}

console.log('\n=== C 组：v2.1 修正（bash 误判 + 检索留痕）===')
{
  const CS = 'TEST-SID-C'
  const L = mk()
  await say(L, '开工闸门 记忆检索 去重 踩坑 验证', CS)
  const r1 = await post(L, 'bash',
    { command: 'node -e "console.log(a>=b ? 1 : 0)" && echo "x => y" && printf "%s" "a -> b"' },
    { isError: false, content: [{ type: 'text', text: 'x' }] }, CS)
  ok('C1 含 >= / => / -> 的**只读**命令 → 不再误判为写入（不附检索）', r1.content === undefined,
    'content=' + JSON.stringify(!!(r1.content && r1.content.length)))
  const r2 = await post(L, 'bash', { command: 'echo hi > /storage/emulated/0/3/_t.js' },
    { isError: false, content: [{ type: 'text', text: 'x' }] }, CS)
  ok('C2 真重定向**仍然**算写入（回归：照旧附检索）', Array.isArray(r2.content) && r2.content.length === 2,
    'content=' + JSON.stringify(!!(r2.content && r2.content.length)))
}
{
  const log = readFileSync(LOG, 'utf8')
  ok('C3 日志留痕含 ISO 时间戳 + shown= 的 id 列表',
    /RETRIEVE \d{4}-\d{2}-\d{2}T/.test(log) && /shown=/.test(log))
  const m = log.match(/RETRIEVE [^\n]*shown=([^\s]+)/)
  ok('C4 留痕真的记下了具体 id（不是 none）', !!m && m[1] !== '(none)' && m[1].length > 5, m ? m[1] : '无')
}

console.log('\n=== D 组：v2.2 收口（两个口子 + 不误伤）===')
{
  const L = mk()
  const d1 = await pre(L, 'bash', { command: 'echo x > /storage/emulated/0/3/桌宠项目/b.js  # 参考 台账' })
  ok('D1 【口子①直接证据】命令里提到"台账"，但目标是实现目录 → deny', d1.kind === 'deny', JSON.stringify(d1).slice(0, 90))
  const d2 = await pre(L, 'bash', { command: "cat > /storage/emulated/0/3/工具/记忆/x.mjs <<'EOF'\nconst a = 1\nEOF" })
  ok('D2 目标真在豁免目录（工具/记忆/）→ 放行（这是对的，不是漏洞）', d2.kind === 'allow', JSON.stringify(d2).slice(0, 90))
  const d3 = await pre(L, 'bash', { command: 'echo x > /storage/emulated/0/3/工具/装机闸门/x.mjs' })
  ok('D3 目标是普通工具目录 → deny', d3.kind === 'deny')
  const d4 = await pre(L, 'bash', { command: 'rm -rf /storage/emulated/0/3/桌宠项目' })
  ok('D4 【口子②直接证据】rm -rf 实现目录 → deny（改前根本不进闸门）', d4.kind === 'deny', JSON.stringify(d4).slice(0, 90))
  const d5 = await pre(L, 'bash', { command: 'mv /storage/emulated/0/3/台账/a.md /storage/emulated/0/3/台账/b.md' })
  ok('D5 豁免目录内部 mv → 放行', d5.kind === 'allow')
  const d6 = await pre(L, 'bash', { command: 'cp /storage/emulated/0/3/a.md /storage/emulated/0/3/桌宠项目/b.md' })
  ok('D6 cp 到实现目录 → deny', d6.kind === 'deny')
  const d7 = await pre(L, 'bash', { command: 'settings put global overlay_display_devices 1920x1200/280' })
  ok('D7 系统写（settings put）→ deny', d7.kind === 'deny')
  const d8 = await pre(L, 'bash', { command: 'chmod 777 /storage/emulated/0/3/桌宠项目' })
  ok('D8 chmod 实现目录 → deny', d8.kind === 'deny')
  const d9 = await pre(L, 'bash', { command: "cd /storage/emulated/0/3 && node - <<'EOF'\nconst a = 1 > 0 ? 'y' : 'n'\nconsole.log(a, 2 >= 1)\nEOF" })
  ok('D9 heredoc 正文里的 > / >= 不算重定向 → 放行（不误伤我的分析脚本）', d9.kind === 'allow', JSON.stringify(d9).slice(0, 90))
  const d10 = await pre(L, 'bash', { command: 'grep -n x /storage/emulated/0/3/内核/内核.md | head -5' })
  ok('D10 只读管道 → 放行', d10.kind === 'allow')
  const d11 = await pre(L, 'bash', { command: 'curl -s http://127.0.0.1:3080/api/x | node -e "let s=0; s+=1"' })
  ok('D11 引号里的 ; 与 += 不误判 → 放行', d11.kind === 'allow', JSON.stringify(d11).slice(0, 90))
  const d12 = await pre(L, 'bash', { command: 'rm -rf /storage/emulated/0/3/_backup/old' })
  ok('D12 豁免目录内 rm → 放行（记账/备份目录免检）', d12.kind === 'allow')
  const d13 = await pre(L, 'bash', { command: 'echo hi 2>/dev/null >/dev/null' })
  ok('D13 只有 /dev/null → 放行', d13.kind === 'allow')
  const d14 = await pre(L, 'bash', { command: "printf '%s\\n' 'a' > '/storage/emulated/0/3/台账/在办.md'" })
  ok('D14 带引号的豁免目标 → 放行', d14.kind === 'allow')
  const d15 = await pre(L, 'bash', { command: 'VAR=1 echo x > /storage/emulated/0/3/桌宠项目/c.js' })
  ok('D15 VAR=val 前缀不干扰 → deny', d15.kind === 'deny')
}

console.log('\n=== E 组：v2.3 免检改按路径段（严一档）===')
{
  const L = mk()
  const deny = async (c) => (await pre(L, 'bash', { command: c })).kind === 'deny'
  const pass = async (c) => (await pre(L, 'bash', { command: c })).kind === 'allow'
  ok('E1 【变严】…/内核备份/code.js → deny（旧的子串命中"内核"漏洞）',
     await deny('echo x > /storage/emulated/0/3/内核备份/code.js'))
  ok('E2 【变严】…/记忆碎片/x.js → deny', await deny('echo x > /storage/emulated/0/3/记忆碎片/x.js'))
  ok('E3 【变严】…/_backup_new/x → deny', await deny('echo x > /storage/emulated/0/3/_backup_new/x'))
  ok('E4 【不回归】台账/在办.md → 放行', await pass('echo x > /storage/emulated/0/3/台账/在办.md'))
  ok('E5 【不回归】工具/记忆/x.mjs → 放行', await pass('echo x > /storage/emulated/0/3/工具/记忆/x.mjs'))
  ok('E6 【不回归】神经/x.mjs → 放行', await pass('echo x > /storage/emulated/0/3/神经/x.mjs'))
  ok('E7 【不回归】.dsh-kickoff/card-x.md → 放行', await pass('echo x > /storage/emulated/0/3/.dsh-kickoff/card-x.md'))
  ok('E8 【不回归】_backup/x → 放行', await pass('echo x > /storage/emulated/0/3/_backup/x'))
  ok('E9 【文件级豁免保留】台账.md → 放行', await pass('echo x > /storage/emulated/0/3/台账.md'))
  ok('E10 【不回归】相对路径 台账/x.md → 放行', await pass('echo x > 台账/x.md'))
  ok('E11 write 工具写 内核备份/x.js → deny',
     (await pre(L, 'write', { file_path: '/storage/emulated/0/3/内核备份/x.js' })).kind === 'deny')
  ok('E12 write 工具写 台账/在办.md → 放行',
     (await pre(L, 'write', { file_path: '/storage/emulated/0/3/台账/在办.md' })).kind === 'allow')
  ok('E13 真漏洞组合：rm -rf 内核备份 → deny', await deny('rm -rf /storage/emulated/0/3/内核备份'))
}

console.log('\n=== F 组：v2.4 fd 前缀重定向不再被当成写入目标（交付测试 bug#1）===')
{
  const L = mk()
  const deny = async (c) => (await pre(L, 'bash', { command: c })).kind === 'deny'
  const pass = async (c) => (await pre(L, 'bash', { command: c })).kind === 'allow'
  ok('F1  rm 豁免 + 2>/dev/null → 放行', await pass('rm -f 台账/x.md 2>/dev/null'))
  ok('F2  cp → 豁免 + 2>/dev/null → 放行', await pass('cp a.md 台账/b.md 2>/dev/null'))
  ok('F3  mv 豁免 + 2>/dev/null → 放行', await pass('mv 台账/a.md 台账/b.md 2>/dev/null'))
  ok('F4  touch 豁免 + 2>/dev/null → 放行', await pass('touch 台账/x.md 2>/dev/null'))
  ok('F5  mkdir 豁免 + 2>/dev/null → 放行', await pass('mkdir -p 台账/_d 2>/dev/null'))
  ok('F6  rmdir 豁免 + 2>/dev/null → 放行', await pass('rmdir 台账/_d 2>/dev/null'))
  ok('F7  chmod 豁免 + 2>/dev/null → 放行', await pass('chmod 644 台账/a.md 2>/dev/null'))
  ok('F8  ln 豁免 + 2>/dev/null → 放行', await pass('ln -s 台账/a.md 台账/b.lnk 2>/dev/null'))
  ok('F9  truncate 豁免 + 2>/dev/null → 放行', await pass('truncate -s 0 台账/x.md 2>/dev/null'))
  ok('F10 tee 豁免 + 2>/dev/null → 放行', await pass('echo x | tee 台账/x.md 2>/dev/null'))
  ok('F11 sed -i 豁免 + 2>/dev/null → 放行', await pass("sed -i 's/a/b/' 台账/x.md 2>/dev/null"))
  ok('F12 install → 豁免 + 2>/dev/null → 放行', await pass('install a.md 台账/b.md 2>/dev/null'))
  ok('F13 &>/dev/null 变体 → 放行', await pass('rm -f 台账/x.md &>/dev/null'))
  ok('F14 2>&1 变体 → 放行', await pass('rm -f 台账/x.md 2>&1'))
  ok('F15 【对照·绝不能修漏】rm 非豁免 + 2>/dev/null → 仍 deny', await deny('rm -f 桌宠项目/x.js 2>/dev/null'))
  ok('F16 【对照·绝不能修漏】rm 非豁免（无重定向）→ 仍 deny', await deny('rm -f 桌宠项目/x.js'))
  ok('F17 【不回归】D13 那条只读命令仍放行', await pass('echo hi 2>/dev/null >/dev/null'))
  ok('F18 【回归·生产原样】rm 多个豁免目标 + 2>/dev/null → 放行',
     await pass('rm -f 神经/_ui_probe.mjs 神经/_p2.mjs 2>/dev/null; echo ok; ls 神经/'))
}

console.log('\n=== G 组：v2.5 免检只管「拦不拦」，不再管「查不查」（交付测试 bug#3）===')
{
  const SIDG = 'TEST-SID-G-0918'
  const L = mk()
  await say(L, '我们要把开工闸门的记忆检索做出来，内核不能再重复踩坑了，要按流程干活', SIDG)
  const CMD = 'cat > /storage/emulated/0/3/台账/g.md <<EOF'
  const RAW = () => ({ isError: false, content: [{ type: "text", text: "原始工具结果" }] })
  ok('G1 拦截行为一字未动：豁免写入仍放行',
     (await pre(L, 'bash', { command: CMD }, SIDG)).kind === 'allow')
  const r2 = await post(L, 'bash', { command: CMD }, RAW(), SIDG)
  const bk = (r2 && r2.content) || []
  ok('G2 豁免写入现在也附【开工闸门·记忆检索】',
     bk.length === 2 && String(bk[1] && bk[1].text).indexOf('【开工闸门·记忆检索】') >= 0, 'blocks=' + bk.length)
  const r3 = await post(L, 'bash', { command: 'ls -la /storage/emulated/0/3' }, RAW(), SIDG)
  ok('G3 只读命令 → 不附块（不空烧）', ((r3 && r3.content) || []).length === 0)
  const r4 = await post(L, 'write', { file_path: P, content: '// 开工闸门 记忆检索 踩坑' }, RAW(), SIDG + '-b')
  ok('G4 非豁免写入 → 行为不变（仍附块）', ((r4 && r4.content) || []).length === 2)
  const r5 = await post(L, 'bash', { command: CMD },
    { isError: true, content: [{ type: 'text', text: '报错' }] }, SIDG + '-c')
  ok('G5 isError 结果 → 不附块（不把报错洗成成功）', ((r5 && r5.content) || []).length === 0)
}

console.log('\n=== F2 组：v2.6 裸 >> 追加写入（v2.4 只修了 fd 前缀，疑似漏了这一类）===')
{
  const L = mk()
  const S2 = 'TEST-SID-F2'
  const deny = async (c) => (await pre(L, 'bash', { command: c }, S2)).kind === 'deny'
  const pass = async (c) => (await pre(L, 'bash', { command: c }, S2)).kind === 'allow'
  ok('F19 台账 >> 追加 → 放行（豁免）', await pass('echo hi >> /storage/emulated/0/3/台账/x.md'))
  ok('F20 台账 >> 追加（带命令替换）→ 放行', await pass('echo "probe $(date +%s)" >> /storage/emulated/0/3/台账/x.md'))
  ok('F21 内核 >> heredoc → 放行', await pass('cat >> /storage/emulated/0/3/内核/内核.md <<EOF'))
  ok('F22 【对照·不能修漏】非豁免 >> 追加 → 仍 deny', await deny('echo hi >> /storage/emulated/0/3/桌宠项目/x.js'))
}

console.log('\n=== F3 组：命令替换里的 `2>/dev/null)` 不许被当成写入目标（1001 实测误伤）===')
{
  // 案发：2026-10-01 23:53 一条**纯只读**探针被判成写（日志原文
  //   `MEM-GATE deny bash [bash:/dev/null) /dev/null)"] 未取 N=1`）。
  // 病根：tokenize 把 `$(grep … 2>/dev/null)` 里的重定向目标取成 `/dev/null)`（**带一个右括号**）
  //   ⇒ v2.4 那句精确比较 `p !== '/dev/null'` 落空 ⇒ 被当"非豁免路径" ⇒ 判成实现类写入。
  const L = mk()
  const S3 = 'TEST-SID-F3'
  const deny = async (c) => (await pre(L, 'bash', { command: c }, S3)).kind === 'deny'
  const pass = async (c) => (await pre(L, 'bash', { command: c }, S3)).kind === 'allow'
  ok('F23 【案发原样】只读探针：循环里 $(grep … 2>/dev/null) → 放行',
     await pass('for f in /a /b; do n=$(grep -c x "$f" 2>/dev/null); echo "$n"; done'))
  ok('F24 只读探针：单条 $(grep -c … 2>/dev/null) → 放行',
     await pass('n=$(grep -c a /storage/emulated/0/3/工具/记忆/块体检.mjs 2>/dev/null); echo $n'))
  ok('F25 只读探针：双引号里套 $(basename "$f") → 放行',
     await pass('for f in /a; do echo "$(basename "$f")"; done'))
  ok('F26 【对照·绝不能修漏】命令替换里带 2>/dev/null，但命令真写实现文件 → 仍 deny',
     await deny('n=$(date +%s 2>/dev/null); echo hi > /storage/emulated/0/3/桌宠项目/x.js'))
  ok('F27 【对照·绝不能修漏】真写实现文件（无命令替换）→ 仍 deny',
     await deny('echo hi > /storage/emulated/0/3/桌宠项目/x.js'))
  ok('F28 【对照】写 /dev/null 之外的路径 → 仍 deny',
     await deny('echo hi > /storage/emulated/0/3/桌宠项目/y.js 2>/dev/null'))
}


console.log('\n=== H 组：检索质量（bug#4 验收 · 跨词碎片率）===')
{
  /* 判据来自设计稿（qwen3.8-max 出的验收表）：**命中词里的跨词碎片占比 ≤ 10%**。
     「碎片」= 一个 2..5 字 CJK 片段，它**没有出现在库里任何一条已标注 keywords 短语里**
     （如 觉后 / 面我 / 乱七）。词典与闸门内部同源：keywords 的子串闭包。 */
  const dict = new Set()
  const CJK = /^[\u4e00-\u9fa5]{2,5}$/
  const db = new DatabaseSync(MEMDB, { readOnly: true })
  for (const row of db.prepare("select coalesce(keywords,'') as kw from lesson where status='active'").all()) {
    let a = null
    try { a = JSON.parse(row.kw) } catch { a = null }
    if (!Array.isArray(a)) continue
    for (const k of a) {
      const t = String(k || "").trim().toLowerCase()
      const cap = Math.min(5, t.length)
      for (let n = 2; n <= cap; n++) for (let i = 0; i + n <= t.length; i++) { const sub = t.slice(i, i + n); if (CJK.test(sub)) dict.add(sub) }
    }
  }
  db.close()
  ok('H0 词典规模合理（>1000 条合法词）', dict.size > 1000, 'dict=' + dict.size)
  const HID = 'TEST-SID-H'
  const L = mk()
  const cases = [
    ['我们要把开工闸门的记忆检索做出来，内核不能再重复踩坑了，要按流程干活', '// 开工闸门 记忆检索 踩坑', true],
    ['会话日志是多帧 zstd，node 只解第一帧，我踩过两次', '神经/注入计量.mjs', true],
    ['把子进程的命系在父进程上要用看门狗，别只靠退出回调', '桌宠项目/服务.js', true],
    ['乱七八糟的感觉后面我是说这句话本身没有意义', '意识流/没有意义.txt', false],
  ]
  let totalTerms = 0, totalBad = 0, gotRows = 0
  for (let ci = 0; ci < cases.length; ci++) {
    const sid = HID + ci
    await say(L, cases[ci][0], sid)
    const r = await post(L, 'write', { file_path: WS + '/g' + ci + '.js', content: cases[ci][1] }, { isError: false, content: [{ type: 'text', text: 'x' }] }, sid)
    const blk = (r && r.content && r.content[1] && String(r.content[1].text)) || ''
    if (/`0[a-z0-9]{8}`/.test(blk)) gotRows++
    const m = blk.match(/第 1 条的命中词：([^\n]+)/)
    const terms = m ? m[1].split('/').filter((t) => t && t.charAt(0) !== '(') : []
    const bad = terms.filter((t) => !/^[a-z][a-z0-9_+-]{3,}$/.test(t) && !dict.has(t))
    totalTerms += terms.length; totalBad += bad.length
    console.log('    · 用例' + (ci + 1) + ' 命中词 = ' + (terms.join('/') || '(空)') + (bad.length ? '  ⚠️ 碎片: ' + bad.join('/') : ''))
  }
  ok('H1 四条查询至少 3 条真捞到东西（召回没被牺牲）', gotRows >= 3, 'gotRows=' + gotRows)
  ok('H2 命中词里跨词碎片占比 ≤ 10%', totalTerms > 0 && totalBad / totalTerms <= 0.1, totalBad + '/' + totalTerms)
}
console.log('\n=== I 组：收手门（v3.1 · 第 3 批第二段）===')
{
  const HMOD = '/storage/emulated/0/3/工具/收手门/收手门.mjs'
  const H = await import(HMOD)
  const LED = WS + '/台账/在办.md'
  const DB = WS + '/工具/收手门/收手.db'
  mkdirSync(WS + '/台账', { recursive: true }); mkdirSync(WS + '/工具/收手门', { recursive: true })
  for (const f of [DB, DB + '-wal', DB + '-shm']) rmSync(f, { force: true })
  const HDR = '| 日期 | 事项 | 状态 | 干到哪 | 下一步 |'
  const SEP = '|---|---|---|---|---|'
  const LEG = '| 09-18 | 存量已完成的一件活 | ✅ 已生效 | 老账 | 无 |'
  const WIP = '| 09-18 | 正在干的一件活 | 🟡 干活中 | 一半 | 继续 |'
  const SUB = '| 09-19 | 刚交上去的一件活 | ⏳ **待审** | 做完了等他勾 | 等他勾 |'
  const DON = '| 09-19 | 刚交上去的一件活 | ✅ **已生效** | 做完了 | 无 |'
  const write = (lines) => writeFileSync(LED, [HDR, SEP].concat(lines).join('\n'))
  write([LEG, WIP])
  const CFG = { handoffModule: HMOD, handoffDb: DB, ledger: LED }
  const L = mk(CFG)
  const st = H.openStore(DB)
  const state = (t) => (st.get(H.keyOf(t)) || {}).state

  ok('I0 启动即迁移：存量 ✅ 行已入账 done', state('存量已完成的一件活') === 'done', JSON.stringify(state('存量已完成的一件活')))
  ok('I0b 存量的来源标成 legacy-migration（他能区分"上线前的老账"）',
    (st.get(H.keyOf('存量已完成的一件活')) || {}).by === 'legacy-migration')

  const heredoc = (lines) => 'cat > ' + LED + " <<'EOF'\n" + [HDR, SEP].concat(lines).join('\n') + '\nEOF'
  const r1 = await pre(L, 'bash', { command: heredoc([LEG, WIP, SUB]) })
  ok('I1 【代码路径 1：bash heredoc】交到「⏳ 待审」⇒ 放行', r1.kind === 'allow', JSON.stringify(r1).slice(0, 90))
  write([LEG, WIP, SUB])
  ok('I1b 闸门当场把它登记成 in_review（真查库）', state('刚交上去的一件活') === 'in_review')

  const r2 = await pre(L, 'bash', { command: heredoc([LEG, WIP, DON]) })
  ok('I2 没勾就写「✅ 已生效」⇒ 拒', r2.kind === 'deny', JSON.stringify(r2).slice(0, 90))
  const reason = String(r2.reason || '')
  ok('I3 拒文含【收手门】', reason.includes('【收手门】'))
  ok('I3b 拒文报真值（现状态=待审 + 谁交的）', reason.includes('待审') && reason.includes('TEST-SID'))
  ok('I3c 拒文给了他要跑的那一行 + 短 key',
    reason.includes('收手门.mjs 勾 ' + H.shortKey(H.keyOf('刚交上去的一件活'))))

  st.accept(H.keyOf('刚交上去的一件活'), '刚交上去的一件活', '老板', '测试：他勾了')
  const r3 = await pre(L, 'bash', { command: heredoc([LEG, WIP, DON]) })
  ok('I4 他勾过之后同一行 ⇒ 放行（门是通的，不是墙）', r3.kind === 'allow', JSON.stringify(r3).slice(0, 90))

  const r4 = await pre(L, 'bash', { command: 'node /storage/emulated/0/3/工具/收手门/收手门.mjs 勾 --all' })
  ok('I5 模型跑「勾」⇒ 拒（人侧开关）', r4.kind === 'deny' && String(r4.reason).includes('人侧开关'))
  const r5 = await pre(L, 'bash', { command: 'node /storage/emulated/0/3/工具/收手门/收手门.mjs 退 3f2a1b' })
  ok('I6 模型跑「退」⇒ 拒（人侧开关）', r5.kind === 'deny')
  const r6 = await pre(L, 'bash', { command: 'node /storage/emulated/0/3/工具/收手门/收手门.mjs 查 --all' })
  ok('I7 模型跑「查」（只读）⇒ 放行', r6.kind === 'allow')
  const r7 = await pre(L, 'bash', { command: 'echo x > ' + DB })
  ok('I8 工具直写账本文件 ⇒ 拒', r7.kind === 'deny' && String(r7.reason).includes('账本'))

  const r8 = await pre(L, 'write', { file_path: LED, content: [HDR, SEP, LEG, WIP, '| 09-19 | 又一个新活 | ✅ 已生效 | x | y |'].join('\n') })
  ok('I9 【代码路径 2：write】新完成行 ⇒ 拒', r8.kind === 'deny')
  const r9 = await pre(L, 'edit', { file_path: LED, old_string: WIP, new_string: '| 09-18 | 悄悄完成的一件活 | ✅ 已生效 | x | y |' })
  ok('I10 【代码路径 3：edit】新完成行 ⇒ 拒', r9.kind === 'deny')
  const r10 = await pre(L, 'edit', { file_path: LED, old_string: WIP, new_string: '| 09-18 | 正在干的一件活 | ⏳ 待审 | 交了 | 等勾 |' })
  ok('I11 【edit】交到待审 ⇒ 放行 + 登记', r10.kind === 'allow' && state('正在干的一件活') === 'in_review')
  const r11 = await pre(L, 'run_node', { code: "const fs=require('fs');fs.writeFileSync('/storage/emulated/0/3/.dsh-kickoff/testws/台账/在办.md','| a | 我用代码写完成 | ✅ 已生效 | b | c |\\n')" })
  ok('I12 【代码路径 4：run_node】代码里写台账完成行 ⇒ 拒', r11.kind === 'deny', JSON.stringify(r11).slice(0, 90))
  const r12 = await pre(L, 'run_python', { code: "open('/storage/emulated/0/3/.dsh-kickoff/testws/台账/在办.md','a').write('| a | py 完成 | ✅ 已生效 | b | c |\\n')" })
  ok('I13 【代码路径 5：run_python】⇒ 拒', r12.kind === 'deny')

  const r13 = await pre(L, 'write', { file_path: LED, content: [HDR, SEP, LEG, WIP, SUB].join('\n') })
  ok('I14 全量重写台账、内容没变 ⇒ 放行（整表重写/搬行不误伤）', r13.kind === 'allow')
  const r14 = await pre(L, 'bash', { command: 'cat ' + LED })
  ok('I15 只读台账 ⇒ 放行', r14.kind === 'allow')
  const r15 = await pre(L, 'bash', { command: heredoc([LEG, WIP, '| 09-19 | 新活 | 🟡 干活中 | 一半 | 继续 |']) })
  ok('I16 新增非完成行 ⇒ 放行', r15.kind === 'allow')
  const r16 = await pre(L, 'bash', { command: 'cat > ' + WS + '/记忆/别的台账.md <<EOF\n| a | b | ✅ 完成 | c | d |\nEOF' })
  ok('I17 别的文件里的 ✅ 行 ⇒ 不管（作用域只在 在办.md）', r16.kind === 'allow', JSON.stringify(r16).slice(0, 60))
  const r17 = await pre(L, 'bash', { command: heredoc(['| 09-18 | 存量已完成的一件活（改了名） | ✅ 已生效 | 老账 | 无 |', WIP]) })
  ok('I18 给已 done 的行改名 ⇒ 判成"新行无 done"⇒ 拒（**已知误伤**，拒文给了补救命令）', r17.kind === 'deny')

  const L2 = mk(Object.assign({}, CFG, { handoff: false }))
  ok('I19 handoff:false ⇒ 写完成放行（一行开关能关掉它）', (await pre(L2, 'bash', { command: heredoc([LEG, WIP, DON]) })).kind === 'allow')
  const L3 = mk(Object.assign({}, CFG, { handoffModule: '/storage/emulated/0/3/工具/收手门/_不存在.mjs' }))
  ok('I20 收手门自己坏了 ⇒ fail-open 放行（新东西坏了不许带坏原有功能）',
    (await pre(L3, 'bash', { command: heredoc([LEG, WIP, DON]) })).kind === 'allow')

  const gateSrc = readFileSync(GATE, 'utf8')
  const iPre = gateSrc.indexOf("ctx.on('tools/pre-execute'")
  const iStampDef = gateSrc.indexOf('const applyHumanStamp')
  const iPreStep = gateSrc.indexOf("ctx.on('agent/pre-step'")
  ok('I21a 工具调用路径（pre-execute 之后）0 处 accept/reject —— 我这一侧仍无「勾」这条路',
    iPre > 0 && gateSrc.slice(iPre).indexOf('.accept(') === -1 && gateSrc.slice(iPre).indexOf('.reject(') === -1)
  // 2026-09-22 改：口令归一（神经/口令.mjs）让**调用点变成 2 处**（原句解析 ＋ 归一后落章），
  //   所以判据从「只许 1 处」改成「**每一处调用都必须落在 agent/pre-step 之后**」—— 仍然只有人侧消息路径能碰
  //   accept/reject，工具路径 0 处由 I21a 守着（改的是接线数，不是放宽那条不变量）。
  const 戳调用位 = [...gateSrc.matchAll(/applyHumanStamp\(/g)].map((m) => m.index)
  ok('I21b 唯一能碰 accept/reject 的 applyHumanStamp：定义在 agent/pre-step 之前，且**每一处调用都在它之后**（人侧路径；0922 起 2 处）',
    iStampDef > 0 && iStampDef < iPreStep && 戳调用位.length >= 1 && 戳调用位.every((i) => i > iPreStep))
  ok('I22 闸门里没有"自动勾完成"的兜底', !/autoAccept/.test(gateSrc))
  st.close()
}
{
  const CLI = '/storage/emulated/0/3/工具/收手门/收手门.mjs'
  // ⚠️ **2026-09-19 修隐患**：原来 DB2 指向**生产账本** `工具/收手门/收手.db`，
  //   而 I24 会跑「不带参数 = 全勾」—— 一旦前面用例没短路，**自测自己就把老板还没验收的行勾掉了**。
  //   ⇒ 自测一律用**临时库**（`openStore` 会自动建表），绝不碰生产账本。
  // ★ 2026-09-22 复跑抓到：固定路径 ⇒ 两个窗同时跑就 `database is locked`（九次里抽一次风，还会传染三条判据）
const DB2 = (process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh') + '/tmp/handoff-selftest-' + process.pid + '.db'
  try { rmSync(DB2, { force: true }) } catch {}
  // ⚠️ 上一步**必须真的删掉**：这个库是固定路径，上一轮跑完那行会留在 `done` 态 ⇒ 再跑时 `交` 变
  //   no-op、`勾` 找不到待审 ⇒ **永久红**（2026-09-19 实测踩到）。本文件是**具名导入**、没有默认 `fs`，
  //   所以只能写 `rmSync` 不是 `fs.rmSync` —— 写错会被 catch 吞掉、**静默不清库**。
  const H = await import(CLI)
  const cli = (...a) => spawnSync('node', [CLI].concat(a, ['--db', DB2]), { encoding: 'utf8' })
  const T = 'CLI 端到端测试用的一行'
  // **2026-09-19 契约变更（老板令「抽不到依据不许进队列」）**：`交` 现在会**拒绝**没有开工卡的行 ⇒
  // 本用例改用**显式降级** `--无卡 <理由>`（那是新契约里唯一的合法出口），
  // 用例本意没变：**验的第一个参数（标题）不被 filter 吞掉**。
  const r1 = cli('交', T, '自测', '--无卡', '回归自测：本行只验 CLI 参数没被吞，不进真验收')
  const st = H.openStore(DB2)
  const row = st.get(H.keyOf(T))
  ok('I23 CLI「交」：标题没被吞（曾因无 --db 时 filter 吞掉第一个参数 —— 真机用出来的 bug）',
    r1.status === 0 && !!row && row.state === 'in_review' && row.title === T, JSON.stringify(row && row.title))
  const r2 = cli('勾')
  const row2 = st.get(H.keyOf(T))
  ok('I24 CLI「勾」不带参数 = 勾掉全部待审（给他的那一行要尽量短）', r2.status === 0 && !!row2 && row2.state === 'done')
  const r3 = cli('查')
  ok('I25 CLI「查」一屏可读：带计数 + 自解释',
    /待审 \d+ ｜ 已勾 \d+/.test(r3.stdout) && /等你勾/.test(r3.stdout))
  st.close()
}
console.log('\n=== J 组：v3.2 阶段 2（开工简报自动投递 + 人话盖章）===')
{
  const HMOD = '/storage/emulated/0/3/工具/收手门/收手门.mjs'
  const H = await import(HMOD)
  const LED = WS + '/台账/在办.md'
  const DB = WS + '/工具/收手门/收手.db'
  mkdirSync(WS + '/台账', { recursive: true }); mkdirSync(WS + '/工具/收手门', { recursive: true })
  const HDR = '| 日期 | 事项 | 状态 | 干到哪 | 下一步 |'
  const SEP = '|---|---|---|---|---|'
  const R = (n) => '| 09-19 | ' + n + ' | ⏳ **待审** | 做完 | 等他勾 |'
  const reset = (rows) => {
    for (const x of [DB, DB + '-wal', DB + '-shm']) rmSync(x, { force: true })
    writeFileSync(LED, [HDR, SEP].concat(rows).join('\n'))
    const L = mk({ handoffModule: HMOD, handoffDb: DB, ledger: LED })
    const st = H.openStore(DB)
    for (const r of rows) { const t = String(r).split('|')[2].trim(); st.submit(H.keyOf(t), t, 'cli-test', '测试用：登记为待审') }
    return { L, st }
  }
  const stOf = (st, t) => { const r = st.get(H.keyOf(t)); return r ? r.state : '(无)' }

  { const { L, st } = reset([R('甲件')])
    await say(L, '勾')
    const r = st.get(H.keyOf('甲件'))
    ok('J1 他的原话「勾」⇒ 账本 done（人侧通道盖章）', r && r.state === 'done', JSON.stringify(r && r.state))
    ok('J1b 盖章人记成「老板」+ hist 留了他的原话', r && r.by === '老板' && String(r.hist).includes('他原话'), JSON.stringify(r && { by: r.by, hist: String(r.hist).slice(-40) }))
    st.close() }

  { const { L, st } = reset([R('甲件')])
    await say(L, '勾是什么意思？')
    ok('J2 带问号的「勾是什么意思？」**不算**盖章（fail-closed）', stOf(st, '甲件') === 'in_review', stOf(st, '甲件'))
    await say(L, '通过 不存在的词')
    ok('J3 指不到对象 ⇒ 不动账本（只记 HUMAN-SKIP）', stOf(st, '甲件') === 'in_review', stOf(st, '甲件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '勾')
    ok('J4 两件待审 + 只说「勾」⇒ **全勾**（2026-09-19 改：与 CLI「勾 不带参数＝全勾」对齐；旧语义「不敢猜」当场让老板的一个字失效）', stOf(st, '甲件') === 'done' && stOf(st, '乙件') === 'done', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '勾 乙件')
    ok('J5 点名叫「乙件」⇒ 只勾乙件，甲件不动', stOf(st, '乙件') === 'done' && stOf(st, '甲件') === 'in_review', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '验收通过')
    ok('J11 他说「验收通过」（动词不在行首）⇒ 全勾', stOf(st, '甲件') === 'done' && stOf(st, '乙件') === 'done', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '这个勾我打得对吗')
    ok('J12 动词不在行首且后面还有字 ⇒ 不认（fail-closed，不许瞎猜）', stOf(st, '甲件') === 'in_review' && stOf(st, '乙件') === 'in_review', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, 'ok重启完成 勾')
    ok('J13 **动词在行尾的整句**（老板真实原话「ok重启完成 勾」）⇒ 全勾', stOf(st, '甲件') === 'done' && stOf(st, '乙件') === 'done', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '甲件勾')
    ok('J14 动词在行尾 + 前面那串正好是某行的名字 ⇒ 只勾那一条', stOf(st, '甲件') === 'done' && stOf(st, '乙件') === 'in_review', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '先别勾')
    ok('J15 **反向句不许触发**：「先别勾」⇒ 一件都不勾（修前行尾规则会把 5 件全勾掉，方向正好相反）', stOf(st, '甲件') === 'in_review' && stOf(st, '乙件') === 'in_review', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '这个还没验收通过')
    ok('J16 反向句之二：「这个还没验收通过」⇒ 不勾（含「有没有问题，验收通过」这类正常句仍须能勾，见 J11）', stOf(st, '甲件') === 'in_review' && stOf(st, '乙件') === 'in_review', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '都没问题，验收通过')
    ok('J17 正常句带「没」但被逗号隔开 ⇒ **仍然全勾**（护栏不能误伤）', stOf(st, '甲件') === 'done' && stOf(st, '乙件') === 'done', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  // ★ 2026-09-22 老板当场撞出来的真 bug（闸门日志 129743）：他真实原话 **67 字**，行首那个「验收通过」被整行拖死了。
  //   ⇒ 下面 1 条正证 + 4 条反证。放宽的**只有**「整行太长／整行里根本没动词」这两处；判据是
  //   「整条里**恰好一个**子句本身就是纯动词短语」——子句里多一个字都不认，多一个动词子句就不猜。
  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '验收通过，其次，把药我觉得那一个调到我现现在的那个上来，你要到时候如果以后有这种情况的话，你直接给我，不然的话，我每次到回头去翻很麻烦')
    ok('J18 **老板的真实长句**（行首「验收通过」+ 后面一大串）⇒ 全勾（修前：HUMAN-NOTE 整行太长 ⇒ 一件都没勾，且界面上看不出）',
      stOf(st, '甲件') === 'done' && stOf(st, '乙件') === 'done', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '这个还没验收通过，你再看看，别急着勾')
    ok('J19 反证①：长句里**没有**纯动词子句（动词被别的字裹着）⇒ 一件都不勾', stOf(st, '甲件') === 'in_review' && stOf(st, '乙件') === 'in_review', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '验收通过，全部通过，都勾了，顺便我还要跟你说一下后面那几件事你得再仔细看看再定下来，不然我心里没底，而且我还想把那个裁决的东西重新拿过来再看一遍才行')
    ok('J20 反证②：长句里**多个**纯动词子句 ⇒ 不猜（fail-closed）', stOf(st, '甲件') === 'in_review' && stOf(st, '乙件') === 'in_review', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '验收通过？我先看看这段再定')
    ok('J21 反证③：长句含问号 ⇒ 一件都不勾', stOf(st, '甲件') === 'in_review' && stOf(st, '乙件') === 'in_review', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件'), R('乙件')])
    await say(L, '我觉得可以验收通过了，你再确认一下这一块到底行不行')
    ok('J22 反证④：动词裹在句子里（不是独立子句）⇒ 一件都不勾', stOf(st, '甲件') === 'in_review' && stOf(st, '乙件') === 'in_review', stOf(st, '甲件') + '/' + stOf(st, '乙件'))
    st.close() }

  { const { L, st } = reset([R('甲件')])
    await say(L, '退回 甲件')
    ok('J6 他说「退回 甲件」⇒ 账本 rejected', stOf(st, '甲件') === 'rejected', stOf(st, '甲件'))
    st.close() }

  { const { L } = reset([R('甲件')])
    const r1 = await pre(L, 'bash', { command: 'cd /storage/emulated/0/3 && node 工具/收手门/收手门.mjs 勾' })
    ok('J7 回归：**工具调用**里的「勾」仍被拒（门还在）', r1.kind === 'deny', JSON.stringify(r1).slice(0, 60))
  }

  { const L6 = mk({ workspace: '/storage/emulated/0/3', handoffModule: HMOD, handoffDb: DB, ledger: LED, retrieve: false })
    const p1 = await post(L6, 'read', { file_path: '/storage/emulated/0/3/AGENTS.md' }, { isError: false, content: [{ type: 'text', text: '(工具输出)' }] }, 'SID-BRIEF-1')
    const t1 = JSON.stringify(p1)
    ok('J8 新会话第一次工具结果里**自动投递**了开工简报', t1.includes('开工简报'), t1.slice(0, 80))
    const p2 = await post(L6, 'read', { file_path: '/storage/emulated/0/3/AGENTS.md' }, { isError: false, content: [{ type: 'text', text: '(工具输出)' }] }, 'SID-BRIEF-1')
    ok('J9 同会话第二次**不重复**投递（省 token）', !JSON.stringify(p2).includes('开工简报'), JSON.stringify(p2).slice(0, 60))
    const p3 = await post(L6, 'read', { file_path: '/storage/emulated/0/3/AGENTS.md' }, { isError: false, content: [{ type: 'text', text: '(工具输出)' }] }, 'SID-BRIEF-2')
    ok('J10 换一个新会话 ⇒ 重新投递', JSON.stringify(p3).includes('开工简报'))
  }
}
console.log('\n=== K 组：v3.3 挂点状态行（调度器接线 · 正证＋反证）===')
const REALWS = '/storage/emulated/0/3'
const postR = (L, name, args, sid) => L['tools/post-execute'][0](
  { name, arguments: args, agent: { id: sid || 'K-SID' } },
  { content: [{ type: 'text', text: '工具输出' }] },
  () => Promise.resolve({ kind: 'accept', content: [{ type: 'text', text: '工具输出' }] }))
const txtOf = (r) => (r && Array.isArray(r.content) ? r.content.map((x) => (x && x.text) || '').join('\n') : '')

// K1 正证：真 workspace ⇒ 工具结果里必须**多出**状态行
const LK = mk({ workspace: REALWS })
const rK1 = await postR(LK, 'bash', { command: 'node /storage/emulated/0/3/工具/开工/库.mjs' })
ok('K1 正证：工具结果里带「〔本轮」状态行', /〔本轮/.test(txtOf(rK1)), txtOf(rK1).slice(0, 140))

// K2 反证：调度器读不到（假 workspace）⇒ 状态行必须**消失**（fail-open，不是无脑加）
// brief/retrieve/handoff 关掉：它们会在假 workspace 上 spawn 简报 ⇒ 刷崩溃栈（那是**已知未决**的第 3 件，别混进这里）
const LBAD = mk({ workspace: WS + '/不存在', brief: false, retrieve: false, handoff: false })
const rK2 = await postR(LBAD, 'bash', { command: 'x' })
ok('K2 反证：调度器读不到 ⇒ 状态行消失（证明它不是永远加）', !/〔本轮/.test(txtOf(rK2)), txtOf(rK2).slice(0, 80))

// K3 必然性：同一会话连喂 5 次 ⇒ **每一次**都带（这才是「下意识」）
let kAll = true
for (let i = 0; i < 5; i++) { const rr = await postR(LK, 'bash', { command: 'echo ' + i }); if (!/〔本轮/.test(txtOf(rr))) kAll = false }
ok('K3 必然性：连续 5 次调用每次都带（不是只第一次）', kAll)

// ★ K4/K5 契约变更 2026-09-27（整检 Q1）：老板 09-27 纠正「闸门是拿来让你做一次性干不完的活、
// 容易被压死的活，你拿来给自己上压力干嘛呢？」=> 阈值由 12/20 提到 40/80。
// 原判据**写死 13 步/21 步**，阈值一动它就假红（这已经是第二次）=> 改根：**从 调度.mjs 源码读真阈值再驱动**，
// 阈值以后再变也不会过期。且 09-27 判据又加了条件：**三条同时满足才出声** ——
//   ① 重活（本轮出现写文件/写代码/改配置）② 本段确实还有活 ③ 步数越线。
//   => 驱动命令必须**长得像重活**（带 .mjs），否则它永远不出声（那才是假绿）。
// 两条要求：① 未越线 ⇒ 不许上压力 ② 越线 ⇒ 只能说「拆轮」，不许说「停」（老板 09-19 原令保留）。
const 调度源 = readFileSync(REALWS + '/神经/调度.mjs', 'utf8')
const 锤 = 调度源.match(/warnAt\s*=\s*(\d+)\s*,\s*costAt\s*=\s*(\d+)/)
const WARN = 锤 ? Number(锤[1]) : 40, COST = 锤 ? Number(锤[2]) : 80
ok('读得到调度器真阈值（读不到=下面两条是空的）', !!锤, 锤 ? ('warnAt=' + WARN + ' / costAt=' + COST) : '调度.mjs 里找不到 warnAt/costAt')

// 同一个门实例、同一个会话：步数靠累加（老版就是靠这个数到 21 的）
const LK4 = mk({ workspace: REALWS })
const 重活命令 = { command: 'node 神经/步数表.mjs --自测' }
let rK4 = null
for (let i = 0; i < WARN - 1; i++) rK4 = await postR(LK4, 'bash', 重活命令)
const tK4 = txtOf(rK4)
ok('K4 ' + (WARN - 1) + ' 步（未越线）⇒ 不上压力：不说「拆轮」「下一轮拆开做」「停」',
  !/拆轮|下一轮拆开做|停下|停顿|停止/.test(tK4), (tK4.match(/〔本轮[^〕]*〕/) || ['(无状态行)'])[0])

let rK5 = null
for (let i = WARN - 1; i < COST + 1; i++) rK5 = await postR(LK4, 'bash', 重活命令)
const tK5 = txtOf(rK5)
ok('K5 ' + (COST + 1) + ' 步（越线）⇒ 只能说「拆轮」不说「停」',
  /拆轮/.test(tK5) && !/停下|停顿|停止/.test(tK5),
  (tK5.match(/［内部判据[^］]*］[^\n]*/) || tK5.match(/〔本轮[^〕]*〕/) || ['(无状态行)'])[0])

// K6 状态行要能指出**漏项**（不是一句空话）
ok('K6 状态行里带得出「漏：…」', /漏：/.test(txtOf(rK1)), txtOf(rK1).slice(0, 140))

console.log('\n=== L 组：v3.4 第二步三件（依据页 / 简报静默 / 收尾记账）===')
// L1 依据页（静态）：submit(key,title,by,note,**spec**) 五格原来只传 4 个 ⇒ spec 恒空 ⇒ 队列行永远「没依据」
const srcP = readFileSync(GATE, 'utf8')
ok('L1 依据页：submit 调用带满 5 个参数（曾经只传 4 ⇒ 检查可被绕过）',
  /HStore\.submit\(s\.key, s\.title, sid, String\(s\.status\)[\s\S]{0,200}?specTxt\)/.test(srcP))
ok('L1b 依据页：卡不在时也要写「（无开工卡…）」而不是空着（空＝miss）', /无开工卡：本会话没出卡/.test(srcP))

// L3 收尾记账（动态）：turn-stopping 从 0 处监听 → 触发后账本里出现本会话条目
const TMPLEDGER = '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh/tmp/记账-自测-' + process.pid + '.json'
try { rmSync(TMPLEDGER, { force: true }) } catch (e) {}   // 干净起点
const AUTO = TMPLEDGER   // ★ 隔离：自测写临时账本，**绝不碰生产**（见插件 cfg.paceLedger）
const LT = mk({ workspace: REALWS, brief: false, retrieve: false, paceLedger: TMPLEDGER })
const SIDT = 'L-STOP-TEST-1'
const tsH = LT['agent/turn-stopping'] || []
ok('L3a turn-stopping 已被监听（原来 0 处）', tsH.length > 0, '监听器数=' + tsH.length)
await postR(LT, 'bash', { command: 'node /storage/emulated/0/3/工具/开工/库.mjs' }, SIDT)
if (tsH.length) await tsH[0]({ agent: { id: SIDT }, turn: 3 })
let after = {}
try { after = JSON.parse(readFileSync(AUTO, 'utf8')) } catch (e) { after = {} }
const row = after[SIDT] || null
ok('L3b 收尾后账本里出现本会话条目（步数 > 0）', !!(row && row.steps > 0), JSON.stringify(row).slice(0, 130))
ok('L3c 条目里带「走到哪一段 + 漏了什么」，不只是步数', !!(row && row.seg), row ? ('段=' + row.seg + ' 漏=' + (row.misses || []).join('、')) : '无')
// L4 反证：workspace 坏掉 ⇒ 必须 fail-open（不炸、不写）
const LBAD2 = mk({ workspace: WS + '/不存在', brief: false, retrieve: false, handoff: false })
let l4ok = false
try { await (LBAD2['agent/turn-stopping'] || [async () => {}])[0]({ agent: { id: 'L-BAD' }, turn: 1 }); l4ok = true } catch (e) { l4ok = false }
ok('L4 反证：收尾时 workspace 坏掉 ⇒ fail-open 不炸', l4ok)

console.log('\n=== 结果 ===')
console.log(fail === 0 ? `全绿：${pass}/${pass + fail}` : `通过 ${pass} / 失败 ${fail}`)
console.log('\n=== 定样：真实检索输出（贴给你看的就是这段）===')
console.log(blockText || '(本次没生成)')
process.exit(fail === 0 ? 0 : 1)
