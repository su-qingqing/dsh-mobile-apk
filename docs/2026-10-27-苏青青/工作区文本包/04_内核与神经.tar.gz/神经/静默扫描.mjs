#!/usr/bin/env node
/**
 * 静默扫描（1006 · 老板令「按2走，然后扫描全工作区」）
 *
 * 治什么：`catch {}` 把**真错**当成**预期失败**吞掉 ⇒ 整表跳过 / 整段丢失，而外面看不出来。
 * 血案：`去重审计.mjs:48` 写死列名含 project，而 soul/user 两张表没有 project 列 ⇒ prepare 抛错
 *      被 `catch { continue }` 吞掉 ⇒ 两张表静默跳过（漏 74 条，含最要紧的 user 表），还让报出的数字看着像真的。
 *
 * 用法：
 *   node 神经/静默扫描.mjs            # 扫全工作区，出清单
 *   node 神经/静默扫描.mjs --全       # 连无害类一起列
 *   node 神经/静默扫描.mjs selftest   # 自证（造一个已知有害样本，看它报不报）
 *
 * 只读。判据两条：
 *   ① 【静默吞】catch 后面直接 `{}` / `{ continue }` / `{ return }`，**错误变量都不接**
 *   ② 【写死列】`select <列举的栏名> from`（不是 `select *`）—— 缺任何一栏就整表跳过
 * 分类：**无害**（清理临时件／读可选配置／文件可能不存在）｜**要查**（取数、SQL、读关键文件）
 */
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs'
import { join, relative } from 'node:path'

const 根 = '/storage/emulated/0/3'
const 扫的目录 = ['工具', '桌宠项目', '记忆'].map(d => join(根, d)).filter(existsSync)
const 只看全 = process.argv.includes('--全')

// 「无害」的判据词：这些操作失败是预期之内的
const 无害词 = [/rmSync/, /unlink/, /rm\(/, /JSON\.parse/, /existsSync/, /statSync/, /mkdirSync/, /chmod/, /kill/, /writeFileSync.*tmp/i]

function 走(dir, 出 = []) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    if (e.name === 'node_modules' || e.name.startsWith('.git')) continue
    if (e.name === '_tmp' || e.name.startsWith('_tmp_') || e.name === '调研' || e.name.endsWith('.bak')) continue
    if (e.name === 'dsh-mobile-apk' || e.name === 'dist' || e.name === 'build') continue
    const p = join(dir, e.name)
    if (e.isDirectory()) 走(p, 出)
    else if (e.name.endsWith('.mjs') || e.name.endsWith('.js')) 出.push(p)
  }
  return 出
}

function 扫文件(p) {
  let 文
  try { 文 = readFileSync(p, 'utf8') } catch (e) { return { 跳过: p + '（' + e.message + '）', 命中: [] } }
  const 行 = 文.split('\n')
  const 命中 = []
  for (let i = 0; i < 行.length; i++) {
    const L = 行[i]
    // ① 静默吞
    if (/catch\s*(\([^)]*\))?\s*\{\s*(continue|return|break)?\s*\}/.test(L)) {
      const 上下文 = (行[i - 1] || '') + L
      // ★ 1008 改根（治「尺子自己错」第 8 次）：**判 catch 是不是沉默吞**，不是判「前面是什么操作」。
      //   若 catch 体里明确 return／continue（＝书写者已表态「失败就不做」）⇒ 那是预期内，归无害；
      //   只有 catch 体是**空的**、或吞掉之后还接着用，才是「坏了没人知道」。
      const 明确退出 = /catch\s*\{[^}]*\b(return|continue)\b/.test(上下文)
      const 无害 = 明确退出 || 无害词.some(r => r.test(上下文))
      命中.push({ 行: i + 1, 种: '静默吞', 类: 无害 ? '无害' : '要查', 文: L.trim().slice(0, 130) })
    }
    // ② 写死列名取数
    const m = L.match(/select\s+(?!\*)([a-z_,\s]+?)\s+from\s/i)
    if (m && /prepare|db\.|sql/i.test(L)) {
      命中.push({ 行: i + 1, 种: '写死列', 类: '要查', 文: L.trim().slice(0, 130) })
    }
  }
  return { 跳过: null, 命中 }
}

if (process.argv[2] === 'selftest') {
  const 样本 = `/storage/emulated/0/3/_tmp_静默样本-${Date.now()}.mjs`
  const fs = await import('node:fs')
  fs.writeFileSync(样本, `const db=null\nfor(const t of ['a','b']){ let r=[]; try{ r=db.prepare('select id,name from '+t).all() }catch{ continue } }\n`)
  const 出 = 扫文件(样本)
  fs.unlinkSync(样本)
  const 有静默 = 出.命中.some(x => x.种 === '静默吞')
  const 有列 = 出.命中.some(x => x.种 === '写死列')
  console.log('── selftest ──')
  console.log('  造样本：一处 catch{continue} ＋ 一处 select 写死列名')
  console.log('  报静默吞：' + (有静默 ? '✅ 抓到' : '❌ 漏了'))
  console.log('  报写死列：' + (有列 ? '✅ 抓到' : '❌ 漏了'))
  // ★ 1008 改根：再加**假红对照** —— 官方写法（失败就 return/continue）必须判「无害」；
  //   它若报「要查」，说明尺子在造红，扫描结果不可信（治「尺子自己错」第 8 次）。
  const 样本2 = `/storage/emulated/0/3/_tmp_静默样本-绿-${Date.now()}.mjs`
  fs.writeFileSync(样本2, `let a=[]\ntry{ a=fs.readdirSync('/nope') }catch{ return }\nfor(const c of ['x']){ try{ x=1 }catch{ continue } }\n`)
  const 出2 = 扫文件(样本2)
  fs.unlinkSync(样本2)
  const 假红 = 出2.命中.filter(x => x.类 === '要查').length
  console.log('  假红对照（官方写法该判绿）：' + (假红 === 0 ? '✅ 没造红' : '❌ 造了 ' + 假红 + ' 处假红'))
  console.log(有静默 && 有列 && 假红 === 0 ? '  ⇒ 3/3 通过' : '  ⇒ 没过，别信它的扫描结果')
  process.exit(有静默 && 有列 && 假红 === 0 ? 0 : 1)
}

// ── 真扫 ──
const 文件 = []
for (const d of 扫的目录) 走(d, 文件)
let 静默总 = 0, 列总 = 0, 要查 = [], 无害数 = 0, 跳过 = []
console.log('── 静默扫描（工作区 · 只读）──')
console.log('扫了 ' + 扫的目录.length + ' 个目录 ／ **' + 文件.length + ' 个文件**')
for (const p of 文件) {
  const r = 扫文件(p)
  if (r.跳过) { 跳过.push(r.跳过); continue }
  for (const x of r.命中) {
    if (x.种 === '静默吞') 静默总++
    else 列总++
    if (x.类 === '要查') 要查.push({ p: relative(根, p), ...x })
    else 无害数++
  }
}
console.log('命中：**静默吞 ' + 静默总 + ' 处** ／ **写死列 ' + 列总 + ' 处** （无害类 ' + 无害数 + ' 处已折叠）')
if (跳过.length) console.log('⚠️ ' + 跳过.length + ' 个文件读不到：' + 跳过.slice(0, 3).join(' / '))
console.log()
console.log('══ 【要查】' + 要查.length + ' 处（这些失败不在预期内，吞掉就是丢数据）══')
const 按文件 = new Map()
for (const x of 要查) { if (!按文件.has(x.p)) 按文件.set(x.p, []); 按文件.get(x.p).push(x) }
for (const [p, xs] of [...按文件.entries()].sort((a, b) => b[1].length - a[1].length)) {
  console.log('  ' + p + '  （' + xs.length + ' 处）')
  for (const x of xs.slice(0, 只看全 ? 99 : 3)) console.log('     :' + x.行 + '  [' + x.种 + ']  ' + x.文)
  if (!只看全 && xs.length > 3) console.log('     …… 还有 ' + (xs.length - 3) + ' 处（--全 看全部）')
}
console.log()
console.log('（口径：一行算一处；只抓「catch 里连错误变量都不接」这一种；写死列只抓 select 那一种。）')
