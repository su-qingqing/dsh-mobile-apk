// 预埋针 v1 · 2026-09-28 立（老板令：「那个**自动注入预埋针**这些没有吗？去把另外一件事情给做掉」）
// ═══════════════════════════════════════════════════════════════════════════
// 判据一句话：**该每轮／每窗自动到场的「针」，现在都在它该在的挂点上吗。**
//
// 【为什么要有它】`台账/接续/交接单_0926夜钩子重挂.md:71` 人读结论 ——
//   老板点的九样里，**唯一"真无动作"的只剩「预埋针」**（动作集 39 条里没有它）。
//   ⚠️ 钩子体检 v2 印的「预埋针 只引了法源」是**假红**：它的正则 /预埋|针/ 命中了
//   C08 原话里的「**针对**我们的任务」（单字匹配的经典假红）。
//   ⇒ 本器就是补上**那条缺的真动作＋门**：不数写了几条，只核**挂点在不在**。
//
// 【预埋针是什么】＝ 那些"不靠我记得、每轮必到"的东西：
//   报告格式四件套／主体优先／资产／成本红线／口令·离场／打样六格。
//   漏预埋的后果 ＝ 换窗即忘（内核 #51：摆出来 ≠ 拦得住）。
//
// 用法：node 神经/预埋针.mjs [核]
import fs from 'node:fs';
import { execFileSync } from 'node:child_process';

const W = '/storage/emulated/0/3';
const H = process.env.DSH_HOME || '/data/user/0/com.dsharnessmobile.shell/files/home/.dsh';
const rd = p => { try { return fs.readFileSync(p, 'utf8'); } catch { return ''; } };
const 有 = p => { try { return fs.statSync(p).isFile(); } catch { return false; } };

const PINS = rd(`${W}/工具/开工/必读卡.mjs`);   // 机器面：每轮渲染
const RED  = rd(`${H}/AGENTS.md`);              // 红线本：每会话注入

// 该预埋的针：名字 · 该在哪几处挂点 · 每处要能看见的词
const 针 = [
  { n: '① 报告格式四件套', 挂: [
      // 1007 夜改判据：pins 的写法已从「四件套」改成「7 格」（报告老板/★+两段式/诚实边界/先查已有的/喊停邀请/落款）⇒ 照**现在的本尊**列全 6 格（旧串 ★标重要程度／苏青青 已不在 pins 里，是判据留在旧口径上）
      ['pins',   ['报告老板','两段式','诚实边界','先查已有的','喊停邀请','落款'].every(s => PINS.includes(s))],
      ['红线本', RED.includes('报告格式') || RED.includes('报告老板')]] },
  { n: '② 主体优先（工具不许比主体大）', 挂: [['pins', PINS.includes('主体优先')]] },
  { n: '③ 资产（内核 #59）', 挂: [
      ['pins', PINS.includes('资产') && PINS.includes('新窗说不出它')],
      ['本尊', 有(`${W}/内核/资产.md`)]] },
  { n: '④ 成本红线（¥0.05/步）', 挂: [
      ['红线本', RED.includes('0.05')],
      ['pins',   PINS.includes('0.05')]] },
  { n: '⑤ 口令·离场', 挂: [
      ['pins', PINS.includes('离场')],
      ['本尊', 有(`${W}/工具/开工/离场.mjs`)]] },
];

// ⑥ 打样六格：跑库一屏，看该印的格子在不在（真值现算，不背数字）
let 库出 = '', 库错 = '';
try { 库出 = execFileSync('node', [`${W}/工具/开工/库.mjs`], { encoding: 'utf8', timeout: 120000 }); }
catch (e) { 库错 = String(e.message || e).slice(0, 80); }
const 格子 = ['动作集', '轮末', '报告格式'];
针.push({ n: '⑥ 打样六格（库一屏直印）', 挂: [['库一屏', 库错 ? false : 格子.every(k => 库出.includes(k))]] });

// ⑦ 已投产自证（1001 立 · 照 `台账/体检/1001-架构体检/D-犯错到红线链路.md` 第 13 行的修法）——
//   病：**声称"已投产"的件，其实没人调用**（实证：`工具/流程/出发表_接线.mjs` 纸面在、令账标已投产、
//   而 `grep 出发表 …/dsh-kickoff-gate/lib/index.js` **0 命中** ⇒ 死件）。
//   判据只认一句话：**到声称的落点里找它的名字**（"文件在盘上"不算数）。
//   声明表 `神经/投产声明.json`：谁声称投产，就加一行（件／落点／词）。
const 声明表 = (() => { try { return JSON.parse(rd(`${W}/神经/投产声明.json`)).claims || []; } catch { return null; } })();
if (声明表 === null) {
  针.push({ n: '⑦ 已投产自证', 挂: [['声明表可读', false]] });
} else if (声明表.length) {
  针.push({
    n: '⑦ 已投产自证（声称＝真接线）',
    挂: 声明表.map((c) => {
      const 落点 = String(c.落点 || '').replace('$DSH_HOME', H);
      const 文 = rd(落点);
      return [String(c.件 || '?').split('/').pop(), 文.length > 0 && 文.includes(String(c.词 || ''))];
    }),
  });
}

console.log('══ 预埋针 v1 · 该自动到场的针，都在挂点上吗 ══');
let 绿 = 0, 红 = 0;
for (const p of 针) {
  const 缺 = p.挂.filter(([, ok]) => !ok).map(([k]) => k);
  const ok = 缺.length === 0;
  ok ? 绿++ : 红++;
  console.log(`  ${ok ? '✅' : '❌'} ${p.n}　${p.挂.map(([k, o]) => `${k} ${o ? '✓' : '✗'}`).join(' ｜ ')}`
    + (ok ? '' : `　← 缺：${缺.join('、')}`));
}
if (库错) console.log(`     （库一屏没跑成：${库错}）`);
console.log('  ──');
console.log(`  ${针.length} 根针：${绿} 绿 / ${红} 红 ⇒ ${红 ? '❌ **缺哪格修哪格（别重做）**' : '✅ 全部到场（换窗即忘的病根＝预埋，这条现在有门了）'}`);
process.exit(红 ? 1 : 0);
